.class public Lcom/android/mms/MmsApp;
.super Landroid/app/Application;
.source "MmsApp.java"


# static fields
.field public static final LOG_TAG:Ljava/lang/String; = "Mms"

.field public static hasPermissionRelated:Z

.field private static sMmsApp:Lcom/android/mms/MmsApp;


# instance fields
.field private mCountryDetector:Landroid/location/CountryDetector;

.field private mCountryIso:Ljava/lang/String;

.field private mCountryListener:Landroid/location/CountryListener;

.field private mDrmManagerClient:Landroid/drm/DrmManagerClient;

.field private mMmsSystemEventReceiver:Lcom/android/mms/transaction/MmsSystemEventReceiver;

.field private mNotificationActionHandleReceiver:Lcom/android/mms/ui/NotificationActionHandleReceiver;

.field private mPduLoaderManager:Lcom/android/mms/util/PduLoaderManager;

.field private mRecentSuggestions:Landroid/provider/SearchRecentSuggestions;

.field private mSimFullReceiver:Lcom/android/mms/transaction/SimFullReceiver;

.field private mSmsRejectedReceiver:Lcom/android/mms/transaction/SmsRejectedReceiver;

.field private mSmsStorageMonitor:Lcom/android/mms/ui/SmsStorageMonitor;

.field private mTelephonyManager:Landroid/telephony/TelephonyManager;

.field private mThumbnailManager:Lcom/android/mms/util/ThumbnailManager;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 64
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    .line 77
    new-instance v0, Lcom/android/mms/ui/SmsStorageMonitor;

    invoke-direct {v0}, Lcom/android/mms/ui/SmsStorageMonitor;-><init>()V

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mSmsStorageMonitor:Lcom/android/mms/ui/SmsStorageMonitor;

    .line 78
    new-instance v0, Lcom/android/mms/transaction/MmsSystemEventReceiver;

    invoke-direct {v0}, Lcom/android/mms/transaction/MmsSystemEventReceiver;-><init>()V

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mMmsSystemEventReceiver:Lcom/android/mms/transaction/MmsSystemEventReceiver;

    .line 79
    new-instance v0, Lcom/android/mms/transaction/SimFullReceiver;

    invoke-direct {v0}, Lcom/android/mms/transaction/SimFullReceiver;-><init>()V

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mSimFullReceiver:Lcom/android/mms/transaction/SimFullReceiver;

    .line 80
    new-instance v0, Lcom/android/mms/transaction/SmsRejectedReceiver;

    invoke-direct {v0}, Lcom/android/mms/transaction/SmsRejectedReceiver;-><init>()V

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mSmsRejectedReceiver:Lcom/android/mms/transaction/SmsRejectedReceiver;

    .line 81
    new-instance v0, Lcom/android/mms/ui/NotificationActionHandleReceiver;

    invoke-direct {v0}, Lcom/android/mms/ui/NotificationActionHandleReceiver;-><init>()V

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mNotificationActionHandleReceiver:Lcom/android/mms/ui/NotificationActionHandleReceiver;

    return-void
.end method

.method static synthetic access$002(Lcom/android/mms/MmsApp;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 64
    iput-object p1, p0, Lcom/android/mms/MmsApp;->mCountryIso:Ljava/lang/String;

    return-object p1
.end method

.method private activePendingMessages()V
    .locals 4

    .line 197
    invoke-static {p0}, Lcom/android/mms/transaction/MmsSystemEventReceiver;->wakeUpService(Landroid/content/Context;)V

    .line 199
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/transaction/SmsReceiver;

    const-string v2, "com.android.mms.transaction.SEND_INACTIVE_MESSAGE"

    const/4 v3, 0x0

    invoke-direct {v0, v2, v3, p0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/MmsApp;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public static declared-synchronized getApplication()Lcom/android/mms/MmsApp;
    .locals 2

    const-class v0, Lcom/android/mms/MmsApp;

    monitor-enter v0

    .line 206
    :try_start_0
    sget-object v1, Lcom/android/mms/MmsApp;->sMmsApp:Lcom/android/mms/MmsApp;

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-object v1

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method private registerMobileDataObserver()V
    .locals 7

    const-string v0, "phone"

    .line 158
    invoke-virtual {p0, v0}, Lcom/android/mms/MmsApp;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    .line 159
    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getActiveModemCount()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_0

    .line 163
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "mobile_data"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/provider/Settings$Global;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    .line 164
    invoke-virtual {p0}, Lcom/android/mms/MmsApp;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    new-instance v5, Lcom/android/mms/MmsApp$2;

    const/4 v6, 0x0

    invoke-direct {v5, p0, v6}, Lcom/android/mms/MmsApp$2;-><init>(Lcom/android/mms/MmsApp;Landroid/os/Handler;)V

    invoke-virtual {v4, v3, v1, v5}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public getCurrentCountryIso()Ljava/lang/String;
    .locals 1

    .line 269
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mCountryIso:Ljava/lang/String;

    if-nez v0, :cond_0

    .line 270
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mCountryDetector:Landroid/location/CountryDetector;

    invoke-virtual {v0}, Landroid/location/CountryDetector;->detectCountry()Landroid/location/Country;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 272
    invoke-virtual {v0}, Landroid/location/Country;->getCountryIso()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mCountryIso:Ljava/lang/String;

    .line 275
    :cond_0
    iget-object p0, p0, Lcom/android/mms/MmsApp;->mCountryIso:Ljava/lang/String;

    return-object p0
.end method

.method public getDrmManagerClient()Landroid/drm/DrmManagerClient;
    .locals 2

    .line 279
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mDrmManagerClient:Landroid/drm/DrmManagerClient;

    if-nez v0, :cond_0

    .line 280
    new-instance v0, Landroid/drm/DrmManagerClient;

    invoke-virtual {p0}, Lcom/android/mms/MmsApp;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/drm/DrmManagerClient;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mDrmManagerClient:Landroid/drm/DrmManagerClient;

    .line 282
    :cond_0
    iget-object p0, p0, Lcom/android/mms/MmsApp;->mDrmManagerClient:Landroid/drm/DrmManagerClient;

    return-object p0
.end method

.method public getPduLoaderManager()Lcom/android/mms/util/PduLoaderManager;
    .locals 0

    .line 230
    iget-object p0, p0, Lcom/android/mms/MmsApp;->mPduLoaderManager:Lcom/android/mms/util/PduLoaderManager;

    return-object p0
.end method

.method public getRecentSuggestions()Landroid/provider/SearchRecentSuggestions;
    .locals 0

    .line 264
    iget-object p0, p0, Lcom/android/mms/MmsApp;->mRecentSuggestions:Landroid/provider/SearchRecentSuggestions;

    return-object p0
.end method

.method public getTelephonyManager()Landroid/telephony/TelephonyManager;
    .locals 2

    .line 246
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mTelephonyManager:Landroid/telephony/TelephonyManager;

    if-nez v0, :cond_0

    .line 247
    invoke-virtual {p0}, Lcom/android/mms/MmsApp;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "phone"

    .line 248
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mTelephonyManager:Landroid/telephony/TelephonyManager;

    .line 250
    :cond_0
    iget-object p0, p0, Lcom/android/mms/MmsApp;->mTelephonyManager:Landroid/telephony/TelephonyManager;

    return-object p0
.end method

.method public getThumbnailManager()Lcom/android/mms/util/ThumbnailManager;
    .locals 0

    .line 234
    iget-object p0, p0, Lcom/android/mms/MmsApp;->mThumbnailManager:Lcom/android/mms/util/ThumbnailManager;

    return-object p0
.end method

.method public initPermissionRelated()V
    .locals 0

    .line 147
    sget-boolean p0, Lcom/android/mms/MmsApp;->hasPermissionRelated:Z

    if-nez p0, :cond_0

    .line 148
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object p0

    invoke-static {p0}, Lcom/android/mms/data/Contact;->init(Landroid/content/Context;)V

    .line 149
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object p0

    invoke-static {p0}, Lcom/android/mms/util/DraftCache;->init(Landroid/content/Context;)V

    .line 150
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object p0

    invoke-static {p0}, Lcom/android/mms/data/Conversation;->init(Landroid/content/Context;)V

    const/4 p0, 0x1

    .line 153
    sput-boolean p0, Lcom/android/mms/MmsApp;->hasPermissionRelated:Z

    :cond_0
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    .line 239
    invoke-static {}, Lcom/android/mms/layout/LayoutManager;->getInstance()Lcom/android/mms/layout/LayoutManager;

    move-result-object p0

    invoke-virtual {p0, p1}, Lcom/android/mms/layout/LayoutManager;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    return-void
.end method

.method public onCreate()V
    .locals 4

    .line 85
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    const-string v0, "Mms"

    const/4 v1, 0x3

    .line 87
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 91
    new-instance v0, Landroid/os/StrictMode$ThreadPolicy$Builder;

    invoke-direct {v0}, Landroid/os/StrictMode$ThreadPolicy$Builder;-><init>()V

    .line 92
    invoke-virtual {v0}, Landroid/os/StrictMode$ThreadPolicy$Builder;->detectAll()Landroid/os/StrictMode$ThreadPolicy$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/StrictMode$ThreadPolicy$Builder;->penaltyLog()Landroid/os/StrictMode$ThreadPolicy$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/StrictMode$ThreadPolicy$Builder;->build()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v0

    .line 91
    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    .line 95
    :cond_0
    sput-object p0, Lcom/android/mms/MmsApp;->sMmsApp:Lcom/android/mms/MmsApp;

    .line 97
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->getInstance()Ljava/util/Properties;

    .line 98
    invoke-static {}, Lcom/android/mms/util/ImsConnectionManager;->getInstance()Lcom/android/mms/util/ImsConnectionManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/util/ImsConnectionManager;->register()V

    .line 101
    invoke-virtual {p0}, Lcom/android/mms/MmsApp;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f040018    # @bool/def_custom_preferences_settings 'false'

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    const/high16 v0, 0x7f110000    # @xml/custom_preferences 'res/xml/custom_preferences.xml'

    .line 102
    invoke-static {p0, v0, v1}, Landroid/preference/PreferenceManager;->setDefaultValues(Landroid/content/Context;IZ)V

    goto :goto_0

    :cond_1
    const v0, 0x7f110001    # @xml/gflip_preferences 'res/xml/gflip_preferences.xml'

    .line 105
    invoke-static {p0, v0, v1}, Landroid/preference/PreferenceManager;->setDefaultValues(Landroid/content/Context;IZ)V

    :goto_0
    const-string v0, "country_detector"

    .line 109
    invoke-virtual {p0, v0}, Lcom/android/mms/MmsApp;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/location/CountryDetector;

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mCountryDetector:Landroid/location/CountryDetector;

    .line 110
    new-instance v0, Lcom/android/mms/MmsApp$1;

    invoke-direct {v0, p0}, Lcom/android/mms/MmsApp$1;-><init>(Lcom/android/mms/MmsApp;)V

    iput-object v0, p0, Lcom/android/mms/MmsApp;->mCountryListener:Landroid/location/CountryListener;

    .line 116
    iget-object v2, p0, Lcom/android/mms/MmsApp;->mCountryDetector:Landroid/location/CountryDetector;

    invoke-virtual {p0}, Lcom/android/mms/MmsApp;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-virtual {v2, v0, v3}, Landroid/location/CountryDetector;->addCountryListener(Landroid/location/CountryListener;Landroid/os/Looper;)V

    .line 118
    invoke-virtual {p0}, Lcom/android/mms/MmsApp;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 119
    new-instance v2, Lcom/android/mms/util/PduLoaderManager;

    invoke-direct {v2, v0}, Lcom/android/mms/util/PduLoaderManager;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Lcom/android/mms/MmsApp;->mPduLoaderManager:Lcom/android/mms/util/PduLoaderManager;

    .line 120
    new-instance v2, Lcom/android/mms/util/ThumbnailManager;

    invoke-direct {v2, v0}, Lcom/android/mms/util/ThumbnailManager;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Lcom/android/mms/MmsApp;->mThumbnailManager:Lcom/android/mms/util/ThumbnailManager;

    .line 122
    invoke-static {p0}, Lcom/android/mms/MmsConfig;->init(Landroid/content/Context;)V

    .line 123
    invoke-static {p0}, Lcom/android/mms/util/DownloadManager;->init(Landroid/content/Context;)V

    .line 124
    invoke-static {p0}, Lcom/android/mms/util/RateController;->init(Landroid/content/Context;)V

    .line 125
    invoke-static {p0}, Lcom/android/mms/layout/LayoutManager;->init(Landroid/content/Context;)V

    .line 126
    invoke-static {p0}, Lcom/android/mms/transaction/MessagingNotification;->init(Landroid/content/Context;)V

    .line 127
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->hasBasicPermissions()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 128
    invoke-virtual {p0}, Lcom/android/mms/MmsApp;->initPermissionRelated()V

    .line 134
    :cond_2
    invoke-virtual {p0}, Lcom/android/mms/MmsApp;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    .line 135
    new-instance v2, Landroid/content/ComponentName;

    const-class v3, Lcom/android/mms/transaction/MmsNoConfirmationSendActivity;

    invoke-direct {v2, p0, v3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v1, v3}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V

    .line 139
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mSmsStorageMonitor:Lcom/android/mms/ui/SmsStorageMonitor;

    invoke-static {}, Lcom/android/mms/ui/SmsStorageMonitor;->getFilter()Landroid/content/IntentFilter;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/MmsApp;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 140
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mMmsSystemEventReceiver:Lcom/android/mms/transaction/MmsSystemEventReceiver;

    invoke-static {}, Lcom/android/mms/transaction/MmsSystemEventReceiver;->getFilter()Landroid/content/IntentFilter;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/MmsApp;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 141
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mSimFullReceiver:Lcom/android/mms/transaction/SimFullReceiver;

    invoke-static {}, Lcom/android/mms/transaction/SimFullReceiver;->getFilter()Landroid/content/IntentFilter;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/MmsApp;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 142
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mSmsRejectedReceiver:Lcom/android/mms/transaction/SmsRejectedReceiver;

    invoke-static {}, Lcom/android/mms/transaction/SmsRejectedReceiver;->getFilter()Landroid/content/IntentFilter;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/MmsApp;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 143
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mNotificationActionHandleReceiver:Lcom/android/mms/ui/NotificationActionHandleReceiver;

    invoke-static {}, Lcom/android/mms/ui/NotificationActionHandleReceiver;->getFilter()Landroid/content/IntentFilter;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/MmsApp;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    # tzib: Tzibbur startup, mirrors TzbApp.onCreate() from the merged app.
    # com.android.mms.MmsApp owns <application>, so TzbApp cannot be used.
    :tzb_try_start
    invoke-static {p0}, Lcom/android/mms/tzib/TzibGate;->sync(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :tzb_done

    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :tzb_done

    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v0

    if-eqz v0, :tzb_done

    invoke-static {p0}, Lcom/tzibbur/basic/sync/TzbSyncService;->ensureRunning(Landroid/content/Context;)V

    :tzb_try_end
    .catch Ljava/lang/Throwable; {:tzb_try_start .. :tzb_try_end} :tzb_catch

    goto :tzb_done

    :tzb_catch
    move-exception v0

    const-string v1, "tzib"

    const-string v2, "Tzibbur init failed"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :tzb_done
    return-void
.end method

.method public onLowMemory()V
    .locals 1

    .line 223
    invoke-super {p0}, Landroid/app/Application;->onLowMemory()V

    .line 225
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mPduLoaderManager:Lcom/android/mms/util/PduLoaderManager;

    invoke-virtual {v0}, Lcom/android/mms/util/PduLoaderManager;->onLowMemory()V

    .line 226
    iget-object p0, p0, Lcom/android/mms/MmsApp;->mThumbnailManager:Lcom/android/mms/util/ThumbnailManager;

    invoke-virtual {p0}, Lcom/android/mms/util/ThumbnailManager;->onLowMemory()V

    return-void
.end method

.method public onTerminate()V
    .locals 2

    .line 211
    invoke-super {p0}, Landroid/app/Application;->onTerminate()V

    .line 212
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mCountryDetector:Landroid/location/CountryDetector;

    iget-object v1, p0, Lcom/android/mms/MmsApp;->mCountryListener:Landroid/location/CountryListener;

    invoke-virtual {v0, v1}, Landroid/location/CountryDetector;->removeCountryListener(Landroid/location/CountryListener;)V

    .line 213
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mSmsStorageMonitor:Lcom/android/mms/ui/SmsStorageMonitor;

    invoke-virtual {p0, v0}, Lcom/android/mms/MmsApp;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 214
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mMmsSystemEventReceiver:Lcom/android/mms/transaction/MmsSystemEventReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/MmsApp;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 215
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mSimFullReceiver:Lcom/android/mms/transaction/SimFullReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/MmsApp;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 216
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mSmsRejectedReceiver:Lcom/android/mms/transaction/SmsRejectedReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/MmsApp;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 217
    iget-object v0, p0, Lcom/android/mms/MmsApp;->mNotificationActionHandleReceiver:Lcom/android/mms/ui/NotificationActionHandleReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/MmsApp;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 218
    invoke-static {}, Lcom/android/mms/util/ImsConnectionManager;->getInstance()Lcom/android/mms/util/ImsConnectionManager;

    move-result-object p0

    invoke-virtual {p0}, Lcom/android/mms/util/ImsConnectionManager;->unregister()V

    return-void
.end method
