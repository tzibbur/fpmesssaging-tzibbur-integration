.class final Lcom/android/mms/tzib/TzibTasks;
.super Ljava/lang/Object;
.source "TzibTasks.java"


# static fields
.field private static final IO:Ljava/util/concurrent/ExecutorService;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 14
    const/4 v0, 0x2

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lcom/android/mms/tzib/TzibTasks;->IO:Ljava/util/concurrent/ExecutorService;

    return-void
.end method

.method constructor <init>()V
    .registers 1

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic lambda$run$0(Landroid/app/Activity;Ljava/lang/Exception;)V
    .registers 4

    .line 17
    nop

    .line 18
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_34

    .line 19
    check-cast p1, Lcom/tzibbur/basic/net/TzbProblem;

    .line 20
    iget-object v0, p1, Lcom/tzibbur/basic/net/TzbProblem;->detail:Ljava/lang/String;

    if-nez v0, :cond_e

    iget-object v0, p1, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    goto :goto_10

    :cond_e
    iget-object v0, p1, Lcom/tzibbur/basic/net/TzbProblem;->detail:Ljava/lang/String;

    .line 21
    :goto_10
    iget v1, p1, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    if-lez v1, :cond_36

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " Try again in "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget p1, p1, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, " seconds."

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_36

    .line 18
    :cond_34
    const-string v0, "Could not connect. Please try again."

    .line 23
    :cond_36
    :goto_36
    const/4 p1, 0x1

    invoke-static {p0, v0, p1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 24
    return-void
.end method

.method static synthetic lambda$run$1(Landroid/app/Activity;Ljava/util/function/Consumer;Ljava/lang/Object;)V
    .registers 4

    .line 32
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_15

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_15

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p0

    if-eqz p0, :cond_15

    invoke-interface {p1, p2}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :cond_15
    return-void
.end method

.method static synthetic lambda$run$2(Landroid/app/Activity;Ljava/util/function/Consumer;Ljava/lang/Exception;)V
    .registers 4

    .line 34
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_15

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_15

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p0

    if-eqz p0, :cond_15

    invoke-interface {p1, p2}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :cond_15
    return-void
.end method

.method static synthetic lambda$run$3(Landroid/app/Activity;Ljava/util/concurrent/Callable;Landroid/os/Handler;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V
    .registers 6

    .line 30
    :try_start_0
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 31
    :cond_7
    invoke-interface {p1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object p1

    .line 32
    new-instance v0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0, p3, p1}, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda2;-><init>(Landroid/app/Activity;Ljava/util/function/Consumer;Ljava/lang/Object;)V

    invoke-virtual {p2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_13} :catch_14

    .line 35
    goto :goto_1d

    .line 33
    :catch_14
    move-exception p1

    .line 34
    new-instance p3, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda3;

    invoke-direct {p3, p0, p4, p1}, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda3;-><init>(Landroid/app/Activity;Ljava/util/function/Consumer;Ljava/lang/Exception;)V

    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 36
    :goto_1d
    return-void
.end method

.method static run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/app/Activity;",
            "Ljava/util/concurrent/Callable<",
            "TT;>;",
            "Ljava/util/function/Consumer<",
            "TT;>;)V"
        }
    .end annotation

    .line 16
    new-instance v0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda0;-><init>(Landroid/app/Activity;)V

    invoke-static {p0, p1, p2, v0}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V

    .line 25
    return-void
.end method

.method static run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/app/Activity;",
            "Ljava/util/concurrent/Callable<",
            "TT;>;",
            "Ljava/util/function/Consumer<",
            "TT;>;",
            "Ljava/util/function/Consumer<",
            "Ljava/lang/Exception;",
            ">;)V"
        }
    .end annotation

    .line 27
    new-instance v3, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v3, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 28
    sget-object v6, Lcom/android/mms/tzib/TzibTasks;->IO:Ljava/util/concurrent/ExecutorService;

    new-instance v7, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;

    move-object v0, v7

    move-object v1, p0

    move-object v2, p1

    move-object v4, p2

    move-object v5, p3

    invoke-direct/range {v0 .. v5}, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;-><init>(Landroid/app/Activity;Ljava/util/concurrent/Callable;Landroid/os/Handler;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V

    invoke-interface {v6, v7}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 37
    return-void
.end method
