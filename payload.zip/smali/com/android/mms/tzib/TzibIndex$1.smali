.class Lcom/android/mms/tzib/TzibIndex$1;
.super Ljava/lang/Object;
.source "TzibIndex.java"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/mms/tzib/TzibIndex;->merge(Ljava/util/List;Ljava/util/List;Z)Ljava/util/List;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcom/android/mms/tzib/TzibIndex$Entry;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public compare(Lcom/android/mms/tzib/TzibIndex$Entry;Lcom/android/mms/tzib/TzibIndex$Entry;)I
    .registers 7

    .line 37
    iget-wide v0, p2, Lcom/android/mms/tzib/TzibIndex$Entry;->date:J

    iget-wide v2, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->date:J

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    move-result v0

    .line 38
    if-eqz v0, :cond_b

    return v0

    .line 40
    :cond_b
    iget-object v0, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    if-nez v0, :cond_1c

    iget-object v0, p2, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    if-nez v0, :cond_1c

    iget p1, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->smsPosition:I

    iget p2, p2, Lcom/android/mms/tzib/TzibIndex$Entry;->smsPosition:I

    invoke-static {p1, p2}, Ljava/lang/Integer;->compare(II)I

    move-result p1

    return p1

    .line 41
    :cond_1c
    iget-object v0, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    if-nez v0, :cond_22

    const/4 p1, -0x1

    return p1

    .line 42
    :cond_22
    iget-object v0, p2, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    if-nez v0, :cond_28

    const/4 p1, 0x1

    return p1

    .line 43
    :cond_28
    iget-object p1, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    iget-object p2, p2, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 3

    .line 35
    check-cast p1, Lcom/android/mms/tzib/TzibIndex$Entry;

    check-cast p2, Lcom/android/mms/tzib/TzibIndex$Entry;

    invoke-virtual {p0, p1, p2}, Lcom/android/mms/tzib/TzibIndex$1;->compare(Lcom/android/mms/tzib/TzibIndex$Entry;Lcom/android/mms/tzib/TzibIndex$Entry;)I

    move-result p1

    return p1
.end method
