.class public final Lcom/android/mms/tzib/TzibDeletedMessages;
.super Ljava/lang/Object;
.source "TzibDeletedMessages.java"


# static fields
.field private static volatile app:Landroid/content/Context;


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static erase(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 10

    .line 66
    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p2, :cond_c

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_c

    move v2, v0

    goto :goto_d

    :cond_c
    move v2, v1

    :goto_d
    if-eqz p3, :cond_17

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_17

    move v3, v0

    goto :goto_18

    :cond_17
    move v3, v1

    .line 67
    :goto_18
    if-nez v2, :cond_25

    if-eqz v3, :cond_1d

    goto :goto_25

    :cond_1d
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Missing message identity"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 68
    :cond_25
    :goto_25
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "group_id=? AND "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    if-eqz v2, :cond_37

    if-eqz v3, :cond_37

    const-string v5, "(id=? OR client_message_id=?)"

    goto :goto_3e

    .line 69
    :cond_37
    if-eqz v2, :cond_3c

    const-string v5, "id=?"

    goto :goto_3e

    :cond_3c
    const-string v5, "client_message_id=?"

    :goto_3e
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 70
    if-eqz v2, :cond_4f

    if-eqz v3, :cond_4f

    filled-new-array {p1, p2, p3}, [Ljava/lang/String;

    move-result-object p2

    goto :goto_5b

    .line 71
    :cond_4f
    const/4 v5, 0x2

    new-array v5, v5, [Ljava/lang/String;

    aput-object p1, v5, v1

    if-eqz v2, :cond_57

    goto :goto_58

    :cond_57
    move-object p2, p3

    :goto_58
    aput-object p2, v5, v0

    move-object p2, v5

    .line 72
    :goto_5b
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 74
    :try_start_5e
    const-string v0, "tzb_messages"

    invoke-static {}, Lcom/android/mms/tzib/TzibDeletedMessages;->erased()Landroid/content/ContentValues;

    move-result-object v1

    invoke-virtual {p0, v0, v1, v4, p2}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    .line 75
    if-eqz v3, :cond_74

    .line 76
    const-string p2, "tzb_outbox"

    const-string v0, "group_id=? AND client_message_id=?"

    filled-new-array {p1, p3}, [Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p2, v0, p1}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 78
    :cond_74
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_77
    .catchall {:try_start_5e .. :try_end_77} :catchall_7b

    .line 79
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 80
    return-void

    .line 79
    :catchall_7b
    move-exception p1

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    throw p1
.end method

.method private static erased()Landroid/content/ContentValues;
    .registers 3

    .line 57
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 58
    const-string v1, "body"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 61
    const-string v1, "expires_at"

    const-string v2, "1970-01-01T00:00:00.000Z"

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 62
    const-wide/16 v1, 0x0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "expires_at_ms"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 63
    return-object v0
.end method

.method public static filter(Landroid/content/Context;Ljava/util/List;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    .line 87
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->init(Landroid/content/Context;)V

    .line 88
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_7
    :goto_7
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_1b

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/tzib/TzibDeletedMessages;->hidden(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    invoke-interface {p0}, Ljava/util/Iterator;->remove()V

    goto :goto_7

    .line 89
    :cond_1b
    return-void
.end method

.method static hidden(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 7

    .line 29
    const/4 v0, 0x0

    if-eqz p0, :cond_3e

    if-eqz p1, :cond_3e

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_3e

    if-nez p2, :cond_e

    goto :goto_3e

    .line 30
    :cond_e
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 31
    if-eqz p3, :cond_26

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_26

    const-string v1, "message"

    invoke-static {p1, p2, v1, p3}, Lcom/android/mms/tzib/TzibDeletedMessages;->key(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-interface {p0, p3, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p3

    if-nez p3, :cond_3a

    :cond_26
    if-eqz p4, :cond_3c

    .line 32
    invoke-virtual {p4}, Ljava/lang/String;->isEmpty()Z

    move-result p3

    if-nez p3, :cond_3c

    const-string p3, "client"

    invoke-static {p1, p2, p3, p4}, Lcom/android/mms/tzib/TzibDeletedMessages;->key(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    if-eqz p0, :cond_3c

    :cond_3a
    const/4 v0, 0x1

    goto :goto_3d

    :cond_3c
    nop

    .line 31
    :goto_3d
    return v0

    .line 29
    :cond_3e
    :goto_3e
    return v0
.end method

.method static hidden(Ljava/lang/Object;)Z
    .registers 3

    .line 39
    instance-of v0, p0, Lcom/tzibbur/basic/model/TzbMessage;

    if-eqz v0, :cond_11

    .line 40
    check-cast p0, Lcom/tzibbur/basic/model/TzbMessage;

    .line 41
    iget-object v0, p0, Lcom/tzibbur/basic/model/TzbMessage;->groupId:Ljava/lang/String;

    iget-object v1, p0, Lcom/tzibbur/basic/model/TzbMessage;->id:Ljava/lang/String;

    iget-object p0, p0, Lcom/tzibbur/basic/model/TzbMessage;->clientMessageId:Ljava/lang/String;

    invoke-static {v0, v1, p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->hidden(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    return p0

    .line 43
    :cond_11
    instance-of v0, p0, Lcom/tzibbur/basic/store/TzbOutboxItem;

    if-eqz v0, :cond_21

    .line 44
    check-cast p0, Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 45
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    invoke-static {v0, v1, p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->hidden(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    return p0

    .line 47
    :cond_21
    const/4 p0, 0x0

    return p0
.end method

.method static hidden(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 5

    .line 35
    sget-object v0, Lcom/android/mms/tzib/TzibDeletedMessages;->app:Landroid/content/Context;

    .line 36
    if-eqz v0, :cond_10

    invoke-static {v0}, Lcom/android/mms/tzib/TzibDeletedMessages;->owner(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, p0, p1, p2}, Lcom/android/mms/tzib/TzibDeletedMessages;->hidden(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_10

    const/4 p0, 0x1

    goto :goto_11

    :cond_10
    const/4 p0, 0x0

    :goto_11
    return p0
.end method

.method public static init(Landroid/content/Context;)V
    .registers 1

    .line 18
    if-eqz p0, :cond_8

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    sput-object p0, Lcom/android/mms/tzib/TzibDeletedMessages;->app:Landroid/content/Context;

    :cond_8
    return-void
.end method

.method private static key(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    .line 26
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, "/"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-static {p1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-static {p3}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static owner(Landroid/content/Context;)Ljava/lang/String;
    .registers 3

    .line 20
    const-string v0, "tzb_session"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "tzb_user_id"

    const-string v1, ""

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .registers 3

    .line 23
    const-string v0, "tzib_deleted_messages"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    return-object p0
.end method

.method static remember(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 50
    if-eqz p1, :cond_44

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_44

    if-eqz p2, :cond_44

    .line 51
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    .line 52
    const/4 v0, 0x1

    if-eqz p3, :cond_24

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_24

    const-string v1, "message"

    invoke-static {p1, p2, v1, p3}, Lcom/android/mms/tzib/TzibDeletedMessages;->key(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-interface {p0, p3, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 53
    :cond_24
    if-eqz p4, :cond_35

    invoke-virtual {p4}, Ljava/lang/String;->isEmpty()Z

    move-result p3

    if-nez p3, :cond_35

    const-string p3, "client"

    invoke-static {p1, p2, p3, p4}, Lcom/android/mms/tzib/TzibDeletedMessages;->key(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 54
    :cond_35
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result p0

    if-eqz p0, :cond_3c

    .line 55
    return-void

    .line 54
    :cond_3c
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Could not save local deletion"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 50
    :cond_44
    new-instance p0, Ljava/io/IOException;

    const-string p1, "No signed-in account"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static scrub(Lcom/tzibbur/basic/model/TzbMessage;Landroid/content/ContentValues;)V
    .registers 2

    .line 83
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->hidden(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_d

    invoke-static {}, Lcom/android/mms/tzib/TzibDeletedMessages;->erased()Landroid/content/ContentValues;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/content/ContentValues;->putAll(Landroid/content/ContentValues;)V

    .line 84
    :cond_d
    return-void
.end method
