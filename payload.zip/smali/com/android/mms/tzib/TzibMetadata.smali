.class public final Lcom/android/mms/tzib/TzibMetadata;
.super Ljava/lang/Object;
.source "TzibMetadata.java"


# static fields
.field private static volatile app:Landroid/content/Context;


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static badge(I)Ljava/lang/String;
    .registers 4

    .line 60
    if-gtz p0, :cond_5

    const-string p0, ""

    return-object p0

    .line 61
    :cond_5
    sget-object v0, Lcom/android/mms/tzib/TzibMetadata;->app:Landroid/content/Context;

    const/4 v1, 0x0

    if-nez v0, :cond_b

    goto :goto_15

    :cond_b
    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->prefs()Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v2, "unread_cap"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    .line 62
    :goto_15
    const/4 v0, 0x2

    if-ge v1, v0, :cond_1b

    const-string p0, " \u2022"

    return-object p0

    .line 63
    :cond_1b
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " \u2022 "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    if-lt p0, v1, :cond_3e

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v1, "+"

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_42

    :cond_3e
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    :goto_42
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static capabilities(Lorg/json/JSONObject;)V
    .registers 4

    .line 34
    sget-object v0, Lcom/android/mms/tzib/TzibMetadata;->app:Landroid/content/Context;

    if-eqz v0, :cond_2d

    if-nez p0, :cond_7

    goto :goto_2d

    .line 35
    :cond_7
    const-string v0, "limits"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p0

    .line 36
    if-eqz p0, :cond_2c

    const-string v0, "unreadCountMax"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2c

    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->prefs()Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "unread_cap"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p0

    invoke-interface {v1, v2, p0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 37
    :cond_2c
    return-void

    .line 34
    :cond_2d
    :goto_2d
    return-void
.end method

.method static clear()V
    .registers 1

    .line 65
    sget-object v0, Lcom/android/mms/tzib/TzibMetadata;->app:Landroid/content/Context;

    if-eqz v0, :cond_13

    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->prefs()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_13
    return-void
.end method

.method static declared-synchronized deleted(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 8

    const-class v0, Lcom/android/mms/tzib/TzibMetadata;

    monitor-enter v0

    .line 67
    :try_start_3
    sget-object v1, Lcom/android/mms/tzib/TzibMetadata;->app:Landroid/content/Context;
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_93

    if-nez v1, :cond_9

    monitor-exit v0

    return-void

    .line 68
    :cond_9
    :try_start_9
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v1, "/"

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_20
    .catchall {:try_start_9 .. :try_end_20} :catchall_93

    .line 70
    :try_start_20
    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->prefs()Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v1, 0x0

    invoke-interface {p1, p0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_29} :catch_88
    .catchall {:try_start_20 .. :try_end_29} :catchall_93

    .line 71
    if-nez p1, :cond_2d

    monitor-exit v0

    return-void

    .line 72
    :cond_2d
    :try_start_2d
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p1, "lastMessage"

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1
    :try_end_38
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_38} :catch_88
    .catchall {:try_start_2d .. :try_end_38} :catchall_93

    .line 73
    if-nez p1, :cond_3c

    monitor-exit v0

    return-void

    .line 74
    :cond_3c
    const/4 v2, 0x1

    if-eqz p2, :cond_51

    :try_start_3f
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_51

    const-string v3, "id"

    invoke-virtual {p1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_65

    :cond_51
    if-eqz p3, :cond_67

    .line 75
    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_67

    const-string p2, "clientMessageId"

    invoke-virtual {p1, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_67

    :cond_65
    move p2, v2

    goto :goto_68

    :cond_67
    const/4 p2, 0x0

    .line 76
    :goto_68
    if-eqz p2, :cond_90

    .line 77
    const-string p2, "body"

    invoke-virtual {p1, p2}, Lorg/json/JSONObject;->remove(Ljava/lang/String;)Ljava/lang/Object;

    const-string p2, "localDeleted"

    invoke-virtual {p1, p2, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 78
    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->prefs()Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p0, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_87
    .catch Ljava/lang/Exception; {:try_start_3f .. :try_end_87} :catch_88
    .catchall {:try_start_3f .. :try_end_87} :catchall_93

    goto :goto_90

    .line 80
    :catch_88
    move-exception p0

    :try_start_89
    const-string p1, "tzib"

    const-string p2, "Could not clear deleted preview"

    invoke-static {p1, p2, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_90
    .catchall {:try_start_89 .. :try_end_90} :catchall_93

    :cond_90
    :goto_90
    nop

    .line 81
    monitor-exit v0

    return-void

    .line 66
    :catchall_93
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static declared-synchronized group(Lorg/json/JSONObject;)V
    .registers 7

    const-class v0, Lcom/android/mms/tzib/TzibMetadata;

    monitor-enter v0

    .line 17
    :try_start_3
    sget-object v1, Lcom/android/mms/tzib/TzibMetadata;->app:Landroid/content/Context;

    if-eqz v1, :cond_a7

    if-nez p0, :cond_b

    goto/16 :goto_a7

    .line 18
    :cond_b
    const-string v1, "id"

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 19
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_a5

    const-string v2, "lastMessage"

    invoke-virtual {p0, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2
    :try_end_1d
    .catchall {:try_start_3 .. :try_end_1d} :catchall_a9

    if-nez v2, :cond_21

    goto/16 :goto_a5

    .line 21
    :cond_21
    :try_start_21
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 22
    const-string v3, "lastMessage"

    invoke-virtual {p0, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 23
    if-eqz v3, :cond_55

    const-string v4, "id"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "clientMessageId"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v4, v5}, Lcom/android/mms/tzib/TzibDeletedMessages;->hidden(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_55

    .line 24
    new-instance v4, Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 25
    const-string v3, "body"

    invoke-virtual {v4, v3}, Lorg/json/JSONObject;->remove(Ljava/lang/String;)Ljava/lang/Object;

    .line 26
    const-string v3, "localDeleted"

    const/4 v5, 0x1

    invoke-virtual {v4, v3, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-object v3, v4

    .line 28
    :cond_55
    const-string v4, "lastMessage"

    if-nez v3, :cond_5b

    sget-object v3, Lorg/json/JSONObject;->NULL:Ljava/lang/Object;

    :cond_5b
    invoke-virtual {v2, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 29
    const-string v3, "membershipStatus"

    const-string v4, "membershipStatus"

    const-string v5, "active"

    invoke-virtual {p0, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, v3, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 30
    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->prefs()Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->owner()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {p0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_99
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_99} :catch_9a
    .catchall {:try_start_21 .. :try_end_99} :catchall_a9

    goto :goto_a2

    .line 31
    :catch_9a
    move-exception p0

    :try_start_9b
    const-string v1, "tzib"

    const-string v2, "Could not cache conversation preview"

    invoke-static {v1, v2, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_a2
    .catchall {:try_start_9b .. :try_end_a2} :catchall_a9

    :goto_a2
    nop

    .line 32
    monitor-exit v0

    return-void

    .line 19
    :cond_a5
    :goto_a5
    monitor-exit v0

    return-void

    .line 17
    :cond_a7
    :goto_a7
    monitor-exit v0

    return-void

    .line 16
    :catchall_a9
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method static init(Landroid/content/Context;)V
    .registers 1

    .line 13
    if-eqz p0, :cond_8

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    sput-object p0, Lcom/android/mms/tzib/TzibMetadata;->app:Landroid/content/Context;

    :cond_8
    return-void
.end method

.method static lastMessage(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbMessage;)Lcom/tzibbur/basic/model/TzbMessage;
    .registers 19

    .line 46
    invoke-static/range {p1 .. p1}, Lcom/android/mms/tzib/TzibDeletedMessages;->hidden(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_9

    move-object v0, v1

    goto :goto_b

    :cond_9
    move-object/from16 v0, p1

    .line 47
    :goto_b
    invoke-static/range {p0 .. p0}, Lcom/android/mms/tzib/TzibMetadata;->snapshot(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 48
    if-nez v2, :cond_12

    return-object v0

    .line 49
    :cond_12
    const-string v3, "lastMessage"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 50
    if-nez v2, :cond_1b

    return-object v1

    .line 51
    :cond_1b
    const-string v3, "localDeleted"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_85

    const-string v3, "id"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "clientMessageId"

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    move-object/from16 v9, p0

    invoke-static {v9, v4, v6}, Lcom/android/mms/tzib/TzibDeletedMessages;->hidden(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_38

    goto :goto_85

    .line 52
    :cond_38
    const-string v4, "seq"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v10

    .line 53
    if-eqz v0, :cond_47

    iget-wide v6, v0, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    cmp-long v4, v6, v10

    if-lez v4, :cond_47

    return-object v0

    .line 54
    :cond_47
    const-string v0, "expiresAt"

    const-string v4, ""

    invoke-virtual {v2, v0, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    .line 55
    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_62

    invoke-static/range {v16 .. v16}, Lcom/android/mms/tzib/TzibInboxAdapter;->timestamp(Ljava/lang/String;)J

    move-result-wide v6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    cmp-long v0, v6, v12

    if-gtz v0, :cond_62

    return-object v1

    .line 56
    :cond_62
    new-instance v0, Lcom/tzibbur/basic/model/TzbMessage;

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v3, "senderId"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 57
    const-string v3, "body"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v2, v5, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v1, "createdAt"

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object v7, v0

    move-object/from16 v9, p0

    invoke-direct/range {v7 .. v16}, Lcom/tzibbur/basic/model/TzbMessage;-><init>(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 56
    return-object v0

    .line 51
    :cond_85
    :goto_85
    return-object v0
.end method

.method private static owner()Ljava/lang/String;
    .registers 3

    .line 15
    sget-object v0, Lcom/android/mms/tzib/TzibMetadata;->app:Landroid/content/Context;

    const-string v1, "tzb_session"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "tzb_user_id"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static prefs()Landroid/content/SharedPreferences;
    .registers 3

    .line 14
    sget-object v0, Lcom/android/mms/tzib/TzibMetadata;->app:Landroid/content/Context;

    const-string v1, "tzib_inbox_metadata"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    return-object v0
.end method

.method static snapshot(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 5

    .line 39
    sget-object v0, Lcom/android/mms/tzib/TzibMetadata;->app:Landroid/content/Context;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return-object v1

    .line 41
    :cond_6
    :try_start_6
    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->prefs()Landroid/content/SharedPreferences;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->owner()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 42
    if-nez p0, :cond_2c

    goto :goto_32

    :cond_2c
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_31
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_31} :catch_33

    move-object v1, v0

    :goto_32
    return-object v1

    .line 43
    :catch_33
    move-exception p0

    return-object v1
.end method
