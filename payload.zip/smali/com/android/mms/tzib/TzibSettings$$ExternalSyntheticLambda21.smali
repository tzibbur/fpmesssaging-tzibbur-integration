.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/tzibbur/basic/core/TzbCore;

.field public final synthetic f$1:Landroid/preference/PreferenceActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/tzibbur/basic/core/TzbCore;Landroid/preference/PreferenceActivity;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda21;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda21;->f$1:Landroid/preference/PreferenceActivity;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda21;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda21;->f$1:Landroid/preference/PreferenceActivity;

    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibSettings;->lambda$install$4(Lcom/tzibbur/basic/core/TzbCore;Landroid/preference/PreferenceActivity;)V

    return-void
.end method
