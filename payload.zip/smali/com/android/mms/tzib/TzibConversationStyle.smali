.class public final Lcom/android/mms/tzib/TzibConversationStyle;
.super Ljava/lang/Object;
.source "TzibConversationStyle.java"


# instance fields
.field private final activity:Landroid/app/Activity;

.field private choiceTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

.field private final editor:Landroid/widget/EditText;

.field private lastPhysicalSend:J

.field private final list:Landroid/widget/ListView;

.field private menuBar:Ljava/lang/Object;

.field private menuOpen:Z

.field private menuTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

.field private final notice:Landroid/view/View;

.field private options:Landroid/view/Menu;

.field private final panel:Landroid/view/View;

.field private final sendButton:Landroid/view/View;

.field private final sendKey:Lcom/android/mms/tzib/TzibSendKey;


# direct methods
.method private constructor <init>(Landroid/app/Activity;)V
    .registers 3

    .line 46
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 39
    new-instance v0, Lcom/android/mms/tzib/TzibSendKey;

    invoke-direct {v0}, Lcom/android/mms/tzib/TzibSendKey;-><init>()V

    iput-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->sendKey:Lcom/android/mms/tzib/TzibSendKey;

    .line 47
    iput-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    .line 48
    const-string v0, "tzb_message_list"

    invoke-static {p1, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    .line 49
    const-string v0, "tzb_compose_edit"

    invoke-static {p1, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    .line 50
    const-string v0, "tzb_compose_panel"

    invoke-static {p1, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->panel:Landroid/view/View;

    .line 51
    const-string v0, "tzb_send_btn"

    invoke-static {p1, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->sendButton:Landroid/view/View;

    .line 52
    const-string v0, "tzb_compose_notice"

    invoke-static {p1, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->notice:Landroid/view/View;

    .line 53
    return-void
.end method

.method static synthetic access$000(Lcom/android/mms/tzib/TzibConversationStyle;)V
    .registers 1

    .line 32
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->updateSoftkeys()V

    return-void
.end method

.method private attachMenuBar()Z
    .registers 9

    .line 115
    const/4 v0, 0x0

    :try_start_1
    const-class v1, Landroid/app/Activity;

    const-string v2, "getMenuBar"

    new-array v3, v0, [Ljava/lang/Class;

    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 116
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 117
    iget-object v3, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    new-array v4, v0, [Ljava/lang/Object;

    invoke-virtual {v1, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    .line 118
    if-nez v1, :cond_1c

    return v0

    .line 119
    :cond_1c
    const-string v1, "android.widget.MenuBar$MenuBarListener"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    .line 120
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v3

    filled-new-array {v1}, [Ljava/lang/Class;

    move-result-object v4

    new-instance v5, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda1;

    invoke-direct {v5, p0}, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda1;-><init>(Lcom/android/mms/tzib/TzibConversationStyle;)V

    invoke-static {v3, v4, v5}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v3

    .line 150
    iget-object v4, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const-string v5, "setMenuBarListener"

    filled-new-array {v1}, [Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v4, v5, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    iget-object v4, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v4, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 151
    iget-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-string v3, "setOptionMenuItemBackground"

    new-array v4, v2, [Ljava/lang/Class;

    sget-object v5, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v5, v4, v0

    invoke-virtual {v1, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    iget-object v3, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    new-array v4, v2, [Ljava/lang/Object;

    iget-object v5, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    const-string v6, "drawable"

    const-string v7, "option_menu_item_selector"

    .line 152
    invoke-static {v5, v6, v7}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    invoke-virtual {v1, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_75
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_75} :catch_76

    .line 153
    return v2

    .line 154
    :catch_76
    move-exception v1

    .line 155
    const-string v2, "tzib"

    const-string v3, "Using fallback conversation buttons"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 156
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    .line 157
    return v0
.end method

.method public static bind(Landroid/view/View;Ljava/lang/Object;)V
    .registers 7

    .line 302
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    .line 303
    const-string v1, "tzb_msg_body"

    const-string v2, "id"

    invoke-static {v0, v2, v1}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    .line 304
    const-string v3, "tzb_msg_time"

    invoke-static {v0, v2, v3}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    check-cast p0, Landroid/widget/TextView;

    .line 305
    invoke-static {v0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "pref_key_zoom_message"

    const/high16 v4, 0x41600000    # 14.0f

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 306
    instance-of v1, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;

    if-eqz v1, :cond_3b

    move-object v1, p1

    check-cast v1, Lcom/tzibbur/basic/store/TzbOutboxItem;

    iget v1, v1, Lcom/tzibbur/basic/store/TzbOutboxItem;->state:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_3b

    const/4 v1, 0x1

    goto :goto_3c

    :cond_3b
    const/4 v1, 0x0

    .line 307
    :goto_3c
    if-eqz v1, :cond_4b

    const-string v1, "color"

    const-string v2, "tzb_error"

    invoke-static {v0, v1, v2}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    goto :goto_4d

    :cond_4b
    const/high16 v1, -0x1000000

    :goto_4d
    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 308
    instance-of v1, p1, Lcom/tzibbur/basic/model/TzbMessage;

    if-eqz v1, :cond_71

    move-object v1, p1

    check-cast v1, Lcom/tzibbur/basic/model/TzbMessage;

    iget-object v1, v1, Lcom/tzibbur/basic/model/TzbMessage;->createdAt:Ljava/lang/String;

    if-eqz v1, :cond_71

    .line 310
    :try_start_5b
    check-cast p1, Lcom/tzibbur/basic/model/TzbMessage;

    iget-object p1, p1, Lcom/tzibbur/basic/model/TzbMessage;->createdAt:Ljava/lang/String;

    invoke-static {p1}, Ljava/time/Instant;->parse(Ljava/lang/CharSequence;)Ljava/time/Instant;

    move-result-object p1

    invoke-virtual {p1}, Ljava/time/Instant;->toEpochMilli()J

    move-result-wide v1

    invoke-static {v0, v1, v2}, Lcom/android/mms/ui/MessageUtils;->formatTimeStampString(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_6e
    .catch Ljava/time/format/DateTimeParseException; {:try_start_5b .. :try_end_6e} :catch_6f

    goto :goto_70

    .line 311
    :catch_6f
    move-exception p0

    :goto_70
    nop

    .line 313
    :cond_71
    return-void
.end method

.method private centerClick()Z
    .registers 6

    .line 162
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_d

    invoke-direct {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->send()V

    const/4 v0, 0x1

    return v0

    .line 163
    :cond_d
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->notice:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_24

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->notice:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isClickable()Z

    move-result v0

    if-eqz v0, :cond_24

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->notice:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->performClick()Z

    move-result v0

    return v0

    .line 164
    :cond_24
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v0

    .line 165
    iget-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->hasFocus()Z

    move-result v1

    if-eqz v1, :cond_51

    if-ltz v0, :cond_51

    iget-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v1

    invoke-interface {v1, v0}, Landroid/widget/ListAdapter;->isEnabled(I)Z

    move-result v1

    if-eqz v1, :cond_51

    .line 166
    iget-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getSelectedView()Landroid/view/View;

    move-result-object v2

    iget-object v3, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v3, v0}, Landroid/widget/ListView;->getItemIdAtPosition(I)J

    move-result-wide v3

    invoke-virtual {v1, v2, v0, v3, v4}, Landroid/widget/ListView;->performItemClick(Landroid/view/View;IJ)Z

    move-result v0

    return v0

    .line 168
    :cond_51
    const/4 v0, 0x0

    return v0
.end method

.method private static find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Landroid/view/View;",
            ">(",
            "Landroid/app/Activity;",
            "Ljava/lang/String;",
            ")TT;"
        }
    .end annotation

    .line 59
    const-string v0, "id"

    invoke-static {p0, v0, p1}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public static focus(Landroid/app/Activity;ZZ)V
    .registers 9

    .line 287
    const-string v0, "tzb_compose_panel"

    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    .line 288
    const-string v1, "tzb_compose_edit"

    invoke-static {p0, v1}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    .line 289
    const-string v2, "tzb_compose_label"

    invoke-static {p0, v2}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    .line 290
    const-string v3, "tzb_char_counter"

    invoke-static {p0, v3}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    .line 291
    nop

    .line 292
    if-eqz p1, :cond_24

    const-string v4, "focus_message_text_color"

    goto :goto_26

    :cond_24
    const-string v4, "unfocus_message_text_color"

    .line 291
    :goto_26
    const-string v5, "color"

    invoke-static {p0, v5, v4}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    invoke-virtual {p0, v4}, Landroid/app/Activity;->getColor(I)I

    move-result v4

    invoke-virtual {v0, v4}, Landroid/view/View;->setBackgroundColor(I)V

    .line 293
    if-eqz p1, :cond_38

    const-string v0, "edittext_focus_background"

    goto :goto_3a

    :cond_38
    const-string v0, "edittext_background"

    :goto_3a
    const-string v4, "drawable"

    invoke-static {p0, v4, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/EditText;->setBackgroundResource(I)V

    .line 294
    if-eqz p1, :cond_47

    const/4 p1, -0x1

    goto :goto_49

    :cond_47
    const/high16 p1, -0x1000000

    .line 295
    :goto_49
    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 296
    if-eqz p2, :cond_58

    const-string p1, "tzb_error"

    invoke-static {p0, v5, p1}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->getColor(I)I

    move-result p1

    :cond_58
    invoke-virtual {v3, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 297
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->get(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibConversationStyle;

    move-result-object p0

    .line 298
    if-eqz p0, :cond_64

    invoke-direct {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->updateSoftkeys()V

    .line 299
    :cond_64
    return-void
.end method

.method private static get(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibConversationStyle;
    .registers 2

    .line 62
    const-string v0, "tzb_message_list"

    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->find(Landroid/app/Activity;Ljava/lang/String;)Landroid/view/View;

    move-result-object p0

    .line 63
    if-eqz p0, :cond_17

    invoke-virtual {p0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Lcom/android/mms/tzib/TzibConversationStyle;

    if-eqz v0, :cond_17

    .line 64
    invoke-virtual {p0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/android/mms/tzib/TzibConversationStyle;

    goto :goto_18

    :cond_17
    const/4 p0, 0x0

    .line 63
    :goto_18
    return-object p0
.end method

.method public static imeAction(Landroid/view/View;I)Z
    .registers 8

    .line 202
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    .line 203
    instance-of v0, p0, Landroid/app/Activity;

    const/4 v1, 0x1

    if-nez v0, :cond_a

    return v1

    .line 204
    :cond_a
    check-cast p0, Landroid/app/Activity;

    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->get(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibConversationStyle;

    move-result-object p0

    .line 205
    if-eqz p0, :cond_31

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    if-eqz v0, :cond_31

    const/4 v0, 0x4

    if-ne p1, v0, :cond_31

    iget-wide v2, p0, Lcom/android/mms/tzib/TzibConversationStyle;->lastPhysicalSend:J

    const-wide/16 v4, 0x0

    cmp-long p1, v2, v4

    if-eqz p1, :cond_2e

    .line 206
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iget-wide v4, p0, Lcom/android/mms/tzib/TzibConversationStyle;->lastPhysicalSend:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x258

    cmp-long p1, v2, v4

    if-lez p1, :cond_31

    .line 207
    :cond_2e
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->send()V

    .line 209
    :cond_31
    return v1
.end method

.method public static install(Landroid/app/Activity;)V
    .registers 4

    .line 74
    new-instance v0, Lcom/android/mms/tzib/TzibConversationStyle;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibConversationStyle;-><init>(Landroid/app/Activity;)V

    .line 75
    iget-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v1, v0}, Landroid/widget/ListView;->setTag(Ljava/lang/Object;)V

    .line 76
    iget-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    new-instance v2, Lcom/android/mms/tzib/TzibConversationStyle$1;

    invoke-direct {v2, v0}, Lcom/android/mms/tzib/TzibConversationStyle$1;-><init>(Lcom/android/mms/tzib/TzibConversationStyle;)V

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 80
    iget-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v1

    new-instance v2, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda5;

    invoke-direct {v2, v0}, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda5;-><init>(Lcom/android/mms/tzib/TzibConversationStyle;)V

    invoke-virtual {v1, v2}, Landroid/view/ViewTreeObserver;->addOnGlobalFocusChangeListener(Landroid/view/ViewTreeObserver$OnGlobalFocusChangeListener;)V

    .line 84
    invoke-direct {v0}, Lcom/android/mms/tzib/TzibConversationStyle;->attachMenuBar()Z

    move-result v1

    if-nez v1, :cond_29

    return-void

    .line 85
    :cond_29
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const-string v2, "tzib_legacy_controls"

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v1

    .line 86
    if-eqz v1, :cond_3e

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 87
    :cond_3e
    iget-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getId()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setNextFocusDownId(I)V

    .line 88
    iget-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    new-instance v2, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda6;

    invoke-direct {v2, v0, p0}, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda6;-><init>(Lcom/android/mms/tzib/TzibConversationStyle;Landroid/app/Activity;)V

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 105
    iget-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    new-instance v2, Lcom/android/mms/tzib/TzibConversationStyle$2;

    invoke-direct {v2, v0}, Lcom/android/mms/tzib/TzibConversationStyle$2;-><init>(Lcom/android/mms/tzib/TzibConversationStyle;)V

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 110
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->refresh(Landroid/app/Activity;)V

    .line 111
    return-void
.end method

.method public static key(Landroid/app/Activity;Landroid/view/KeyEvent;)Z
    .registers 12

    .line 179
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->get(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibConversationStyle;

    move-result-object v0

    .line 180
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v1

    .line 181
    const/4 v2, 0x0

    if-eqz v0, :cond_68

    iget-object v3, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    if-eqz v3, :cond_68

    const/16 v3, 0x52

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eq v1, v3, :cond_1a

    if-eq v1, v4, :cond_1a

    if-eq v1, v5, :cond_1a

    goto :goto_68

    .line 184
    :cond_1a
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v6

    if-ne v6, v5, :cond_67

    invoke-virtual {p1}, Landroid/view/KeyEvent;->isCanceled()Z

    move-result v6

    if-nez v6, :cond_67

    .line 185
    invoke-direct {v0}, Lcom/android/mms/tzib/TzibConversationStyle;->updateSoftkeys()V

    .line 186
    if-eq v1, v5, :cond_31

    .line 187
    iget-object v6, v0, Lcom/android/mms/tzib/TzibConversationStyle;->choiceTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

    iput-object v6, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

    .line 188
    iput-boolean v5, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuOpen:Z

    .line 190
    :cond_31
    :try_start_31
    iget-object v6, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    const-string v7, "onKeyUp"

    new-array v8, v4, [Ljava/lang/Class;

    sget-object v9, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v9, v8, v2

    const-class v9, Landroid/view/KeyEvent;

    aput-object v9, v8, v5

    invoke-virtual {v6, v7, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v6

    iget-object v7, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    new-array v8, v4, [Ljava/lang/Object;

    .line 191
    if-ne v1, v3, :cond_4e

    move v1, v4

    :cond_4e
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v8, v2

    aput-object p1, v8, v5

    invoke-virtual {v6, v7, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_59
    .catch Ljava/lang/Exception; {:try_start_31 .. :try_end_59} :catch_5a

    .line 196
    goto :goto_67

    .line 192
    :catch_5a
    move-exception p1

    .line 193
    iput-boolean v2, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuOpen:Z

    .line 194
    const-string v0, "tzib"

    const-string v1, "Could not open native options"

    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 195
    invoke-virtual {p0}, Landroid/app/Activity;->openOptionsMenu()V

    .line 198
    :cond_67
    :goto_67
    return v5

    .line 183
    :cond_68
    :goto_68
    return v2
.end method

.method static synthetic lambda$install$0(Lcom/android/mms/tzib/TzibConversationStyle;Landroid/view/View;Landroid/view/View;)V
    .registers 3

    .line 81
    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    if-eq p2, p1, :cond_9

    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->sendKey:Lcom/android/mms/tzib/TzibSendKey;

    invoke-virtual {p1}, Lcom/android/mms/tzib/TzibSendKey;->reset()V

    .line 82
    :cond_9
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->updateSoftkeys()V

    .line 83
    return-void
.end method

.method static synthetic lambda$install$1(Lcom/android/mms/tzib/TzibConversationStyle;)V
    .registers 3

    .line 90
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->lastPhysicalSend:J

    .line 91
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->send()V

    .line 92
    return-void
.end method

.method static synthetic lambda$install$2(Lcom/android/mms/tzib/TzibConversationStyle;Landroid/app/Activity;Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .registers 7

    .line 89
    iget-object p2, p0, Lcom/android/mms/tzib/TzibConversationStyle;->sendKey:Lcom/android/mms/tzib/TzibSendKey;

    new-instance v0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda2;-><init>(Lcom/android/mms/tzib/TzibConversationStyle;)V

    invoke-virtual {p2, p4, v0}, Lcom/android/mms/tzib/TzibSendKey;->handle(Landroid/view/KeyEvent;Ljava/lang/Runnable;)Z

    move-result p2

    const/4 v0, 0x1

    if-eqz p2, :cond_f

    .line 92
    return v0

    .line 93
    :cond_f
    invoke-virtual {p4}, Landroid/view/KeyEvent;->getAction()I

    move-result p2

    const/4 p4, 0x0

    if-nez p2, :cond_6c

    iget-object p2, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {p2}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object p2

    if-nez p2, :cond_1f

    goto :goto_6c

    .line 94
    :cond_1f
    iget-object p2, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {p2}, Landroid/widget/EditText;->getSelectionStart()I

    move-result p2

    invoke-static {p4, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    .line 95
    iget-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object v1

    invoke-virtual {v1, p2}, Landroid/text/Layout;->getLineForOffset(I)I

    move-result p2

    .line 96
    const/16 v1, 0x13

    if-ne p3, v1, :cond_5c

    if-nez p2, :cond_5c

    iget-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getCount()I

    move-result v1

    if-lez v1, :cond_5c

    .line 98
    :try_start_41
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const-string p2, "tzibFocusMessages"

    new-array p3, p4, [Ljava/lang/Class;

    invoke-virtual {p0, p2, p3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0

    new-array p2, p4, [Ljava/lang/Object;

    invoke-virtual {p0, p1, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_52
    .catch Ljava/lang/Exception; {:try_start_41 .. :try_end_52} :catch_53

    .line 99
    goto :goto_5b

    :catch_53
    move-exception p0

    const-string p1, "tzib"

    const-string p2, "Could not focus messages"

    invoke-static {p1, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 100
    :goto_5b
    return v0

    .line 103
    :cond_5c
    const/16 p1, 0x14

    if-ne p3, p1, :cond_6a

    iget-object p0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {p0}, Landroid/widget/EditText;->getLineCount()I

    move-result p0

    sub-int/2addr p0, v0

    if-ne p2, p0, :cond_6a

    goto :goto_6b

    :cond_6a
    move v0, p4

    :goto_6b
    return v0

    .line 93
    :cond_6c
    :goto_6c
    return p4
.end method

.method static synthetic lambda$messageOption$5(Lcom/android/mms/tzib/TzibConversationStyle;II)V
    .registers 4

    .line 273
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getCount()I

    move-result v0

    if-lez v0, :cond_41

    .line 274
    const/4 v0, 0x0

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getCount()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    move-result p1

    .line 275
    :goto_19
    if-lez p1, :cond_2a

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/widget/ListAdapter;->isEnabled(I)Z

    move-result v0

    if-nez v0, :cond_2a

    add-int/lit8 p1, p1, -0x1

    goto :goto_19

    .line 276
    :cond_2a
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/widget/ListAdapter;->isEnabled(I)Z

    move-result v0

    if-eqz v0, :cond_40

    .line 277
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->requestFocus()Z

    .line 278
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v0, p1, p2}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    .line 280
    :cond_40
    goto :goto_5c

    :cond_41
    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->panel:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    if-nez p1, :cond_4f

    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->requestFocus()Z

    goto :goto_5c

    .line 281
    :cond_4f
    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->notice:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->isFocusable()Z

    move-result p1

    if-eqz p1, :cond_5c

    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->notice:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    .line 282
    :cond_5c
    :goto_5c
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->updateSoftkeys()V

    .line 283
    return-void
.end method

.method static synthetic lambda$messageOption$6(Lcom/android/mms/tzib/TzibConversationStyle;II)V
    .registers 5

    .line 272
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    new-instance v1, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1, p2}, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda0;-><init>(Lcom/android/mms/tzib/TzibConversationStyle;II)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static messageOption(Landroid/app/Activity;I)Z
    .registers 7

    .line 265
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibClipboard;->option(Landroid/app/Activity;I)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    return v1

    .line 266
    :cond_8
    const/16 v0, 0x2396

    const/4 v2, 0x0

    if-eq p1, v0, :cond_12

    const/16 v0, 0x2397

    if-eq p1, v0, :cond_12

    return v2

    .line 267
    :cond_12
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->get(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibConversationStyle;

    move-result-object v0

    .line 268
    if-nez v0, :cond_19

    return v1

    .line 269
    :cond_19
    iget-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v1

    .line 270
    iget-object v3, v0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v3}, Landroid/widget/ListView;->getSelectedView()Landroid/view/View;

    move-result-object v3

    .line 271
    if-nez v3, :cond_28

    goto :goto_2c

    :cond_28
    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    move-result v2

    .line 272
    :goto_2c
    iget-object v3, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

    new-instance v4, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda3;

    invoke-direct {v4, v0, v1, v2}, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda3;-><init>(Lcom/android/mms/tzib/TzibConversationStyle;II)V

    invoke-static {p0, p1, v3, v4}, Lcom/android/mms/tzib/TzibMessageActions;->perform(Landroid/app/Activity;ILcom/android/mms/tzib/TzibMessageActions$Target;Ljava/lang/Runnable;)Z

    move-result p0

    return p0
.end method

.method static prepareMessageMenu(Landroid/app/Activity;Landroid/view/Menu;)V
    .registers 7

    .line 252
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibClipboard;->prepare(Landroid/app/Activity;Landroid/view/Menu;)V

    .line 253
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->get(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibConversationStyle;

    move-result-object v0

    .line 254
    const/16 v1, 0x2396

    invoke-interface {p1, v1}, Landroid/view/Menu;->removeItem(I)V

    .line 255
    const/16 v2, 0x2397

    invoke-interface {p1, v2}, Landroid/view/Menu;->removeItem(I)V

    .line 256
    if-nez v0, :cond_14

    return-void

    .line 257
    :cond_14
    iget-boolean v3, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuOpen:Z

    if-nez v3, :cond_20

    iget-object v3, v0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-static {p0, v3}, Lcom/android/mms/tzib/TzibMessageActions;->selected(Landroid/app/Activity;Landroid/widget/ListView;)Lcom/android/mms/tzib/TzibMessageActions$Target;

    move-result-object v3

    iput-object v3, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

    .line 258
    :cond_20
    iget-object v0, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

    if-eqz v0, :cond_3a

    .line 259
    const-string v0, "tzb_msg_copy"

    const-string v3, "string"

    invoke-static {p0, v3, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x0

    invoke-interface {p1, v4, v1, v4, v0}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    .line 260
    const-string v0, "delete_message"

    invoke-static {p0, v3, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    const/4 v0, 0x1

    invoke-interface {p1, v4, v2, v0, p0}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    .line 262
    :cond_3a
    return-void
.end method

.method public static refresh(Landroid/app/Activity;)V
    .registers 4

    .line 213
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->get(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibConversationStyle;

    move-result-object v0

    .line 214
    if-eqz v0, :cond_28

    iget-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    if-eqz v1, :cond_28

    iget-boolean v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->menuOpen:Z

    if-eqz v1, :cond_f

    goto :goto_28

    .line 215
    :cond_f
    new-instance v1, Landroid/widget/PopupMenu;

    iget-object v2, v0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-direct {v1, p0, v2}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    invoke-virtual {v1}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    iput-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->options:Landroid/view/Menu;

    .line 216
    invoke-virtual {p0, v1}, Landroid/app/Activity;->onCreateOptionsMenu(Landroid/view/Menu;)Z

    .line 217
    iget-object v1, v0, Lcom/android/mms/tzib/TzibConversationStyle;->options:Landroid/view/Menu;

    invoke-virtual {p0, v1}, Landroid/app/Activity;->onPrepareOptionsMenu(Landroid/view/Menu;)Z

    .line 218
    invoke-direct {v0}, Lcom/android/mms/tzib/TzibConversationStyle;->updateSoftkeys()V

    .line 219
    return-void

    .line 214
    :cond_28
    :goto_28
    return-void
.end method

.method public static requestWindow(Landroid/app/Activity;)V
    .registers 3

    .line 69
    const/16 v0, 0xe

    :try_start_2
    invoke-virtual {p0, v0}, Landroid/app/Activity;->requestWindowFeature(I)Z
    :try_end_5
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_5} :catch_6

    .line 70
    goto :goto_e

    :catch_6
    move-exception p0

    const-string v0, "tzib"

    const-string v1, "Native softkey window unavailable"

    invoke-static {v0, v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 71
    :goto_e
    return-void
.end method

.method static resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I
    .registers 4

    .line 56
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p2, p1, p0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private send()V
    .registers 2

    .line 171
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->panel:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_31

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_31

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    .line 172
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_31

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_31

    .line 173
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->sendButton:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->performClick()Z

    .line 175
    :cond_31
    return-void
.end method

.method private updateSoftkeys()V
    .registers 14

    .line 221
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    if-eqz v0, :cond_15d

    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuOpen:Z

    if-eqz v0, :cond_a

    goto/16 :goto_15d

    .line 222
    :cond_a
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibMessageActions;->selected(Landroid/app/Activity;Landroid/widget/ListView;)Lcom/android/mms/tzib/TzibMessageActions$Target;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->choiceTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

    .line 223
    nop

    .line 224
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->hasFocus()Z

    move-result v0

    const/4 v1, 0x0

    const-string v2, "string"

    if-eqz v0, :cond_49

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->panel:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_49

    .line 225
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->editor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6f

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    const-string v3, "send"

    invoke-static {v0, v2, v3}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_70

    .line 226
    :cond_49
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->notice:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_5c

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->notice:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isClickable()Z

    move-result v0

    if-eqz v0, :cond_5c

    const-string v0, "Open"

    goto :goto_70

    .line 227
    :cond_5c
    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_6f

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v0

    if-ltz v0, :cond_6f

    const-string v0, "View"

    goto :goto_70

    .line 228
    :cond_6f
    move-object v0, v1

    :goto_70
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 229
    iget-object v4, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    invoke-static {v4, v3}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V

    .line 230
    iget-object v4, p0, Lcom/android/mms/tzib/TzibConversationStyle;->choiceTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

    if-eqz v4, :cond_b2

    .line 231
    new-instance v4, Landroid/util/Pair;

    const/16 v5, 0x2396

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget-object v6, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    const-string v7, "tzb_msg_copy"

    invoke-static {v6, v2, v7}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 232
    new-instance v4, Landroid/util/Pair;

    const/16 v5, 0x2397

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget-object v6, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    const-string v7, "delete_message"

    invoke-static {v6, v2, v7}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 234
    :cond_b2
    const-string v4, "tzb_menu_members"

    const-string v5, "tzb_menu_refresh"

    const-string v6, "tzb_menu_group_info"

    const-string v7, "tzb_menu_mute"

    filled-new-array {v6, v4, v7, v5}, [Ljava/lang/String;

    move-result-object v4

    .line 235
    const/4 v5, 0x0

    move v6, v5

    :goto_c0
    const/4 v8, 0x4

    if-ge v6, v8, :cond_121

    aget-object v8, v4, v6

    .line 236
    iget-object v9, p0, Lcom/android/mms/tzib/TzibConversationStyle;->options:Landroid/view/Menu;

    if-nez v9, :cond_cb

    move-object v9, v1

    goto :goto_d7

    :cond_cb
    iget-object v10, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    const-string v11, "id"

    invoke-static {v10, v11, v8}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v10

    invoke-interface {v9, v10}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v9

    .line 237
    :goto_d7
    if-eqz v9, :cond_11e

    invoke-interface {v9}, Landroid/view/MenuItem;->isVisible()Z

    move-result v10

    if-eqz v10, :cond_11e

    invoke-interface {v9}, Landroid/view/MenuItem;->isEnabled()Z

    move-result v10

    if-nez v10, :cond_e6

    goto :goto_11e

    .line 238
    :cond_e6
    nop

    .line 239
    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_104

    iget-object v10, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    const-string v11, "tzb_menu_unmute"

    invoke-static {v10, v2, v11}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v10

    invoke-interface {v9}, Landroid/view/MenuItem;->getTitle()Ljava/lang/CharSequence;

    move-result-object v12

    invoke-virtual {v10, v12}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_104

    .line 240
    move-object v8, v11

    .line 242
    :cond_104
    new-instance v10, Landroid/util/Pair;

    invoke-interface {v9}, Landroid/view/MenuItem;->getItemId()I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    iget-object v11, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    invoke-static {v11, v2, v8}, Lcom/android/mms/tzib/TzibConversationStyle;->resource(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v10, v9, v8}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v3, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 235
    :cond_11e
    :goto_11e
    add-int/lit8 v6, v6, 0x1

    goto :goto_c0

    .line 245
    :cond_121
    :try_start_121
    iget-object v2, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const-string v4, "updateMenuBar"

    new-array v6, v8, [Ljava/lang/Class;

    const-class v7, Ljava/lang/String;

    aput-object v7, v6, v5

    const-class v7, Ljava/lang/String;

    const/4 v9, 0x1

    aput-object v7, v6, v9

    const-class v7, Ljava/lang/String;

    const/4 v10, 0x2

    aput-object v7, v6, v10

    const-class v7, Ljava/util/List;

    const/4 v11, 0x3

    aput-object v7, v6, v11

    invoke-virtual {v2, v4, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    iget-object v4, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuBar:Ljava/lang/Object;

    new-array v6, v8, [Ljava/lang/Object;

    aput-object v1, v6, v5

    aput-object v0, v6, v9

    const-string v0, "Options"

    aput-object v0, v6, v10

    aput-object v3, v6, v11

    .line 246
    invoke-virtual {v2, v4, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_153
    .catch Ljava/lang/Exception; {:try_start_121 .. :try_end_153} :catch_154

    .line 247
    goto :goto_15c

    :catch_154
    move-exception v0

    const-string v1, "tzib"

    const-string v2, "Could not update conversation softkeys"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 248
    :goto_15c
    return-void

    .line 221
    :cond_15d
    :goto_15d
    return-void
.end method


# virtual methods
.method synthetic lambda$attachMenuBar$3$com-android-mms-tzib-TzibConversationStyle()V
    .registers 2

    .line 134
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuOpen:Z

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibConversationStyle;->refresh(Landroid/app/Activity;)V

    return-void
.end method

.method synthetic lambda$attachMenuBar$4$com-android-mms-tzib-TzibConversationStyle(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    .line 121
    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    .line 123
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    .line 121
    sparse-switch v1, :sswitch_data_104

    :cond_11
    goto :goto_6d

    :sswitch_12
    const-string v1, "onOptionMenuDismiss"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    const/4 v0, 0x4

    goto :goto_6e

    :sswitch_1c
    const-string v1, "onOptionMenuClick"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    const/4 v0, 0x5

    goto :goto_6e

    :sswitch_26
    const-string v1, "hashCode"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    const/4 v0, 0x7

    goto :goto_6e

    :sswitch_30
    const-string v1, "onClickRSK"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    const/4 v0, 0x2

    goto :goto_6e

    :sswitch_3a
    const-string v1, "onClickLSK"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    move v0, v2

    goto :goto_6e

    :sswitch_44
    const-string v1, "onClickCSK"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    move v0, v3

    goto :goto_6e

    :sswitch_4e
    const-string v1, "equals"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    const/16 v0, 0x8

    goto :goto_6e

    :sswitch_59
    const-string v1, "toString"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    const/4 v0, 0x6

    goto :goto_6e

    :sswitch_63
    const-string v1, "onOptionMenuShow"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    const/4 v0, 0x3

    goto :goto_6e

    :goto_6d
    const/4 v0, -0x1

    :goto_6e
    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_12a

    .line 147
    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object p1

    sget-object p2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    if-ne p1, p2, :cond_102

    goto/16 :goto_103

    .line 146
    :pswitch_7c
    aget-object p2, p3, v3

    if-ne p1, p2, :cond_81

    goto :goto_82

    :cond_81
    move v2, v3

    :goto_82
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1

    .line 145
    :pswitch_87
    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1

    .line 144
    :pswitch_90
    const-string p1, "Tzibbur conversation softkeys"

    return-object p1

    .line 137
    :pswitch_93
    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    aget-object p2, p3, v3

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {p1, p2}, Lcom/android/mms/tzib/TzibClipboard;->option(Landroid/app/Activity;I)Z

    move-result p1

    if-eqz p1, :cond_a4

    return-object v1

    .line 138
    :cond_a4
    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    aget-object p2, p3, v3

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {p1, p2}, Lcom/android/mms/tzib/TzibConversationStyle;->messageOption(Landroid/app/Activity;I)Z

    move-result p1

    if-eqz p1, :cond_b5

    return-object v1

    .line 139
    :cond_b5
    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->options:Landroid/view/Menu;

    if-nez p1, :cond_bb

    move-object p1, v1

    goto :goto_c7

    :cond_bb
    aget-object p2, p3, v3

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-interface {p1, p2}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    .line 140
    :goto_c7
    if-eqz p1, :cond_e2

    invoke-interface {p1}, Landroid/view/MenuItem;->isVisible()Z

    move-result p2

    if-eqz p2, :cond_e2

    invoke-interface {p1}, Landroid/view/MenuItem;->isEnabled()Z

    move-result p2

    if-eqz p2, :cond_e2

    iget-object p2, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    invoke-static {p2}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p2

    if-eqz p2, :cond_e2

    .line 141
    iget-object p2, p0, Lcom/android/mms/tzib/TzibConversationStyle;->activity:Landroid/app/Activity;

    invoke-virtual {p2, p1}, Landroid/app/Activity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    .line 143
    :cond_e2
    return-object v1

    .line 134
    :pswitch_e3
    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->list:Landroid/widget/ListView;

    new-instance p2, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda4;

    invoke-direct {p2, p0}, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda4;-><init>(Lcom/android/mms/tzib/TzibConversationStyle;)V

    invoke-virtual {p1, p2}, Landroid/widget/ListView;->post(Ljava/lang/Runnable;)Z

    .line 135
    return-object v1

    .line 129
    :pswitch_ee
    iput-boolean v2, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuOpen:Z

    .line 130
    return-object v1

    .line 125
    :pswitch_f1
    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->choiceTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

    iput-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuTarget:Lcom/android/mms/tzib/TzibMessageActions$Target;

    .line 126
    iput-boolean v2, p0, Lcom/android/mms/tzib/TzibConversationStyle;->menuOpen:Z

    .line 127
    return-object v4

    .line 123
    :pswitch_f8
    return-object v4

    .line 122
    :pswitch_f9
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->centerClick()Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1

    .line 147
    :cond_102
    move-object v4, v1

    :goto_103
    return-object v4

    :sswitch_data_104
    .sparse-switch
        -0x794c13b0 -> :sswitch_63
        -0x69e9ad94 -> :sswitch_59
        -0x4d378041 -> :sswitch_4e
        -0x24dee9ae -> :sswitch_44
        -0x24dec7e5 -> :sswitch_3a
        -0x24deb15f -> :sswitch_30
        0x8cdac1b -> :sswitch_26
        0x4ee9de95 -> :sswitch_1c
        0x6c45bc57 -> :sswitch_12
    .end sparse-switch

    :pswitch_data_12a
    .packed-switch 0x0
        :pswitch_f9
        :pswitch_f8
        :pswitch_f1
        :pswitch_ee
        :pswitch_e3
        :pswitch_93
        :pswitch_90
        :pswitch_87
        :pswitch_7c
    .end packed-switch
.end method
