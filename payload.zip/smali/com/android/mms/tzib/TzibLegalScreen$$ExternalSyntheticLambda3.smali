.class public final synthetic Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibLegalScreen;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibLegalScreen;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda3;->f$0:Lcom/android/mms/tzib/TzibLegalScreen;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda3;->f$0:Lcom/android/mms/tzib/TzibLegalScreen;

    invoke-virtual {v0, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->lambda$onCreate$0$com-android-mms-tzib-TzibLegalScreen(Landroid/view/View;)V

    return-void
.end method
