.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic f$0:Lcom/tzibbur/basic/core/TzbCore;


# direct methods
.method public synthetic constructor <init>(Lcom/tzibbur/basic/core/TzbCore;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda8;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda8;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibSettings;->lambda$devices$19(Lcom/tzibbur/basic/core/TzbCore;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
