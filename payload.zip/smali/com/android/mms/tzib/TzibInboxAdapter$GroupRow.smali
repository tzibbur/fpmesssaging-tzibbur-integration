.class final Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;
.super Ljava/lang/Object;
.source "TzibInboxAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/mms/tzib/TzibInboxAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "GroupRow"
.end annotation


# instance fields
.field final date:J

.field final group:Lcom/tzibbur/basic/model/TzbGroup;

.field final preview:Ljava/lang/String;

.field final readThrough:J

.field final unread:I


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/model/TzbGroup;Lcom/tzibbur/basic/model/TzbMessage;IJ)V
    .registers 13

    .line 43
    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-wide v4, p4

    invoke-direct/range {v0 .. v6}, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;-><init>(Lcom/tzibbur/basic/model/TzbGroup;Lcom/tzibbur/basic/model/TzbMessage;IJLcom/tzibbur/basic/store/TzbOutboxItem;)V

    .line 44
    return-void
.end method

.method constructor <init>(Lcom/tzibbur/basic/model/TzbGroup;Lcom/tzibbur/basic/model/TzbMessage;IJLcom/tzibbur/basic/store/TzbOutboxItem;)V
    .registers 10

    .line 45
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    iput-object p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    .line 47
    if-eqz p6, :cond_25

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p6, Lcom/tzibbur/basic/store/TzbOutboxItem;->state:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_14

    const-string v1, "Not sent: "

    goto :goto_16

    :cond_14
    const-string v1, "Sending: "

    :goto_16
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p6, Lcom/tzibbur/basic/store/TzbOutboxItem;->body:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_2c

    .line 48
    :cond_25
    if-nez p2, :cond_2a

    const-string v0, ""

    goto :goto_2c

    :cond_2a
    iget-object v0, p2, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    :goto_2c
    iput-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->preview:Ljava/lang/String;

    .line 49
    if-nez p6, :cond_33

    const-wide/16 v0, 0x0

    goto :goto_35

    :cond_33
    iget-wide v0, p6, Lcom/tzibbur/basic/store/TzbOutboxItem;->createdAtMillis:J

    .line 50
    :goto_35
    if-nez p2, :cond_3a

    iget-object p1, p1, Lcom/tzibbur/basic/model/TzbGroup;->createdAt:Ljava/lang/String;

    goto :goto_3c

    :cond_3a
    iget-object p1, p2, Lcom/tzibbur/basic/model/TzbMessage;->createdAt:Ljava/lang/String;

    :goto_3c
    invoke-static {p1}, Lcom/android/mms/tzib/TzibInboxAdapter;->timestamp(Ljava/lang/String;)J

    move-result-wide p1

    .line 49
    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p1

    iput-wide p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->date:J

    .line 51
    iput p3, p0, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->unread:I

    .line 52
    iput-wide p4, p0, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->readThrough:J

    .line 53
    return-void
.end method
