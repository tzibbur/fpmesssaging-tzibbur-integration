.class public final synthetic Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibConversationStyle;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibConversationStyle;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda4;->f$0:Lcom/android/mms/tzib/TzibConversationStyle;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda4;->f$0:Lcom/android/mms/tzib/TzibConversationStyle;

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibConversationStyle;->lambda$attachMenuBar$3$com-android-mms-tzib-TzibConversationStyle()V

    return-void
.end method
