.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Z


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Ljava/lang/String;Z)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda6;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda6;->f$1:Ljava/lang/String;

    iput-boolean p3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda6;->f$2:Z

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda6;->f$0:Landroid/app/Activity;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda6;->f$1:Ljava/lang/String;

    iget-boolean v2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda6;->f$2:Z

    invoke-static {v0, v1, v2}, Lcom/android/mms/tzib/TzibSettings;->lambda$answerInvite$30(Landroid/app/Activity;Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v0

    return-object v0
.end method
