.class final Lcom/android/mms/tzib/TzibThreadOptions$Target;
.super Ljava/lang/Object;
.source "TzibThreadOptions.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/mms/tzib/TzibThreadOptions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Target"
.end annotation


# instance fields
.field final group:Ljava/lang/String;

.field final key:Ljava/lang/String;

.field final paused:Z

.field final sms:J


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;JZ)V
    .registers 6

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    iput-object p1, p0, Lcom/android/mms/tzib/TzibThreadOptions$Target;->key:Ljava/lang/String;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibThreadOptions$Target;->group:Ljava/lang/String;

    iput-wide p3, p0, Lcom/android/mms/tzib/TzibThreadOptions$Target;->sms:J

    iput-boolean p5, p0, Lcom/android/mms/tzib/TzibThreadOptions$Target;->paused:Z

    .line 21
    return-void
.end method
