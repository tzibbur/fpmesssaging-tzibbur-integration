.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Z)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda7;->f$0:Landroid/app/Activity;

    iput-boolean p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda7;->f$1:Z

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .registers 4

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda7;->f$0:Landroid/app/Activity;

    iget-boolean v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda7;->f$1:Z

    check-cast p1, Lorg/json/JSONObject;

    invoke-static {v0, v1, p1}, Lcom/android/mms/tzib/TzibSettings;->lambda$answerInvite$31(Landroid/app/Activity;ZLorg/json/JSONObject;)V

    return-void
.end method
