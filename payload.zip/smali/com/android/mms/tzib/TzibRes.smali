.class public final Lcom/android/mms/tzib/TzibRes;
.super Ljava/lang/Object;
.source "TzibRes.java"


# static fields
.field public static final drawable_conversation_item_background_read:I = 0x7f07006f

.field public static final drawable_tzib_logo_bubble:I = 0x7f0701a1

.field public static final id_date:I = 0x7f08007e

.field public static final id_from:I = 0x7f0800b5

.field public static final id_indicator:I = 0x7f0800d0

.field public static final id_subject:I = 0x7f0801ab

.field public static final id_time:I = 0x7f0801ca

.field public static final layout_conversation_list_item:I = 0x7f0a002e

.field public static final string_tzib_row_subtitle:I = 0x7f0e0305

.field public static final string_tzib_row_title:I = 0x7f0e0304


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
