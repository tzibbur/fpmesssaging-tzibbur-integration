.class public final synthetic Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibConversationStyle;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibConversationStyle;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda1;->f$0:Lcom/android/mms/tzib/TzibConversationStyle;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda1;->f$0:Lcom/android/mms/tzib/TzibConversationStyle;

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/mms/tzib/TzibConversationStyle;->lambda$attachMenuBar$4$com-android-mms-tzib-TzibConversationStyle(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
