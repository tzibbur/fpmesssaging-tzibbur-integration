.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda46;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda46;->f$0:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda46;->f$0:Landroid/app/Activity;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibSettings;->lambda$clearSession$43(Landroid/app/Activity;)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method
