.class public final Lcom/android/mms/tzib/TzibThreadOptions;
.super Ljava/lang/Object;
.source "TzibThreadOptions.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/mms/tzib/TzibThreadOptions$State;,
        Lcom/android/mms/tzib/TzibThreadOptions$Target;
    }
.end annotation


# static fields
.field public static final PAUSE:I = 0x23a1

.field private static final states:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/app/Activity;",
            "Lcom/android/mms/tzib/TzibThreadOptions$State;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 24
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Lcom/android/mms/tzib/TzibThreadOptions;->states:Ljava/util/WeakHashMap;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static add(Landroid/app/Activity;Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Ljava/util/List<",
            "Landroid/util/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;)V"
        }
    .end annotation

    .line 44
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->state(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$State;

    move-result-object v0

    .line 45
    iget-boolean v1, v0, Lcom/android/mms/tzib/TzibThreadOptions$State;->open:Z

    if-nez v1, :cond_e

    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->selected(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$Target;

    move-result-object v1

    iput-object v1, v0, Lcom/android/mms/tzib/TzibThreadOptions$State;->offered:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    .line 46
    :cond_e
    iget-object v0, v0, Lcom/android/mms/tzib/TzibThreadOptions$State;->offered:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    .line 47
    if-eqz v0, :cond_32

    new-instance v1, Landroid/util/Pair;

    const/16 v2, 0x23a1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    .line 48
    iget-boolean v0, v0, Lcom/android/mms/tzib/TzibThreadOptions$Target;->paused:Z

    if-eqz v0, :cond_21

    const-string v0, "tzib_unpause_notifications"

    goto :goto_23

    :cond_21
    const-string v0, "tzib_pause_notifications"

    .line 47
    :goto_23
    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibHook;->resource(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-direct {v1, v2, p0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p0, 0x0

    invoke-interface {p1, p0, v1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 49
    :cond_32
    return-void
.end method

.method public static dismissed(Landroid/app/Activity;)V
    .registers 3

    .line 59
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcom/android/mms/tzib/TzibThreadOptions$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/android/mms/tzib/TzibThreadOptions$$ExternalSyntheticLambda0;-><init>(Landroid/app/Activity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 63
    return-void
.end method

.method public static isOpen(Landroid/app/Activity;)Z
    .registers 1

    .line 42
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->state(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$State;

    move-result-object p0

    iget-boolean p0, p0, Lcom/android/mms/tzib/TzibThreadOptions$State;->open:Z

    return p0
.end method

.method static synthetic lambda$dismissed$0(Landroid/app/Activity;)V
    .registers 3

    .line 60
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->state(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$State;

    move-result-object v0

    const/4 v1, 0x0

    iput-boolean v1, v0, Lcom/android/mms/tzib/TzibThreadOptions$State;->open:Z

    .line 61
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->inboxChanged(Landroid/app/Activity;)V

    .line 62
    return-void
.end method

.method public static opened(Landroid/app/Activity;)V
    .registers 3

    .line 51
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->state(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$State;

    move-result-object v0

    .line 52
    iget-object v1, v0, Lcom/android/mms/tzib/TzibThreadOptions$State;->offered:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    iput-object v1, v0, Lcom/android/mms/tzib/TzibThreadOptions$State;->selected:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    .line 53
    const/4 v1, 0x1

    iput-boolean v1, v0, Lcom/android/mms/tzib/TzibThreadOptions$State;->open:Z

    .line 54
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;

    move-result-object p0

    .line 55
    if-eqz p0, :cond_14

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->userInteracted()V

    .line 56
    :cond_14
    return-void
.end method

.method public static option(Landroid/app/Activity;I)Z
    .registers 7

    .line 73
    const/16 v0, 0x23a1

    const/4 v1, 0x0

    if-eq p1, v0, :cond_6

    return v1

    .line 74
    :cond_6
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->state(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$State;

    move-result-object p1

    iget-object p1, p1, Lcom/android/mms/tzib/TzibThreadOptions$State;->selected:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    .line 75
    const/4 v0, 0x1

    if-nez p1, :cond_10

    return v0

    .line 76
    :cond_10
    iget-object v2, p1, Lcom/android/mms/tzib/TzibThreadOptions$Target;->group:Ljava/lang/String;

    if-eqz v2, :cond_29

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_28

    iget-object v2, p1, Lcom/android/mms/tzib/TzibThreadOptions$Target;->key:Ljava/lang/String;

    iget-object v3, p1, Lcom/android/mms/tzib/TzibThreadOptions$Target;->group:Ljava/lang/String;

    .line 77
    invoke-static {p0, v3}, Lcom/android/mms/tzib/TzibNotifications;->groupKey(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_29

    :cond_28
    return v0

    .line 78
    :cond_29
    iget-boolean v2, p1, Lcom/android/mms/tzib/TzibThreadOptions$Target;->paused:Z

    .line 79
    xor-int/2addr v2, v0

    iget-object v3, p1, Lcom/android/mms/tzib/TzibThreadOptions$Target;->key:Ljava/lang/String;

    invoke-static {p0, v3, v2}, Lcom/android/mms/tzib/TzibNotifications;->setPaused(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result v3

    if-nez v3, :cond_3e

    .line 80
    const-string p1, "Could not save notification setting"

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 81
    return v0

    .line 83
    :cond_3e
    iget-object v3, p1, Lcom/android/mms/tzib/TzibThreadOptions$Target;->group:Ljava/lang/String;

    if-eqz v3, :cond_4a

    .line 84
    if-eqz v2, :cond_4f

    iget-object p1, p1, Lcom/android/mms/tzib/TzibThreadOptions$Target;->group:Ljava/lang/String;

    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibNotifications;->cancelGroup(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_4f

    .line 85
    :cond_4a
    iget-wide v3, p1, Lcom/android/mms/tzib/TzibThreadOptions$Target;->sms:J

    invoke-static {p0, v3, v4, v2}, Lcom/android/mms/tzib/TzibNotifications;->refreshSms(Landroid/content/Context;JZ)V

    .line 86
    :cond_4f
    :goto_4f
    if-eqz v2, :cond_54

    const-string p1, "Notifications paused"

    goto :goto_56

    :cond_54
    const-string p1, "Notifications unpaused"

    :goto_56
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 87
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;

    move-result-object p0

    .line 88
    if-eqz p0, :cond_66

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->notifyDataSetChanged()V

    .line 89
    :cond_66
    return v0
.end method

.method public static prepare(Landroid/app/Activity;Landroid/view/Menu;)V
    .registers 5

    .line 65
    const/16 v0, 0x23a1

    invoke-interface {p1, v0}, Landroid/view/Menu;->removeItem(I)V

    .line 66
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->state(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$State;

    move-result-object v1

    .line 67
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->selected(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$Target;

    move-result-object v2

    iput-object v2, v1, Lcom/android/mms/tzib/TzibThreadOptions$State;->offered:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    .line 68
    iget-object v2, v1, Lcom/android/mms/tzib/TzibThreadOptions$State;->offered:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    iput-object v2, v1, Lcom/android/mms/tzib/TzibThreadOptions$State;->selected:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    .line 69
    iget-object v2, v1, Lcom/android/mms/tzib/TzibThreadOptions$State;->offered:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    if-eqz v2, :cond_2a

    .line 70
    iget-object v1, v1, Lcom/android/mms/tzib/TzibThreadOptions$State;->offered:Lcom/android/mms/tzib/TzibThreadOptions$Target;

    iget-boolean v1, v1, Lcom/android/mms/tzib/TzibThreadOptions$Target;->paused:Z

    if-eqz v1, :cond_20

    const-string v1, "tzib_unpause_notifications"

    goto :goto_22

    :cond_20
    const-string v1, "tzib_pause_notifications"

    .line 69
    :goto_22
    invoke-static {p0, v1}, Lcom/android/mms/tzib/TzibHook;->resource(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    const/4 v1, 0x0

    invoke-interface {p1, v1, v0, v1, p0}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    .line 71
    :cond_2a
    return-void
.end method

.method static selected(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$Target;
    .registers 12

    .line 31
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;

    move-result-object v0

    .line 32
    const/4 v1, 0x0

    if-eqz v0, :cond_59

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibInboxAdapter;->editing()Z

    move-result v2

    if-eqz v2, :cond_e

    goto :goto_59

    .line 33
    :cond_e
    move-object v2, p0

    check-cast v2, Landroid/app/ListActivity;

    invoke-virtual {v2}, Landroid/app/ListActivity;->getListView()Landroid/widget/ListView;

    move-result-object v2

    .line 34
    invoke-virtual {v2}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v3

    invoke-virtual {v2}, Landroid/widget/ListView;->getHeaderViewsCount()I

    move-result v2

    sub-int/2addr v3, v2

    .line 35
    if-ltz v3, :cond_58

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibInboxAdapter;->getCount()I

    move-result v2

    if-lt v3, v2, :cond_27

    goto :goto_58

    .line 36
    :cond_27
    invoke-virtual {v0, v3}, Lcom/android/mms/tzib/TzibInboxAdapter;->groupAt(I)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object v2

    .line 37
    if-nez v2, :cond_2f

    move-object v7, v1

    goto :goto_34

    :cond_2f
    iget-object v4, v2, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v4, v4, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    move-object v7, v4

    .line 38
    :goto_34
    if-nez v2, :cond_3b

    invoke-virtual {v0, v3}, Lcom/android/mms/tzib/TzibInboxAdapter;->getItemId(I)J

    move-result-wide v3

    goto :goto_3d

    :cond_3b
    const-wide/16 v3, 0x0

    :goto_3d
    move-wide v8, v3

    .line 39
    if-nez v2, :cond_45

    invoke-static {v8, v9}, Lcom/android/mms/tzib/TzibNotifications;->smsKey(J)Ljava/lang/String;

    move-result-object v0

    goto :goto_49

    :cond_45
    invoke-static {p0, v7}, Lcom/android/mms/tzib/TzibNotifications;->groupKey(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_49
    move-object v6, v0

    .line 40
    if-nez v6, :cond_4d

    goto :goto_57

    :cond_4d
    new-instance v1, Lcom/android/mms/tzib/TzibThreadOptions$Target;

    invoke-static {p0, v6}, Lcom/android/mms/tzib/TzibNotifications;->paused(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v10

    move-object v5, v1

    invoke-direct/range {v5 .. v10}, Lcom/android/mms/tzib/TzibThreadOptions$Target;-><init>(Ljava/lang/String;Ljava/lang/String;JZ)V

    :goto_57
    return-object v1

    .line 35
    :cond_58
    :goto_58
    return-object v1

    .line 32
    :cond_59
    :goto_59
    return-object v1
.end method

.method private static state(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibThreadOptions$State;
    .registers 4

    .line 26
    sget-object v0, Lcom/android/mms/tzib/TzibThreadOptions;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/mms/tzib/TzibThreadOptions$State;

    .line 27
    if-nez v1, :cond_13

    new-instance v1, Lcom/android/mms/tzib/TzibThreadOptions$State;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Lcom/android/mms/tzib/TzibThreadOptions$State;-><init>(Lcom/android/mms/tzib/TzibThreadOptions$1;)V

    invoke-virtual {v0, p0, v1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    :cond_13
    return-object v1
.end method
