.class final Lcom/android/mms/tzib/TzibSearch;
.super Ljava/lang/Object;
.source "TzibSearch.java"


# direct methods
.method constructor <init>()V
    .registers 1

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic lambda$open$0(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 3

    .line 19
    if-nez p2, :cond_11

    new-instance p1, Landroid/content/Intent;

    invoke-direct {p1}, Landroid/content/Intent;-><init>()V

    const-string p2, "com.android.mms.ui.SearchConversationActivity"

    invoke-virtual {p1, p0, p2}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    goto :goto_14

    .line 20
    :cond_11
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSearch;->search(Landroid/app/Activity;)V

    .line 21
    :goto_14
    return-void
.end method

.method static synthetic lambda$search$1(Landroid/app/Activity;Ljava/lang/String;)Ljava/util/List;
    .registers 14
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 32
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 33
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object p0

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object p0

    .line 34
    invoke-interface {p0}, Lcom/tzibbur/basic/store/TzbStore;->groups()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_15
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_a5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/tzibbur/basic/model/TzbGroup;

    .line 35
    nop

    .line 36
    iget-object v3, v2, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v3, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_33

    iget-object v3, v2, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    goto :goto_34

    :cond_33
    const/4 v3, 0x0

    .line 37
    :goto_34
    iget-object v4, v2, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    const/16 v5, 0x64

    invoke-interface {p0, v4, v5}, Lcom/tzibbur/basic/store/TzbStore;->latestMessages(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v4

    .line 38
    :goto_3c
    if-nez v3, :cond_7f

    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_7f

    .line 39
    nop

    .line 40
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v6

    add-int/lit8 v6, v6, -0x1

    const-wide v7, 0x7fffffffffffffffL

    :goto_50
    if-ltz v6, :cond_76

    .line 41
    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/tzibbur/basic/model/TzbMessage;

    .line 42
    iget-wide v10, v9, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    invoke-static {v7, v8, v10, v11}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v7

    .line 43
    iget-object v10, v9, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    if-eqz v10, :cond_73

    iget-object v10, v9, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    sget-object v11, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v10, v11}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_73

    iget-object v3, v9, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    goto :goto_76

    .line 40
    :cond_73
    add-int/lit8 v6, v6, -0x1

    goto :goto_50

    .line 45
    :cond_76
    :goto_76
    if-nez v3, :cond_7e

    iget-object v4, v2, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-interface {p0, v4, v7, v8, v5}, Lcom/tzibbur/basic/store/TzbStore;->messagesBefore(Ljava/lang/String;JI)Ljava/util/List;

    move-result-object v4

    .line 46
    :cond_7e
    goto :goto_3c

    .line 47
    :cond_7f
    if-eqz v3, :cond_a3

    iget-object v4, v2, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, v2, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, "\n"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    filled-new-array {v4, v2}, [Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 48
    :cond_a3
    goto/16 :goto_15

    .line 49
    :cond_a5
    return-object v0
.end method

.method static synthetic lambda$search$2(Landroid/app/Activity;Ljava/util/List;Landroid/content/DialogInterface;I)V
    .registers 4

    .line 55
    invoke-interface {p1, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    const/4 p2, 0x0

    aget-object p1, p1, p2

    invoke-static {p0, p1, p2}, Lcom/android/mms/tzib/TzibHook;->openGroup(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic lambda$search$3(Landroid/app/Activity;Ljava/util/List;)V
    .registers 7

    .line 51
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    new-array v1, v0, [Ljava/lang/String;

    .line 52
    const/4 v2, 0x0

    :goto_7
    if-ge v2, v0, :cond_17

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/String;

    const/4 v4, 0x1

    aget-object v3, v3, v4

    aput-object v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    .line 53
    :cond_17
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const-string v3, "Tzibbur results"

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    .line 54
    if-nez v0, :cond_29

    const-string p0, "No downloaded messages match."

    invoke-virtual {v2, p0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    goto :goto_31

    .line 55
    :cond_29
    new-instance v0, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda4;

    invoke-direct {v0, p0, p1}, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda4;-><init>(Landroid/app/Activity;Ljava/util/List;)V

    invoke-virtual {v2, v1, v0}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 56
    :goto_31
    const/high16 p0, 0x1040000

    const/4 p1, 0x0

    invoke-virtual {v2, p0, p1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 57
    return-void
.end method

.method static synthetic lambda$search$4(Landroid/widget/EditText;Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 4

    .line 29
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    sget-object p2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, p2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    .line 30
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_19

    return-void

    .line 31
    :cond_19
    new-instance p2, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda0;

    invoke-direct {p2, p1, p0}, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda0;-><init>(Landroid/app/Activity;Ljava/lang/String;)V

    new-instance p0, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda1;

    invoke-direct {p0, p1}, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda1;-><init>(Landroid/app/Activity;)V

    invoke-static {p1, p2, p0}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    .line 58
    return-void
.end method

.method static open(Landroid/app/Activity;)V
    .registers 4

    .line 17
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Search"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Text messages"

    const-string v2, "Tzibbur messages"

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda3;-><init>(Landroid/app/Activity;)V

    .line 18
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 21
    const/high16 v0, 0x1040000

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 22
    return-void
.end method

.method private static search(Landroid/app/Activity;)V
    .registers 4

    .line 24
    new-instance v0, Landroid/widget/EditText;

    invoke-direct {v0, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 25
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 26
    const-string v1, "Search downloaded messages"

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 27
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const-string v2, "Search Tzibbur"

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda2;

    invoke-direct {v2, v0, p0}, Lcom/android/mms/tzib/TzibSearch$$ExternalSyntheticLambda2;-><init>(Landroid/widget/EditText;Landroid/app/Activity;)V

    .line 28
    const-string p0, "Search"

    invoke-virtual {v1, p0, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 58
    const/high16 v0, 0x1040000

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 59
    return-void
.end method
