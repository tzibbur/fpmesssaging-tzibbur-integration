.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Lcom/tzibbur/basic/core/TzbCore;

.field public final synthetic f$1:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Lcom/tzibbur/basic/core/TzbCore;Landroid/app/Activity;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda9;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda9;->f$1:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .registers 4

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda9;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda9;->f$1:Landroid/app/Activity;

    check-cast p1, Ljava/util/List;

    invoke-static {v0, v1, p1}, Lcom/android/mms/tzib/TzibSettings;->lambda$devices$24(Lcom/tzibbur/basic/core/TzbCore;Landroid/app/Activity;Ljava/util/List;)V

    return-void
.end method
