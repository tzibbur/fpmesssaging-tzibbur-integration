.class public final Lcom/android/mms/tzib/TzibHook;
.super Ljava/lang/Object;
.source "TzibHook.java"


# static fields
.field private static final restored:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/app/Activity;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 20
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Lcom/android/mms/tzib/TzibHook;->restored:Ljava/util/WeakHashMap;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;
    .registers 3

    .line 27
    instance-of v0, p0, Landroid/app/ListActivity;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return-object v1

    .line 28
    :cond_6
    check-cast p0, Landroid/app/ListActivity;

    invoke-virtual {p0}, Landroid/app/ListActivity;->getListAdapter()Landroid/widget/ListAdapter;

    move-result-object p0

    .line 29
    instance-of v0, p0, Landroid/widget/HeaderViewListAdapter;

    if-eqz v0, :cond_16

    check-cast p0, Landroid/widget/HeaderViewListAdapter;

    invoke-virtual {p0}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object p0

    .line 30
    :cond_16
    instance-of v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;

    if-eqz v0, :cond_1d

    move-object v1, p0

    check-cast v1, Lcom/android/mms/tzib/TzibInboxAdapter;

    :cond_1d
    return-object v1
.end method

.method public static allowed(Landroid/content/Context;)Z
    .registers 4

    .line 23
    const/4 v0, 0x0

    :try_start_1
    invoke-static {p0}, Lcom/android/mms/tzib/TzibGate;->sync(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_e

    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result p0
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_b} :catch_f

    if-nez p0, :cond_e

    const/4 v0, 0x1

    :cond_e
    return v0

    .line 24
    :catch_f
    move-exception p0

    const-string v1, "tzib"

    const-string v2, "Could not read gate"

    invoke-static {v1, v2, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v0
.end method

.method public static contextMenu(Landroid/app/Activity;Landroid/view/MenuItem;)Z
    .registers 5

    .line 148
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->selected(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object v0

    .line 149
    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    .line 150
    :cond_8
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    const/4 v2, 0x1

    if-ne p1, v2, :cond_16

    iget-object p1, v0, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object p1, p1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-static {p0, p1, v1}, Lcom/android/mms/tzib/TzibHook;->openGroup(Landroid/app/Activity;Ljava/lang/String;Z)V

    .line 151
    :cond_16
    return v2
.end method

.method public static destroy(Landroid/app/Activity;)V
    .registers 1

    .line 70
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;

    move-result-object p0

    .line 71
    if-eqz p0, :cond_9

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->dispose()V

    .line 72
    :cond_9
    return-void
.end method

.method static groupAt(Landroid/app/Activity;I)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;
    .registers 3

    .line 33
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;

    move-result-object v0

    .line 34
    if-nez v0, :cond_8

    const/4 p0, 0x0

    return-object p0

    .line 35
    :cond_8
    check-cast p0, Landroid/app/ListActivity;

    invoke-virtual {p0}, Landroid/app/ListActivity;->getListView()Landroid/widget/ListView;

    move-result-object p0

    .line 36
    invoke-virtual {p0}, Landroid/widget/ListView;->getHeaderViewsCount()I

    move-result p0

    sub-int/2addr p1, p0

    invoke-virtual {v0, p1}, Lcom/android/mms/tzib/TzibInboxAdapter;->groupAt(I)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object p0

    return-object p0
.end method

.method public static handleClick(Landroid/app/Activity;I)Z
    .registers 3

    .line 79
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibHook;->groupAt(Landroid/app/Activity;I)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object p1

    .line 80
    const/4 v0, 0x0

    if-nez p1, :cond_8

    return v0

    .line 81
    :cond_8
    iget-object p1, p1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object p1, p1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-static {p0, p1, v0}, Lcom/android/mms/tzib/TzibHook;->openGroup(Landroid/app/Activity;Ljava/lang/String;Z)V

    .line 82
    const/4 p0, 0x1

    return p0
.end method

.method public static handleSelected(Landroid/app/Activity;I)Z
    .registers 2

    .line 85
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibHook;->groupAt(Landroid/app/Activity;I)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object p1

    if-nez p1, :cond_8

    const/4 p0, 0x0

    return p0

    .line 86
    :cond_8
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->menu(Landroid/app/Activity;)Z

    .line 87
    const/4 p0, 0x1

    return p0
.end method

.method public static inboxChanged(Landroid/app/Activity;)V
    .registers 5

    .line 74
    :try_start_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v1, "tzibInboxChanged"

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v1, v2, [Ljava/lang/Object;

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_12} :catch_13

    .line 75
    goto :goto_1b

    :catch_13
    move-exception p0

    const-string v0, "tzib"

    const-string v1, "Could not update inbox state"

    invoke-static {v0, v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 76
    :goto_1b
    return-void
.end method

.method public static install(Landroid/app/Activity;Landroid/widget/ListView;)V
    .registers 3

    .line 43
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    .line 44
    new-instance v0, Lcom/android/mms/tzib/TzibHook$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibHook$$ExternalSyntheticLambda1;-><init>(Landroid/app/Activity;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 48
    return-void
.end method

.method public static interacted(Landroid/app/Activity;)V
    .registers 1

    .line 50
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;

    move-result-object p0

    .line 51
    if-eqz p0, :cond_9

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->userInteracted()V

    .line 52
    :cond_9
    return-void
.end method

.method public static keyDown(Landroid/app/Activity;ILandroid/view/KeyEvent;)Z
    .registers 4

    .line 140
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->interacted(Landroid/app/Activity;)V

    .line 141
    const/16 v0, 0x54

    if-ne p1, v0, :cond_18

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_18

    .line 142
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result p1

    if-nez p1, :cond_16

    invoke-static {p0}, Lcom/android/mms/tzib/TzibSearch;->open(Landroid/app/Activity;)V

    .line 143
    :cond_16
    const/4 p0, 0x1

    return p0

    .line 145
    :cond_18
    const/4 p0, 0x0

    return p0
.end method

.method static synthetic lambda$install$0(Landroid/app/Activity;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 3

    .line 45
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    if-nez p1, :cond_9

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->interacted(Landroid/app/Activity;)V

    .line 46
    :cond_9
    const/4 p0, 0x0

    return p0
.end method

.method static synthetic lambda$newMessage$3(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 3

    .line 169
    if-nez p2, :cond_c

    const-wide/16 p1, 0x0

    invoke-static {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->createIntent(Landroid/content/Context;J)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    goto :goto_33

    .line 170
    :cond_c
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_13

    return-void

    .line 171
    :cond_13
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object p1

    invoke-virtual {p1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object p1

    invoke-interface {p1}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result p1

    if-nez p1, :cond_25

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->open(Landroid/app/Activity;)V

    goto :goto_33

    .line 172
    :cond_25
    new-instance p1, Landroid/content/Intent;

    invoke-direct {p1}, Landroid/content/Intent;-><init>()V

    const-string p2, "com.tzibbur.basic.ui.TzbGroupCreateActivity"

    invoke-virtual {p1, p0, p2}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 173
    :goto_33
    return-void
.end method

.method static synthetic lambda$option$1(Landroid/app/Activity;)Ljava/lang/Boolean;
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 115
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object p0

    .line 116
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbStore;->groups()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/tzibbur/basic/model/TzbGroup;

    .line 117
    iget-object v2, v1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v3

    iget-object v4, v1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-interface {v3, v4}, Lcom/tzibbur/basic/store/TzbStore;->lastMessage(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMessage;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/mms/tzib/TzibMetadata;->lastMessage(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbMessage;)Lcom/tzibbur/basic/model/TzbMessage;

    move-result-object v2

    .line 118
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v3

    iget-object v4, v1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    if-nez v2, :cond_37

    iget-wide v5, v1, Lcom/tzibbur/basic/model/TzbGroup;->readSeq:J

    goto :goto_39

    :cond_37
    iget-wide v5, v2, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    :goto_39
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v2

    iget-object v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-interface {v2, v1}, Lcom/tzibbur/basic/store/TzbStore;->maxSeq(Ljava/lang/String;)J

    move-result-wide v1

    invoke-static {v5, v6, v1, v2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    invoke-interface {v3, v4, v1, v2}, Lcom/tzibbur/basic/sync/TzbSync;->markRead(Ljava/lang/String;J)V

    .line 119
    goto :goto_10

    .line 120
    :cond_4b
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$option$2(Ljava/lang/Boolean;)V
    .registers 1

    .line 121
    return-void
.end method

.method public static menu(Landroid/app/Activity;)Z
    .registers 11

    .line 90
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->isOpen(Landroid/app/Activity;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    return v1

    .line 91
    :cond_8
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;

    move-result-object v0

    .line 92
    const/4 v2, 0x0

    if-eqz v0, :cond_cb

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibInboxAdapter;->editing()Z

    move-result v0

    if-nez v0, :cond_cb

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->selected(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object v0

    if-nez v0, :cond_1d

    goto/16 :goto_cb

    .line 94
    :cond_1d
    :try_start_1d
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v3, "mMenuBar"

    invoke-virtual {v0, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    .line 95
    invoke-virtual {v0, v1}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    .line 96
    invoke-virtual {v0, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 97
    if-nez v0, :cond_31

    return v1

    .line 98
    :cond_31
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 99
    invoke-static {p0, v3}, Lcom/android/mms/tzib/TzibThreadOptions;->add(Landroid/app/Activity;Ljava/util/List;)V

    .line 100
    new-instance v4, Landroid/util/Pair;

    const/16 v5, 0x238c

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v6, "tzb_menu_group_info"

    invoke-static {p0, v6}, Lcom/android/mms/tzib/TzibHook;->resource(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 101
    new-instance v4, Landroid/util/Pair;

    const/16 v5, 0x238d

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v6, "tzib_mark_read"

    invoke-static {p0, v6}, Lcom/android/mms/tzib/TzibHook;->resource(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-direct {v4, v5, p0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 102
    new-instance p0, Landroid/util/Pair;

    const/4 v4, 0x3

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v6, 0x7f0e014f

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {p0, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v3, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 103
    new-instance p0, Landroid/util/Pair;

    const/4 v5, 0x2

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v7, 0x7f0e012d

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {p0, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v3, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 104
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const-string v6, "updateMenuBar"

    const/4 v7, 0x4

    new-array v8, v7, [Ljava/lang/Class;

    const-class v9, Ljava/lang/String;

    aput-object v9, v8, v2

    const-class v9, Ljava/lang/String;

    aput-object v9, v8, v1

    const-class v9, Ljava/lang/String;

    aput-object v9, v8, v5

    const-class v9, Ljava/util/List;

    aput-object v9, v8, v4

    invoke-virtual {p0, v6, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0

    new-array v6, v7, [Ljava/lang/Object;

    const-string v7, "New"

    aput-object v7, v6, v2

    const-string v2, "Open"

    aput-object v2, v6, v1

    const-string v2, "Options"

    aput-object v2, v6, v5

    aput-object v3, v6, v4

    .line 105
    invoke-virtual {p0, v0, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_c1
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_c1} :catch_c2

    .line 106
    goto :goto_ca

    :catch_c2
    move-exception p0

    const-string v0, "tzib"

    const-string v2, "Could not set Tzibbur softkeys"

    invoke-static {v0, v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 107
    :goto_ca
    return v1

    .line 92
    :cond_cb
    :goto_cb
    return v2
.end method

.method public static mmsNotificationPosition()I
    .registers 1

    .line 77
    const/4 v0, 0x0

    return v0
.end method

.method public static newMessage(Landroid/app/Activity;)Z
    .registers 4

    .line 166
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_8

    const/4 p0, 0x0

    return p0

    .line 167
    :cond_8
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "New message"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Text message"

    const-string v2, "Tzibbur group"

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lcom/android/mms/tzib/TzibHook$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0}, Lcom/android/mms/tzib/TzibHook$$ExternalSyntheticLambda0;-><init>(Landroid/app/Activity;)V

    .line 168
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 173
    const/high16 v0, 0x1040000

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 174
    const/4 p0, 0x1

    return p0
.end method

.method public static open(Landroid/app/Activity;)V
    .registers 3

    .line 163
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_14

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "com.tzibbur.basic.ui.TzbLaunchActivity"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 164
    :cond_14
    return-void
.end method

.method public static openGroup(Landroid/app/Activity;Ljava/lang/String;Z)V
    .registers 6

    .line 157
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 158
    :cond_7
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v0

    if-eqz v0, :cond_51

    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->deviceBlocked()Z

    move-result v0

    if-eqz v0, :cond_24

    goto :goto_51

    .line 159
    :cond_24
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "com.tzibbur.basic.ui."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 160
    if-eqz p2, :cond_39

    const-string p2, "TzbGroupInfoActivity"

    goto :goto_3b

    :cond_39
    const-string p2, "TzbConversationActivity"

    :goto_3b
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 159
    invoke-virtual {v0, p0, p2}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p2

    .line 160
    const-string v0, "tzb_group_id"

    invoke-virtual {p2, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    .line 159
    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 161
    return-void

    .line 158
    :cond_51
    :goto_51
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->open(Landroid/app/Activity;)V

    return-void
.end method

.method public static option(Landroid/app/Activity;I)Z
    .registers 6

    .line 110
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibThreadOptions;->option(Landroid/app/Activity;I)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    return v1

    .line 111
    :cond_8
    const/4 v0, 0x3

    if-ne p1, v0, :cond_15

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_15

    invoke-static {p0}, Lcom/android/mms/tzib/TzibSearch;->open(Landroid/app/Activity;)V

    return v1

    .line 112
    :cond_15
    if-ne p1, v1, :cond_30

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->selected(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object v0

    if-nez v0, :cond_30

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_30

    .line 114
    new-instance v0, Lcom/android/mms/tzib/TzibHook$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibHook$$ExternalSyntheticLambda2;-><init>(Landroid/app/Activity;)V

    new-instance v2, Lcom/android/mms/tzib/TzibHook$$ExternalSyntheticLambda3;

    invoke-direct {v2}, Lcom/android/mms/tzib/TzibHook$$ExternalSyntheticLambda3;-><init>()V

    invoke-static {p0, v0, v2}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    .line 123
    :cond_30
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->selected(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object v0

    .line 124
    if-nez v0, :cond_38

    const/4 p0, 0x0

    return p0

    .line 125
    :cond_38
    const/4 v2, 0x2

    if-ne p1, v2, :cond_3f

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->settings(Landroid/app/Activity;)V

    return v1

    .line 126
    :cond_3f
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_46

    return v1

    .line 127
    :cond_46
    const/16 v2, 0x238c

    if-ne p1, v2, :cond_52

    iget-object p1, v0, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object p1, p1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-static {p0, p1, v1}, Lcom/android/mms/tzib/TzibHook;->openGroup(Landroid/app/Activity;Ljava/lang/String;Z)V

    goto :goto_67

    .line 128
    :cond_52
    const/16 v2, 0x238d

    if-ne p1, v2, :cond_67

    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object p0

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object p0

    iget-object p1, v0, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object p1, p1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    iget-wide v2, v0, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->readThrough:J

    invoke-interface {p0, p1, v2, v3}, Lcom/tzibbur/basic/sync/TzbSync;->markRead(Ljava/lang/String;J)V

    .line 130
    :cond_67
    :goto_67
    return v1
.end method

.method public static optionsMenu(Landroid/app/Activity;Landroid/view/MenuItem;)Z
    .registers 4

    .line 133
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibThreadOptions;->option(Landroid/app/Activity;I)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_c

    return v1

    .line 134
    :cond_c
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    const v0, 0x7f080163

    if-ne p1, v0, :cond_1f

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_1f

    .line 135
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSearch;->open(Landroid/app/Activity;)V

    return v1

    .line 137
    :cond_1f
    const/4 p0, 0x0

    return p0
.end method

.method public static pause(Landroid/app/Activity;)V
    .registers 1

    .line 65
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->interacted(Landroid/app/Activity;)V

    .line 66
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;

    move-result-object p0

    .line 67
    if-eqz p0, :cond_c

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->pause()V

    .line 68
    :cond_c
    return-void
.end method

.method public static refresh(Landroid/app/Activity;Landroid/widget/ListView;)V
    .registers 4

    .line 58
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->adapter(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter;

    move-result-object p1

    .line 59
    if-eqz p1, :cond_9

    invoke-virtual {p1}, Lcom/android/mms/tzib/TzibInboxAdapter;->resume()V

    .line 60
    :cond_9
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string v0, "tzb_group_id"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 61
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    .line 62
    if-eqz p1, :cond_26

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_26

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Lcom/android/mms/tzib/TzibHook;->openGroup(Landroid/app/Activity;Ljava/lang/String;Z)V

    .line 63
    :cond_26
    return-void
.end method

.method static resource(Landroid/content/Context;Ljava/lang/String;)I
    .registers 4

    .line 176
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "string"

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p1, v1, p0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static restored(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    .line 54
    if-eqz p1, :cond_c

    sget-object p1, Lcom/android/mms/tzib/TzibHook;->restored:Ljava/util/WeakHashMap;

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {p1, p0, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    :cond_c
    return-void
.end method

.method static selected(Landroid/app/Activity;)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;
    .registers 2

    .line 39
    instance-of v0, p0, Landroid/app/ListActivity;

    if-eqz v0, :cond_14

    move-object v0, p0

    check-cast v0, Landroid/app/ListActivity;

    .line 40
    invoke-virtual {v0}, Landroid/app/ListActivity;->getListView()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v0

    .line 39
    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibHook;->groupAt(Landroid/app/Activity;I)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object p0

    goto :goto_15

    .line 40
    :cond_14
    const/4 p0, 0x0

    .line 39
    :goto_15
    return-object p0
.end method

.method public static settings(Landroid/app/Activity;)V
    .registers 3

    .line 154
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "com.android.mms.ui.MessagingPreferenceActivity"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 155
    return-void
.end method

.method static wasRestored(Landroid/app/Activity;)Z
    .registers 2

    .line 56
    sget-object v0, Lcom/android/mms/tzib/TzibHook;->restored:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-eqz p0, :cond_a

    const/4 p0, 0x1

    goto :goto_b

    :cond_a
    const/4 p0, 0x0

    :goto_b
    return p0
.end method
