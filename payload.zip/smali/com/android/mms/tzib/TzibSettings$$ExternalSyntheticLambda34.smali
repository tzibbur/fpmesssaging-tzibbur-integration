.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda34;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:[Ljava/lang/String;

.field public final synthetic f$2:Lorg/json/JSONArray;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;[Ljava/lang/String;Lorg/json/JSONArray;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda34;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda34;->f$1:[Ljava/lang/String;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda34;->f$2:Lorg/json/JSONArray;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda34;->f$0:Landroid/app/Activity;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda34;->f$1:[Ljava/lang/String;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda34;->f$2:Lorg/json/JSONArray;

    invoke-static {v0, v1, v2, p1, p2}, Lcom/android/mms/tzib/TzibSettings;->lambda$blocks$36(Landroid/app/Activity;[Ljava/lang/String;Lorg/json/JSONArray;Landroid/content/DialogInterface;I)V

    return-void
.end method
