.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/preference/PreferenceActivity;

.field public final synthetic f$1:Lcom/tzibbur/basic/core/TzbCore;


# direct methods
.method public synthetic constructor <init>(Landroid/preference/PreferenceActivity;Lcom/tzibbur/basic/core/TzbCore;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda20;->f$0:Landroid/preference/PreferenceActivity;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda20;->f$1:Lcom/tzibbur/basic/core/TzbCore;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda20;->f$0:Landroid/preference/PreferenceActivity;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda20;->f$1:Lcom/tzibbur/basic/core/TzbCore;

    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibSettings;->lambda$install$3(Landroid/preference/PreferenceActivity;Lcom/tzibbur/basic/core/TzbCore;)V

    return-void
.end method
