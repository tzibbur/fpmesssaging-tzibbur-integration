.class Lcom/android/mms/tzib/TzibInboxAdapter$1$1;
.super Ljava/lang/Object;
.source "TzibInboxAdapter.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/mms/tzib/TzibInboxAdapter$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

.field final synthetic val$loaded:Z

.field final synthetic val$result:Ljava/util/Map;


# direct methods
.method constructor <init>(Lcom/android/mms/tzib/TzibInboxAdapter$1;ZLjava/util/Map;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 131
    iput-object p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iput-boolean p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->val$loaded:Z

    iput-object p3, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->val$result:Ljava/util/Map;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 133
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    const/4 v1, 0x0

    # setter for: Lcom/android/mms/tzib/TzibInboxAdapter;->loading:Z
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$102(Lcom/android/mms/tzib/TzibInboxAdapter;Z)Z

    .line 134
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->disposed:Z
    invoke-static {v0}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$200(Lcom/android/mms/tzib/TzibInboxAdapter;)Z

    move-result v0

    if-eqz v0, :cond_13

    return-void

    .line 135
    :cond_13
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->userId()Ljava/lang/String;

    move-result-object v0

    .line 136
    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v2, v2, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->active:Z
    invoke-static {v2}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$300(Lcom/android/mms/tzib/TzibInboxAdapter;)Z

    move-result v2

    if-eqz v2, :cond_8b

    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget v2, v2, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$request:I

    iget-object v3, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v3, v3, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->generation:I
    invoke-static {v3}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$400(Lcom/android/mms/tzib/TzibInboxAdapter;)I

    move-result v3

    if-ne v2, v3, :cond_8b

    iget-boolean v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->val$loaded:Z

    if-eqz v2, :cond_8b

    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v2, v2, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$user:Ljava/lang/String;

    if-nez v2, :cond_44

    if-nez v0, :cond_8b

    goto :goto_4e

    :cond_44
    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v2, v2, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$user:Ljava/lang/String;

    .line 137
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8b

    .line 138
    :goto_4e
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v2, v2, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;
    invoke-static {v2}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$000(Lcom/android/mms/tzib/TzibInboxAdapter;)Landroid/app/Activity;

    move-result-object v2

    invoke-static {v2}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v2

    # setter for: Lcom/android/mms/tzib/TzibInboxAdapter;->allowed:Z
    invoke-static {v0, v2}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$502(Lcom/android/mms/tzib/TzibInboxAdapter;Z)Z

    .line 139
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v2, v2, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->allowed:Z
    invoke-static {v2}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$500(Lcom/android/mms/tzib/TzibInboxAdapter;)Z

    move-result v2

    if-eqz v2, :cond_72

    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->val$result:Ljava/util/Map;

    goto :goto_76

    :cond_72
    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v2

    :goto_76
    # setter for: Lcom/android/mms/tzib/TzibInboxAdapter;->groups:Ljava/util/Map;
    invoke-static {v0, v2}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$602(Lcom/android/mms/tzib/TzibInboxAdapter;Ljava/util/Map;)Ljava/util/Map;

    .line 140
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->initialSelection:Lcom/android/mms/tzib/TzibInitialSelection;
    invoke-static {v0}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$700(Lcom/android/mms/tzib/TzibInboxAdapter;)Lcom/android/mms/tzib/TzibInitialSelection;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibInitialSelection;->groupsReady()V

    .line 141
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibInboxAdapter;->notifyDataSetChanged()V

    .line 143
    :cond_8b
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->reload:Z
    invoke-static {v0}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$800(Lcom/android/mms/tzib/TzibInboxAdapter;)Z

    move-result v0

    if-eqz v0, :cond_ad

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->active:Z
    invoke-static {v0}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$300(Lcom/android/mms/tzib/TzibInboxAdapter;)Z

    move-result v0

    if-eqz v0, :cond_ad

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # setter for: Lcom/android/mms/tzib/TzibInboxAdapter;->reload:Z
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$802(Lcom/android/mms/tzib/TzibInboxAdapter;Z)Z

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;->this$1:Lcom/android/mms/tzib/TzibInboxAdapter$1;

    iget-object v0, v0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # invokes: Lcom/android/mms/tzib/TzibInboxAdapter;->load()V
    invoke-static {v0}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$900(Lcom/android/mms/tzib/TzibInboxAdapter;)V

    .line 144
    :cond_ad
    return-void
.end method
