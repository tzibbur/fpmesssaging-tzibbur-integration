.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda39;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic f$0:Lcom/tzibbur/basic/core/TzbCore;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/tzibbur/basic/core/TzbCore;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda39;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda39;->f$1:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda39;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda39;->f$1:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibSettings;->lambda$editName$14(Lcom/tzibbur/basic/core/TzbCore;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbUser;

    move-result-object v0

    return-object v0
.end method
