.class final Lcom/android/mms/tzib/TzibLegalDocuments$Document;
.super Ljava/lang/Object;
.source "TzibLegalDocuments.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/mms/tzib/TzibLegalDocuments;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Document"
.end annotation


# instance fields
.field final checksum:Ljava/lang/String;

.field final key:Ljava/lang/String;

.field final text:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalDocuments$Document;->key:Ljava/lang/String;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibLegalDocuments$Document;->text:Ljava/lang/String;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibLegalDocuments$Document;->checksum:Ljava/lang/String;

    .line 22
    return-void
.end method
