.class Lcom/android/mms/tzib/TzibInboxAdapter$1;
.super Ljava/lang/Object;
.source "TzibInboxAdapter.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/mms/tzib/TzibInboxAdapter;->load()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

.field final synthetic val$core:Lcom/tzibbur/basic/core/TzbCore;

.field final synthetic val$request:I

.field final synthetic val$user:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/android/mms/tzib/TzibInboxAdapter;Lcom/tzibbur/basic/core/TzbCore;ILjava/lang/String;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 110
    iput-object p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$core:Lcom/tzibbur/basic/core/TzbCore;

    iput p3, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$request:I

    iput-object p4, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$user:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 16

    .line 112
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 113
    nop

    .line 115
    :try_start_6
    iget-object v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_a4

    iget-object v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbSession;->deviceBlocked()Z

    move-result v1

    if-nez v1, :cond_a4

    .line 116
    iget-object v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->val$core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v1

    .line 117
    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbStore;->groups()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_2d
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_a4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v6, v4

    check-cast v6, Lcom/tzibbur/basic/model/TzbGroup;

    .line 118
    iget-object v4, v6, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-static {v4}, Lcom/android/mms/tzib/TzibMetadata;->snapshot(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 119
    if-eqz v4, :cond_51

    const-string v5, "pending"

    const-string v7, "membershipStatus"

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_51

    goto :goto_2d

    .line 120
    :cond_51
    iget-object v4, v6, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    iget-object v5, v6, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-interface {v1, v5}, Lcom/tzibbur/basic/store/TzbStore;->lastMessage(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMessage;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/android/mms/tzib/TzibMetadata;->lastMessage(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbMessage;)Lcom/tzibbur/basic/model/TzbMessage;

    move-result-object v7

    .line 121
    iget-object v4, v6, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-interface {v1, v4}, Lcom/tzibbur/basic/store/TzbStore;->outbox(Ljava/lang/String;)Ljava/util/List;

    move-result-object v4

    .line 122
    iget-object v5, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;
    invoke-static {v5}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$000(Lcom/android/mms/tzib/TzibInboxAdapter;)Landroid/app/Activity;

    move-result-object v5

    invoke-static {v5, v4}, Lcom/android/mms/tzib/TzibDeletedMessages;->filter(Landroid/content/Context;Ljava/util/List;)V

    .line 123
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_75

    const/4 v4, 0x0

    :goto_73
    move-object v11, v4

    goto :goto_81

    :cond_75
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v5

    sub-int/2addr v5, v2

    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/tzibbur/basic/store/TzbOutboxItem;

    goto :goto_73

    .line 124
    :goto_81
    iget-object v4, v6, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    new-instance v12, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    iget-object v5, v6, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-interface {v1, v5}, Lcom/tzibbur/basic/store/TzbStore;->unreadCount(Ljava/lang/String;)I

    move-result v8

    .line 125
    if-nez v7, :cond_90

    iget-wide v9, v6, Lcom/tzibbur/basic/model/TzbGroup;->readSeq:J

    goto :goto_92

    :cond_90
    iget-wide v9, v7, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    :goto_92
    iget-object v5, v6, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-interface {v1, v5}, Lcom/tzibbur/basic/store/TzbStore;->maxSeq(Ljava/lang/String;)J

    move-result-wide v13

    invoke-static {v9, v10, v13, v14}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v9

    move-object v5, v12

    invoke-direct/range {v5 .. v11}, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;-><init>(Lcom/tzibbur/basic/model/TzbGroup;Lcom/tzibbur/basic/model/TzbMessage;IJLcom/tzibbur/basic/store/TzbOutboxItem;)V

    .line 124
    invoke-interface {v0, v4, v12}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_a3
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_a3} :catch_a6

    .line 126
    goto :goto_2d

    .line 128
    :cond_a4
    nop

    .line 129
    goto :goto_af

    :catch_a6
    move-exception v1

    const-string v2, "tzib"

    const-string v3, "Could not load inbox cache"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v2, 0x0

    .line 130
    :goto_af
    nop

    .line 131
    iget-object v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$1;->this$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    # getter for: Lcom/android/mms/tzib/TzibInboxAdapter;->main:Landroid/os/Handler;
    invoke-static {v1}, Lcom/android/mms/tzib/TzibInboxAdapter;->access$1000(Lcom/android/mms/tzib/TzibInboxAdapter;)Landroid/os/Handler;

    move-result-object v1

    new-instance v3, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;

    invoke-direct {v3, p0, v2, v0}, Lcom/android/mms/tzib/TzibInboxAdapter$1$1;-><init>(Lcom/android/mms/tzib/TzibInboxAdapter$1;ZLjava/util/Map;)V

    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 146
    return-void
.end method
