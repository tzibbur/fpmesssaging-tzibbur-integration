.class public final synthetic Lcom/android/mms/tzib/TzibNetwork$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/tzibbur/basic/net/TzbTokenSupplier;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibNetwork$$ExternalSyntheticLambda0;->f$0:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final token()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/android/mms/tzib/TzibNetwork$$ExternalSyntheticLambda0;->f$0:Ljava/lang/String;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibNetwork;->lambda$request$0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
