.class public final synthetic Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/preference/Preference$OnPreferenceClickListener;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibAboutScreen;

.field public final synthetic f$1:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibAboutScreen;Ljava/lang/Runnable;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda0;->f$0:Lcom/android/mms/tzib/TzibAboutScreen;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final onPreferenceClick(Landroid/preference/Preference;)Z
    .registers 4

    iget-object v0, p0, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda0;->f$0:Lcom/android/mms/tzib/TzibAboutScreen;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Runnable;

    invoke-virtual {v0, v1, p1}, Lcom/android/mms/tzib/TzibAboutScreen;->lambda$add$3$com-android-mms-tzib-TzibAboutScreen(Ljava/lang/Runnable;Landroid/preference/Preference;)Z

    move-result p1

    return p1
.end method
