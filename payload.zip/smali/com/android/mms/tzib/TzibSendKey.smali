.class final Lcom/android/mms/tzib/TzibSendKey;
.super Ljava/lang/Object;
.source "TzibSendKey.java"


# instance fields
.field private armed:I


# direct methods
.method constructor <init>()V
    .registers 2

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    const/4 v0, -0x1

    iput v0, p0, Lcom/android/mms/tzib/TzibSendKey;->armed:I

    return-void
.end method


# virtual methods
.method handle(Landroid/view/KeyEvent;Ljava/lang/Runnable;)Z
    .registers 7

    .line 10
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    .line 11
    const/16 v1, 0x17

    const/4 v2, 0x0

    if-eq v0, v1, :cond_e

    const/16 v1, 0x42

    if-eq v0, v1, :cond_e

    return v2

    .line 12
    :cond_e
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    const/4 v3, 0x1

    if-nez v1, :cond_1e

    .line 13
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result p1

    if-nez p1, :cond_37

    iput v0, p0, Lcom/android/mms/tzib/TzibSendKey;->armed:I

    goto :goto_37

    .line 14
    :cond_1e
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    if-ne v1, v3, :cond_37

    .line 15
    iget v1, p0, Lcom/android/mms/tzib/TzibSendKey;->armed:I

    if-ne v1, v0, :cond_2f

    invoke-virtual {p1}, Landroid/view/KeyEvent;->isCanceled()Z

    move-result p1

    if-nez p1, :cond_2f

    move v2, v3

    .line 16
    :cond_2f
    const/4 p1, -0x1

    iput p1, p0, Lcom/android/mms/tzib/TzibSendKey;->armed:I

    .line 17
    if-eqz v2, :cond_37

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    .line 19
    :cond_37
    :goto_37
    return v3
.end method

.method reset()V
    .registers 2

    .line 22
    const/4 v0, -0x1

    iput v0, p0, Lcom/android/mms/tzib/TzibSendKey;->armed:I

    return-void
.end method
