.class public final synthetic Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Ljava/util/concurrent/Callable;

.field public final synthetic f$2:Landroid/os/Handler;

.field public final synthetic f$3:Ljava/util/function/Consumer;

.field public final synthetic f$4:Ljava/util/function/Consumer;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Ljava/util/concurrent/Callable;Landroid/os/Handler;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$1:Ljava/util/concurrent/Callable;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$2:Landroid/os/Handler;

    iput-object p4, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$3:Ljava/util/function/Consumer;

    iput-object p5, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$4:Ljava/util/function/Consumer;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    iget-object v0, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$0:Landroid/app/Activity;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$1:Ljava/util/concurrent/Callable;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$2:Landroid/os/Handler;

    iget-object v3, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$3:Ljava/util/function/Consumer;

    iget-object v4, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda1;->f$4:Ljava/util/function/Consumer;

    invoke-static {v0, v1, v2, v3, v4}, Lcom/android/mms/tzib/TzibTasks;->lambda$run$3(Landroid/app/Activity;Ljava/util/concurrent/Callable;Landroid/os/Handler;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V

    return-void
.end method
