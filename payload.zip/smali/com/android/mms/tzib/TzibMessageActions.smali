.class public final Lcom/android/mms/tzib/TzibMessageActions;
.super Ljava/lang/Object;
.source "TzibMessageActions.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/mms/tzib/TzibMessageActions$Target;
    }
.end annotation


# static fields
.field public static final COPY:I = 0x2396

.field public static final DELETE:I = 0x2397


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic lambda$perform$0(Lcom/android/mms/tzib/TzibMessageActions$Target;Landroid/app/Activity;)Ljava/lang/Boolean;
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 73
    iget-object v0, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->owner:Ljava/lang/String;

    invoke-static {p1}, Lcom/android/mms/tzib/TzibDeletedMessages;->owner(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12

    const/4 p0, 0x0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    .line 74
    :cond_12
    invoke-static {p1}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    check-cast v0, Landroid/database/sqlite/SQLiteOpenHelper;

    .line 75
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 77
    iget-object v1, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->owner:Ljava/lang/String;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->group:Ljava/lang/String;

    iget-object v3, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->id:Ljava/lang/String;

    iget-object v4, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->clientId:Ljava/lang/String;

    invoke-static {p1, v1, v2, v3, v4}, Lcom/android/mms/tzib/TzibDeletedMessages;->remember(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 78
    iget-object p1, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->group:Ljava/lang/String;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->id:Ljava/lang/String;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->clientId:Ljava/lang/String;

    invoke-static {v0, p1, v1, v2}, Lcom/android/mms/tzib/TzibDeletedMessages;->erase(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    iget-object p1, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->owner:Ljava/lang/String;

    iget-object v0, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->group:Ljava/lang/String;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->id:Ljava/lang/String;

    iget-object p0, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->clientId:Ljava/lang/String;

    invoke-static {p1, v0, v1, p0}, Lcom/android/mms/tzib/TzibMetadata;->deleted(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 80
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$perform$1(Lcom/android/mms/tzib/TzibMessageActions$Target;Landroid/app/Activity;Ljava/lang/Runnable;Ljava/lang/Boolean;)V
    .registers 6

    .line 82
    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    if-eqz p3, :cond_2e

    iget-object p3, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->owner:Ljava/lang/String;

    invoke-static {p1}, Lcom/android/mms/tzib/TzibDeletedMessages;->owner(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p3, v0}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_13

    goto :goto_2e

    .line 83
    :cond_13
    iget-object p3, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->group:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "tzb_group_id"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p3, v0}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_2d

    .line 84
    iget-object p0, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->item:Ljava/lang/Object;

    invoke-static {p1, p0}, Lcom/android/mms/tzib/TzibMessageActions;->removeVisible(Landroid/app/Activity;Ljava/lang/Object;)V

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    .line 86
    :cond_2d
    return-void

    .line 82
    :cond_2e
    :goto_2e
    return-void
.end method

.method static synthetic lambda$perform$2(Landroid/app/Activity;Ljava/lang/Exception;)V
    .registers 3

    .line 86
    const-string p1, "Could not delete the message. Please try again."

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method static synthetic lambda$perform$3(Lcom/android/mms/tzib/TzibMessageActions$Target;Landroid/app/Activity;Ljava/lang/Runnable;Landroid/content/DialogInterface;I)V
    .registers 5

    .line 68
    iget-object p3, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->owner:Ljava/lang/String;

    invoke-static {p1}, Lcom/android/mms/tzib/TzibDeletedMessages;->owner(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p4

    invoke-static {p3, p4}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_35

    invoke-static {p1}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p3

    if-nez p3, :cond_13

    goto :goto_35

    .line 69
    :cond_13
    iget-object p3, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->item:Ljava/lang/Object;

    instance-of p3, p3, Lcom/tzibbur/basic/model/TzbCommandResult;

    if-eqz p3, :cond_22

    .line 70
    iget-object p0, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->item:Ljava/lang/Object;

    invoke-static {p1, p0}, Lcom/android/mms/tzib/TzibMessageActions;->removeVisible(Landroid/app/Activity;Ljava/lang/Object;)V

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    return-void

    .line 72
    :cond_22
    new-instance p3, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda0;

    invoke-direct {p3, p0, p1}, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda0;-><init>(Lcom/android/mms/tzib/TzibMessageActions$Target;Landroid/app/Activity;)V

    new-instance p4, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda1;

    invoke-direct {p4, p0, p1, p2}, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda1;-><init>(Lcom/android/mms/tzib/TzibMessageActions$Target;Landroid/app/Activity;Ljava/lang/Runnable;)V

    new-instance p0, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda2;

    invoke-direct {p0, p1}, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda2;-><init>(Landroid/app/Activity;)V

    invoke-static {p1, p3, p4, p0}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V

    .line 87
    return-void

    .line 68
    :cond_35
    :goto_35
    return-void
.end method

.method public static option(Landroid/app/Activity;Landroid/view/MenuItem;)Z
    .registers 2

    .line 98
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibConversationStyle;->messageOption(Landroid/app/Activity;I)Z

    move-result p0

    return p0
.end method

.method static perform(Landroid/app/Activity;ILcom/android/mms/tzib/TzibMessageActions$Target;Ljava/lang/Runnable;)Z
    .registers 9

    .line 53
    const/4 v0, 0x0

    const/16 v1, 0x2396

    if-eq p1, v1, :cond_a

    const/16 v2, 0x2397

    if-eq p1, v2, :cond_a

    return v0

    .line 54
    :cond_a
    const/4 v2, 0x1

    if-eqz p2, :cond_86

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_86

    iget-object v3, p2, Lcom/android/mms/tzib/TzibMessageActions$Target;->owner:Ljava/lang/String;

    .line 55
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->owner(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_20

    goto :goto_86

    .line 56
    :cond_20
    if-ne p1, v1, :cond_48

    .line 57
    const-string p1, "clipboard"

    invoke-virtual {p0, p1}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/ClipboardManager;

    .line 58
    if-eqz p1, :cond_47

    .line 59
    iget-object p3, p2, Lcom/android/mms/tzib/TzibMessageActions$Target;->text:Ljava/lang/String;

    if-nez p3, :cond_33

    const-string p2, ""

    goto :goto_35

    :cond_33
    iget-object p2, p2, Lcom/android/mms/tzib/TzibMessageActions$Target;->text:Ljava/lang/String;

    :goto_35
    const-string p3, "Tzibbur message"

    invoke-static {p3, p2}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 60
    const-string p1, "Message copied"

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 62
    :cond_47
    return v2

    .line 64
    :cond_48
    nop

    .line 65
    iget-boolean p1, p2, Lcom/android/mms/tzib/TzibMessageActions$Target;->sending:Z

    const-string v0, "Delete this message from this phone? Other members will keep their copies."

    if-eqz p1, :cond_62

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, " A send already in progress may still be delivered."

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 66
    :cond_62
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string v1, "Delete message?"

    invoke-virtual {p1, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v0, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda3;

    invoke-direct {v0, p2, p0, p3}, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda3;-><init>(Lcom/android/mms/tzib/TzibMessageActions$Target;Landroid/app/Activity;Ljava/lang/Runnable;)V

    .line 67
    const-string p0, "Delete"

    invoke-virtual {p1, p0, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 87
    const/high16 p1, 0x1040000

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 88
    return v2

    .line 55
    :cond_86
    :goto_86
    return v2
.end method

.method public static prepare(Landroid/app/Activity;Landroid/view/Menu;)V
    .registers 2

    .line 95
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibConversationStyle;->prepareMessageMenu(Landroid/app/Activity;Landroid/view/Menu;)V

    .line 96
    return-void
.end method

.method private static removeVisible(Landroid/app/Activity;Ljava/lang/Object;)V
    .registers 7

    .line 91
    :try_start_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v1, "tzibRemoveMessage"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Class;

    const-class v3, Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v0, p0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_19} :catch_1a

    .line 92
    goto :goto_22

    :catch_1a
    move-exception p0

    const-string p1, "tzib"

    const-string v0, "Could not refresh deleted message"

    invoke-static {p1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 93
    :goto_22
    return-void
.end method

.method static selected(Landroid/app/Activity;Landroid/widget/ListView;)Lcom/android/mms/tzib/TzibMessageActions$Target;
    .registers 4

    .line 47
    invoke-virtual {p1}, Landroid/widget/ListView;->hasFocus()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return-object v1

    .line 48
    :cond_8
    invoke-virtual {p1}, Landroid/widget/ListView;->getSelectedItem()Ljava/lang/Object;

    move-result-object p1

    .line 49
    invoke-static {p1}, Lcom/android/mms/tzib/TzibDeletedMessages;->hidden(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_13

    return-object v1

    .line 50
    :cond_13
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->owner(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p0

    const-string v1, "tzb_group_id"

    invoke-virtual {p0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0, p1}, Lcom/android/mms/tzib/TzibMessageActions;->target(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Lcom/android/mms/tzib/TzibMessageActions$Target;

    move-result-object p0

    return-object p0
.end method

.method static target(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Lcom/android/mms/tzib/TzibMessageActions$Target;
    .registers 12

    .line 33
    instance-of v0, p2, Lcom/tzibbur/basic/model/TzbMessage;

    if-eqz v0, :cond_19

    .line 34
    move-object p1, p2

    check-cast p1, Lcom/tzibbur/basic/model/TzbMessage;

    .line 35
    new-instance v8, Lcom/android/mms/tzib/TzibMessageActions$Target;

    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbMessage;->groupId:Ljava/lang/String;

    iget-object v4, p1, Lcom/tzibbur/basic/model/TzbMessage;->id:Ljava/lang/String;

    iget-object v5, p1, Lcom/tzibbur/basic/model/TzbMessage;->clientMessageId:Ljava/lang/String;

    iget-object v6, p1, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    const/4 v7, 0x0

    move-object v0, v8

    move-object v1, p2

    move-object v2, p0

    invoke-direct/range {v0 .. v7}, Lcom/android/mms/tzib/TzibMessageActions$Target;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v8

    .line 37
    :cond_19
    instance-of v0, p2, Lcom/tzibbur/basic/store/TzbOutboxItem;

    if-eqz v0, :cond_39

    .line 38
    move-object p1, p2

    check-cast p1, Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 39
    new-instance v8, Lcom/android/mms/tzib/TzibMessageActions$Target;

    iget-object v3, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    const/4 v4, 0x0

    iget-object v5, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    iget-object v6, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->body:Ljava/lang/String;

    iget p1, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->state:I

    const/4 v0, 0x2

    if-eq p1, v0, :cond_30

    const/4 p1, 0x1

    goto :goto_31

    :cond_30
    const/4 p1, 0x0

    :goto_31
    move v7, p1

    move-object v0, v8

    move-object v1, p2

    move-object v2, p0

    invoke-direct/range {v0 .. v7}, Lcom/android/mms/tzib/TzibMessageActions$Target;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v8

    .line 41
    :cond_39
    instance-of v0, p2, Lcom/tzibbur/basic/model/TzbCommandResult;

    if-eqz v0, :cond_4f

    .line 42
    new-instance v0, Lcom/android/mms/tzib/TzibMessageActions$Target;

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, p2

    check-cast v1, Lcom/tzibbur/basic/model/TzbCommandResult;

    iget-object v7, v1, Lcom/tzibbur/basic/model/TzbCommandResult;->text:Ljava/lang/String;

    const/4 v8, 0x0

    move-object v1, v0

    move-object v2, p2

    move-object v3, p0

    move-object v4, p1

    invoke-direct/range {v1 .. v8}, Lcom/android/mms/tzib/TzibMessageActions$Target;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v0

    .line 44
    :cond_4f
    const/4 p0, 0x0

    return-object p0
.end method
