.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda49;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/widget/EditText;

.field public final synthetic f$1:Landroid/app/AlertDialog;

.field public final synthetic f$2:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;Landroid/app/AlertDialog;Landroid/app/Activity;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda49;->f$0:Landroid/widget/EditText;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda49;->f$1:Landroid/app/AlertDialog;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda49;->f$2:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda49;->f$0:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda49;->f$1:Landroid/app/AlertDialog;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda49;->f$2:Landroid/app/Activity;

    invoke-static {v0, v1, v2, p1}, Lcom/android/mms/tzib/TzibSettings;->lambda$deleteAccount$46(Landroid/widget/EditText;Landroid/app/AlertDialog;Landroid/app/Activity;Landroid/view/View;)V

    return-void
.end method
