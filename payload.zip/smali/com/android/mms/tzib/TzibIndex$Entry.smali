.class public final Lcom/android/mms/tzib/TzibIndex$Entry;
.super Ljava/lang/Object;
.source "TzibIndex.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/mms/tzib/TzibIndex;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Entry"
.end annotation


# instance fields
.field public final date:J

.field public final groupId:Ljava/lang/String;

.field public final id:J

.field public final smsPosition:I


# direct methods
.method private constructor <init>(JJILjava/lang/String;)V
    .registers 7

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    iput-wide p1, p0, Lcom/android/mms/tzib/TzibIndex$Entry;->id:J

    iput-wide p3, p0, Lcom/android/mms/tzib/TzibIndex$Entry;->date:J

    iput p5, p0, Lcom/android/mms/tzib/TzibIndex$Entry;->smsPosition:I

    iput-object p6, p0, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    .line 18
    return-void
.end method

.method synthetic constructor <init>(JJILjava/lang/String;Lcom/android/mms/tzib/TzibIndex$1;)V
    .registers 8

    .line 12
    invoke-direct/range {p0 .. p6}, Lcom/android/mms/tzib/TzibIndex$Entry;-><init>(JJILjava/lang/String;)V

    return-void
.end method

.method public static sms(JJI)Lcom/android/mms/tzib/TzibIndex$Entry;
    .registers 13

    .line 20
    const-wide/16 v0, 0x0

    cmp-long v0, p0, v0

    if-lez v0, :cond_13

    if-ltz p4, :cond_13

    .line 21
    new-instance v0, Lcom/android/mms/tzib/TzibIndex$Entry;

    const/4 v7, 0x0

    move-object v1, v0

    move-wide v2, p0

    move-wide v4, p2

    move v6, p4

    invoke-direct/range {v1 .. v7}, Lcom/android/mms/tzib/TzibIndex$Entry;-><init>(JJILjava/lang/String;)V

    return-object v0

    .line 20
    :cond_13
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid SMS identity"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
