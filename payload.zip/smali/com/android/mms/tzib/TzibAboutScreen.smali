.class public Lcom/android/mms/tzib/TzibAboutScreen;
.super Landroid/preference/PreferenceActivity;
.source "TzibAboutScreen.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 13
    invoke-direct {p0}, Landroid/preference/PreferenceActivity;-><init>()V

    return-void
.end method

.method private add(Landroid/preference/PreferenceScreen;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
    .registers 8

    .line 40
    new-instance v0, Landroid/preference/Preference;

    invoke-direct {v0, p0}, Landroid/preference/Preference;-><init>(Landroid/content/Context;)V

    .line 41
    const-string v1, "layout"

    const-string v2, "custom_preference_layout"

    invoke-direct {p0, v1, v2}, Lcom/android/mms/tzib/TzibAboutScreen;->res(Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setLayoutResource(I)V

    .line 42
    invoke-virtual {v0, p2}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, p3}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    const/4 p2, 0x0

    invoke-virtual {v0, p2}, Landroid/preference/Preference;->setPersistent(Z)V

    .line 43
    new-instance p2, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda0;

    invoke-direct {p2, p0, p4}, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda0;-><init>(Lcom/android/mms/tzib/TzibAboutScreen;Ljava/lang/Runnable;)V

    invoke-virtual {v0, p2}, Landroid/preference/Preference;->setOnPreferenceClickListener(Landroid/preference/Preference$OnPreferenceClickListener;)V

    .line 44
    invoke-virtual {p1, v0}, Landroid/preference/PreferenceScreen;->addPreference(Landroid/preference/Preference;)Z

    .line 45
    return-void
.end method

.method private open(Ljava/lang/String;)V
    .registers 2

    .line 46
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->intent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibAboutScreen;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private res(Ljava/lang/String;Ljava/lang/String;)I
    .registers 5

    .line 38
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibAboutScreen;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibAboutScreen;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p2, p1, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    return p1
.end method


# virtual methods
.method synthetic lambda$add$3$com-android-mms-tzib-TzibAboutScreen(Ljava/lang/Runnable;Landroid/preference/Preference;)Z
    .registers 3

    .line 43
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p2

    if-eqz p2, :cond_9

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    :cond_9
    const/4 p1, 0x1

    return p1
.end method

.method synthetic lambda$onCreate$0$com-android-mms-tzib-TzibAboutScreen()V
    .registers 2

    .line 21
    const-string v0, "privacy"

    invoke-direct {p0, v0}, Lcom/android/mms/tzib/TzibAboutScreen;->open(Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$onCreate$1$com-android-mms-tzib-TzibAboutScreen()V
    .registers 2

    .line 22
    const-string v0, "terms"

    invoke-direct {p0, v0}, Lcom/android/mms/tzib/TzibAboutScreen;->open(Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$onCreate$2$com-android-mms-tzib-TzibAboutScreen()V
    .registers 4

    .line 27
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "About Tzibbur"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 28
    const-string v1, "Tzibbur is an independent third-party group messaging service for kosher phones. It is separate from your phone manufacturer, carrier, and the provider of this Messages app. Tzibbur handles your phone number and group conversations. Read its Privacy Policy and Terms of Service for details."

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 31
    const v1, 0x104000a

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 27
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 5

    .line 15
    invoke-super {p0, p1}, Landroid/preference/PreferenceActivity;->onCreate(Landroid/os/Bundle;)V

    .line 16
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_d

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibAboutScreen;->finish()V

    return-void

    .line 17
    :cond_d
    const-string p1, "layout"

    const-string v0, "tzb_about_activity"

    invoke-direct {p0, p1, v0}, Lcom/android/mms/tzib/TzibAboutScreen;->res(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibAboutScreen;->setContentView(I)V

    .line 18
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 19
    const-string p1, "id"

    const-string v0, "tzb_title_text"

    invoke-direct {p0, p1, v0}, Lcom/android/mms/tzib/TzibAboutScreen;->res(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibAboutScreen;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const-string v0, "About Tzibbur"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 20
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibAboutScreen;->getPreferenceManager()Landroid/preference/PreferenceManager;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/preference/PreferenceManager;->createPreferenceScreen(Landroid/content/Context;)Landroid/preference/PreferenceScreen;

    move-result-object p1

    .line 21
    new-instance v0, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda1;-><init>(Lcom/android/mms/tzib/TzibAboutScreen;)V

    const-string v1, "1. Privacy policy"

    const-string v2, "Read the current policy"

    invoke-direct {p0, p1, v1, v2, v0}, Lcom/android/mms/tzib/TzibAboutScreen;->add(Landroid/preference/PreferenceScreen;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 22
    new-instance v0, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda2;-><init>(Lcom/android/mms/tzib/TzibAboutScreen;)V

    const-string v1, "2. Terms of service"

    const-string v2, "Read the current terms"

    invoke-direct {p0, p1, v1, v2, v0}, Lcom/android/mms/tzib/TzibAboutScreen;->add(Landroid/preference/PreferenceScreen;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 24
    :try_start_4e
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibAboutScreen;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibAboutScreen;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_5d
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_4e .. :try_end_5d} :catch_5e

    .line 25
    goto :goto_61

    :catch_5e
    move-exception v0

    const-string v0, ""

    .line 26
    :goto_61
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Messages "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda3;-><init>(Lcom/android/mms/tzib/TzibAboutScreen;)V

    const-string v2, "3. About the service"

    invoke-direct {p0, p1, v2, v0, v1}, Lcom/android/mms/tzib/TzibAboutScreen;->add(Landroid/preference/PreferenceScreen;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 32
    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibAboutScreen;->setPreferenceScreen(Landroid/preference/PreferenceScreen;)V

    .line 33
    return-void
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .registers 5

    .line 48
    add-int/lit8 v0, p1, -0x8

    .line 49
    if-ltz v0, :cond_24

    const/4 v1, 0x3

    if-ge v0, v1, :cond_24

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibAboutScreen;->getPreferenceScreen()Landroid/preference/PreferenceScreen;

    move-result-object v1

    if-eqz v1, :cond_24

    .line 50
    invoke-virtual {p2}, Landroid/view/KeyEvent;->isCanceled()Z

    move-result p1

    if-nez p1, :cond_22

    .line 51
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibAboutScreen;->getPreferenceScreen()Landroid/preference/PreferenceScreen;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/preference/PreferenceScreen;->getPreference(I)Landroid/preference/Preference;

    move-result-object p1

    .line 52
    invoke-virtual {p1}, Landroid/preference/Preference;->getOnPreferenceClickListener()Landroid/preference/Preference$OnPreferenceClickListener;

    move-result-object p2

    invoke-interface {p2, p1}, Landroid/preference/Preference$OnPreferenceClickListener;->onPreferenceClick(Landroid/preference/Preference;)Z

    .line 54
    :cond_22
    const/4 p1, 0x1

    return p1

    .line 56
    :cond_24
    invoke-super {p0, p1, p2}, Landroid/preference/PreferenceActivity;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

.method protected onStart()V
    .registers 2

    .line 35
    invoke-super {p0}, Landroid/preference/PreferenceActivity;->onStart()V

    .line 36
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_c

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibAboutScreen;->finish()V

    .line 37
    :cond_c
    return-void
.end method
