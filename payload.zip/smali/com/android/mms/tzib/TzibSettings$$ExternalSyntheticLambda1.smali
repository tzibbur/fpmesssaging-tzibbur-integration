.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Lorg/json/JSONObject;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda1;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda1;->f$1:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 5

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda1;->f$0:Landroid/app/Activity;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda1;->f$1:Lorg/json/JSONObject;

    invoke-static {v0, v1, p1, p2}, Lcom/android/mms/tzib/TzibSettings;->lambda$invitations$26(Landroid/app/Activity;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V

    return-void
.end method
