.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Lorg/json/JSONArray;

.field public final synthetic f$2:I


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Lorg/json/JSONArray;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda3;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda3;->f$1:Lorg/json/JSONArray;

    iput p3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda3;->f$2:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda3;->f$0:Landroid/app/Activity;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda3;->f$1:Lorg/json/JSONArray;

    iget v2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda3;->f$2:I

    invoke-static {v0, v1, v2, p1, p2}, Lcom/android/mms/tzib/TzibSettings;->lambda$blocks$35(Landroid/app/Activity;Lorg/json/JSONArray;ILandroid/content/DialogInterface;I)V

    return-void
.end method
