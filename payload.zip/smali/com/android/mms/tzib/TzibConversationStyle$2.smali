.class Lcom/android/mms/tzib/TzibConversationStyle$2;
.super Ljava/lang/Object;
.source "TzibConversationStyle.java"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/mms/tzib/TzibConversationStyle;->install(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$style:Lcom/android/mms/tzib/TzibConversationStyle;


# direct methods
.method constructor <init>(Lcom/android/mms/tzib/TzibConversationStyle;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 105
    iput-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle$2;->val$style:Lcom/android/mms/tzib/TzibConversationStyle;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .registers 2

    .line 108
    iget-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle$2;->val$style:Lcom/android/mms/tzib/TzibConversationStyle;

    # invokes: Lcom/android/mms/tzib/TzibConversationStyle;->updateSoftkeys()V
    invoke-static {p1}, Lcom/android/mms/tzib/TzibConversationStyle;->access$000(Lcom/android/mms/tzib/TzibConversationStyle;)V

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .registers 5

    .line 106
    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .registers 5

    .line 107
    return-void
.end method
