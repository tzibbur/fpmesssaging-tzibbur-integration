.class public final Lcom/android/mms/tzib/TzibInboxAdapter;
.super Lcom/android/mms/ui/ConversationListAdapter;
.source "TzibInboxAdapter.java"

# interfaces
.implements Lcom/tzibbur/basic/sync/TzbSyncListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;
    }
.end annotation


# instance fields
.field private active:Z

.field private final activity:Landroid/app/Activity;

.field private allowed:Z

.field private disposed:Z

.field private editing:Z

.field private entries:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/android/mms/tzib/TzibIndex$Entry;",
            ">;"
        }
    .end annotation
.end field

.field private generation:I

.field private groups:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;",
            ">;"
        }
    .end annotation
.end field

.field private final index:Lcom/android/mms/tzib/TzibIndex;

.field private final initialSelection:Lcom/android/mms/tzib/TzibInitialSelection;

.field private loading:Z

.field private final main:Landroid/os/Handler;

.field private reload:Z

.field private final worker:Ljava/util/concurrent/ExecutorService;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/database/Cursor;)V
    .registers 4

    .line 66
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ConversationListAdapter;-><init>(Landroid/content/Context;Landroid/database/Cursor;)V

    .line 56
    new-instance p2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p2, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->main:Landroid/os/Handler;

    .line 57
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object p2

    iput-object p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->worker:Ljava/util/concurrent/ExecutorService;

    .line 58
    new-instance p2, Lcom/android/mms/tzib/TzibIndex;

    invoke-direct {p2}, Lcom/android/mms/tzib/TzibIndex;-><init>()V

    iput-object p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->index:Lcom/android/mms/tzib/TzibIndex;

    .line 59
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p2

    iput-object p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->entries:Ljava/util/List;

    .line 60
    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object p2

    iput-object p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->groups:Ljava/util/Map;

    .line 63
    new-instance p2, Lcom/android/mms/tzib/TzibInitialSelection;

    invoke-direct {p2}, Lcom/android/mms/tzib/TzibInitialSelection;-><init>()V

    iput-object p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->initialSelection:Lcom/android/mms/tzib/TzibInitialSelection;

    .line 67
    check-cast p1, Landroid/app/Activity;

    iput-object p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    .line 68
    invoke-static {p1}, Lcom/android/mms/tzib/TzibHook;->wasRestored(Landroid/app/Activity;)Z

    move-result p1

    if-eqz p1, :cond_3b

    invoke-virtual {p2}, Lcom/android/mms/tzib/TzibInitialSelection;->interacted()V

    .line 69
    :cond_3b
    return-void
.end method

.method static synthetic access$000(Lcom/android/mms/tzib/TzibInboxAdapter;)Landroid/app/Activity;
    .registers 1

    .line 36
    iget-object p0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    return-object p0
.end method

.method static synthetic access$1000(Lcom/android/mms/tzib/TzibInboxAdapter;)Landroid/os/Handler;
    .registers 1

    .line 36
    iget-object p0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->main:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$102(Lcom/android/mms/tzib/TzibInboxAdapter;Z)Z
    .registers 2

    .line 36
    iput-boolean p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->loading:Z

    return p1
.end method

.method static synthetic access$200(Lcom/android/mms/tzib/TzibInboxAdapter;)Z
    .registers 1

    .line 36
    iget-boolean p0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->disposed:Z

    return p0
.end method

.method static synthetic access$300(Lcom/android/mms/tzib/TzibInboxAdapter;)Z
    .registers 1

    .line 36
    iget-boolean p0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->active:Z

    return p0
.end method

.method static synthetic access$400(Lcom/android/mms/tzib/TzibInboxAdapter;)I
    .registers 1

    .line 36
    iget p0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->generation:I

    return p0
.end method

.method static synthetic access$500(Lcom/android/mms/tzib/TzibInboxAdapter;)Z
    .registers 1

    .line 36
    iget-boolean p0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->allowed:Z

    return p0
.end method

.method static synthetic access$502(Lcom/android/mms/tzib/TzibInboxAdapter;Z)Z
    .registers 2

    .line 36
    iput-boolean p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->allowed:Z

    return p1
.end method

.method static synthetic access$602(Lcom/android/mms/tzib/TzibInboxAdapter;Ljava/util/Map;)Ljava/util/Map;
    .registers 2

    .line 36
    iput-object p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->groups:Ljava/util/Map;

    return-object p1
.end method

.method static synthetic access$700(Lcom/android/mms/tzib/TzibInboxAdapter;)Lcom/android/mms/tzib/TzibInitialSelection;
    .registers 1

    .line 36
    iget-object p0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->initialSelection:Lcom/android/mms/tzib/TzibInitialSelection;

    return-object p0
.end method

.method static synthetic access$800(Lcom/android/mms/tzib/TzibInboxAdapter;)Z
    .registers 1

    .line 36
    iget-boolean p0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->reload:Z

    return p0
.end method

.method static synthetic access$802(Lcom/android/mms/tzib/TzibInboxAdapter;Z)Z
    .registers 2

    .line 36
    iput-boolean p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->reload:Z

    return p1
.end method

.method static synthetic access$900(Lcom/android/mms/tzib/TzibInboxAdapter;)V
    .registers 1

    .line 36
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->load()V

    return-void
.end method

.method private dateLabel(J)Ljava/lang/String;
    .registers 5

    .line 263
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-gtz v0, :cond_9

    const-string p1, ""

    goto :goto_11

    :cond_9
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    const/16 v1, 0x10

    invoke-static {v0, p1, p2, v1}, Landroid/text/format/DateUtils;->formatDateTime(Landroid/content/Context;JI)Ljava/lang/String;

    move-result-object p1

    :goto_11
    return-object p1
.end method

.method private entry(I)Lcom/android/mms/tzib/TzibIndex$Entry;
    .registers 3

    .line 202
    if-ltz p1, :cond_12

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->getCount()I

    move-result v0

    if-lt p1, v0, :cond_9

    goto :goto_12

    :cond_9
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->entries:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/mms/tzib/TzibIndex$Entry;

    goto :goto_13

    :cond_12
    :goto_12
    const/4 p1, 0x0

    :goto_13
    return-object p1
.end method

.method private load()V
    .registers 6

    .line 104
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->active:Z

    if-eqz v0, :cond_2e

    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->disposed:Z

    if-eqz v0, :cond_9

    goto :goto_2e

    .line 105
    :cond_9
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->loading:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_11

    iput-boolean v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->reload:Z

    return-void

    .line 106
    :cond_11
    iput-boolean v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->loading:Z

    .line 107
    iget v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->generation:I

    .line 108
    iget-object v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-static {v1}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v1

    .line 109
    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v2

    invoke-interface {v2}, Lcom/tzibbur/basic/store/TzbSession;->userId()Ljava/lang/String;

    move-result-object v2

    .line 110
    iget-object v3, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->worker:Ljava/util/concurrent/ExecutorService;

    new-instance v4, Lcom/android/mms/tzib/TzibInboxAdapter$1;

    invoke-direct {v4, p0, v1, v0, v2}, Lcom/android/mms/tzib/TzibInboxAdapter$1;-><init>(Lcom/android/mms/tzib/TzibInboxAdapter;Lcom/tzibbur/basic/core/TzbCore;ILjava/lang/String;)V

    invoke-interface {v3, v4}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 148
    return-void

    .line 104
    :cond_2e
    :goto_2e
    return-void
.end method

.method private rebuild()V
    .registers 11

    .line 152
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->index:Lcom/android/mms/tzib/TzibIndex;

    if-nez v0, :cond_5

    return-void

    .line 153
    :cond_5
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 154
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->getCursor()Landroid/database/Cursor;

    move-result-object v1

    .line 155
    if-eqz v1, :cond_42

    invoke-interface {v1}, Landroid/database/Cursor;->isClosed()Z

    move-result v2

    if-nez v2, :cond_42

    .line 156
    invoke-interface {v1}, Landroid/database/Cursor;->getPosition()I

    move-result v2

    .line 157
    const-string v3, "date"

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v3

    .line 158
    const-string v4, "_id"

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v4

    .line 159
    const/4 v5, 0x0

    :goto_27
    invoke-interface {v1, v5}, Landroid/database/Cursor;->moveToPosition(I)Z

    move-result v6

    if-eqz v6, :cond_3f

    .line 160
    invoke-interface {v1, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v8

    invoke-static {v6, v7, v8, v9, v5}, Lcom/android/mms/tzib/TzibIndex$Entry;->sms(JJI)Lcom/android/mms/tzib/TzibIndex$Entry;

    move-result-object v6

    invoke-interface {v0, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 159
    add-int/lit8 v5, v5, 0x1

    goto :goto_27

    .line 162
    :cond_3f
    invoke-interface {v1, v2}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 164
    :cond_42
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 165
    iget-boolean v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->allowed:Z

    if-eqz v2, :cond_71

    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->groups:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_55
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_71

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    iget-object v4, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->index:Lcom/android/mms/tzib/TzibIndex;

    iget-object v5, v3, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v5, v5, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    iget-wide v6, v3, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->date:J

    invoke-virtual {v4, v5, v6, v7}, Lcom/android/mms/tzib/TzibIndex;->group(Ljava/lang/String;J)Lcom/android/mms/tzib/TzibIndex$Entry;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_55

    .line 166
    :cond_71
    iget-boolean v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->editing:Z

    invoke-static {v0, v1, v2}, Lcom/android/mms/tzib/TzibIndex;->merge(Ljava/util/List;Ljava/util/List;Z)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->entries:Ljava/util/List;

    .line 167
    return-void
.end method

.method private selectNewestInitially()V
    .registers 3

    .line 189
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->initialSelection:Lcom/android/mms/tzib/TzibInitialSelection;

    if-eqz v0, :cond_20

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibInitialSelection;->ready()Z

    move-result v0

    if-eqz v0, :cond_20

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    instance-of v1, v0, Landroid/app/ListActivity;

    if-nez v1, :cond_11

    goto :goto_20

    .line 190
    :cond_11
    check-cast v0, Landroid/app/ListActivity;

    invoke-virtual {v0}, Landroid/app/ListActivity;->getListView()Landroid/widget/ListView;

    move-result-object v0

    .line 191
    new-instance v1, Lcom/android/mms/tzib/TzibInboxAdapter$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, v0}, Lcom/android/mms/tzib/TzibInboxAdapter$$ExternalSyntheticLambda0;-><init>(Lcom/android/mms/tzib/TzibInboxAdapter;Landroid/widget/ListView;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->post(Ljava/lang/Runnable;)Z

    .line 197
    return-void

    .line 189
    :cond_20
    :goto_20
    return-void
.end method

.method static timestamp(Ljava/lang/String;)J
    .registers 3

    .line 72
    :try_start_0
    invoke-static {p0}, Ljava/time/Instant;->parse(Ljava/lang/CharSequence;)Ljava/time/Instant;

    move-result-object p0

    invoke-virtual {p0}, Ljava/time/Instant;->toEpochMilli()J

    move-result-wide v0
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8} :catch_9

    return-wide v0

    .line 73
    :catch_9
    move-exception p0

    const-wide/16 v0, 0x0

    return-wide v0
.end method


# virtual methods
.method public changeCursor(Landroid/database/Cursor;)V
    .registers 3

    .line 183
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->initialSelection:Lcom/android/mms/tzib/TzibInitialSelection;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibInitialSelection;->smsReady()V

    .line 184
    :cond_7
    invoke-super {p0, p1}, Lcom/android/mms/ui/ConversationListAdapter;->changeCursor(Landroid/database/Cursor;)V

    .line 185
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->selectNewestInitially()V

    .line 186
    return-void
.end method

.method public dispose()V
    .registers 2

    .line 101
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->pause()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->disposed:Z

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->worker:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    return-void
.end method

.method editing()Z
    .registers 2

    .line 266
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->editing:Z

    return v0
.end method

.method public exitEditMode()V
    .registers 2

    .line 265
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->editing:Z

    invoke-super {p0}, Lcom/android/mms/ui/ConversationListAdapter;->exitEditMode()V

    return-void
.end method

.method public getCount()I
    .registers 2

    .line 198
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->entries:Ljava/util/List;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_a

    :cond_6
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    :goto_a
    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .registers 3

    .line 209
    invoke-direct {p0, p1}, Lcom/android/mms/tzib/TzibInboxAdapter;->entry(I)Lcom/android/mms/tzib/TzibIndex$Entry;

    move-result-object p1

    .line 211
    if-eqz p1, :cond_12

    iget-object v0, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    if-eqz v0, :cond_b

    goto :goto_12

    :cond_b
    iget p1, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->smsPosition:I

    invoke-super {p0, p1}, Lcom/android/mms/ui/ConversationListAdapter;->getItem(I)Ljava/lang/Object;

    move-result-object p1

    goto :goto_13

    :cond_12
    :goto_12
    const/4 p1, 0x0

    :goto_13
    return-object p1
.end method

.method public getItemId(I)J
    .registers 4

    .line 214
    invoke-direct {p0, p1}, Lcom/android/mms/tzib/TzibInboxAdapter;->entry(I)Lcom/android/mms/tzib/TzibIndex$Entry;

    move-result-object p1

    .line 215
    if-nez p1, :cond_9

    const-wide/16 v0, -0x1

    goto :goto_b

    :cond_9
    iget-wide v0, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->id:J

    :goto_b
    return-wide v0
.end method

.method public getItemViewType(I)I
    .registers 2

    .line 218
    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibInboxAdapter;->groupAt(I)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object p1

    if-nez p1, :cond_8

    const/4 p1, 0x0

    goto :goto_9

    :cond_8
    const/4 p1, 0x1

    :goto_9
    return p1
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 16

    .line 220
    invoke-direct {p0, p1}, Lcom/android/mms/tzib/TzibInboxAdapter;->entry(I)Lcom/android/mms/tzib/TzibIndex$Entry;

    move-result-object v0

    .line 221
    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibInboxAdapter;->groupAt(I)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    move-result-object v1

    .line 222
    if-nez v1, :cond_13

    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    iget-wide v3, v0, Lcom/android/mms/tzib/TzibIndex$Entry;->id:J

    invoke-static {v2, v3, v4}, Lcom/android/mms/tzib/TzibNotifications;->smsPaused(Landroid/content/Context;J)Z

    move-result v2

    goto :goto_1d

    .line 223
    :cond_13
    iget-object v2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    iget-object v3, v1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v3, v3, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-static {v2, v3}, Lcom/android/mms/tzib/TzibNotifications;->groupPaused(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v2

    .line 225
    :goto_1d
    const/16 v3, 0x8

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v1, :cond_34

    .line 226
    iget v1, v0, Lcom/android/mms/tzib/TzibIndex$Entry;->smsPosition:I

    invoke-super {p0, v1, p2, p3}, Lcom/android/mms/ui/ConversationListAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p2

    .line 228
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->getCursor()Landroid/database/Cursor;

    move-result-object p3

    iget v1, v0, Lcom/android/mms/tzib/TzibIndex$Entry;->smsPosition:I

    invoke-interface {p3, v1}, Landroid/database/Cursor;->moveToPosition(I)Z

    goto/16 :goto_117

    .line 230
    :cond_34
    if-eqz p2, :cond_37

    goto :goto_44

    .line 231
    :cond_37
    iget-object p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    .line 230
    invoke-static {p2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p2

    .line 231
    const v6, 0x7f0a002e

    invoke-virtual {p2, v6, p3, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 232
    :goto_44
    const p3, 0x7f0800b5

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    check-cast p3, Landroid/widget/TextView;

    .line 233
    const v6, 0x7f0801ab

    invoke-virtual {p2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 234
    const v7, 0x7f0801ca

    invoke-virtual {p2, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    .line 235
    const v8, 0x7f0800d0

    invoke-virtual {p2, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/ImageView;

    .line 236
    iget v9, v1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->unread:I

    invoke-static {v9}, Lcom/android/mms/tzib/TzibMetadata;->badge(I)Ljava/lang/String;

    move-result-object v9

    .line 237
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v11, v1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v11, v11, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {p3, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 238
    iget v10, v1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->unread:I

    if-lez v10, :cond_8c

    move v10, v4

    goto :goto_8d

    :cond_8c
    move v10, v5

    :goto_8d
    const/4 v11, 0x0

    invoke-virtual {p3, v11, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 239
    iget-object v10, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-virtual {v10}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    invoke-virtual {v10}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v10

    iget v10, v10, Landroid/util/DisplayMetrics;->widthPixels:I

    if-eqz v2, :cond_a2

    const/16 v11, 0x4a

    goto :goto_a4

    :cond_a2
    const/16 v11, 0x34

    :goto_a4
    sub-int/2addr v10, v11

    invoke-virtual {p3, v10}, Landroid/widget/TextView;->setMaxWidth(I)V

    .line 240
    invoke-virtual {p3, v4}, Landroid/widget/TextView;->setTextDirection(I)V

    .line 241
    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 242
    iget-object p3, v1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->preview:Ljava/lang/String;

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result p3

    const-string v10, "Tzibbur"

    if-eqz p3, :cond_ba

    move-object p3, v10

    goto :goto_bc

    :cond_ba
    iget-object p3, v1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->preview:Ljava/lang/String;

    :goto_bc
    invoke-virtual {v6, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 243
    invoke-virtual {v6, v4}, Landroid/widget/TextView;->setTextDirection(I)V

    .line 244
    invoke-virtual {v6, v4}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 246
    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 247
    const p3, 0x7f0701a1

    invoke-virtual {v8, p3}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 248
    invoke-virtual {v8, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 249
    invoke-virtual {v8, v10}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 250
    iget p3, v1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->unread:I

    if-lez p3, :cond_dc

    const p3, 0x7f070070

    goto :goto_df

    :cond_dc
    const p3, 0x7f07006f

    :goto_df
    invoke-virtual {p2, p3}, Landroid/view/View;->setBackgroundResource(I)V

    .line 251
    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Tzibbur, "

    invoke-virtual {p3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    iget-object v6, v1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v6, v6, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    invoke-virtual {p3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    invoke-virtual {p3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    const-string v6, ", "

    invoke-virtual {p3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    iget-object v1, v1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;->preview:Ljava/lang/String;

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    .line 252
    if-eqz v2, :cond_10a

    const-string v1, ", Notifications paused"

    goto :goto_10c

    :cond_10a
    const-string v1, ""

    :goto_10c
    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    .line 251
    invoke-virtual {p2, p3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 254
    :goto_117
    const-string p3, "tzib_paused_bell"

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object p3

    .line 255
    if-eqz p3, :cond_127

    if-eqz v2, :cond_123

    move v1, v5

    goto :goto_124

    :cond_123
    move v1, v3

    :goto_124
    invoke-virtual {p3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 256
    :cond_127
    const p3, 0x7f08007e

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    check-cast p3, Landroid/widget/TextView;

    .line 257
    iget-wide v0, v0, Lcom/android/mms/tzib/TzibIndex$Entry;->date:J

    invoke-direct {p0, v0, v1}, Lcom/android/mms/tzib/TzibInboxAdapter;->dateLabel(J)Ljava/lang/String;

    move-result-object v0

    .line 258
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_154

    if-eqz p1, :cond_153

    iget-object v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->entries:Ljava/util/List;

    sub-int/2addr p1, v4

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/mms/tzib/TzibIndex$Entry;

    iget-wide v1, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->date:J

    invoke-direct {p0, v1, v2}, Lcom/android/mms/tzib/TzibInboxAdapter;->dateLabel(J)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_154

    :cond_153
    goto :goto_155

    :cond_154
    move v4, v5

    .line 259
    :goto_155
    if-eqz v4, :cond_158

    move v3, v5

    :cond_158
    invoke-virtual {p3, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 260
    invoke-virtual {p3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 261
    return-object p2
.end method

.method public getViewTypeCount()I
    .registers 2

    .line 217
    const/4 v0, 0x2

    return v0
.end method

.method groupAt(I)Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;
    .registers 3

    .line 205
    invoke-direct {p0, p1}, Lcom/android/mms/tzib/TzibInboxAdapter;->entry(I)Lcom/android/mms/tzib/TzibIndex$Entry;

    move-result-object p1

    .line 206
    if-eqz p1, :cond_16

    iget-object v0, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    if-nez v0, :cond_b

    goto :goto_16

    :cond_b
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->groups:Ljava/util/Map;

    iget-object p1, p1, Lcom/android/mms/tzib/TzibIndex$Entry;->groupId:Ljava/lang/String;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/mms/tzib/TzibInboxAdapter$GroupRow;

    goto :goto_17

    :cond_16
    :goto_16
    const/4 p1, 0x0

    :goto_17
    return-object p1
.end method

.method public hasStableIds()Z
    .registers 2

    .line 200
    const/4 v0, 0x1

    return v0
.end method

.method public inEditMode()V
    .registers 2

    .line 264
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->editing:Z

    invoke-super {p0}, Lcom/android/mms/ui/ConversationListAdapter;->inEditMode()V

    return-void
.end method

.method public isEmpty()Z
    .registers 2

    .line 199
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->getCount()I

    move-result v0

    if-nez v0, :cond_8

    const/4 v0, 0x1

    goto :goto_9

    :cond_8
    const/4 v0, 0x0

    :goto_9
    return v0
.end method

.method synthetic lambda$selectNewestInitially$0$com-android-mms-tzib-TzibInboxAdapter(Landroid/widget/ListView;)V
    .registers 4

    .line 192
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->disposed:Z

    if-nez v0, :cond_23

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_23

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->initialSelection:Lcom/android/mms/tzib/TzibInitialSelection;

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->getCount()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/android/mms/tzib/TzibInitialSelection;->select(I)Z

    move-result v0

    if-eqz v0, :cond_23

    .line 193
    invoke-virtual {p1}, Landroid/widget/ListView;->requestFocus()Z

    .line 194
    invoke-virtual {p1}, Landroid/widget/ListView;->getHeaderViewsCount()I

    move-result v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    .line 196
    :cond_23
    return-void
.end method

.method public notifyDataSetChanged()V
    .registers 2

    .line 170
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->rebuild()V

    .line 171
    invoke-super {p0}, Lcom/android/mms/ui/ConversationListAdapter;->notifyDataSetChanged()V

    .line 172
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    if-eqz v0, :cond_15

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_15

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibHook;->inboxChanged(Landroid/app/Activity;)V

    .line 173
    :cond_15
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->selectNewestInitially()V

    .line 174
    return-void
.end method

.method public notifyDataSetInvalidated()V
    .registers 2

    .line 177
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->rebuild()V

    .line 178
    invoke-super {p0}, Lcom/android/mms/ui/ConversationListAdapter;->notifyDataSetChanged()V

    .line 179
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    if-eqz v0, :cond_15

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_15

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibHook;->inboxChanged(Landroid/app/Activity;)V

    .line 180
    :cond_15
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->selectNewestInitially()V

    .line 181
    return-void
.end method

.method public onCommandResult(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbCommandResult;)V
    .registers 3

    .line 272
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->load()V

    return-void
.end method

.method public onConnectionChanged(I)V
    .registers 2

    .line 269
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->load()V

    return-void
.end method

.method public onDeviceBlocked()V
    .registers 2

    .line 271
    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->groups:Ljava/util/Map;

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->notifyDataSetChanged()V

    return-void
.end method

.method public onGroupMessagesChanged(Ljava/lang/String;)V
    .registers 2

    .line 268
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->load()V

    return-void
.end method

.method public onGroupsChanged()V
    .registers 1

    .line 267
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->load()V

    return-void
.end method

.method public onSendFailed(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
    .registers 4

    .line 273
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->load()V

    return-void
.end method

.method public onSessionExpired()V
    .registers 2

    .line 270
    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->clear()V

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->groups:Ljava/util/Map;

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->notifyDataSetChanged()V

    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->load()V

    return-void
.end method

.method public pause()V
    .registers 3

    .line 96
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->active:Z

    if-eqz v0, :cond_11

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0, p0}, Lcom/tzibbur/basic/sync/TzbSync;->removeListener(Lcom/tzibbur/basic/sync/TzbSyncListener;)V

    .line 97
    :cond_11
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->active:Z

    .line 98
    iget v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->generation:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->generation:I

    .line 99
    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->reload:Z

    .line 100
    return-void
.end method

.method public resume()V
    .registers 2

    .line 77
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->disposed:Z

    if-eqz v0, :cond_5

    return-void

    .line 78
    :cond_5
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->allowed:Z

    .line 79
    if-nez v0, :cond_21

    .line 80
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->initialSelection:Lcom/android/mms/tzib/TzibInitialSelection;

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibInitialSelection;->groupsReady()V

    .line 81
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->pause()V

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->groups:Ljava/util/Map;

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->notifyDataSetChanged()V

    .line 82
    return-void

    .line 84
    :cond_21
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->active:Z

    if-nez v0, :cond_35

    .line 85
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->active:Z

    .line 86
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0, p0}, Lcom/tzibbur/basic/sync/TzbSync;->addListener(Lcom/tzibbur/basic/sync/TzbSyncListener;)V

    .line 88
    :cond_35
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v0

    if-eqz v0, :cond_57

    .line 89
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncService;->ensureRunning(Landroid/content/Context;)V

    .line 90
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->activity:Landroid/app/Activity;

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    .line 92
    :cond_57
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibInboxAdapter;->load()V

    .line 93
    return-void
.end method

.method userInteracted()V
    .registers 2

    .line 187
    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter;->initialSelection:Lcom/android/mms/tzib/TzibInitialSelection;

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibInitialSelection;->interacted()V

    return-void
.end method
