.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Lcom/tzibbur/basic/core/TzbCore;

.field public final synthetic f$2:Lcom/tzibbur/basic/model/TzbDevice;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Lcom/tzibbur/basic/core/TzbCore;Lcom/tzibbur/basic/model/TzbDevice;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda5;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda5;->f$1:Lcom/tzibbur/basic/core/TzbCore;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda5;->f$2:Lcom/tzibbur/basic/model/TzbDevice;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda5;->f$0:Landroid/app/Activity;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda5;->f$1:Lcom/tzibbur/basic/core/TzbCore;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda5;->f$2:Lcom/tzibbur/basic/model/TzbDevice;

    invoke-static {v0, v1, v2, p1, p2}, Lcom/android/mms/tzib/TzibSettings;->lambda$devices$22(Landroid/app/Activity;Lcom/tzibbur/basic/core/TzbCore;Lcom/tzibbur/basic/model/TzbDevice;Landroid/content/DialogInterface;I)V

    return-void
.end method
