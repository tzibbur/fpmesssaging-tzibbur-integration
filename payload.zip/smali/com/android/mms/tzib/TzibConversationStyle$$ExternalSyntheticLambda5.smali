.class public final synthetic Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalFocusChangeListener;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibConversationStyle;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibConversationStyle;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda5;->f$0:Lcom/android/mms/tzib/TzibConversationStyle;

    return-void
.end method


# virtual methods
.method public final onGlobalFocusChanged(Landroid/view/View;Landroid/view/View;)V
    .registers 4

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda5;->f$0:Lcom/android/mms/tzib/TzibConversationStyle;

    invoke-static {v0, p1, p2}, Lcom/android/mms/tzib/TzibConversationStyle;->lambda$install$0(Lcom/android/mms/tzib/TzibConversationStyle;Landroid/view/View;Landroid/view/View;)V

    return-void
.end method
