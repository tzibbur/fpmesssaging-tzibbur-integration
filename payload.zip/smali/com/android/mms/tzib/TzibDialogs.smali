.class public final Lcom/android/mms/tzib/TzibDialogs;
.super Ljava/lang/Object;
.source "TzibDialogs.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;
    .registers 5

    .line 10
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "style"

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "TzibDialogTheme"

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 11
    new-instance v1, Landroid/app/AlertDialog$Builder;

    if-eqz v0, :cond_15

    goto :goto_18

    :cond_15
    const v0, 0x103023a

    :goto_18
    invoke-direct {v1, p0, v0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    return-object v1
.end method
