.class public final synthetic Lcom/android/mms/tzib/TzibLegalDocuments$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/tzibbur/basic/net/TzbTokenSupplier;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final token()Ljava/lang/String;
    .registers 2

    invoke-static {}, Lcom/android/mms/tzib/TzibLegalDocuments;->lambda$fetch$0()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
