.class public final Lcom/android/mms/tzib/TzibGate;
.super Ljava/lang/Object;
.source "TzibGate.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static declared-synchronized enableFromDialer(Landroid/content/Context;)Z
    .registers 2

    const-class v0, Lcom/android/mms/tzib/TzibGate;

    monitor-enter v0

    .line 32
    :try_start_3
    invoke-static {p0}, Lcom/android/mms/tzib/TzibGate;->sync(Landroid/content/Context;)Z
    :try_end_6
    .catchall {:try_start_3 .. :try_end_6} :catchall_9

    .line 33
    monitor-exit v0

    const/4 p0, 0x0

    return p0

    .line 31
    :catchall_9
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static sync(Landroid/content/Context;)Z
    .registers 5

    .line 12
    const-string v0, "disable_tzibbur"

    :try_start_2
    invoke-static {p0}, Lcom/android/mms/tzib/TzibMetadata;->init(Landroid/content/Context;)V

    .line 13
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->init(Landroid/content/Context;)V
    :try_end_8
    .catchall {:try_start_2 .. :try_end_8} :catchall_9

    goto :goto_a

    .line 14
    :catchall_9
    move-exception v1

    :goto_a
    nop

    .line 15
    if-eqz p0, :cond_39

    .line 17
    :try_start_d
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    .line 18
    if-nez v1, :cond_14

    goto :goto_15

    :cond_14
    move-object p0, v1

    .line 19
    :goto_15
    const-string v1, "tzb_config"

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 20
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p0}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object v3

    invoke-interface {v3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_37

    .line 21
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v0, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_37
    .catchall {:try_start_d .. :try_end_37} :catchall_38

    .line 25
    :cond_37
    goto :goto_39

    .line 23
    :catchall_38
    move-exception p0

    .line 27
    :cond_39
    :goto_39
    const/4 p0, 0x1

    return p0
.end method
