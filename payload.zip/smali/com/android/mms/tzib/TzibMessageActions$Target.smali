.class final Lcom/android/mms/tzib/TzibMessageActions$Target;
.super Ljava/lang/Object;
.source "TzibMessageActions.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/mms/tzib/TzibMessageActions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Target"
.end annotation


# instance fields
.field final clientId:Ljava/lang/String;

.field final group:Ljava/lang/String;

.field final id:Ljava/lang/String;

.field final item:Ljava/lang/Object;

.field final owner:Ljava/lang/String;

.field final sending:Z

.field final text:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 8

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    iput-object p1, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->item:Ljava/lang/Object;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->owner:Ljava/lang/String;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->group:Ljava/lang/String;

    iput-object p4, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->id:Ljava/lang/String;

    .line 29
    iput-object p5, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->clientId:Ljava/lang/String;

    iput-object p6, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->text:Ljava/lang/String;

    iput-boolean p7, p0, Lcom/android/mms/tzib/TzibMessageActions$Target;->sending:Z

    .line 30
    return-void
.end method
