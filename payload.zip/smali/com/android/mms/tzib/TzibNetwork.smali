.class final Lcom/android/mms/tzib/TzibNetwork;
.super Ljava/lang/Object;
.source "TzibNetwork.java"


# direct methods
.method constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic lambda$request$0(Ljava/lang/String;)Ljava/lang/String;
    .registers 1

    .line 15
    return-object p0
.end method

.method static request(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 12
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_4e

    .line 13
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object p0

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object p0

    invoke-interface {p0}, Lcom/tzibbur/basic/store/TzbSession;->token()Ljava/lang/String;

    move-result-object p0

    .line 14
    if-eqz p0, :cond_46

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_46

    .line 15
    new-instance v0, Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v1, Lcom/android/mms/tzib/TzibNetwork$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/android/mms/tzib/TzibNetwork$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    const-string p0, "https://api.tzibbur.me"

    invoke-direct {v0, p0, v1}, Lcom/tzibbur/basic/net/TzbHttp;-><init>(Ljava/lang/String;Lcom/tzibbur/basic/net/TzbTokenSupplier;)V

    .line 16
    const/4 p0, 0x1

    invoke-virtual {v0, p1, p2, p3, p0}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object p0

    .line 17
    iget-object p1, p0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    if-eqz p1, :cond_40

    iget-object p1, p0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_38

    goto :goto_40

    :cond_38
    new-instance p1, Lorg/json/JSONObject;

    iget-object p0, p0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-direct {p1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    goto :goto_45

    :cond_40
    :goto_40
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    :goto_45
    return-object p1

    .line 14
    :cond_46
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Sign in to Tzibbur first"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 12
    :cond_4e
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Tzibbur is disabled"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static segment(Ljava/lang/String;)Ljava/lang/String;
    .registers 1

    .line 19
    invoke-static {p0}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
