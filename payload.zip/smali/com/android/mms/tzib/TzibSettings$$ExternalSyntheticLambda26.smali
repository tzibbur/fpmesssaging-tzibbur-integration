.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda26;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/preference/PreferenceActivity;


# direct methods
.method public synthetic constructor <init>(Landroid/preference/PreferenceActivity;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda26;->f$0:Landroid/preference/PreferenceActivity;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda26;->f$0:Landroid/preference/PreferenceActivity;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibSettings;->lambda$install$9(Landroid/preference/PreferenceActivity;)V

    return-void
.end method
