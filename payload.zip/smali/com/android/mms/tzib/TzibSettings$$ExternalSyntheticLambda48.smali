.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/widget/EditText;

.field public final synthetic f$1:Lcom/tzibbur/basic/core/TzbCore;

.field public final synthetic f$2:Landroid/app/AlertDialog;

.field public final synthetic f$3:Landroid/preference/PreferenceActivity;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;Lcom/tzibbur/basic/core/TzbCore;Landroid/app/AlertDialog;Landroid/preference/PreferenceActivity;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;->f$0:Landroid/widget/EditText;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;->f$1:Lcom/tzibbur/basic/core/TzbCore;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;->f$2:Landroid/app/AlertDialog;

    iput-object p4, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;->f$3:Landroid/preference/PreferenceActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 6

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;->f$0:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;->f$1:Lcom/tzibbur/basic/core/TzbCore;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;->f$2:Landroid/app/AlertDialog;

    iget-object v3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;->f$3:Landroid/preference/PreferenceActivity;

    invoke-static {v0, v1, v2, v3, p1}, Lcom/android/mms/tzib/TzibSettings;->lambda$editName$17(Landroid/widget/EditText;Lcom/tzibbur/basic/core/TzbCore;Landroid/app/AlertDialog;Landroid/preference/PreferenceActivity;Landroid/view/View;)V

    return-void
.end method
