.class public final synthetic Lcom/android/mms/tzib/TzibInboxAdapter$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibInboxAdapter;

.field public final synthetic f$1:Landroid/widget/ListView;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibInboxAdapter;Landroid/widget/ListView;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$$ExternalSyntheticLambda0;->f$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibInboxAdapter$$ExternalSyntheticLambda0;->f$1:Landroid/widget/ListView;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lcom/android/mms/tzib/TzibInboxAdapter$$ExternalSyntheticLambda0;->f$0:Lcom/android/mms/tzib/TzibInboxAdapter;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibInboxAdapter$$ExternalSyntheticLambda0;->f$1:Landroid/widget/ListView;

    invoke-virtual {v0, v1}, Lcom/android/mms/tzib/TzibInboxAdapter;->lambda$selectNewestInitially$0$com-android-mms-tzib-TzibInboxAdapter(Landroid/widget/ListView;)V

    return-void
.end method
