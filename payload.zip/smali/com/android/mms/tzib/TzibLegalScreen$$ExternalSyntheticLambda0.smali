.class public final synthetic Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibLegalScreen;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibLegalScreen;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda0;->f$0:Lcom/android/mms/tzib/TzibLegalScreen;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda0;->f$0:Lcom/android/mms/tzib/TzibLegalScreen;

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibLegalScreen;->lambda$fetch$1$com-android-mms-tzib-TzibLegalScreen()Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    move-result-object v0

    return-object v0
.end method
