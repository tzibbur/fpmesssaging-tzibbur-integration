.class public final Lcom/android/mms/tzib/TzibIndex;
.super Ljava/lang/Object;
.source "TzibIndex.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/mms/tzib/TzibIndex$Entry;
    }
.end annotation


# instance fields
.field private final ids:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private nextId:J


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/android/mms/tzib/TzibIndex;->ids:Ljava/util/Map;

    .line 25
    const-wide/16 v0, -0x2

    iput-wide v0, p0, Lcom/android/mms/tzib/TzibIndex;->nextId:J

    return-void
.end method

.method public static merge(Ljava/util/List;Ljava/util/List;Z)Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/android/mms/tzib/TzibIndex$Entry;",
            ">;",
            "Ljava/util/List<",
            "Lcom/android/mms/tzib/TzibIndex$Entry;",
            ">;Z)",
            "Ljava/util/List<",
            "Lcom/android/mms/tzib/TzibIndex$Entry;",
            ">;"
        }
    .end annotation

    .line 33
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 34
    if-nez p2, :cond_a

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 35
    :cond_a
    new-instance p0, Lcom/android/mms/tzib/TzibIndex$1;

    invoke-direct {p0}, Lcom/android/mms/tzib/TzibIndex$1;-><init>()V

    invoke-static {v0, p0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 46
    return-object v0
.end method


# virtual methods
.method public group(Ljava/lang/String;J)Lcom/android/mms/tzib/TzibIndex$Entry;
    .registers 14

    .line 27
    if-eqz p1, :cond_32

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_32

    .line 28
    iget-object v0, p0, Lcom/android/mms/tzib/TzibIndex;->ids:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    .line 29
    if-nez v0, :cond_23

    iget-wide v0, p0, Lcom/android/mms/tzib/TzibIndex;->nextId:J

    const-wide/16 v2, 0x1

    sub-long v2, v0, v2

    iput-wide v2, p0, Lcom/android/mms/tzib/TzibIndex;->nextId:J

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    iget-object v1, p0, Lcom/android/mms/tzib/TzibIndex;->ids:Ljava/util/Map;

    invoke-interface {v1, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    :cond_23
    new-instance v9, Lcom/android/mms/tzib/TzibIndex$Entry;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v6, -0x1

    const/4 v8, 0x0

    move-object v1, v9

    move-wide v4, p2

    move-object v7, p1

    invoke-direct/range {v1 .. v8}, Lcom/android/mms/tzib/TzibIndex$Entry;-><init>(JJILjava/lang/String;Lcom/android/mms/tzib/TzibIndex$1;)V

    return-object v9

    .line 27
    :cond_32
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Missing group identity"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
