.class final Lcom/android/mms/tzib/TzibThreadOptions$State;
.super Ljava/lang/Object;
.source "TzibThreadOptions.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/mms/tzib/TzibThreadOptions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "State"
.end annotation


# instance fields
.field offered:Lcom/android/mms/tzib/TzibThreadOptions$Target;

.field open:Z

.field selected:Lcom/android/mms/tzib/TzibThreadOptions$Target;


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/android/mms/tzib/TzibThreadOptions$1;)V
    .registers 2

    .line 23
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibThreadOptions$State;-><init>()V

    return-void
.end method
