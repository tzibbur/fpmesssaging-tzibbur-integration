.class final Lcom/android/mms/tzib/TzibPreferenceNumbers;
.super Ljava/lang/Object;
.source "TzibPreferenceNumbers.java"


# direct methods
.method constructor <init>()V
    .registers 1

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static apply(Landroid/preference/PreferenceGroup;I)V
    .registers 8

    .line 25
    const/4 v0, 0x0

    :goto_1
    invoke-virtual {p0}, Landroid/preference/PreferenceGroup;->getPreferenceCount()I

    move-result v1

    if-ge v0, v1, :cond_42

    .line 26
    invoke-virtual {p0, v0}, Landroid/preference/PreferenceGroup;->getPreference(I)Landroid/preference/Preference;

    move-result-object v1

    .line 27
    invoke-virtual {v1}, Landroid/preference/Preference;->getTitle()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-interface {v2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v2

    .line 28
    invoke-static {v2}, Lcom/android/mms/tzib/TzibPreferenceNumbers;->number(Ljava/lang/CharSequence;)I

    move-result v3

    const-string v4, ". "

    if-ltz v3, :cond_25

    invoke-virtual {v2, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v3

    add-int/lit8 v3, v3, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    .line 29
    :cond_25
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    add-int v5, p1, v0

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    .line 25
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 31
    :cond_42
    return-void
.end method

.method static next(Landroid/preference/PreferenceGroup;)I
    .registers 5

    .line 17
    nop

    .line 18
    const/4 v0, 0x0

    move v1, v0

    :goto_3
    invoke-virtual {p0}, Landroid/preference/PreferenceGroup;->getPreferenceCount()I

    move-result v2

    if-ge v0, v2, :cond_29

    .line 19
    invoke-virtual {p0, v0}, Landroid/preference/PreferenceGroup;->getPreference(I)Landroid/preference/Preference;

    move-result-object v2

    .line 20
    instance-of v3, v2, Landroid/preference/PreferenceGroup;

    if-eqz v3, :cond_18

    check-cast v2, Landroid/preference/PreferenceGroup;

    invoke-static {v2}, Lcom/android/mms/tzib/TzibPreferenceNumbers;->next(Landroid/preference/PreferenceGroup;)I

    move-result v2

    goto :goto_22

    :cond_18
    invoke-virtual {v2}, Landroid/preference/Preference;->getTitle()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Lcom/android/mms/tzib/TzibPreferenceNumbers;->number(Ljava/lang/CharSequence;)I

    move-result v2

    add-int/lit8 v2, v2, 0x1

    :goto_22
    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 18
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    .line 22
    :cond_29
    return v1
.end method

.method static number(Ljava/lang/CharSequence;)I
    .registers 4

    .line 9
    const/4 v0, -0x1

    if-nez p0, :cond_4

    return v0

    .line 10
    :cond_4
    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    .line 11
    const-string v1, ". "

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    .line 12
    const/4 v2, 0x1

    if-ge v1, v2, :cond_12

    return v0

    .line 13
    :cond_12
    const/4 v2, 0x0

    :try_start_13
    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0
    :try_end_1b
    .catch Ljava/lang/NumberFormatException; {:try_start_13 .. :try_end_1b} :catch_1c

    return p0

    .line 14
    :catch_1c
    move-exception p0

    return v0
.end method
