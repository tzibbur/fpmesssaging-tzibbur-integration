.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda40;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Lcom/tzibbur/basic/core/TzbCore;

.field public final synthetic f$1:Landroid/app/AlertDialog;

.field public final synthetic f$2:Landroid/preference/PreferenceActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/tzibbur/basic/core/TzbCore;Landroid/app/AlertDialog;Landroid/preference/PreferenceActivity;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda40;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda40;->f$1:Landroid/app/AlertDialog;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda40;->f$2:Landroid/preference/PreferenceActivity;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .registers 5

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda40;->f$0:Lcom/tzibbur/basic/core/TzbCore;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda40;->f$1:Landroid/app/AlertDialog;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda40;->f$2:Landroid/preference/PreferenceActivity;

    check-cast p1, Lcom/tzibbur/basic/model/TzbUser;

    invoke-static {v0, v1, v2, p1}, Lcom/android/mms/tzib/TzibSettings;->lambda$editName$15(Lcom/tzibbur/basic/core/TzbCore;Landroid/app/AlertDialog;Landroid/preference/PreferenceActivity;Lcom/tzibbur/basic/model/TzbUser;)V

    return-void
.end method
