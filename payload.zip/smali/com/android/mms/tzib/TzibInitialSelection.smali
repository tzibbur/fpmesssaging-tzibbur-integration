.class final Lcom/android/mms/tzib/TzibInitialSelection;
.super Ljava/lang/Object;
.source "TzibInitialSelection.java"


# instance fields
.field private finished:Z

.field private groupsReady:Z

.field private smsReady:Z


# direct methods
.method constructor <init>()V
    .registers 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method groupsReady()V
    .registers 2

    .line 7
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInitialSelection;->groupsReady:Z

    return-void
.end method

.method interacted()V
    .registers 2

    .line 8
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInitialSelection;->finished:Z

    return-void
.end method

.method ready()Z
    .registers 2

    .line 9
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInitialSelection;->finished:Z

    if-nez v0, :cond_e

    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInitialSelection;->smsReady:Z

    if-eqz v0, :cond_e

    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibInitialSelection;->groupsReady:Z

    if-eqz v0, :cond_e

    const/4 v0, 0x1

    goto :goto_f

    :cond_e
    const/4 v0, 0x0

    :goto_f
    return v0
.end method

.method select(I)Z
    .registers 3

    .line 11
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibInitialSelection;->ready()Z

    move-result v0

    if-eqz v0, :cond_d

    if-nez p1, :cond_9

    goto :goto_d

    .line 12
    :cond_9
    const/4 p1, 0x1

    iput-boolean p1, p0, Lcom/android/mms/tzib/TzibInitialSelection;->finished:Z

    .line 13
    return p1

    .line 11
    :cond_d
    :goto_d
    const/4 p1, 0x0

    return p1
.end method

.method smsReady()V
    .registers 2

    .line 6
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibInitialSelection;->smsReady:Z

    return-void
.end method
