.class public final synthetic Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibConversationStyle;

.field public final synthetic f$1:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibConversationStyle;Landroid/app/Activity;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda6;->f$0:Lcom/android/mms/tzib/TzibConversationStyle;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda6;->f$1:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .registers 6

    iget-object v0, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda6;->f$0:Lcom/android/mms/tzib/TzibConversationStyle;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibConversationStyle$$ExternalSyntheticLambda6;->f$1:Landroid/app/Activity;

    invoke-static {v0, v1, p1, p2, p3}, Lcom/android/mms/tzib/TzibConversationStyle;->lambda$install$2(Lcom/android/mms/tzib/TzibConversationStyle;Landroid/app/Activity;Landroid/view/View;ILandroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method
