.class public final synthetic Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibAboutScreen;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibAboutScreen;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda3;->f$0:Lcom/android/mms/tzib/TzibAboutScreen;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lcom/android/mms/tzib/TzibAboutScreen$$ExternalSyntheticLambda3;->f$0:Lcom/android/mms/tzib/TzibAboutScreen;

    invoke-virtual {v0}, Lcom/android/mms/tzib/TzibAboutScreen;->lambda$onCreate$2$com-android-mms-tzib-TzibAboutScreen()V

    return-void
.end method
