.class public final synthetic Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda2;->f$0:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .registers 3

    iget-object v0, p0, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda2;->f$0:Landroid/app/Activity;

    check-cast p1, Ljava/lang/Exception;

    invoke-static {v0, p1}, Lcom/android/mms/tzib/TzibMessageActions;->lambda$perform$2(Landroid/app/Activity;Ljava/lang/Exception;)V

    return-void
.end method
