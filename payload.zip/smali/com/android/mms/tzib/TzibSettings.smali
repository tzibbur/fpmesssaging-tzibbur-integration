.class public final Lcom/android/mms/tzib/TzibSettings;
.super Ljava/lang/Object;
.source "TzibSettings.java"


# static fields
.field private static final KEY:Ljava/lang/String; = "tzib_settings_category"


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
    .registers 10

    .line 83
    new-instance v0, Landroid/preference/Preference;

    invoke-direct {v0, p0}, Landroid/preference/Preference;-><init>(Landroid/content/Context;)V

    .line 84
    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    .line 85
    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getPackageName()Ljava/lang/String;

    move-result-object v2

    .line 84
    const-string v3, "custom_preference_layout"

    const-string v4, "layout"

    invoke-virtual {v1, v3, v4, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setLayoutResource(I)V

    .line 86
    invoke-virtual {v0, p2}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    .line 87
    if-eqz p3, :cond_26

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_26

    invoke-virtual {v0, p3}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    .line 88
    :cond_26
    const/4 p2, 0x0

    invoke-virtual {v0, p2}, Landroid/preference/Preference;->setPersistent(Z)V

    .line 89
    new-instance p2, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda0;

    invoke-direct {p2, p0, p4}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda0;-><init>(Landroid/preference/PreferenceActivity;Ljava/lang/Runnable;)V

    invoke-virtual {v0, p2}, Landroid/preference/Preference;->setOnPreferenceClickListener(Landroid/preference/Preference$OnPreferenceClickListener;)V

    .line 94
    invoke-virtual {p1, v0}, Landroid/preference/PreferenceCategory;->addPreference(Landroid/preference/Preference;)Z

    .line 95
    return-void
.end method

.method private static answerInvite(Landroid/app/Activity;Ljava/lang/String;Z)V
    .registers 4

    .line 179
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda6;

    invoke-direct {v0, p0, p1, p2}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda6;-><init>(Landroid/app/Activity;Ljava/lang/String;Z)V

    new-instance p1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda7;

    invoke-direct {p1, p0, p2}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda7;-><init>(Landroid/app/Activity;Z)V

    invoke-static {p0, v0, p1}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    .line 185
    return-void
.end method

.method private static blocks(Landroid/app/Activity;)V
    .registers 3

    .line 187
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda44;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda44;-><init>(Landroid/app/Activity;)V

    new-instance v1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda45;

    invoke-direct {v1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda45;-><init>(Landroid/app/Activity;)V

    invoke-static {p0, v0, v1}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    .line 203
    return-void
.end method

.method private static changed(Landroid/app/Activity;)V
    .registers 2

    .line 101
    instance-of v0, p0, Landroid/preference/PreferenceActivity;

    if-eqz v0, :cond_a

    move-object v0, p0

    check-cast v0, Landroid/preference/PreferenceActivity;

    invoke-static {v0}, Lcom/android/mms/tzib/TzibSettings;->install(Landroid/preference/PreferenceActivity;)V

    .line 102
    :cond_a
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object p0

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object p0

    invoke-interface {p0}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    .line 103
    return-void
.end method

.method private static clearSession(Landroid/app/Activity;)V
    .registers 3

    .line 218
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda46;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda46;-><init>(Landroid/app/Activity;)V

    new-instance v1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda47;

    invoke-direct {v1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda47;-><init>(Landroid/app/Activity;)V

    invoke-static {p0, v0, v1}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    .line 222
    return-void
.end method

.method private static confirmSignOut(Landroid/app/Activity;)V
    .registers 3

    .line 205
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Sign out of Tzibbur?"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 206
    const-string v1, "Tzibbur messages on this phone will be cleared. You will need to sign in again. Text messages stay on this phone."

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda10;

    invoke-direct {v1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda10;-><init>(Landroid/app/Activity;)V

    .line 207
    const-string p0, "Sign out"

    invoke-virtual {v0, p0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 215
    const/high16 v0, 0x1040000

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 216
    return-void
.end method

.method private static connection(I)Ljava/lang/String;
    .registers 1

    .line 98
    packed-switch p0, :pswitch_data_10

    const-string p0, "Offline"

    return-object p0

    :pswitch_6
    const-string p0, "Connected (polling)"

    return-object p0

    :pswitch_9
    const-string p0, "Connected"

    return-object p0

    :pswitch_c
    const-string p0, "Connecting"

    return-object p0

    nop

    :pswitch_data_10
    .packed-switch 0x1
        :pswitch_c
        :pswitch_9
        :pswitch_6
    .end packed-switch
.end method

.method private static deleteAccount(Landroid/app/Activity;)V
    .registers 4

    .line 224
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Delete Tzibbur account"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Delete in 7 days"

    const-string v2, "Delete without a grace period"

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda4;

    invoke-direct {v2, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda4;-><init>(Landroid/app/Activity;)V

    .line 225
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 247
    const/high16 v0, 0x1040000

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 248
    return-void
.end method

.method private static devices(Landroid/app/Activity;)V
    .registers 4

    .line 142
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    .line 143
    new-instance v1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda8;

    invoke-direct {v1, v0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda8;-><init>(Lcom/tzibbur/basic/core/TzbCore;)V

    new-instance v2, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda9;

    invoke-direct {v2, v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda9;-><init>(Lcom/tzibbur/basic/core/TzbCore;Landroid/app/Activity;)V

    invoke-static {p0, v1, v2}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    .line 161
    return-void
.end method

.method private static editName(Landroid/preference/PreferenceActivity;)V
    .registers 6

    .line 105
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    .line 106
    new-instance v1, Landroid/widget/EditText;

    invoke-direct {v1, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 107
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 108
    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v2

    invoke-interface {v2}, Lcom/tzibbur/basic/store/TzbSession;->displayName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 109
    invoke-virtual {v1}, Landroid/widget/EditText;->selectAll()V

    .line 110
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const-string v3, "Display name"

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    .line 111
    const-string v3, "Save"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const/high16 v3, 0x1040000

    invoke-virtual {v2, v3, v4}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v2

    .line 112
    new-instance v3, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda36;

    invoke-direct {v3, v2, v1, v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda36;-><init>(Landroid/app/AlertDialog;Landroid/widget/EditText;Lcom/tzibbur/basic/core/TzbCore;Landroid/preference/PreferenceActivity;)V

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 127
    invoke-virtual {v2}, Landroid/app/AlertDialog;->show()V

    .line 128
    return-void
.end method

.method public static install(Landroid/preference/PreferenceActivity;)V
    .registers 8

    .line 27
    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getPreferenceScreen()Landroid/preference/PreferenceScreen;

    move-result-object v0

    .line 28
    if-nez v0, :cond_7

    return-void

    .line 29
    :cond_7
    const-string v1, "tzib_settings_category"

    invoke-virtual {p0, v1}, Landroid/preference/PreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v2

    .line 30
    if-eqz v2, :cond_12

    invoke-virtual {v0, v2}, Landroid/preference/PreferenceScreen;->removePreference(Landroid/preference/Preference;)Z

    .line 31
    :cond_12
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_19

    return-void

    .line 32
    :cond_19
    invoke-static {v0}, Lcom/android/mms/tzib/TzibPreferenceNumbers;->next(Landroid/preference/PreferenceGroup;)I

    move-result v2

    .line 33
    new-instance v3, Landroid/preference/PreferenceCategory;

    invoke-direct {v3, p0}, Landroid/preference/PreferenceCategory;-><init>(Landroid/content/Context;)V

    .line 34
    invoke-virtual {v3, v1}, Landroid/preference/PreferenceCategory;->setKey(Ljava/lang/String;)V

    .line 35
    const-string v1, "Tzibbur"

    invoke-virtual {v3, v1}, Landroid/preference/PreferenceCategory;->setTitle(Ljava/lang/CharSequence;)V

    .line 36
    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    .line 37
    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    .line 36
    const-string v5, "custom_preference_layout"

    const-string v6, "layout"

    invoke-virtual {v1, v5, v6, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v3, v1}, Landroid/preference/PreferenceCategory;->setLayoutResource(I)V

    .line 38
    const/16 v1, 0x3e8

    invoke-virtual {v3, v1}, Landroid/preference/PreferenceCategory;->setOrder(I)V

    .line 39
    invoke-virtual {v0, v3}, Landroid/preference/PreferenceScreen;->addPreference(Landroid/preference/Preference;)Z

    .line 40
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    .line 41
    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v1

    if-eqz v1, :cond_ed

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbSession;->deviceBlocked()Z

    move-result v1

    if-eqz v1, :cond_5f

    goto/16 :goto_ed

    .line 44
    :cond_5f
    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbSession;->displayName()Ljava/lang/String;

    move-result-object v1

    new-instance v4, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda19;

    invoke-direct {v4, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda19;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v5, "Display name"

    invoke-static {p0, v3, v5, v1, v4}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 45
    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v1

    new-instance v4, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda20;

    invoke-direct {v4, p0, v0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda20;-><init>(Landroid/preference/PreferenceActivity;Lcom/tzibbur/basic/core/TzbCore;)V

    const-string v5, "Account"

    invoke-static {p0, v3, v5, v1, v4}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 50
    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/sync/TzbSync;->connectionState()I

    move-result v1

    invoke-static {v1}, Lcom/android/mms/tzib/TzibSettings;->connection(I)Ljava/lang/String;

    move-result-object v1

    new-instance v4, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda21;

    invoke-direct {v4, v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda21;-><init>(Lcom/tzibbur/basic/core/TzbCore;Landroid/preference/PreferenceActivity;)V

    const-string v0, "Connection"

    invoke-static {p0, v3, v0, v1, v4}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 54
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda22;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda22;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v1, "Tzibbur notifications"

    const-string v4, "Message sound and alerts"

    invoke-static {p0, v3, v1, v4, v0}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 55
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda23;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda23;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v1, "Background notification"

    const-string v4, "Background connection status"

    invoke-static {p0, v3, v1, v4, v0}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 56
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda24;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda24;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v1, "My devices"

    const-string v4, "Manage devices signed in to Tzibbur"

    invoke-static {p0, v3, v1, v4, v0}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 57
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda25;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda25;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v1, "Invitations"

    const-string v4, "Review group invitations"

    invoke-static {p0, v3, v1, v4, v0}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 58
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda26;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda26;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v1, "Blocked groups and people"

    const-string v4, "Review or remove blocks"

    invoke-static {p0, v3, v1, v4, v0}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 59
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda27;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda27;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v1, "Sign out of Tzibbur"

    const/4 v4, 0x0

    invoke-static {p0, v3, v1, v4, v0}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 60
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda17;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda17;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v1, "Delete Tzibbur account"

    const-string v4, "Manage account deletion"

    invoke-static {p0, v3, v1, v4, v0}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    goto :goto_f9

    .line 42
    :cond_ed
    :goto_ed
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda16;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda16;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v1, "Set up Tzibbur"

    const-string v4, "Group messaging"

    invoke-static {p0, v3, v1, v4, v0}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 62
    :goto_f9
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda18;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda18;-><init>(Landroid/preference/PreferenceActivity;)V

    const-string v1, "About Tzibbur"

    const-string v4, "Privacy policy, terms and service information"

    invoke-static {p0, v3, v1, v4, v0}, Lcom/android/mms/tzib/TzibSettings;->add(Landroid/preference/PreferenceActivity;Landroid/preference/PreferenceCategory;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 64
    invoke-static {v3, v2}, Lcom/android/mms/tzib/TzibPreferenceNumbers;->apply(Landroid/preference/PreferenceGroup;I)V

    .line 65
    return-void
.end method

.method static invitations(Landroid/app/Activity;)V
    .registers 3

    .line 163
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda37;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda37;-><init>(Landroid/app/Activity;)V

    new-instance v1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda38;

    invoke-direct {v1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda38;-><init>(Landroid/app/Activity;)V

    invoke-static {p0, v0, v1}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    .line 177
    return-void
.end method

.method static synthetic lambda$add$13(Landroid/preference/PreferenceActivity;Ljava/lang/Runnable;Landroid/preference/Preference;)Z
    .registers 3

    .line 90
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p2

    if-eqz p2, :cond_a

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    goto :goto_d

    .line 91
    :cond_a
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->install(Landroid/preference/PreferenceActivity;)V

    .line 92
    :goto_d
    const/4 p0, 0x1

    return p0
.end method

.method static synthetic lambda$answerInvite$30(Landroid/app/Activity;Ljava/lang/String;Z)Lorg/json/JSONObject;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 179
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "/v1/groups/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {p1}, Lcom/android/mms/tzib/TzibNetwork;->segment(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    .line 180
    if-eqz p2, :cond_18

    const-string p2, "/accept"

    goto :goto_1a

    :cond_18
    const-string p2, "/decline"

    :goto_1a
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Lorg/json/JSONObject;

    invoke-direct {p2}, Lorg/json/JSONObject;-><init>()V

    .line 179
    const-string v0, "POST"

    invoke-static {p0, v0, p1, p2}, Lcom/android/mms/tzib/TzibNetwork;->request(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$answerInvite$31(Landroid/app/Activity;ZLorg/json/JSONObject;)V
    .registers 3

    .line 181
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->changed(Landroid/app/Activity;)V

    .line 182
    if-eqz p1, :cond_8

    const-string p1, "Joined group"

    goto :goto_a

    :cond_8
    const-string p1, "Invitation declined"

    :goto_a
    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 183
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->invitations(Landroid/app/Activity;)V

    .line 184
    return-void
.end method

.method static synthetic lambda$blocks$32(Landroid/app/Activity;)Lorg/json/JSONArray;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 187
    const-string v0, "/v1/blocks"

    const/4 v1, 0x0

    const-string v2, "GET"

    invoke-static {p0, v2, v0, v1}, Lcom/android/mms/tzib/TzibNetwork;->request(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object p0

    const-string v0, "items"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$blocks$33(Landroid/app/Activity;Lorg/json/JSONArray;I)Lorg/json/JSONObject;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 198
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "/v1/blocks/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1, p2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object p1

    const-string p2, "id"

    invoke-virtual {p1, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/tzib/TzibNetwork;->segment(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    const-string v0, "DELETE"

    invoke-static {p0, v0, p1, p2}, Lcom/android/mms/tzib/TzibNetwork;->request(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$blocks$34(Landroid/app/Activity;Lorg/json/JSONObject;)V
    .registers 2

    .line 199
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->blocks(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$blocks$35(Landroid/app/Activity;Lorg/json/JSONArray;ILandroid/content/DialogInterface;I)V
    .registers 5

    .line 197
    new-instance p3, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda14;

    invoke-direct {p3, p0, p1, p2}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda14;-><init>(Landroid/app/Activity;Lorg/json/JSONArray;I)V

    new-instance p1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda15;

    invoke-direct {p1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda15;-><init>(Landroid/app/Activity;)V

    invoke-static {p0, p3, p1}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    return-void
.end method

.method static synthetic lambda$blocks$36(Landroid/app/Activity;[Ljava/lang/String;Lorg/json/JSONArray;Landroid/content/DialogInterface;I)V
    .registers 6

    .line 196
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object p3

    const-string v0, "Remove block?"

    invoke-virtual {p3, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p3

    aget-object p1, p1, p4

    invoke-virtual {p3, p1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance p3, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda3;

    invoke-direct {p3, p0, p2, p4}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda3;-><init>(Landroid/app/Activity;Lorg/json/JSONArray;I)V

    .line 197
    const-string p0, "Unblock"

    invoke-virtual {p1, p0, p3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 200
    const/high16 p1, 0x1040000

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 196
    return-void
.end method

.method static synthetic lambda$blocks$37(Landroid/app/Activity;Lorg/json/JSONArray;)V
    .registers 9

    .line 188
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v0

    const-string v1, "Blocked groups and people"

    if-nez v0, :cond_e

    const-string p1, "No blocks."

    invoke-static {p0, v1, p1}, Lcom/android/mms/tzib/TzibSettings;->notice(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 189
    :cond_e
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v0

    new-array v2, v0, [Ljava/lang/String;

    .line 190
    const/4 v3, 0x0

    :goto_15
    if-ge v3, v0, :cond_52

    .line 191
    invoke-virtual {p1, v3}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    .line 192
    const-string v5, "currentName"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_25

    const-string v5, "nameAtBlock"

    :cond_25
    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 193
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "kind"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v6, "group"

    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_43

    const-string v4, " (group)"

    goto :goto_45

    :cond_43
    const-string v4, " (person)"

    :goto_45
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    .line 190
    add-int/lit8 v3, v3, 0x1

    goto :goto_15

    .line 195
    :cond_52
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda34;

    invoke-direct {v1, p0, v2, p1}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda34;-><init>(Landroid/app/Activity;[Ljava/lang/String;Lorg/json/JSONArray;)V

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 201
    const/high16 p1, 0x1040000

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 202
    return-void
.end method

.method static synthetic lambda$clearSession$43(Landroid/app/Activity;)Ljava/lang/Boolean;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 219
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "com.tzibbur.basic.sync.TzbSyncService"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/app/Activity;->stopService(Landroid/content/Intent;)Z

    .line 220
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object p0

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->signOutLocally()V

    invoke-static {}, Lcom/android/mms/tzib/TzibMetadata;->clear()V

    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$clearSession$44(Landroid/app/Activity;Ljava/lang/Boolean;)V
    .registers 2

    .line 221
    instance-of p1, p0, Landroid/preference/PreferenceActivity;

    if-eqz p1, :cond_9

    check-cast p0, Landroid/preference/PreferenceActivity;

    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->install(Landroid/preference/PreferenceActivity;)V

    :cond_9
    return-void
.end method

.method static synthetic lambda$confirmSignOut$38(Landroid/app/Activity;)Ljava/lang/Boolean;
    .registers 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 208
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object p0

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object p0

    invoke-interface {p0}, Lcom/tzibbur/basic/net/TzbApi;->logout()V

    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$confirmSignOut$39(Landroid/app/Activity;Ljava/lang/Boolean;)V
    .registers 2

    .line 209
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->clearSession(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$confirmSignOut$40(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 3

    .line 213
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->clearSession(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$confirmSignOut$41(Landroid/app/Activity;Ljava/lang/Exception;)V
    .registers 3

    .line 210
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_10

    check-cast p1, Lcom/tzibbur/basic/net/TzbProblem;

    iget p1, p1, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v0, 0x191

    if-ne p1, v0, :cond_10

    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->clearSession(Landroid/app/Activity;)V

    return-void

    .line 211
    :cond_10
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string v0, "Sign out on this phone?"

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    .line 212
    const-string v0, "The server could not be reached. You can clear this phone, but its session may remain active until revoked from another device."

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda31;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda31;-><init>(Landroid/app/Activity;)V

    .line 213
    const-string p0, "Clear this phone"

    invoke-virtual {p1, p0, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 214
    const/high16 p1, 0x1040000

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 215
    return-void
.end method

.method static synthetic lambda$confirmSignOut$42(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 4

    .line 207
    new-instance p1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda11;

    invoke-direct {p1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda11;-><init>(Landroid/app/Activity;)V

    new-instance p2, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda12;

    invoke-direct {p2, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda12;-><init>(Landroid/app/Activity;)V

    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda13;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda13;-><init>(Landroid/app/Activity;)V

    invoke-static {p0, p1, p2, v0}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V

    return-void
.end method

.method static synthetic lambda$deleteAccount$45(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 3

    .line 231
    const/4 p1, 0x0

    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibSettings;->submitDeletion(Landroid/app/Activity;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$deleteAccount$46(Landroid/widget/EditText;Landroid/app/AlertDialog;Landroid/app/Activity;Landroid/view/View;)V
    .registers 5

    .line 242
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p3

    const-string v0, "delete my account"

    invoke-virtual {v0, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_16

    const-string p1, "Type: delete my account"

    invoke-virtual {p0, p1}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    return-void

    .line 243
    :cond_16
    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p2, p0}, Lcom/android/mms/tzib/TzibSettings;->submitDeletion(Landroid/app/Activity;Ljava/lang/String;)V

    .line 244
    return-void
.end method

.method static synthetic lambda$deleteAccount$47(Landroid/app/AlertDialog;Landroid/widget/EditText;Landroid/app/Activity;Landroid/content/DialogInterface;)V
    .registers 5

    .line 241
    const/4 p3, -0x1

    invoke-virtual {p0, p3}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object p3

    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda49;

    invoke-direct {v0, p1, p0, p2}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda49;-><init>(Landroid/widget/EditText;Landroid/app/AlertDialog;Landroid/app/Activity;)V

    invoke-virtual {p3, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method static synthetic lambda$deleteAccount$48(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 8

    .line 226
    nop

    .line 228
    const/high16 p1, 0x1040000

    const-string v0, "Delete account"

    const/4 v1, 0x0

    const-string v2, "Your account will be disabled and all devices signed out. Groups survive. The operator audit trail and any abuse flag under a one-way hash are retained. "

    if-nez p2, :cond_3c

    .line 229
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object p2

    const-string v3, "Delete in 7 days?"

    invoke-virtual {p2, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "Signing in within 7 days cancels deletion."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 230
    invoke-virtual {p2, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p2

    new-instance v2, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda32;

    invoke-direct {v2, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda32;-><init>(Landroid/app/Activity;)V

    .line 231
    invoke-virtual {p2, v0, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 232
    invoke-virtual {p0, p1, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    goto :goto_86

    .line 234
    :cond_3c
    new-instance p2, Landroid/widget/EditText;

    invoke-direct {p2, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 235
    const/4 v3, 0x1

    invoke-virtual {p2, v3}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 236
    const-string v3, "delete my account"

    invoke-virtual {p2, v3}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 237
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    const-string v4, "Delete without a grace period?"

    invoke-virtual {v3, v4}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "This cannot be undone. Type: delete my account"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 238
    invoke-virtual {v3, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    .line 239
    invoke-virtual {v2, p2}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    invoke-virtual {v2, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 240
    invoke-virtual {v0, p1, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    .line 241
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda33;

    invoke-direct {v0, p1, p2, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda33;-><init>(Landroid/app/AlertDialog;Landroid/widget/EditText;Landroid/app/Activity;)V

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 245
    invoke-virtual {p1}, Landroid/app/AlertDialog;->show()V

    .line 247
    :goto_86
    return-void
.end method

.method static synthetic lambda$devices$19(Lcom/tzibbur/basic/core/TzbCore;)Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 143
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object p0

    invoke-interface {p0}, Lcom/tzibbur/basic/net/TzbApi;->myDevices()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$devices$20(Lcom/tzibbur/basic/core/TzbCore;Lcom/tzibbur/basic/model/TzbDevice;)Ljava/lang/Boolean;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 156
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object p0

    iget-object p1, p1, Lcom/tzibbur/basic/model/TzbDevice;->id:Ljava/lang/String;

    invoke-interface {p0, p1}, Lcom/tzibbur/basic/net/TzbApi;->revokeDevice(Ljava/lang/String;)V

    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$devices$21(Landroid/app/Activity;Ljava/lang/Boolean;)V
    .registers 2

    .line 157
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->devices(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$devices$22(Landroid/app/Activity;Lcom/tzibbur/basic/core/TzbCore;Lcom/tzibbur/basic/model/TzbDevice;Landroid/content/DialogInterface;I)V
    .registers 5

    .line 155
    new-instance p3, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda42;

    invoke-direct {p3, p1, p2}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda42;-><init>(Lcom/tzibbur/basic/core/TzbCore;Lcom/tzibbur/basic/model/TzbDevice;)V

    new-instance p1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda43;

    invoke-direct {p1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda43;-><init>(Landroid/app/Activity;)V

    invoke-static {p0, p3, p1}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    return-void
.end method

.method static synthetic lambda$devices$23(Ljava/util/List;Lcom/tzibbur/basic/core/TzbCore;Landroid/app/Activity;[Ljava/lang/String;Landroid/content/DialogInterface;I)V
    .registers 7

    .line 152
    invoke-interface {p0, p5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/tzibbur/basic/model/TzbDevice;

    .line 153
    iget-object p4, p0, Lcom/tzibbur/basic/model/TzbDevice;->id:Ljava/lang/String;

    invoke-virtual {p1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->deviceId()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p4

    if-eqz p4, :cond_1a

    invoke-static {p2}, Lcom/android/mms/tzib/TzibSettings;->confirmSignOut(Landroid/app/Activity;)V

    return-void

    .line 154
    :cond_1a
    invoke-static {p2}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object p4

    const-string v0, "Sign out this device?"

    invoke-virtual {p4, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p4

    aget-object p3, p3, p5

    invoke-virtual {p4, p3}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p3

    new-instance p4, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda5;

    invoke-direct {p4, p2, p1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda5;-><init>(Landroid/app/Activity;Lcom/tzibbur/basic/core/TzbCore;Lcom/tzibbur/basic/model/TzbDevice;)V

    .line 155
    const-string p0, "Sign out"

    invoke-virtual {p3, p0, p4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 158
    const/high16 p1, 0x1040000

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 159
    return-void
.end method

.method static synthetic lambda$devices$24(Lcom/tzibbur/basic/core/TzbCore;Landroid/app/Activity;Ljava/util/List;)V
    .registers 10

    .line 144
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    new-array v1, v0, [Ljava/lang/String;

    .line 145
    const/4 v2, 0x0

    :goto_7
    if-ge v2, v0, :cond_66

    .line 146
    invoke-interface {p2, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/tzibbur/basic/model/TzbDevice;

    .line 147
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v3, Lcom/tzibbur/basic/model/TzbDevice;->deviceModel:Ljava/lang/String;

    if-nez v5, :cond_1b

    iget-object v5, v3, Lcom/tzibbur/basic/model/TzbDevice;->platform:Ljava/lang/String;

    goto :goto_1d

    :cond_1b
    iget-object v5, v3, Lcom/tzibbur/basic/model/TzbDevice;->deviceModel:Ljava/lang/String;

    :goto_1d
    invoke-static {v5}, Lcom/android/mms/tzib/TzibSettings;->safe(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 148
    iget-object v5, v3, Lcom/tzibbur/basic/model/TzbDevice;->id:Ljava/lang/String;

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v6

    invoke-interface {v6}, Lcom/tzibbur/basic/store/TzbSession;->deviceId()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-string v6, ""

    if-eqz v5, :cond_3a

    const-string v5, " (this phone)"

    goto :goto_3b

    :cond_3a
    move-object v5, v6

    :goto_3b
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 149
    iget-object v5, v3, Lcom/tzibbur/basic/model/TzbDevice;->lastSeenAt:Ljava/lang/String;

    if-nez v5, :cond_44

    goto :goto_59

    :cond_44
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\nLast seen: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v3, v3, Lcom/tzibbur/basic/model/TzbDevice;->lastSeenAt:Ljava/lang/String;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    :goto_59
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    .line 145
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    .line 151
    :cond_66
    invoke-static {p1}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v2, "My devices"

    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v2, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;

    invoke-direct {v2, p2, p0, p1, v1}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;-><init>(Ljava/util/List;Lcom/tzibbur/basic/core/TzbCore;Landroid/app/Activity;[Ljava/lang/String;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 159
    const/high16 p1, 0x1040000

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 160
    return-void
.end method

.method static synthetic lambda$editName$14(Lcom/tzibbur/basic/core/TzbCore;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbUser;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 119
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object p0

    invoke-interface {p0, p1}, Lcom/tzibbur/basic/net/TzbApi;->updateDisplayName(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbUser;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$editName$15(Lcom/tzibbur/basic/core/TzbCore;Landroid/app/AlertDialog;Landroid/preference/PreferenceActivity;Lcom/tzibbur/basic/model/TzbUser;)V
    .registers 4

    .line 120
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object p0

    iget-object p3, p3, Lcom/tzibbur/basic/model/TzbUser;->displayName:Ljava/lang/String;

    invoke-interface {p0, p3}, Lcom/tzibbur/basic/store/TzbSession;->setDisplayName(Ljava/lang/String;)V

    .line 121
    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    invoke-static {p2}, Lcom/android/mms/tzib/TzibSettings;->install(Landroid/preference/PreferenceActivity;)V

    .line 122
    return-void
.end method

.method static synthetic lambda$editName$16(Landroid/app/AlertDialog;Landroid/widget/EditText;Ljava/lang/Exception;)V
    .registers 4

    .line 123
    const/4 v0, -0x1

    invoke-virtual {p0, v0}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object p0

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/widget/Button;->setEnabled(Z)V

    .line 124
    instance-of p0, p2, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz p0, :cond_12

    check-cast p2, Lcom/tzibbur/basic/net/TzbProblem;

    iget-object p0, p2, Lcom/tzibbur/basic/net/TzbProblem;->detail:Ljava/lang/String;

    goto :goto_14

    :cond_12
    const-string p0, "Could not connect. Try again."

    :goto_14
    invoke-virtual {p1, p0}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    .line 125
    return-void
.end method

.method static synthetic lambda$editName$17(Landroid/widget/EditText;Lcom/tzibbur/basic/core/TzbCore;Landroid/app/AlertDialog;Landroid/preference/PreferenceActivity;Landroid/view/View;)V
    .registers 8

    .line 113
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p4

    .line 114
    invoke-virtual {p1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    const/16 v1, 0x40

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbSession;->displayNameMaxLength(I)I

    move-result v0

    .line 115
    invoke-virtual {p4}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_43

    invoke-virtual {p4}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {p4, v2, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    if-le v1, v0, :cond_28

    goto :goto_43

    .line 118
    :cond_28
    const/4 v0, -0x1

    invoke-virtual {p2, v0}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setEnabled(Z)V

    .line 119
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda39;

    invoke-direct {v0, p1, p4}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda39;-><init>(Lcom/tzibbur/basic/core/TzbCore;Ljava/lang/String;)V

    new-instance p4, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda40;

    invoke-direct {p4, p1, p2, p3}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda40;-><init>(Lcom/tzibbur/basic/core/TzbCore;Landroid/app/AlertDialog;Landroid/preference/PreferenceActivity;)V

    new-instance p1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda41;

    invoke-direct {p1, p2, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda41;-><init>(Landroid/app/AlertDialog;Landroid/widget/EditText;)V

    invoke-static {p3, v0, p4, p1}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V

    .line 126
    return-void

    .line 116
    :cond_43
    :goto_43
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "Enter a name of up to "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, " characters"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    return-void
.end method

.method static synthetic lambda$editName$18(Landroid/app/AlertDialog;Landroid/widget/EditText;Lcom/tzibbur/basic/core/TzbCore;Landroid/preference/PreferenceActivity;Landroid/content/DialogInterface;)V
    .registers 6

    .line 112
    const/4 p4, -0x1

    invoke-virtual {p0, p4}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object p4

    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;

    invoke-direct {v0, p1, p2, p0, p3}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda48;-><init>(Landroid/widget/EditText;Lcom/tzibbur/basic/core/TzbCore;Landroid/app/AlertDialog;Landroid/preference/PreferenceActivity;)V

    invoke-virtual {p4, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method static synthetic lambda$install$0(Landroid/preference/PreferenceActivity;)V
    .registers 1

    .line 42
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->open(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$install$1(Landroid/preference/PreferenceActivity;)V
    .registers 1

    .line 44
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->editName(Landroid/preference/PreferenceActivity;)V

    return-void
.end method

.method static synthetic lambda$install$10(Landroid/preference/PreferenceActivity;)V
    .registers 1

    .line 59
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->confirmSignOut(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$install$11(Landroid/preference/PreferenceActivity;)V
    .registers 1

    .line 60
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->deleteAccount(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$install$12(Landroid/preference/PreferenceActivity;)V
    .registers 3

    .line 63
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "com.tzibbur.basic.ui.TzbAboutActivity"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/preference/PreferenceActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method static synthetic lambda$install$2(Landroid/preference/PreferenceActivity;Landroid/content/DialogInterface;I)V
    .registers 3

    .line 48
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->confirmSignOut(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$install$3(Landroid/preference/PreferenceActivity;Lcom/tzibbur/basic/core/TzbCore;)V
    .registers 5

    .line 46
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Tzibbur account"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 47
    invoke-virtual {p1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v2

    invoke-interface {v2}, Lcom/tzibbur/basic/store/TzbSession;->displayName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object p1

    invoke-interface {p1}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/tzib/TzibSettings;->safe(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda35;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda35;-><init>(Landroid/preference/PreferenceActivity;)V

    .line 48
    const-string p0, "Sign out"

    invoke-virtual {p1, p0, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 49
    const/high16 p1, 0x1040000

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 46
    return-void
.end method

.method static synthetic lambda$install$4(Lcom/tzibbur/basic/core/TzbCore;Landroid/preference/PreferenceActivity;)V
    .registers 3

    .line 51
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object p0

    invoke-interface {p0}, Lcom/tzibbur/basic/sync/TzbSync;->nudge()V

    .line 52
    const-string p0, "Reconnecting to Tzibbur"

    const/4 v0, 0x0

    invoke-static {p1, p0, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 53
    return-void
.end method

.method static synthetic lambda$install$5(Landroid/preference/PreferenceActivity;)V
    .registers 2

    .line 54
    const-string v0, "tzb_messages"

    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibSettings;->notifications(Landroid/app/Activity;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$install$6(Landroid/preference/PreferenceActivity;)V
    .registers 2

    .line 55
    const-string v0, "tzb_service_quiet"

    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibSettings;->notifications(Landroid/app/Activity;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$install$7(Landroid/preference/PreferenceActivity;)V
    .registers 1

    .line 56
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->devices(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$install$8(Landroid/preference/PreferenceActivity;)V
    .registers 1

    .line 57
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->invitations(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$install$9(Landroid/preference/PreferenceActivity;)V
    .registers 1

    .line 58
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->blocks(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic lambda$invitations$25(Landroid/app/Activity;)Lorg/json/JSONArray;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 163
    const-string v0, "/v1/invites"

    const/4 v1, 0x0

    const-string v2, "GET"

    invoke-static {p0, v2, v0, v1}, Lcom/android/mms/tzib/TzibNetwork;->request(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object p0

    const-string v0, "items"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$invitations$26(Landroid/app/Activity;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .registers 4

    .line 172
    const-string p2, "groupId"

    invoke-virtual {p1, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x1

    invoke-static {p0, p1, p2}, Lcom/android/mms/tzib/TzibSettings;->answerInvite(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic lambda$invitations$27(Landroid/app/Activity;Lorg/json/JSONObject;Landroid/content/DialogInterface;I)V
    .registers 4

    .line 173
    const-string p2, "groupId"

    invoke-virtual {p1, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Lcom/android/mms/tzib/TzibSettings;->answerInvite(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic lambda$invitations$28(Lorg/json/JSONArray;Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 6

    .line 168
    invoke-virtual {p0, p3}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object p0

    .line 169
    const-string p2, "addedBy"

    invoke-virtual {p0, p2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p2

    .line 170
    invoke-static {p1}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object p3

    const-string v0, "groupName"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p3

    .line 171
    if-nez p2, :cond_1d

    const-string p2, "Join this group?"

    goto :goto_36

    :cond_1d
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Invited by "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "displayName"

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    :goto_36
    invoke-virtual {p3, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p2

    new-instance p3, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda1;

    invoke-direct {p3, p1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda1;-><init>(Landroid/app/Activity;Lorg/json/JSONObject;)V

    .line 172
    const-string v0, "Join"

    invoke-virtual {p2, v0, p3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p2

    new-instance p3, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda2;

    invoke-direct {p3, p1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda2;-><init>(Landroid/app/Activity;Lorg/json/JSONObject;)V

    .line 173
    const-string p0, "Decline"

    invoke-virtual {p2, p0, p3}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 174
    const/high16 p1, 0x1040000

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 175
    return-void
.end method

.method static synthetic lambda$invitations$29(Landroid/app/Activity;Lorg/json/JSONArray;)V
    .registers 8

    .line 164
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v0

    const-string v1, "Invitations"

    if-nez v0, :cond_e

    const-string p1, "No pending invitations."

    invoke-static {p0, v1, p1}, Lcom/android/mms/tzib/TzibSettings;->notice(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 165
    :cond_e
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v0

    new-array v2, v0, [Ljava/lang/String;

    .line 166
    const/4 v3, 0x0

    :goto_15
    if-ge v3, v0, :cond_26

    invoke-virtual {p1, v3}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "groupName"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_15

    .line 167
    :cond_26
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda50;

    invoke-direct {v1, p1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda50;-><init>(Lorg/json/JSONArray;Landroid/app/Activity;)V

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 175
    const/high16 p1, 0x1040000

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 176
    return-void
.end method

.method static synthetic lambda$submitDeletion$49(Ljava/lang/String;Landroid/app/Activity;)Lorg/json/JSONObject;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 251
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 252
    if-eqz p0, :cond_13

    const-string v1, "immediate"

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "confirmation"

    invoke-virtual {v1, v2, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 253
    :cond_13
    const-string p0, "DELETE"

    const-string v1, "/v1/me"

    invoke-static {p1, p0, v1, v0}, Lcom/android/mms/tzib/TzibNetwork;->request(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$submitDeletion$50(Landroid/app/Activity;Ljava/lang/String;Lorg/json/JSONObject;)V
    .registers 3

    .line 255
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->clearSession(Landroid/app/Activity;)V

    .line 256
    if-nez p1, :cond_8

    .line 257
    const-string p1, "Your account is disabled. Sign in within 7 days to cancel deletion."

    goto :goto_a

    :cond_8
    const-string p1, "Your account is disabled and queued for permanent deletion."

    .line 256
    :goto_a
    const-string p2, "Account deletion requested"

    invoke-static {p0, p2, p1}, Lcom/android/mms/tzib/TzibSettings;->notice(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V

    .line 258
    return-void
.end method

.method private static notice(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 261
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    const p1, 0x104000a

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 262
    return-void
.end method

.method private static notifications(Landroid/app/Activity;Ljava/lang/String;)V
    .registers 5

    .line 130
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.CHANNEL_NOTIFICATION_SETTINGS"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 131
    invoke-virtual {p0}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "android.provider.extra.APP_PACKAGE"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 132
    const-string v1, "android.provider.extra.CHANNEL_ID"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    .line 133
    :try_start_17
    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_1a
    .catch Landroid/content/ActivityNotFoundException; {:try_start_17 .. :try_end_1a} :catch_1b

    .line 139
    goto :goto_3a

    .line 134
    :catch_1b
    move-exception p1

    .line 135
    :try_start_1c
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.settings.APP_NOTIFICATION_SETTINGS"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_2e
    .catch Landroid/content/ActivityNotFoundException; {:try_start_1c .. :try_end_2e} :catch_2f

    .line 138
    goto :goto_3a

    .line 136
    :catch_2f
    move-exception p1

    .line 137
    const-string p1, "Notification settings are unavailable on this phone"

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 140
    :goto_3a
    return-void
.end method

.method public static numberKey(Landroid/preference/PreferenceActivity;ILandroid/view/KeyEvent;)Z
    .registers 10

    .line 68
    const/4 v0, 0x0

    const/4 v1, 0x7

    if-lt p1, v1, :cond_4c

    const/16 v2, 0x10

    if-le p1, v2, :cond_9

    goto :goto_4c

    .line 69
    :cond_9
    const-string v2, "tzib_settings_category"

    invoke-virtual {p0, v2}, Landroid/preference/PreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v2

    .line 70
    instance-of v3, v2, Landroid/preference/PreferenceCategory;

    if-nez v3, :cond_14

    return v0

    .line 71
    :cond_14
    check-cast v2, Landroid/preference/PreferenceCategory;

    .line 72
    move v3, v0

    :goto_17
    invoke-virtual {v2}, Landroid/preference/PreferenceCategory;->getPreferenceCount()I

    move-result v4

    if-ge v3, v4, :cond_4b

    .line 73
    invoke-virtual {v2, v3}, Landroid/preference/PreferenceCategory;->getPreference(I)Landroid/preference/Preference;

    move-result-object v4

    .line 74
    invoke-virtual {v4}, Landroid/preference/Preference;->getTitle()Ljava/lang/CharSequence;

    move-result-object v5

    invoke-static {v5}, Lcom/android/mms/tzib/TzibPreferenceNumbers;->number(Ljava/lang/CharSequence;)I

    move-result v5

    add-int/lit8 v6, p1, -0x7

    if-eq v5, v6, :cond_30

    .line 72
    add-int/lit8 v3, v3, 0x1

    goto :goto_17

    .line 75
    :cond_30
    invoke-virtual {p2}, Landroid/view/KeyEvent;->isCanceled()Z

    move-result p1

    if-nez p1, :cond_49

    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p0

    if-eqz p0, :cond_49

    invoke-virtual {v4}, Landroid/preference/Preference;->isEnabled()Z

    move-result p0

    if-eqz p0, :cond_49

    .line 76
    invoke-virtual {v4}, Landroid/preference/Preference;->getOnPreferenceClickListener()Landroid/preference/Preference$OnPreferenceClickListener;

    move-result-object p0

    invoke-interface {p0, v4}, Landroid/preference/Preference$OnPreferenceClickListener;->onPreferenceClick(Landroid/preference/Preference;)Z

    .line 78
    :cond_49
    const/4 p0, 0x1

    return p0

    .line 80
    :cond_4b
    return v0

    .line 68
    :cond_4c
    :goto_4c
    return v0
.end method

.method private static safe(Ljava/lang/String;)Ljava/lang/String;
    .registers 1

    .line 96
    if-nez p0, :cond_4

    const-string p0, ""

    :cond_4
    return-object p0
.end method

.method private static submitDeletion(Landroid/app/Activity;Ljava/lang/String;)V
    .registers 4

    .line 250
    new-instance v0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda28;

    invoke-direct {v0, p1, p0}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda28;-><init>(Ljava/lang/String;Landroid/app/Activity;)V

    new-instance v1, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda29;

    invoke-direct {v1, p0, p1}, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda29;-><init>(Landroid/app/Activity;Ljava/lang/String;)V

    invoke-static {p0, v0, v1}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;)V

    .line 259
    return-void
.end method
