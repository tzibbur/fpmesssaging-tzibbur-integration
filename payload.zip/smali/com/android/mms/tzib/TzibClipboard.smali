.class public final Lcom/android/mms/tzib/TzibClipboard;
.super Ljava/lang/Object;
.source "TzibClipboard.java"


# static fields
.field public static final PASTE:I = 0x23a0

.field private static final targets:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/app/Activity;",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/widget/EditText;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 18
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Lcom/android/mms/tzib/TzibClipboard;->targets:Ljava/util/WeakHashMap;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static add(Landroid/app/Activity;Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Ljava/util/List<",
            "Landroid/util/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;)V"
        }
    .end annotation

    .line 31
    invoke-static {p0}, Lcom/android/mms/tzib/TzibClipboard;->focused(Landroid/app/Activity;)Landroid/widget/EditText;

    move-result-object v0

    .line 32
    if-eqz v0, :cond_2a

    if-nez p1, :cond_9

    goto :goto_2a

    .line 33
    :cond_9
    sget-object v1, Lcom/android/mms/tzib/TzibClipboard;->targets:Ljava/util/WeakHashMap;

    new-instance v2, Ljava/lang/ref/WeakReference;

    invoke-direct {v2, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v1, p0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    new-instance p0, Landroid/util/Pair;

    const/16 v0, 0x23a0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const v1, 0x104000b

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v0, 0x0

    invoke-interface {p1, v0, p0}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 35
    return-void

    .line 32
    :cond_2a
    :goto_2a
    return-void
.end method

.method static focused(Landroid/app/Activity;)Landroid/widget/EditText;
    .registers 4

    .line 21
    invoke-virtual {p0}, Landroid/app/Activity;->getCurrentFocus()Landroid/view/View;

    move-result-object v0

    .line 22
    instance-of v1, v0, Landroid/widget/EditText;

    const/4 v2, 0x0

    if-eqz v1, :cond_4c

    invoke-virtual {v0}, Landroid/view/View;->isEnabled()Z

    move-result v1

    if-eqz v1, :cond_4c

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-nez v1, :cond_16

    goto :goto_4c

    .line 24
    :cond_16
    :try_start_16
    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {v0}, Landroid/view/View;->getId()I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    move-result-object p0
    :try_end_22
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_22} :catch_4a

    .line 25
    nop

    .line 27
    nop

    .line 26
    const-string v1, "embedded_text_editor"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_46

    const-string v1, "embedded_text_editor_btnstyle"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_46

    .line 27
    const-string v1, "tzb_compose_edit"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_46

    const-string v1, "subject"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_45

    goto :goto_46

    .line 28
    :cond_45
    goto :goto_49

    :cond_46
    :goto_46
    move-object v2, v0

    check-cast v2, Landroid/widget/EditText;

    .line 26
    :goto_49
    return-object v2

    .line 25
    :catch_4a
    move-exception p0

    return-object v2

    .line 22
    :cond_4c
    :goto_4c
    return-object v2
.end method

.method public static option(Landroid/app/Activity;I)Z
    .registers 3

    .line 44
    const/16 v0, 0x23a0

    if-eq p1, v0, :cond_6

    const/4 p0, 0x0

    return p0

    .line 45
    :cond_6
    sget-object p1, Lcom/android/mms/tzib/TzibClipboard;->targets:Ljava/util/WeakHashMap;

    invoke-virtual {p1, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/ref/WeakReference;

    .line 46
    if-nez p0, :cond_12

    const/4 p0, 0x0

    goto :goto_18

    :cond_12
    invoke-virtual {p0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/widget/EditText;

    .line 47
    :goto_18
    if-eqz p0, :cond_29

    invoke-virtual {p0}, Landroid/widget/EditText;->isShown()Z

    move-result p1

    if-eqz p1, :cond_29

    invoke-virtual {p0}, Landroid/widget/EditText;->isEnabled()Z

    move-result p1

    if-eqz p1, :cond_29

    invoke-static {p0}, Lcom/android/mms/tzib/TzibClipboard;->paste(Landroid/widget/EditText;)Z

    .line 48
    :cond_29
    const/4 p0, 0x1

    return p0
.end method

.method public static optionItem(Landroid/app/Activity;Landroid/view/MenuItem;)Z
    .registers 2

    .line 51
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibClipboard;->option(Landroid/app/Activity;I)Z

    move-result p0

    return p0
.end method

.method static paste(Landroid/widget/EditText;)Z
    .registers 3

    .line 54
    invoke-virtual {p0}, Landroid/widget/EditText;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "clipboard"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ClipboardManager;

    .line 55
    if-eqz v0, :cond_20

    invoke-virtual {v0}, Landroid/content/ClipboardManager;->hasPrimaryClip()Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_20

    .line 59
    :cond_15
    invoke-virtual {p0}, Landroid/widget/EditText;->requestFocus()Z

    .line 61
    const v0, 0x1020031

    invoke-virtual {p0, v0}, Landroid/widget/EditText;->onTextContextMenuItem(I)Z

    move-result p0

    return p0

    .line 56
    :cond_20
    :goto_20
    invoke-virtual {p0}, Landroid/widget/EditText;->getContext()Landroid/content/Context;

    move-result-object p0

    const-string v0, "Nothing to paste"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 57
    return v1
.end method

.method public static prepare(Landroid/app/Activity;Landroid/view/Menu;)V
    .registers 6

    .line 37
    const/16 v0, 0x23a0

    invoke-interface {p1, v0}, Landroid/view/Menu;->removeItem(I)V

    .line 38
    invoke-static {p0}, Lcom/android/mms/tzib/TzibClipboard;->focused(Landroid/app/Activity;)Landroid/widget/EditText;

    move-result-object v1

    .line 39
    if-nez v1, :cond_c

    return-void

    .line 40
    :cond_c
    sget-object v2, Lcom/android/mms/tzib/TzibClipboard;->targets:Ljava/util/WeakHashMap;

    new-instance v3, Ljava/lang/ref/WeakReference;

    invoke-direct {v3, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v2, p0, v3}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    const p0, 0x104000b

    const/4 v1, 0x0

    invoke-interface {p1, v1, v0, v1, p0}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    .line 42
    return-void
.end method
