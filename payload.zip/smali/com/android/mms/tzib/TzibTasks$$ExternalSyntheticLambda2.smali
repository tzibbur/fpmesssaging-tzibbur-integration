.class public final synthetic Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Ljava/util/function/Consumer;

.field public final synthetic f$2:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Ljava/util/function/Consumer;Ljava/lang/Object;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda2;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda2;->f$1:Ljava/util/function/Consumer;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda2;->f$2:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda2;->f$0:Landroid/app/Activity;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda2;->f$1:Ljava/util/function/Consumer;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibTasks$$ExternalSyntheticLambda2;->f$2:Ljava/lang/Object;

    invoke-static {v0, v1, v2}, Lcom/android/mms/tzib/TzibTasks;->lambda$run$1(Landroid/app/Activity;Ljava/util/function/Consumer;Ljava/lang/Object;)V

    return-void
.end method
