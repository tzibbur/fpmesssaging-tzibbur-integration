.class public final synthetic Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic f$0:Lcom/android/mms/tzib/TzibMessageActions$Target;

.field public final synthetic f$1:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Lcom/android/mms/tzib/TzibMessageActions$Target;Landroid/app/Activity;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda0;->f$0:Lcom/android/mms/tzib/TzibMessageActions$Target;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda0;->f$1:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda0;->f$0:Lcom/android/mms/tzib/TzibMessageActions$Target;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibMessageActions$$ExternalSyntheticLambda0;->f$1:Landroid/app/Activity;

    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibMessageActions;->lambda$perform$0(Lcom/android/mms/tzib/TzibMessageActions$Target;Landroid/app/Activity;)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method
