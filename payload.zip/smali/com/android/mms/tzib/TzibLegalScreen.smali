.class public Lcom/android/mms/tzib/TzibLegalScreen;
.super Landroid/app/Activity;
.source "TzibLegalScreen.java"


# instance fields
.field private body:Landroid/widget/TextView;

.field private current:Lcom/android/mms/tzib/TzibLegalDocuments$Document;

.field private documents:Lcom/android/mms/tzib/TzibLegalDocuments;

.field private key:Ljava/lang/String;

.field private loading:Z

.field private resolved:Z

.field private resumed:Z

.field private retry:Landroid/widget/Button;

.field private scroll:Landroid/widget/ScrollView;

.field private status:Landroid/widget/TextView;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 18
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private fetch()V
    .registers 4

    .line 64
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->loading:Z

    if-eqz v0, :cond_5

    return-void

    .line 65
    :cond_5
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->loading:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->resolved:Z

    .line 66
    iget-object v1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->retry:Landroid/widget/Button;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 67
    iget-object v1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->status:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 68
    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->status:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->current:Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    if-nez v1, :cond_20

    const-string v1, "Loading\u2026"

    goto :goto_22

    :cond_20
    const-string v1, "Showing saved copy. Checking for updates\u2026"

    :goto_22
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 69
    new-instance v0, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda0;-><init>(Lcom/android/mms/tzib/TzibLegalScreen;)V

    new-instance v1, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda1;-><init>(Lcom/android/mms/tzib/TzibLegalScreen;)V

    new-instance v2, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda2;-><init>(Lcom/android/mms/tzib/TzibLegalScreen;)V

    invoke-static {p0, v0, v1, v2}, Lcom/android/mms/tzib/TzibTasks;->run(Landroid/app/Activity;Ljava/util/concurrent/Callable;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V

    .line 91
    return-void
.end method

.method static format(Ljava/lang/String;)Ljava/lang/CharSequence;
    .registers 8

    .line 93
    new-instance v0, Landroid/text/SpannableStringBuilder;

    invoke-direct {v0}, Landroid/text/SpannableStringBuilder;-><init>()V

    .line 94
    const-string v1, "\n"

    const/4 v2, -0x1

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p0

    .line 95
    const/4 v1, 0x0

    move v2, v1

    :goto_e
    array-length v3, p0

    if-ge v2, v3, :cond_62

    .line 96
    aget-object v3, p0, v2

    .line 97
    move v4, v1

    .line 98
    :goto_14
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v5

    if-ge v4, v5, :cond_25

    invoke-virtual {v3, v4}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x23

    if-ne v5, v6, :cond_25

    add-int/lit8 v4, v4, 0x1

    goto :goto_14

    .line 99
    :cond_25
    if-lez v4, :cond_54

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v5

    if-ge v4, v5, :cond_54

    invoke-virtual {v3, v4}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x20

    if-ne v5, v6, :cond_54

    .line 100
    invoke-virtual {v0}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v5

    invoke-virtual {v3, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 101
    new-instance v3, Landroid/text/style/StyleSpan;

    const/4 v4, 0x1

    invoke-direct {v3, v4}, Landroid/text/style/StyleSpan;-><init>(I)V

    invoke-virtual {v0}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v4

    const/16 v6, 0x21

    invoke-virtual {v0, v3, v5, v4, v6}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 102
    goto :goto_57

    :cond_54
    invoke-virtual {v0, v3}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 103
    :goto_57
    add-int/lit8 v2, v2, 0x1

    array-length v3, p0

    if-ge v2, v3, :cond_61

    const/16 v3, 0xa

    invoke-virtual {v0, v3}, Landroid/text/SpannableStringBuilder;->append(C)Landroid/text/SpannableStringBuilder;

    .line 95
    :cond_61
    goto :goto_e

    .line 105
    :cond_62
    return-object v0
.end method

.method public static intent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .registers 4

    .line 28
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "com.tzibbur.basic.ui.TzbLegalActivity"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    .line 29
    invoke-static {p1}, Lcom/android/mms/tzib/TzibLegalDocuments;->key(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "tzb_legal_key"

    invoke-virtual {p0, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    .line 28
    return-object p0
.end method

.method private markShown()V
    .registers 3

    .line 61
    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->resumed:Z

    if-eqz v0, :cond_19

    iget-boolean v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->resolved:Z

    if-eqz v0, :cond_19

    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->current:Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    if-eqz v0, :cond_19

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_19

    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->documents:Lcom/android/mms/tzib/TzibLegalDocuments;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->current:Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    invoke-virtual {v0, v1}, Lcom/android/mms/tzib/TzibLegalDocuments;->markShown(Lcom/android/mms/tzib/TzibLegalDocuments$Document;)V

    .line 62
    :cond_19
    return-void
.end method

.method private res(Ljava/lang/String;Ljava/lang/String;)I
    .registers 5

    .line 59
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p2, p1, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    return p1
.end method


# virtual methods
.method synthetic lambda$fetch$1$com-android-mms-tzib-TzibLegalScreen()Lcom/android/mms/tzib/TzibLegalDocuments$Document;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 69
    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->documents:Lcom/android/mms/tzib/TzibLegalDocuments;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->key:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/android/mms/tzib/TzibLegalDocuments;->fetch(Ljava/lang/String;)Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    move-result-object v0

    return-object v0
.end method

.method synthetic lambda$fetch$2$com-android-mms-tzib-TzibLegalScreen(Lcom/android/mms/tzib/TzibLegalDocuments$Document;)V
    .registers 7

    .line 70
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->loading:Z

    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->resolved:Z

    .line 71
    iget-object v2, p0, Lcom/android/mms/tzib/TzibLegalScreen;->documents:Lcom/android/mms/tzib/TzibLegalDocuments;

    invoke-virtual {v2, p1}, Lcom/android/mms/tzib/TzibLegalDocuments;->updated(Lcom/android/mms/tzib/TzibLegalDocuments$Document;)Z

    move-result v2

    .line 72
    iget-object v3, p0, Lcom/android/mms/tzib/TzibLegalScreen;->current:Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    if-eqz v3, :cond_1c

    iget-object v3, v3, Lcom/android/mms/tzib/TzibLegalDocuments$Document;->checksum:Ljava/lang/String;

    iget-object v4, p1, Lcom/android/mms/tzib/TzibLegalDocuments$Document;->checksum:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1b

    goto :goto_1c

    :cond_1b
    move v1, v0

    .line 73
    :cond_1c
    :goto_1c
    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->current:Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    .line 74
    if-eqz v1, :cond_30

    .line 75
    iget-object v1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->body:Landroid/widget/TextView;

    iget-object p1, p1, Lcom/android/mms/tzib/TzibLegalDocuments$Document;->text:Ljava/lang/String;

    invoke-static {p1}, Lcom/android/mms/tzib/TzibLegalScreen;->format(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 76
    iget-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {p1, v0, v0}, Landroid/widget/ScrollView;->scrollTo(II)V

    .line 78
    :cond_30
    iget-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->status:Landroid/widget/TextView;

    if-eqz v2, :cond_37

    const-string v1, "Updated since your last visit."

    goto :goto_39

    :cond_37
    const-string v1, ""

    :goto_39
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 79
    iget-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->status:Landroid/widget/TextView;

    const/16 v1, 0x8

    if-eqz v2, :cond_43

    goto :goto_44

    :cond_43
    move v0, v1

    :goto_44
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 80
    iget-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->retry:Landroid/widget/Button;

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 81
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->markShown()V

    .line 82
    return-void
.end method

.method synthetic lambda$fetch$3$com-android-mms-tzib-TzibLegalScreen(Ljava/lang/Exception;)V
    .registers 4

    .line 83
    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->loading:Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->resolved:Z

    .line 84
    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->status:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 85
    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->status:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->current:Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    if-nez v1, :cond_14

    const-string v1, "Could not load the document. Please try again."

    goto :goto_16

    .line 86
    :cond_14
    const-string v1, "Could not refresh. Showing the saved copy."

    .line 85
    :goto_16
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 87
    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->retry:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setVisibility(I)V

    .line 88
    iget-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->current:Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    if-nez p1, :cond_27

    iget-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->retry:Landroid/widget/Button;

    invoke-virtual {p1}, Landroid/widget/Button;->requestFocus()Z

    .line 89
    :cond_27
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->markShown()V

    .line 90
    return-void
.end method

.method synthetic lambda$onCreate$0$com-android-mms-tzib-TzibLegalScreen(Landroid/view/View;)V
    .registers 2

    .line 47
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->fetch()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 4

    .line 32
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 33
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_d

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->finish()V

    return-void

    .line 34
    :cond_d
    const-string p1, "layout"

    const-string v0, "tzb_legal_activity"

    invoke-direct {p0, p1, v0}, Lcom/android/mms/tzib/TzibLegalScreen;->res(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->setContentView(I)V

    .line 35
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 36
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string v0, "tzb_legal_key"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/tzib/TzibLegalDocuments;->key(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->key:Ljava/lang/String;

    .line 37
    const-string v0, "terms"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_36

    const-string p1, "Terms of service"

    goto :goto_38

    :cond_36
    const-string p1, "Privacy policy"

    .line 38
    :goto_38
    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->setTitle(Ljava/lang/CharSequence;)V

    .line 39
    const-string v0, "tzb_title_text"

    const-string v1, "id"

    invoke-direct {p0, v1, v0}, Lcom/android/mms/tzib/TzibLegalScreen;->res(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/android/mms/tzib/TzibLegalScreen;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 40
    const-string p1, "tzb_legal_text"

    invoke-direct {p0, v1, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->res(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->body:Landroid/widget/TextView;

    .line 41
    const-string p1, "tzb_legal_scroll"

    invoke-direct {p0, v1, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->res(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ScrollView;

    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->scroll:Landroid/widget/ScrollView;

    .line 42
    const-string p1, "tzb_legal_retry_btn"

    invoke-direct {p0, v1, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->res(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->retry:Landroid/widget/Button;

    .line 43
    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const-string v0, "tzib_legal_status"

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->status:Landroid/widget/TextView;

    .line 44
    new-instance p1, Lcom/android/mms/tzib/TzibLegalDocuments;

    invoke-direct {p1, p0}, Lcom/android/mms/tzib/TzibLegalDocuments;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->documents:Lcom/android/mms/tzib/TzibLegalDocuments;

    .line 45
    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->key:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lcom/android/mms/tzib/TzibLegalDocuments;->cached(Ljava/lang/String;)Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->current:Lcom/android/mms/tzib/TzibLegalDocuments$Document;

    .line 46
    if-eqz p1, :cond_a4

    iget-object v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->body:Landroid/widget/TextView;

    iget-object p1, p1, Lcom/android/mms/tzib/TzibLegalDocuments$Document;->text:Ljava/lang/String;

    invoke-static {p1}, Lcom/android/mms/tzib/TzibLegalScreen;->format(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 47
    :cond_a4
    iget-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->retry:Landroid/widget/Button;

    new-instance v0, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0}, Lcom/android/mms/tzib/TzibLegalScreen$$ExternalSyntheticLambda3;-><init>(Lcom/android/mms/tzib/TzibLegalScreen;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 48
    iget-object p1, p0, Lcom/android/mms/tzib/TzibLegalScreen;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {p1}, Landroid/widget/ScrollView;->requestFocus()Z

    .line 49
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->fetch()V

    .line 50
    return-void
.end method

.method protected onPause()V
    .registers 2

    .line 58
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->resumed:Z

    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    return-void
.end method

.method protected onResume()V
    .registers 2

    .line 56
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/mms/tzib/TzibLegalScreen;->resumed:Z

    invoke-direct {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->markShown()V

    .line 57
    return-void
.end method

.method protected onStart()V
    .registers 2

    .line 52
    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    .line 53
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->allowed(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_c

    invoke-virtual {p0}, Lcom/android/mms/tzib/TzibLegalScreen;->finish()V

    .line 54
    :cond_c
    return-void
.end method
