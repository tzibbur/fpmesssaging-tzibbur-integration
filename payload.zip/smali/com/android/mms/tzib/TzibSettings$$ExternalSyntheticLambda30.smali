.class public final synthetic Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:Lcom/tzibbur/basic/core/TzbCore;

.field public final synthetic f$2:Landroid/app/Activity;

.field public final synthetic f$3:[Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lcom/tzibbur/basic/core/TzbCore;Landroid/app/Activity;[Ljava/lang/String;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;->f$0:Ljava/util/List;

    iput-object p2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;->f$1:Lcom/tzibbur/basic/core/TzbCore;

    iput-object p3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;->f$2:Landroid/app/Activity;

    iput-object p4, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;->f$3:[Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 9

    iget-object v0, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;->f$0:Ljava/util/List;

    iget-object v1, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;->f$1:Lcom/tzibbur/basic/core/TzbCore;

    iget-object v2, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;->f$2:Landroid/app/Activity;

    iget-object v3, p0, Lcom/android/mms/tzib/TzibSettings$$ExternalSyntheticLambda30;->f$3:[Ljava/lang/String;

    move-object v4, p1

    move v5, p2

    invoke-static/range {v0 .. v5}, Lcom/android/mms/tzib/TzibSettings;->lambda$devices$23(Ljava/util/List;Lcom/tzibbur/basic/core/TzbCore;Landroid/app/Activity;[Ljava/lang/String;Landroid/content/DialogInterface;I)V

    return-void
.end method
