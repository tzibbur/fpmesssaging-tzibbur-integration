# extended-by: Lcom/android/mms/ui/ComposeMessageActivityNoLockScreen;
.class public Lcom/android/mms/ui/ComposeMessageActivity;
.super Landroid/app/Activity;
.source "ComposeMessageActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;
.implements Landroid/widget/TextView$OnEditorActionListener;
.implements Lcom/android/mms/data/WorkingMessage$MessageStatusListener;
.implements Lcom/android/mms/data/Contact$UpdateListener;
.implements Lcom/android/mms/ui/zoom/ZoomGestureOverlayView$IZoomListener;
.implements Landroid/widget/MenuBar$MenuBarListener;
.implements Landroid/content/DialogInterface$OnDismissListener;
.implements Lcom/android/ex/chips/RecipientEditTextView$RecipientChipInvalidDialogListener;
.implements Lcom/android/mms/ui/MessageListAdapter$OnMessageBodyLoaded;
.implements Lcom/android/mms/ui/MessageListAdapter$OnImageLoaded;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/mms/ui/ComposeMessageActivity$MMSAudioPlayer;,
        Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;,
        Lcom/android/mms/ui/ComposeMessageActivity$IMMSUpdateProgressBar;,
        Lcom/android/mms/ui/ComposeMessageActivity$CopyToSimThread;,
        Lcom/android/mms/ui/ComposeMessageActivity$CopyToSimSelectListener;,
        Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;,
        Lcom/android/mms/ui/ComposeMessageActivity$TemplateSelectListener;,
        Lcom/android/mms/ui/ComposeMessageActivity$RecipientsMenuClickListener;,
        Lcom/android/mms/ui/ComposeMessageActivity$CancelSendingListener;,
        Lcom/android/mms/ui/ComposeMessageActivity$SendIgnoreInvalidRecipientListener;,
        Lcom/android/mms/ui/ComposeMessageActivity$DiscardDraftListener;,
        Lcom/android/mms/ui/ComposeMessageActivity$DeleteMessageListener;
    }
.end annotation


# static fields
.field public static final ADD_AUDIO:I = 0x2

.field public static final ADD_CONTACT_AS_VCARD:I = 0x3

.field public static final ADD_IMAGE:I = 0x0

.field public static final ADD_VIDEO:I = 0x1

.field private static BROADCAST_DATA_SCHEME:Ljava/lang/String; = "file"

.field private static final CDMA_SUBSCRIPTION_NV:I = 0x1

.field private static final CHARS_REMAINING_BEFORE_COUNTER_SHOWN:I = 0xa

.field public static final CHOOSE_PICTURE:I = 0x1

.field public static final CHOOSE_VIDEO:I = 0x1

.field private static final COLON:Ljava/lang/String; = ":"

.field private static final DEBUG:Z = true

.field private static final DEBUG_MULTI_CHOICE:Z = true

.field private static final DEFAULT_ATTACHMENT_PAGER:I = 0x0

.field private static final DEFER_LOADING_MESSAGES_AND_DRAFT:Z = false

.field private static final DELETE_MESSAGE_TOKEN:I = 0x25e4

.field private static final DIALOG_IMPORT_TEMPLATE:I = 0x1

.field private static final DIALOG_TYPE_INVALID:Ljava/lang/String; = "dialog_invalid"

.field private static final DIALOG_TYPE_INVALID_RECIPIENT:Ljava/lang/String; = "invalid_recipient"

.field private static final DIALOG_TYPE_LIMIT:Ljava/lang/String; = "dialog_limit"

.field private static final DIALOG_TYPE_REMOVE:Ljava/lang/String; = "dialog_remove"

.field public static final DISCARD:I = 0x1

.field private static final EXIT_ECM_RESULT:Ljava/lang/String; = "exit_ecm_result"

.field private static final EXTRA_START_COMPOSE_FROM:Ljava/lang/String; = "start_compose_from"

.field private static FILE_PATH_COLUMN:Ljava/lang/String; = "_data"

.field private static final INTENT_ACTION_LTE_DATA_ONLY_DIALOG:Ljava/lang/String; = "com.qualcomm.qti.phonefeature.DISABLE_TDD_LTE"

.field private static final INTENT_MULTI_PICK_ACTION:Ljava/lang/String; = "com.android.contacts.action.MULTI_PICK"

.field private static final IS_SENDING:Ljava/lang/String; = "is_sending"

.field protected static final KEY_EXIT_ON_SENT:Ljava/lang/String; = "exit_on_sent"

.field protected static final KEY_FORWARDED_MESSAGE:Ljava/lang/String; = "forwarded_message"

.field protected static final KEY_REPLY_MESSAGE:Ljava/lang/String; = "reply_message"

.field private static final KILOBYTE:I = 0x400

.field private static final LEFT_PARENTHESES:Ljava/lang/String; = "("

.field private static final LINE_BREAK:Ljava/lang/String; = "\n"

.field private static final LOADING_MESSAGES_AND_DRAFT_MAX_DELAY_MS:I = 0x1f4

.field private static final LOCAL_LOGV:Z = false

.field private static final LTE_DATA_ONLY_KEY:Ljava/lang/String; = "network_band"

.field private static final LTE_DATA_ONLY_MODE:I = 0x2

.field public static final MANAGE_MODE:Ljava/lang/String; = "manage_mode"

.field private static final MAX_ITEMS_TO_INVOKE_SCROLL_SHORTCUT:I = 0x14

.field private static final MEDIA_DATE_FORMAT:Ljava/lang/String; = "\'MMS\'_yyyyMMdd_HHmmss"

.field public static final MENU_ACTION_ADD_ATTACHMENT:I = 0x5

.field public static final MENU_ACTION_ADD_SUBJECT:I = 0xe

.field public static final MENU_ACTION_CALL:I = 0xd

.field public static final MENU_ACTION_CANCEL_EDIT:I = 0x4

.field public static final MENU_ACTION_CLEAR_ALL:I = 0x2

.field public static final MENU_ACTION_DELETE:I = 0xb

.field public static final MENU_ACTION_FORWARD:I = 0x8

.field public static final MENU_ACTION_MESSAGE_REPORT:I = 0x6

.field public static final MENU_ACTION_PLAY:I = 0xc

.field public static final MENU_ACTION_REMOVE:I = 0x9

.field public static final MENU_ACTION_REMOVE_SUBJECT:I = 0xf

.field public static final MENU_ACTION_RESEND:I = 0xa

.field public static final MENU_ACTION_RTT_CALL:I = 0x12

.field public static final MENU_ACTION_SAVE_ATTACHMENT:I = 0x10

.field public static final MENU_ACTION_SELECT_CONTACT:I = 0x0

.field public static final MENU_ACTION_SELECT_GROUP:I = 0x11

.field public static final MENU_ACTION_SEND:I = 0x1

.field public static final MENU_ACTION_VIEW:I = 0x7

.field private static final MENU_ADD_ADDRESS_TO_CONTACTS:I = 0x1b

.field private static final MENU_ADD_ATTACHMENT:I = 0x2

.field private static final MENU_ADD_SUBJECT:I = 0x0

.field private static final MENU_ADD_TO_CONTACTS:I = 0xd

.field private static final MENU_CALL_BACK:I = 0x16

.field private static final MENU_CALL_RECIPIENT:I = 0x5

.field private static final MENU_CONVERSATION_LIST:I = 0x6

.field private static final MENU_COPY_EXTRACT_URL:I = 0x24

.field private static final MENU_COPY_MESSAGE_TEXT:I = 0x18

.field private static final MENU_COPY_PHONENUMBER:I = 0xe

.field private static final MENU_COPY_TO_SDCARD:I = 0x19

.field private static final MENU_COPY_TO_SIM:I = 0x22

.field private static final MENU_DEBUG_DUMP:I = 0x7

.field private static final MENU_DELETE_MESSAGE:I = 0x12

.field private static final MENU_DELETE_THREAD:I = 0x1

.field private static final MENU_DELIVERY_REPORT:I = 0x14

.field private static final MENU_DISCARD:I = 0x3

.field private static final MENU_EDIT_MESSAGE:I = 0xf

.field private static final MENU_FORWARD_MESSAGE:I = 0x15

.field private static final MENU_GROUP_PARTICIPANTS:I = 0x20

.field private static final MENU_IMPORT_TEMPLATE:I = 0x21

.field private static final MENU_LOCK_MESSAGE:I = 0x1c

.field private static final MENU_PREFERENCES:I = 0x1f

.field private static final MENU_RESEND:I = 0x23

.field private static final MENU_SAVE_RINGTONE:I = 0x1e

.field private static final MENU_SEARCH:I = 0x13

.field private static final MENU_SEND:I = 0x4

.field private static final MENU_SEND_BY_SLOT1:I = 0x9

.field private static final MENU_SEND_BY_SLOT2:I = 0xa

.field private static final MENU_SEND_EMAIL:I = 0x17

.field private static final MENU_UNLOCK_MESSAGE:I = 0x1d

.field private static final MENU_VIDEOCALL_RECIPIENT:I = 0x25

.field private static final MENU_VIEW_CONTACT:I = 0xc

.field private static final MENU_VIEW_MESSAGE_DETAILS:I = 0x11

.field private static final MENU_VIEW_SLIDESHOW:I = 0x10

.field private static final MESSAGE_BODY:Ljava/lang/String; = "message_body"

.field private static final MESSAGE_ID:Ljava/lang/String; = "message_id"

.field private static final MESSAGE_LIST_QUERY_AFTER_DELETE_TOKEN:I = 0x2538

.field private static final MESSAGE_LIST_QUERY_TOKEN:I = 0x2537

.field private static final MESSAGE_SIZE:Ljava/lang/String; = "message_size"

.field private static final MESSAGE_SUBJECT:Ljava/lang/String; = "message_subject"

.field private static final MESSAGE_SUBJECT_CHARSET:Ljava/lang/String; = "message_subject_charset"

.field private static final MESSAGE_TYPE:Ljava/lang/String; = "message_type"

.field private static final MSG_ADD_ATTACHMENT_FAILED:I = 0x1

.field private static final MSG_COPY_TO_SIM_SUCCESS:I = 0x2

.field private static final MSG_ONLY_ONE_FAIL_LIST_ITEM:I = 0x1

.field private static final MSG_SUBJECT_SIZE:Ljava/lang/String; = "subject_size"

.field private static final NEED_RESEND:Ljava/lang/String; = "needResend"

.field private static final NO_DATE_FOR_DIALOG:J = -0x1L

.field private static final NUMBER_OF_BUTTONS:I = 0x2

.field private static final PRESENCESERV:Ljava/lang/String; = "com.qualcomm.qti.presenceserv"

.field private static final PRESENCESERV_PRESENCESERVICE:Ljava/lang/String; = "com.qualcomm.qti.presenceserv.PresenceService"

.field private static final PRESENCE_AVAILABILITY_FETCH:I = 0x0

.field private static final RECIPIENTS:Ljava/lang/String; = "recipients"

.field private static final RECIPIENTS_MAX_LENGTH:I = 0x138

.field public static final RECORD_VIDEO:I = 0x0

.field private static final REPLACE_ATTACHMEN_MASK:I = 0x10000

.field public static final REQUEST_CODE_ADD_CONTACT:I = 0x6c

.field public static final REQUEST_CODE_ATTACH_ADD_CONTACT_INFO:I = 0x6e

.field public static final REQUEST_CODE_ATTACH_ADD_CONTACT_VCARD:I = 0x6f

.field public static final REQUEST_CODE_ATTACH_IMAGE:I = 0x64

.field public static final REQUEST_CODE_ATTACH_REPLACE_CONTACT_INFO:I = 0x70

.field public static final REQUEST_CODE_ATTACH_SOUND:I = 0x68

.field public static final REQUEST_CODE_ATTACH_VIDEO:I = 0x66

.field public static final REQUEST_CODE_CREATE_SLIDESHOW:I = 0x6a

.field public static final REQUEST_CODE_ECM_EXIT_DIALOG:I = 0x6b

.field public static final REQUEST_CODE_PICK:I = 0x6d

.field public static final REQUEST_CODE_RECORD_SOUND:I = 0x69

.field public static final REQUEST_CODE_TAKE_PICTURE:I = 0x65

.field public static final REQUEST_CODE_TAKE_VIDEO:I = 0x67

.field public static final REQUEST_GROUP_PICK:I = 0x78

.field private static final RIGHT_PARENTHESES:Ljava/lang/String; = ")"

.field private static final SAVE_ATTACHMENT_PERMISSION_REQUEST_CODE:I = 0x7e0

.field public static final SAVE_DRAFT:I = 0x0

.field private static final SIM_STATE_CHANGE_ACTION:Ljava/lang/String; = "android.intent.action.SIM_STATE_CHANGED"

.field private static final SMOOTH_SCROLL_THRESHOLD:I = 0xc8

.field private static final SUBJECT_MAX_LENGTH:I

.field private static final TAG:Ljava/lang/String; = "Mms"

.field public static final TAKE_PICTURE:I = 0x0

.field public static final THREAD_ID:Ljava/lang/String; = "thread_id"

.field private static final TRACE:Z = false

.field private static URI_HOST_MEDIA:Ljava/lang/String; = "media"

.field private static URI_SCHEME_CONTENT:Ljava/lang/String; = "content"

.field private static mActionBarColor:I

.field private static final mAudioUri:Ljava/lang/String;

.field private static mCurrentSelectedCursor:Landroid/database/Cursor;

.field private static mHasDraft:Z

.field public static mHaveRecipients:Z

.field private static final mImageUri:Ljava/lang/String;

.field private static mIsNewMessageUi:Z

.field public static mMenuBar:Landroid/widget/MenuBar;

.field public static mRemoveDialogMenuBar:Landroid/widget/MenuBar;

.field private static mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

.field private static mSendContactColor:I

.field private static final mVideoUri:Ljava/lang/String;

.field private static sDefaultContactImage:Landroid/graphics/drawable/Drawable;

.field private static sEmptyContactList:Lcom/android/mms/data/ContactList;

.field private static sPrimaryColorDark:I


# instance fields
.field private final AUDIO_TYPE:Ljava/lang/String;

.field private ChooseAttachDialog:Landroid/app/AlertDialog;

.field private ChooseAttachMode:I

.field private ChooseImageDialog:Landroid/app/AlertDialog;

.field private ChooseImageMode:I

.field private ChooseVideoDialog:Landroid/app/AlertDialog;

.field private ChooseVideoMode:I

.field private final DialogKeyListener:Landroid/content/DialogInterface$OnKeyListener;

.field private DraftSlideShow:Lcom/android/mms/model/SlideshowModel;

.field private Draftitems:[Ljava/lang/String;

.field private final ErrorDialogKeyListener:Landroid/content/DialogInterface$OnKeyListener;

.field private final IMAGE_TYPE:Ljava/lang/String;

.field private final MAX_DURATION:I

.field private final POST_DELAY:I

.field private SaveDraftDialog:Landroid/app/AlertDialog;

.field private SaveDraftMode:I

.field private final VCARD_TYPE:Ljava/lang/String;

.field private final VIDEO_TYPE:Ljava/lang/String;

.field private attachsizeTemp:I

.field private disCardDraftDialog:Landroid/app/TctDialog;

.field private discardDialogShow:Z

.field private isAvoidingSavingDraft:Z

.field private isFirstQuery:Z

.field private isLocked:Z

.field private mAccentColor:I

.field private mAddAttachmentButton:Landroid/widget/LinearLayout;

.field private mAddAttachmentHandler:Landroid/os/Handler;

.field private mAddContactIntent:Landroid/content/Intent;

.field private mAddVoiceMsg:Landroid/widget/ImageView;

.field private mAirplaneModeBroadcastReceiver:Landroid/content/BroadcastReceiver;

.field private final mAirplaneModeFilter:Landroid/content/IntentFilter;

.field private mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

.field private mAttachMentLayout:Landroid/widget/LinearLayout;

.field private mAttach_type:Ljava/lang/String;

.field private mAttachmentEditor:Lcom/android/mms/ui/AttachmentEditor;

.field private final mAttachmentEditorHandler:Landroid/os/Handler;

.field private mAttachmentEditorScrollView:Landroid/view/View;

.field private mAttachmentPager:Landroidx/viewpager/widget/ViewPager;

.field private mAttachmentPagerAdapter:Lcom/android/mms/ui/AttachmentPagerAdapter;

.field private final mAttachmentPagerChangeListener:Landroidx/viewpager/widget/ViewPager$OnPageChangeListener;

.field private mAttachmentSelector:Landroid/view/View;

.field private mAttachmentSize:Landroid/widget/TextView;

.field private mAttachmentViewer:Landroid/widget/RelativeLayout;

.field private mAudioManager:Landroid/media/AudioManager;

.field private mAvailabilityfetchHandler:Landroid/os/Handler;

.field private mAvatarDrawable:Landroid/graphics/drawable/Drawable;

.field private mBackgroundQueryHandler:Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;

.field private mBodyString:Ljava/lang/String;

.field private mBottomPanel:Landroid/view/View;

.field private mCallback:Lorg/codeaurora/presenceserv/IPresenceServiceCB;

.field private mClearButton:Landroid/widget/ImageButton;

.field private mCompresVideoCount:I

.field private final mCompressVideoResultCallback:Lcom/android/mms/ui/VideoUtils$CompressVideoResultCallback;

.field private mConnection:Landroid/content/ServiceConnection;

.field private mContent:Landroid/widget/RelativeLayout;

.field private mContentResolver:Landroid/content/ContentResolver;

.field private mConversation:Lcom/android/mms/data/Conversation;

.field private mCopyToSimWithToastHandler:Landroid/os/Handler;

.field private mCurPlayUrl:Ljava/lang/String;

.field private mCurrentAttachmentPager:I

.field private final mDataSetChangedListener:Lcom/android/mms/ui/MessageListAdapter$OnDataSetChangedListener;

.field private mDebugRecipients:Ljava/lang/String;

.field private mDeleteMsgId:I

.field private mDeviderView:Landroid/view/View;

.field private mDialog:Landroid/app/Dialog;

.field private mDialogMode:I

.field private mDiscardDialog:Z

.field private mEnablePresence:Z

.field private mErrorDiscardDialog:Z

.field private mExistsRecipientsCount:I

.field private mForwardMessageMode:Z

.field private mFourText:Landroid/widget/TextView;

.field private mHandler:Landroid/os/Handler;

.field private final mHomeWatcherFilter:Landroid/content/IntentFilter;

.field private final mHomeWatcherReceiver:Landroid/content/BroadcastReceiver;

.field private final mHttpProgressFilter:Landroid/content/IntentFilter;

.field private final mHttpProgressReceiver:Landroid/content/BroadcastReceiver;

.field private mId:I

.field private mInAsyncAddAttathProcess:Z

.field private mIndicatorForSimMmsFir:Landroid/widget/ImageView;

.field private mIndicatorForSimMmsSec:Landroid/widget/ImageView;

.field private mIndicatorForSimSmsFir:Landroid/widget/ImageView;

.field private mIndicatorForSimSmsSec:Landroid/widget/ImageView;

.field private mInvalidRecipientDialog:Landroid/app/AlertDialog;

.field private mIsActvityPause:Z

.field private mIsAirplaneModeOn:Z

.field private mIsAttachmentErrorOnSend:Z

.field private mIsChooseDialogShow:Z

.field private mIsCursorHaveData:Z

.field private mIsEnableSelectCopy:Z

.field private mIsKeyboardOpen:Z

.field private mIsLandscape:Z

.field private mIsPickingContact:Z

.field private mIsPresenceServiceBound:Z

.field private mIsProcessPickedRecipients:Z

.field private mIsRTL:Z

.field private mIsRemoveDialogShow:Z

.field private mIsReplaceAttachment:Z

.field private mIsRunning:Z

.field private mIsSmsEnabled:Z

.field private mLastItemDeleted:Z

.field private mLastMessageId:J

.field private mLastRecipientCount:I

.field private mLastSmoothScrollPosition:I

.field private mMMSAudioPlayer:Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;

.field private mMediaPlayer:Landroid/media/MediaPlayer;

.field private mMediaPlayerPrepared:Z

.field private final mMediaStateReceiver:Landroid/content/BroadcastReceiver;

.field private final mMessageListItemHandler:Landroid/os/Handler;

.field private mMessageText:Landroid/widget/LinearLayout;

.field private mMessagesAndDraftLoaded:Z

.field private mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

.field private mMsgDetailDialog:Landroid/app/AlertDialog;

.field public mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

.field private mMsgListView:Lcom/android/mms/ui/MessageListView;

.field private mMsimDialog:Landroid/app/AlertDialog;

.field private mObjectLock:Ljava/lang/Object;

.field private mOneText:Landroid/widget/TextView;

.field private mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

.field private mRecipientsPickList:Lcom/android/mms/data/ContactList;

.field private mRecipientsPickerGroups:Landroid/widget/ImageButton;

.field private final mRecipientsWatcher:Landroid/text/TextWatcher;

.field private mRegistered:Z

.field private mRemoveDialog:Landroid/app/AlertDialog;

.field private mReplyMessageMode:Z

.field private mResendSmsRecipient:Ljava/lang/String;

.field mResetMessageRunnable:Ljava/lang/Runnable;

.field private final mResizeImageCallback:Lcom/android/mms/ui/MessageUtils$ResizeImageResultCallback;

.field private mResizeImageCount:I

.field private mRunnable:Ljava/lang/Runnable;

.field private final mSIMStatusChangeFilter:Landroid/content/IntentFilter;

.field private mSavedScrollPosition:I

.field private mScrollOnSend:Z

.field private mSendButtonMms:Landroid/widget/ImageButton;

.field private mSendButtonMmsText:Landroid/widget/TextView;

.field private mSendButtonMmsViewSec:Landroid/widget/TextView;

.field private mSendButtonSms:Landroid/widget/ImageButton;

.field private mSendButtonSmsViewSec:Landroid/widget/ImageButton;

.field private mSendDiscreetMode:Z

.field private mSendLayoutMmsFir:Landroid/view/View;

.field private mSendLayoutMmsSec:Landroid/view/View;

.field private mSendLayoutSmsFir:Landroid/view/View;

.field private mSendLayoutSmsSec:Landroid/view/View;

.field private mSendMmsSupportViaWiFi:Z

.field private mSendingMessage:Z

.field private mSentMessage:Z

.field private mService:Lorg/codeaurora/presenceserv/IPresenceService;

.field private mShouldLoadDraft:Z

.field private mShowAttachIcon:Z

.field private mShowMobileDataDialog:Landroid/app/TctDialog;

.field private mShowTwoButtons:Z

.field private final mSimBroadcastReceiver:Landroid/content/BroadcastReceiver;

.field private mStatusBarColor:I

.field private final mSubjectEditorWatcher:Landroid/text/TextWatcher;

.field private final mSubjectKeyListener:Landroid/view/View$OnKeyListener;

.field private mSubjectLable:Landroid/widget/TextView;

.field private mSubjectText:Landroid/widget/LinearLayout;

.field private mSubjectTextEditor:Landroid/widget/EditText;

.field private mTempMmsUri:Landroid/net/Uri;

.field private mTempThreadId:J

.field private mTextCounter:Landroid/widget/TextView;

.field private mTextCounterSec:Landroid/widget/TextView;

.field private mTextEditor:Landroid/widget/EditText;

.field private final mTextEditorWatcher:Landroid/text/TextWatcher;

.field private mTextLable:Landroid/widget/TextView;

.field private mThreeImageLine:Landroid/widget/ImageView;

.field private mThreeText:Landroid/widget/TextView;

.field private mTitleText:Landroid/widget/TextView;

.field private mToast:Landroid/widget/Toast;

.field private mToastForDraftSave:Z

.field private mTopPanel:Landroid/view/View;

.field private mTwoImageLine:Landroid/widget/ImageView;

.field private mTwoText:Landroid/widget/TextView;

.field private mUpdateCallBack:Lcom/android/mms/ui/ComposeMessageActivity$IMMSUpdateProgressBar;

.field private mUpdateMmsSizeIndRunnable:Ljava/lang/Runnable;

.field private mUpdateThread:Ljava/lang/Runnable;

.field private mVideoCapable:Z

.field private mWaitingForSubActivity:Z

.field private mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

.field private mZoomGestureOverlayView:Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;

.field private messageListQueryRunnable:Ljava/lang/Runnable;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 417
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxSubjectLength()I

    move-result v0

    sput v0, Lcom/android/mms/ui/ComposeMessageActivity;->SUBJECT_MAX_LENGTH:I

    const/4 v0, 0x0

    .line 429
    sput-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    .line 430
    sput-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mCurrentSelectedCursor:Landroid/database/Cursor;

    const-string v0, "external"

    .line 6204
    invoke-static {v0}, Landroid/provider/MediaStore$Video$Media;->getContentUri(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mVideoUri:Ljava/lang/String;

    .line 6206
    invoke-static {v0}, Landroid/provider/MediaStore$Images$Media;->getContentUri(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mImageUri:Ljava/lang/String;

    .line 6208
    invoke-static {v0}, Landroid/provider/MediaStore$Audio$Media;->getContentUri(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mAudioUri:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 6

    .line 245
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    .line 522
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInAsyncAddAttathProcess:Z

    const/4 v1, -0x1

    .line 541
    iput v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSavedScrollPosition:I

    .line 571
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsAttachmentErrorOnSend:Z

    .line 583
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsAirplaneModeOn:Z

    .line 584
    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHandler:Landroid/os/Handler;

    .line 586
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRTL:Z

    const-string v1, "video"

    .line 610
    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->VIDEO_TYPE:Ljava/lang/String;

    const-string v1, "image"

    .line 611
    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->IMAGE_TYPE:Ljava/lang/String;

    const-string v1, "audio"

    .line 612
    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->AUDIO_TYPE:Ljava/lang/String;

    const-string v1, "vcard"

    .line 613
    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->VCARD_TYPE:Ljava/lang/String;

    const/4 v1, 0x1

    .line 615
    iput-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsActvityPause:Z

    .line 626
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->isLocked:Z

    .line 627
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsPickingContact:Z

    const/4 v2, 0x0

    .line 629
    iput-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsPickList:Lcom/android/mms/data/ContactList;

    .line 633
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsProcessPickedRecipients:Z

    .line 634
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mExistsRecipientsCount:I

    .line 637
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResizeImageCount:I

    .line 638
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCompresVideoCount:I

    .line 639
    new-instance v3, Ljava/lang/Object;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mObjectLock:Ljava/lang/Object;

    .line 641
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowAttachIcon:Z

    .line 644
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    .line 646
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendMmsSupportViaWiFi:Z

    .line 648
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->isAvoidingSavingDraft:Z

    .line 653
    iput-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mVideoCapable:Z

    .line 666
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsEnableSelectCopy:Z

    .line 667
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAccentColor:I

    .line 668
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mStatusBarColor:I

    .line 670
    new-instance v3, Landroid/content/IntentFilter;

    const-string v4, "android.intent.action.AIRPLANE_MODE"

    invoke-direct {v3, v4}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAirplaneModeFilter:Landroid/content/IntentFilter;

    .line 671
    new-instance v3, Landroid/content/IntentFilter;

    const-string v4, "android.intent.action.SIM_STATE_CHANGED"

    invoke-direct {v3, v4}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSIMStatusChangeFilter:Landroid/content/IntentFilter;

    .line 672
    new-instance v3, Landroid/content/IntentFilter;

    const-string v4, "android.intent.action.CLOSE_SYSTEM_DIALOGS"

    invoke-direct {v3, v4}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHomeWatcherFilter:Landroid/content/IntentFilter;

    .line 683
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachMode:I

    .line 684
    iput v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageMode:I

    const/4 v3, 0x2

    .line 685
    iput v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoMode:I

    const/4 v4, 0x3

    .line 686
    iput v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftMode:I

    .line 693
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    .line 694
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRemoveDialogShow:Z

    .line 696
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDiscardDialog:Z

    .line 697
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mErrorDiscardDialog:Z

    .line 701
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->attachsizeTemp:I

    .line 702
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsCursorHaveData:Z

    .line 703
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRegistered:Z

    .line 766
    new-instance v4, Lcom/android/mms/ui/ComposeMessageActivity$3;

    invoke-direct {v4, p0}, Lcom/android/mms/ui/ComposeMessageActivity$3;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditorHandler:Landroid/os/Handler;

    .line 867
    new-instance v4, Lcom/android/mms/ui/ComposeMessageActivity$6;

    invoke-direct {v4, p0}, Lcom/android/mms/ui/ComposeMessageActivity$6;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessageListItemHandler:Landroid/os/Handler;

    .line 954
    new-instance v4, Lcom/android/mms/ui/ComposeMessageActivity$7;

    invoke-direct {v4, p0}, Lcom/android/mms/ui/ComposeMessageActivity$7;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectKeyListener:Landroid/view/View$OnKeyListener;

    .line 1784
    new-instance v4, Lcom/android/mms/ui/ComposeMessageActivity$15;

    invoke-direct {v4, p0}, Lcom/android/mms/ui/ComposeMessageActivity$15;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsWatcher:Landroid/text/TextWatcher;

    .line 2606
    new-instance v4, Landroid/content/IntentFilter;

    const-string v5, "com.android.mms.PROGRESS_STATUS"

    invoke-direct {v4, v5}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHttpProgressFilter:Landroid/content/IntentFilter;

    .line 2608
    new-instance v4, Lcom/android/mms/ui/ComposeMessageActivity$16;

    invoke-direct {v4, p0}, Lcom/android/mms/ui/ComposeMessageActivity$16;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHttpProgressReceiver:Landroid/content/BroadcastReceiver;

    .line 2634
    new-instance v4, Lcom/android/mms/ui/ComposeMessageActivity$17;

    invoke-direct {v4, p0}, Lcom/android/mms/ui/ComposeMessageActivity$17;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMediaStateReceiver:Landroid/content/BroadcastReceiver;

    .line 2960
    new-instance v4, Lcom/android/mms/ui/ComposeMessageActivity$23;

    invoke-direct {v4, p0}, Lcom/android/mms/ui/ComposeMessageActivity$23;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSimBroadcastReceiver:Landroid/content/BroadcastReceiver;

    .line 2974
    new-instance v4, Lcom/android/mms/ui/ComposeMessageActivity$24;

    invoke-direct {v4, p0}, Lcom/android/mms/ui/ComposeMessageActivity$24;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHomeWatcherReceiver:Landroid/content/BroadcastReceiver;

    new-array v3, v3, [Ljava/lang/String;

    .line 3609
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/mms/MmsApp;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f0e0255    # @string/save_draft 'Save draft'

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v0

    .line 3610
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/mms/MmsApp;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f0e00c0    # @string/discard_draft 'Discard draft'

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v1

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->Draftitems:[Ljava/lang/String;

    .line 4212
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->discardDialogShow:Z

    .line 4226
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$34;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$34;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->DialogKeyListener:Landroid/content/DialogInterface$OnKeyListener;

    .line 4407
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$37;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$37;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResetMessageRunnable:Ljava/lang/Runnable;

    .line 4972
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$45;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$45;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPagerChangeListener:Landroidx/viewpager/widget/ViewPager$OnPageChangeListener;

    .line 5266
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$46;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$46;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mUpdateMmsSizeIndRunnable:Ljava/lang/Runnable;

    .line 5527
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$52;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$52;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResizeImageCallback:Lcom/android/mms/ui/MessageUtils$ResizeImageResultCallback;

    .line 5580
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$53;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$53;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCompressVideoResultCallback:Lcom/android/mms/ui/VideoUtils$CompressVideoResultCallback;

    .line 5681
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$55;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$55;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ErrorDialogKeyListener:Landroid/content/DialogInterface$OnKeyListener;

    .line 6252
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$72;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$72;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentHandler:Landroid/os/Handler;

    .line 6695
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$75;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$75;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditorWatcher:Landroid/text/TextWatcher;

    .line 6787
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$76;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$76;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectEditorWatcher:Landroid/text/TextWatcher;

    .line 7423
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$85;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$85;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->messageListQueryRunnable:Ljava/lang/Runnable;

    .line 7430
    iput-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->isFirstQuery:Z

    .line 7686
    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$88;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$88;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAirplaneModeBroadcastReceiver:Landroid/content/BroadcastReceiver;

    .line 8182
    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$89;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$89;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDataSetChangedListener:Lcom/android/mms/ui/MessageListAdapter$OnDataSetChangedListener;

    .line 8778
    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$91;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$91;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCopyToSimWithToastHandler:Landroid/os/Handler;

    .line 9815
    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$MMSAudioPlayer;

    invoke-direct {v1, p0, v2}, Lcom/android/mms/ui/ComposeMessageActivity$MMSAudioPlayer;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/ComposeMessageActivity$1;)V

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMMSAudioPlayer:Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;

    .line 9817
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMediaPlayerPrepared:Z

    const/16 v0, 0x64

    .line 9820
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->POST_DELAY:I

    .line 9821
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->MAX_DURATION:I

    .line 9922
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$96;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$96;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mUpdateThread:Ljava/lang/Runnable;

    .line 9951
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$97;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$97;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConnection:Landroid/content/ServiceConnection;

    .line 9968
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$98;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$98;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCallback:Lorg/codeaurora/presenceserv/IPresenceServiceCB;

    return-void
.end method

.method private ImaeAttach(IZ)V
    .locals 1

    if-eqz p1, :cond_1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_0

    goto :goto_0

    :cond_0
    const/16 p1, 0x64

    .line 3962
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 3961
    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->selectImage(Landroid/content/Context;I)V

    goto :goto_0

    :cond_1
    const/16 p1, 0x65

    .line 3958
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 3957
    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->capturePicture(Landroid/app/Activity;I)V

    :goto_0
    return-void
.end method

.method private SaveDraftFP(ILjava/lang/Runnable;)V
    .locals 1

    const/4 v0, 0x1

    if-eqz p1, :cond_2

    if-eq p1, v0, :cond_0

    goto :goto_1

    .line 3717
    :cond_0
    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    .line 3718
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->discard()V

    .line 3720
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const p2, 0x7f0e00b8    # @string/diacarded_toast 'The message draft has discarded'

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 3721
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    if-nez p2, :cond_1

    const/4 p2, 0x0

    .line 3722
    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    goto :goto_0

    .line 3724
    :cond_1
    invoke-virtual {p2, p1}, Landroid/widget/Toast;->setText(Ljava/lang/CharSequence;)V

    .line 3726
    :goto_0
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    goto :goto_1

    .line 3712
    :cond_2
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->saveDraft(Z)V

    .line 3713
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToastForDraftSave:Z

    .line 3714
    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    :goto_1
    return-void
.end method

.method private VideoAttach(IZ)V
    .locals 5

    if-eqz p1, :cond_1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_0

    goto :goto_1

    :cond_0
    const/16 p1, 0x66

    .line 3852
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 3851
    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->selectVideo(Landroid/content/Context;I)V

    goto :goto_1

    .line 3834
    :cond_1
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p1

    const/4 v0, 0x0

    if-eqz p2, :cond_2

    if-eqz p1, :cond_2

    .line 3836
    invoke-static {p1}, Lcom/android/mms/data/WorkingMessage;->removeThumbnailsFromCache(Lcom/android/mms/model/SlideshowModel;)V

    .line 3837
    invoke-virtual {p1, v0}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v1

    .line 3838
    invoke-virtual {v1}, Lcom/android/mms/model/SlideModel;->getSlideSize()I

    move-result v1

    goto :goto_0

    :cond_2
    move v1, v0

    .line 3840
    :goto_0
    invoke-static {p1, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->computeAttachmentSizeLimit(Lcom/android/mms/model/SlideshowModel;I)J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long p1, v1, v3

    if-lez p1, :cond_3

    const/16 p1, 0x67

    .line 3843
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 3842
    invoke-static {p0, p1, v1, v2}, Lcom/android/mms/ui/MessageUtils;->recordVideo(Landroid/app/Activity;IJ)V

    goto :goto_1

    :cond_3
    const p1, 0x7f0e016b    # @string/message_too_big_for_video 'The message is too big to attach a video.'

    .line 3846
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 3845
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 3847
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :goto_1
    return-void
.end method

.method static synthetic access$000(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/net/Uri;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    return-object p0
.end method

.method static synthetic access$002(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;)Landroid/net/Uri;
    .locals 0

    .line 245
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    return-object p1
.end method

.method static synthetic access$100(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/data/WorkingMessage;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    return-object p0
.end method

.method static synthetic access$1000(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/ui/MessageListView;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    return-object p0
.end method

.method static synthetic access$10000(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/ui/VideoUtils$CompressVideoResultCallback;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCompressVideoResultCallback:Lcom/android/mms/ui/VideoUtils$CompressVideoResultCallback;

    return-object p0
.end method

.method static synthetic access$10100(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;Lcom/android/mms/ui/MessageItem;Ljava/lang/Runnable;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->alertDialog(Ljava/lang/String;Lcom/android/mms/ui/MessageItem;Ljava/lang/Runnable;)V

    return-void
.end method

.method static synthetic access$10200(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->addAudio(Landroid/net/Uri;ZLjava/lang/String;)V

    return-void
.end method

.method static synthetic access$10300(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;Landroid/net/Uri;Z)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachment(Ljava/lang/String;Landroid/net/Uri;Z)V

    return-void
.end method

.method static synthetic access$10400(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsLandscape:Z

    return p0
.end method

.method static synthetic access$10500(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;)Ljava/lang/String;
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getAttachmentMimeType(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$10600(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->waitForResizeImagesOrCompressVideo()V

    return-void
.end method

.method static synthetic access$10700(Lcom/android/mms/ui/ComposeMessageActivity;ILjava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->getResourcesString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$10800(Lcom/android/mms/ui/ComposeMessageActivity;IZ)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentFP(IZ)V

    return-void
.end method

.method static synthetic access$10900(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/TextView;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$1100(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;)Z
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showMessageDetails(Lcom/android/mms/ui/MessageItem;)Z

    move-result p0

    return p0
.end method

.method static synthetic access$11000(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateMenuOption()V

    return-void
.end method

.method static synthetic access$11100(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/CharSequence;III)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/android/mms/ui/ComposeMessageActivity;->updateCounter(Ljava/lang/CharSequence;III)V

    return-void
.end method

.method static synthetic access$11200()I
    .locals 1

    .line 245
    sget v0, Lcom/android/mms/ui/ComposeMessageActivity;->SUBJECT_MAX_LENGTH:I

    return v0
.end method

.method static synthetic access$11300(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessagesAndDraftLoaded:Z

    return p0
.end method

.method static synthetic access$11400(Lcom/android/mms/ui/ComposeMessageActivity;I)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->loadMessagesAndDraft(I)V

    return-void
.end method

.method static synthetic access$11500(Lcom/android/mms/ui/ComposeMessageActivity;ZI)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->smoothScrollToEnd(ZI)V

    return-void
.end method

.method static synthetic access$11600(Lcom/android/mms/ui/ComposeMessageActivity;)I
    .locals 0

    .line 245
    iget p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mId:I

    return p0
.end method

.method static synthetic access$11602(Lcom/android/mms/ui/ComposeMessageActivity;I)I
    .locals 0

    .line 245
    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mId:I

    return p1
.end method

.method static synthetic access$11700(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/ui/MoreAttachmentView;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    return-object p0
.end method

.method static synthetic access$11800(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/LinearLayout;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessageText:Landroid/widget/LinearLayout;

    return-object p0
.end method

.method static synthetic access$11900(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/TextView;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextLable:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$1200(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->editMessageItem(Lcom/android/mms/ui/MessageItem;)V

    return-void
.end method

.method static synthetic access$12002(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRemoveDialogShow:Z

    return p1
.end method

.method static synthetic access$12100(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->removeMessageItem(Lcom/android/mms/ui/MessageItem;)V

    return-void
.end method

.method static synthetic access$12200(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/app/AlertDialog;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialog:Landroid/app/AlertDialog;

    return-object p0
.end method

.method static synthetic access$12300(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastItemDeleted:Z

    return p0
.end method

.method static synthetic access$12302(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastItemDeleted:Z

    return p1
.end method

.method static synthetic access$12400(Lcom/android/mms/ui/ComposeMessageActivity;I)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->startMsgListQuery(I)V

    return-void
.end method

.method static synthetic access$12500(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsEnableSelectCopy:Z

    return p0
.end method

.method static synthetic access$12600(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateMmsSizeIndicator()V

    return-void
.end method

.method static synthetic access$12700(Lcom/android/mms/ui/ComposeMessageActivity;Z)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->drawTopPanel(Z)V

    return-void
.end method

.method static synthetic access$12802(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsAirplaneModeOn:Z

    return p1
.end method

.method static synthetic access$12900()Z
    .locals 1

    .line 245
    sget-boolean v0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    return v0
.end method

.method static synthetic access$12902(Z)Z
    .locals 0

    .line 245
    sput-boolean p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    return p0
.end method

.method static synthetic access$1300(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->drawBottomPanel()V

    return-void
.end method

.method static synthetic access$13000(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->sanityCheckConversation()V

    return-void
.end method

.method static synthetic access$13100(Lcom/android/mms/ui/ComposeMessageActivity;)I
    .locals 0

    .line 245
    iget p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSavedScrollPosition:I

    return p0
.end method

.method static synthetic access$13102(Lcom/android/mms/ui/ComposeMessageActivity;I)I
    .locals 0

    .line 245
    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSavedScrollPosition:I

    return p1
.end method

.method static synthetic access$13200(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mScrollOnSend:Z

    return p0
.end method

.method static synthetic access$13202(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mScrollOnSend:Z

    return p1
.end method

.method static synthetic access$13300(Lcom/android/mms/ui/ComposeMessageActivity;)J
    .locals 2

    .line 245
    iget-wide v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastMessageId:J

    return-wide v0
.end method

.method static synthetic access$13302(Lcom/android/mms/ui/ComposeMessageActivity;J)J
    .locals 0

    .line 245
    iput-wide p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastMessageId:J

    return-wide p1
.end method

.method static synthetic access$13400(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsCursorHaveData:Z

    return p0
.end method

.method static synthetic access$13402(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsCursorHaveData:Z

    return p1
.end method

.method static synthetic access$13500(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSentMessage:Z

    return p0
.end method

.method static synthetic access$13600(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isHasSomeTosend()Z

    move-result p0

    return p0
.end method

.method static synthetic access$13700(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->initRecipientsEditor()V

    return-void
.end method

.method static synthetic access$13800(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->regRecipientsWatcher()V

    return-void
.end method

.method static synthetic access$13900(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/Runnable;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->exitComposeMessageActivity(Ljava/lang/Runnable;)V

    return-void
.end method

.method static synthetic access$1400(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->resendMessage(Lcom/android/mms/ui/MessageItem;)V

    return-void
.end method

.method static synthetic access$14002(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->isFirstQuery:Z

    return p1
.end method

.method static synthetic access$14100(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateThreadAttachType()V

    return-void
.end method

.method static synthetic access$14200(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/os/Handler;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$14300(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateSendFailedNotification()V

    return-void
.end method

.method static synthetic access$14400(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showInvalidCopyDialog()V

    return-void
.end method

.method static synthetic access$14500(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/os/Handler;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCopyToSimWithToastHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$14600(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;I)Z
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->copyToSim(Lcom/android/mms/ui/MessageItem;I)Z

    move-result p0

    return p0
.end method

.method static synthetic access$14700(Lcom/android/mms/ui/ComposeMessageActivity;)J
    .locals 2

    .line 245
    iget-wide v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempThreadId:J

    return-wide v0
.end method

.method static synthetic access$14702(Lcom/android/mms/ui/ComposeMessageActivity;J)J
    .locals 0

    .line 245
    iput-wide p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempThreadId:J

    return-wide p1
.end method

.method static synthetic access$14800(Lcom/android/mms/ui/ComposeMessageActivity;)Ljava/lang/String;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBodyString:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$14802(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 245
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBodyString:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic access$1500(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/content/Context;
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$15000(Lcom/android/mms/ui/ComposeMessageActivity;)Ljava/lang/String;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCurPlayUrl:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$15002(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 245
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCurPlayUrl:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic access$15100(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMediaPlayerPrepared:Z

    return p0
.end method

.method static synthetic access$15102(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMediaPlayerPrepared:Z

    return p1
.end method

.method static synthetic access$15200(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/media/MediaPlayer;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMediaPlayer:Landroid/media/MediaPlayer;

    return-object p0
.end method

.method static synthetic access$15202(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/media/MediaPlayer;)Landroid/media/MediaPlayer;
    .locals 0

    .line 245
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMediaPlayer:Landroid/media/MediaPlayer;

    return-object p1
.end method

.method static synthetic access$15300(Lcom/android/mms/ui/ComposeMessageActivity;)Ljava/lang/Runnable;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mUpdateThread:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic access$15400(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/ui/ComposeMessageActivity$IMMSUpdateProgressBar;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mUpdateCallBack:Lcom/android/mms/ui/ComposeMessageActivity$IMMSUpdateProgressBar;

    return-object p0
.end method

.method static synthetic access$15402(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/ComposeMessageActivity$IMMSUpdateProgressBar;)Lcom/android/mms/ui/ComposeMessageActivity$IMMSUpdateProgressBar;
    .locals 0

    .line 245
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mUpdateCallBack:Lcom/android/mms/ui/ComposeMessageActivity$IMMSUpdateProgressBar;

    return-object p1
.end method

.method static synthetic access$15900(Lcom/android/mms/ui/ComposeMessageActivity;)Lorg/codeaurora/presenceserv/IPresenceService;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mService:Lorg/codeaurora/presenceserv/IPresenceService;

    return-object p0
.end method

.method static synthetic access$15902(Lcom/android/mms/ui/ComposeMessageActivity;Lorg/codeaurora/presenceserv/IPresenceService;)Lorg/codeaurora/presenceserv/IPresenceService;
    .locals 0

    .line 245
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mService:Lorg/codeaurora/presenceserv/IPresenceService;

    return-object p1
.end method

.method static synthetic access$1600(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/EditText;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    return-object p0
.end method

.method static synthetic access$16000(Lcom/android/mms/ui/ComposeMessageActivity;)Lorg/codeaurora/presenceserv/IPresenceServiceCB;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCallback:Lorg/codeaurora/presenceserv/IPresenceServiceCB;

    return-object p0
.end method

.method static synthetic access$16100(Lcom/android/mms/ui/ComposeMessageActivity;I)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->updateAttachmentView(I)V

    return-void
.end method

.method static synthetic access$16200(Lcom/android/mms/ui/ComposeMessageActivity;I)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->updateAttachmentSize(I)V

    return-void
.end method

.method static synthetic access$16300(Lcom/android/mms/ui/ComposeMessageActivity;I)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->setFocusToAttachmentView(I)V

    return-void
.end method

.method static synthetic access$1700(Lcom/android/mms/ui/ComposeMessageActivity;Z)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showSubjectEditor(Z)V

    return-void
.end method

.method static synthetic access$1800(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateSendButtonState()V

    return-void
.end method

.method static synthetic access$1900(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showEmptyTextError()Z

    move-result p0

    return p0
.end method

.method static synthetic access$200(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->editSlideshow()V

    return-void
.end method

.method static synthetic access$2000(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showAirplaneModeDialog()V

    return-void
.end method

.method static synthetic access$2100(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->toSendWhenInvalidSim()V

    return-void
.end method

.method static synthetic access$2200(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/RelativeLayout;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentViewer:Landroid/widget/RelativeLayout;

    return-object p0
.end method

.method static synthetic access$2300(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/ui/RecipientsEditor;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    return-object p0
.end method

.method static synthetic access$2502(Lcom/android/mms/ui/ComposeMessageActivity;I)I
    .locals 0

    .line 245
    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDeleteMsgId:I

    return p1
.end method

.method static synthetic access$2600(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBackgroundQueryHandler:Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;

    return-object p0
.end method

.method static synthetic access$2700(Lcom/android/mms/ui/ComposeMessageActivity;ZI)Z
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->isMmsWithMobileDataOff(ZI)Z

    move-result p0

    return p0
.end method

.method static synthetic access$2800(Lcom/android/mms/ui/ComposeMessageActivity;I)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showMobileDataDisabledDialog(I)V

    return-void
.end method

.method static synthetic access$2900(Lcom/android/mms/ui/ComposeMessageActivity;ZI)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMsimMessage(ZI)V

    return-void
.end method

.method static synthetic access$300(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result p0

    return p0
.end method

.method static synthetic access$3000(Lcom/android/mms/ui/ComposeMessageActivity;Z)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMessage(Z)V

    return-void
.end method

.method static synthetic access$3100(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result p0

    return p0
.end method

.method static synthetic access$3200(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->dismissMsimDialog()V

    return-void
.end method

.method static synthetic access$3400(Lcom/android/mms/ui/ComposeMessageActivity;)I
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->recipientCount()I

    move-result p0

    return p0
.end method

.method static synthetic access$3500(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/ImageButton;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mClearButton:Landroid/widget/ImageButton;

    return-object p0
.end method

.method static synthetic access$3600(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->checkForTooManyRecipients()V

    return-void
.end method

.method static synthetic access$3700(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsProcessPickedRecipients:Z

    return p0
.end method

.method static synthetic access$3702(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsProcessPickedRecipients:Z

    return p1
.end method

.method static synthetic access$3800(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/data/ContactList;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsPickList:Lcom/android/mms/data/ContactList;

    return-object p0
.end method

.method static synthetic access$3802(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/data/ContactList;)Lcom/android/mms/data/ContactList;
    .locals 0

    .line 245
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsPickList:Lcom/android/mms/data/ContactList;

    return-object p1
.end method

.method static synthetic access$3900(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/data/ContactList;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->updateTitle(Lcom/android/mms/data/ContactList;)V

    return-void
.end method

.method static synthetic access$400(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded()V

    return-void
.end method

.method static synthetic access$4000(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/text/Editable;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->updateTitleForRecipientsChange(Landroid/text/Editable;)V

    return-void
.end method

.method static synthetic access$4100(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDiscardDialog:Z

    return p0
.end method

.method static synthetic access$4102(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDiscardDialog:Z

    return p1
.end method

.method static synthetic access$4200(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mErrorDiscardDialog:Z

    return p0
.end method

.method static synthetic access$4202(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mErrorDiscardDialog:Z

    return p1
.end method

.method static synthetic access$4300(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->is911Recipient()Z

    move-result p0

    return p0
.end method

.method static synthetic access$4400(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/content/Intent;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddContactIntent:Landroid/content/Intent;

    return-object p0
.end method

.method static synthetic access$4402(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/content/Intent;)Landroid/content/Intent;
    .locals 0

    .line 245
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddContactIntent:Landroid/content/Intent;

    return-object p1
.end method

.method static synthetic access$4500(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->copyToClipboard(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$4600(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/data/Conversation;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    return-object p0
.end method

.method static synthetic access$4700(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/content/Context;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->checkAttachFileState(Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$4800(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/EditText;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    return-object p0
.end method

.method static synthetic access$4900(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsActvityPause:Z

    return p0
.end method

.method static synthetic access$500(Lcom/android/mms/ui/ComposeMessageActivity;I)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->viewMmsMessageAttachment(I)V

    return-void
.end method

.method static synthetic access$5000(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/LinearLayout;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    return-object p0
.end method

.method static synthetic access$5100(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/TextView;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectLable:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$5200(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/data/ContactList;
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$5300(Lcom/android/mms/ui/ComposeMessageActivity;)Ljava/lang/Runnable;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRunnable:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic access$5400(Lcom/android/mms/ui/ComposeMessageActivity;ILjava/lang/Runnable;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftFP(ILjava/lang/Runnable;)V

    return-void
.end method

.method static synthetic access$5500(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/media/AudioManager;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAudioManager:Landroid/media/AudioManager;

    return-object p0
.end method

.method static synthetic access$5602(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    return p1
.end method

.method static synthetic access$5700(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/TextView;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$5800(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/TextView;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$5900(Lcom/android/mms/ui/ComposeMessageActivity;IZ)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->VideoAttach(IZ)V

    return-void
.end method

.method static synthetic access$600(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/view/View;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    return-object p0
.end method

.method static synthetic access$6000(Lcom/android/mms/ui/ComposeMessageActivity;IZ)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->ImaeAttach(IZ)V

    return-void
.end method

.method static synthetic access$6102(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->discardDialogShow:Z

    return p1
.end method

.method static synthetic access$6200(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    return p0
.end method

.method static synthetic access$6300(Lcom/android/mms/ui/ComposeMessageActivity;Z)[Landroid/view/View;
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showTwoSmsOrMmsSendButton(Z)[Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$6400(Lcom/android/mms/ui/ComposeMessageActivity;Z)Landroid/view/View;
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showSmsOrMmsSendButton(Z)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$6500(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/TextView;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$6600(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/TextView;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounterSec:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$6700(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showConvertToMmsToast()V

    return-void
.end method

.method static synthetic access$6800(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showConvertToSmsToast()V

    return-void
.end method

.method static synthetic access$6900(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->resetCounter()V

    return-void
.end method

.method static synthetic access$700(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsReplaceAttachment:Z

    return p0
.end method

.method static synthetic access$7000(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->resetMessage()V

    return-void
.end method

.method static synthetic access$7100(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->startMsgListQuery()V

    return-void
.end method

.method static synthetic access$7200(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateThreadIdIfRunning()V

    return-void
.end method

.method static synthetic access$7300(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsAttachmentErrorOnSend:Z

    return p0
.end method

.method static synthetic access$7302(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsAttachmentErrorOnSend:Z

    return p1
.end method

.method static synthetic access$7400(Lcom/android/mms/ui/ComposeMessageActivity;II)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->handleAddAttachmentError(II)V

    return-void
.end method

.method static synthetic access$7500(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;)Z
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->startAvailabilityFetch(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method static synthetic access$7600(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mVideoCapable:Z

    return p0
.end method

.method static synthetic access$7700(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/os/Handler;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAvailabilityfetchHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$7800(Lcom/android/mms/ui/ComposeMessageActivity;)V
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->goToConversationList()V

    return-void
.end method

.method static synthetic access$7900(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isSubjectEditorVisible()Z

    move-result p0

    return p0
.end method

.method static synthetic access$800(Lcom/android/mms/ui/ComposeMessageActivity;Z)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showAttachmentSelector(Z)V

    return-void
.end method

.method static synthetic access$8000(Lcom/android/mms/ui/ComposeMessageActivity;)I
    .locals 0

    .line 245
    iget p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCurrentAttachmentPager:I

    return p0
.end method

.method static synthetic access$8002(Lcom/android/mms/ui/ComposeMessageActivity;I)I
    .locals 0

    .line 245
    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCurrentAttachmentPager:I

    return p1
.end method

.method static synthetic access$8100(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/ui/AttachmentPagerAdapter;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPagerAdapter:Lcom/android/mms/ui/AttachmentPagerAdapter;

    return-object p0
.end method

.method static synthetic access$8200(Lcom/android/mms/ui/ComposeMessageActivity;IZ)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachment(IZ)V

    return-void
.end method

.method static synthetic access$8300(Lcom/android/mms/ui/ComposeMessageActivity;)Z
    .locals 0

    .line 245
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRTL:Z

    return p0
.end method

.method static synthetic access$8400(Lcom/android/mms/ui/ComposeMessageActivity;I)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->updateAttachmentSelectorIndicator(I)V

    return-void
.end method

.method static synthetic access$8500(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/ui/AttachmentEditor;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditor:Lcom/android/mms/ui/AttachmentEditor;

    return-object p0
.end method

.method static synthetic access$8600(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/data/WorkingMessage;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->reUpdateAttachmentView(Lcom/android/mms/data/WorkingMessage;)V

    return-void
.end method

.method static synthetic access$8700(Lcom/android/mms/ui/ComposeMessageActivity;)I
    .locals 0

    .line 245
    iget p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mExistsRecipientsCount:I

    return p0
.end method

.method static synthetic access$8800(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/content/Intent;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->gfProcessAddRecipients(Landroid/content/Intent;)V

    return-void
.end method

.method static synthetic access$8900(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/util/Set;I)[Landroid/net/Uri;
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->buildUris(Ljava/util/Set;I)[Landroid/net/Uri;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$9000(Lcom/android/mms/ui/ComposeMessageActivity;)Ljava/lang/Object;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mObjectLock:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic access$902(Lcom/android/mms/ui/MessageListItem;)Lcom/android/mms/ui/MessageListItem;
    .locals 0

    .line 245
    sput-object p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    return-object p0
.end method

.method static synthetic access$9100(Lcom/android/mms/ui/ComposeMessageActivity;)I
    .locals 0

    .line 245
    iget p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResizeImageCount:I

    return p0
.end method

.method static synthetic access$9102(Lcom/android/mms/ui/ComposeMessageActivity;I)I
    .locals 0

    .line 245
    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResizeImageCount:I

    return p1
.end method

.method static synthetic access$9200(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;Landroid/net/Uri;ZII)V
    .locals 0

    .line 245
    invoke-direct/range {p0 .. p5}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    return-void
.end method

.method static synthetic access$9300(Lcom/android/mms/ui/ComposeMessageActivity;)I
    .locals 0

    .line 245
    iget p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCompresVideoCount:I

    return p0
.end method

.method static synthetic access$9302(Lcom/android/mms/ui/ComposeMessageActivity;I)I
    .locals 0

    .line 245
    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCompresVideoCount:I

    return p1
.end method

.method static synthetic access$9400(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/widget/Toast;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    return-object p0
.end method

.method static synthetic access$9402(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/widget/Toast;)Landroid/widget/Toast;
    .locals 0

    .line 245
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    return-object p1
.end method

.method static synthetic access$9500(Lcom/android/mms/ui/ComposeMessageActivity;)Landroid/content/DialogInterface$OnKeyListener;
    .locals 0

    .line 245
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ErrorDialogKeyListener:Landroid/content/DialogInterface$OnKeyListener;

    return-object p0
.end method

.method static synthetic access$9600(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->addImage(Landroid/net/Uri;ZLjava/lang/String;)V

    return-void
.end method

.method static synthetic access$9702(Lcom/android/mms/ui/ComposeMessageActivity;Z)Z
    .locals 0

    .line 245
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInAsyncAddAttathProcess:Z

    return p1
.end method

.method static synthetic access$9800(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/Runnable;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->handleUnsupportedTypeWarning(Ljava/lang/Runnable;)V

    return-void
.end method

.method static synthetic access$9900(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V
    .locals 0

    .line 245
    invoke-direct {p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->addVideo(Landroid/net/Uri;ZLjava/lang/String;)V

    return-void
.end method

.method private addAttachment(IZ)V
    .locals 6

    .line 4836
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz p2, :cond_0

    if-eqz v0, :cond_0

    .line 4838
    invoke-static {v0}, Lcom/android/mms/data/WorkingMessage;->removeThumbnailsFromCache(Lcom/android/mms/model/SlideshowModel;)V

    .line 4839
    invoke-virtual {v0, v1}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v2

    .line 4840
    invoke-virtual {v2}, Lcom/android/mms/model/SlideModel;->getSlideSize()I

    move-result v2

    goto :goto_0

    :cond_0
    move v2, v1

    :goto_0
    const/4 v3, 0x1

    packed-switch p1, :pswitch_data_0

    goto/16 :goto_1

    :pswitch_0    # 0xa
    const/4 p1, 0x2

    const/16 p2, 0x6f

    .line 4899
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->pickContacts(II)V

    goto/16 :goto_1

    :pswitch_1    # 0x9
    const/16 p1, 0x6e

    .line 4894
    invoke-direct {p0, v3, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->pickContacts(II)V

    goto/16 :goto_1

    .line 4903
    :pswitch_2    # 0x8
    invoke-virtual {p0, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->showDialog(I)V

    goto/16 :goto_1

    .line 4891
    :pswitch_3    # 0x7
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->editSlideshow()V

    goto :goto_1

    .line 4885
    :pswitch_4    # 0x6
    invoke-static {v0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->computeAttachmentSizeLimit(Lcom/android/mms/model/SlideshowModel;I)J

    move-result-wide v0

    const/16 p1, 0x69

    .line 4887
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 4886
    invoke-static {p0, p1, v0, v1}, Lcom/android/mms/ui/MessageUtils;->recordSound(Landroid/app/Activity;IJ)V

    goto :goto_1

    :pswitch_5    # 0x5
    const/16 p1, 0x68

    .line 4881
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 4880
    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->selectAudio(Landroid/app/Activity;I)V

    goto :goto_1

    .line 4867
    :pswitch_6    # 0x4
    invoke-static {v0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->computeAttachmentSizeLimit(Lcom/android/mms/model/SlideshowModel;I)J

    move-result-wide v2

    const-wide/16 v4, 0x0

    cmp-long p1, v2, v4

    if-lez p1, :cond_1

    const/16 p1, 0x67

    .line 4870
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 4869
    invoke-static {p0, p1, v2, v3}, Lcom/android/mms/ui/MessageUtils;->recordVideo(Landroid/app/Activity;IJ)V

    goto :goto_1

    :cond_1
    const p1, 0x7f0e016b    # @string/message_too_big_for_video 'The message is too big to attach a video.'

    .line 4873
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 4872
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 4874
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    goto :goto_1

    :pswitch_7    # 0x3
    const/16 p1, 0x66

    .line 4863
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 4862
    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->selectVideo(Landroid/content/Context;I)V

    goto :goto_1

    :pswitch_8    # 0x2
    const/16 p1, 0x65

    .line 4857
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 4856
    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->capturePicture(Landroid/app/Activity;I)V

    goto :goto_1

    :pswitch_9    # 0x1
    const/16 p1, 0x64

    .line 4852
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 4851
    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->selectImage(Landroid/content/Context;I)V

    goto :goto_1

    .line 4844
    :pswitch_a    # 0x0
    invoke-direct {p0, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->showSubjectEditor(Z)V

    .line 4845
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    const-string p2, ""

    invoke-virtual {p1, p2, v3}, Lcom/android/mms/data/WorkingMessage;->setSubject(Ljava/lang/CharSequence;Z)V

    .line 4846
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateSendButtonState()V

    .line 4847
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    invoke-virtual {p0}, Landroid/widget/EditText;->requestFocus()Z

    :goto_1
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a    # 0x0
        :pswitch_9    # 0x1
        :pswitch_8    # 0x2
        :pswitch_7    # 0x3
        :pswitch_6    # 0x4
        :pswitch_5    # 0x5
        :pswitch_4    # 0x6
        :pswitch_3    # 0x7
        :pswitch_2    # 0x8
        :pswitch_1    # 0x9
        :pswitch_0    # 0xa
    .end packed-switch
.end method

.method private addAttachment(Ljava/lang/String;Landroid/net/Uri;Z)V
    .locals 3

    if-eqz p2, :cond_c

    .line 6218
    invoke-static {}, Lcom/android/mms/MmsConfig;->isCreationModeEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 6219
    invoke-static {}, Lcom/android/mms/model/ContentRestrictionFactory;->reset()V

    :cond_0
    const-string v0, "*/*"

    .line 6221
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "image/"

    .line 6222
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_b

    if-eqz v0, :cond_1

    invoke-virtual {p2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/android/mms/ui/ComposeMessageActivity;->mImageUri:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_b

    :cond_1
    if-eqz v0, :cond_2

    .line 6223
    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->isImageFile(Landroid/net/Uri;)Z

    move-result v1

    if-eqz v1, :cond_2

    goto/16 :goto_2

    :cond_2
    const-string v1, "video/"

    .line 6226
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_a

    if-eqz v0, :cond_3

    .line 6227
    invoke-virtual {p2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/android/mms/ui/ComposeMessageActivity;->mVideoUri:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_a

    :cond_3
    if-eqz v0, :cond_4

    .line 6228
    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->isVideoFile(Landroid/net/Uri;)Z

    move-result v1

    if-eqz v1, :cond_4

    goto :goto_1

    :cond_4
    const-string v1, "audio/"

    .line 6230
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_9

    if-eqz v0, :cond_5

    .line 6231
    invoke-virtual {p2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/android/mms/ui/ComposeMessageActivity;->mAudioUri:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_9

    :cond_5
    if-eqz v0, :cond_6

    .line 6232
    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->isAudioFile(Landroid/net/Uri;)Z

    move-result v1

    if-eqz v1, :cond_6

    goto :goto_0

    .line 6235
    :cond_6
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p3

    const v1, 0x7f040016    # @bool/config_vcard 'true'

    invoke-virtual {p3, v1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p3

    if-eqz p3, :cond_8

    const-string p3, "text/x-vcard"

    .line 6236
    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_7

    if-eqz v0, :cond_8

    .line 6237
    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->isVcardFile(Landroid/net/Uri;)Z

    move-result p1

    if-eqz p1, :cond_8

    :cond_7
    const-string p1, "vcard"

    .line 6239
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    .line 6241
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->addVcard(Ljava/lang/String;Landroid/net/Uri;)V

    goto :goto_3

    .line 6244
    :cond_8
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentHandler:Landroid/os/Handler;

    const/4 p3, 0x1

    invoke-static {p1, p3, p2}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    .line 6246
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentHandler:Landroid/os/Handler;

    invoke-virtual {p0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_3

    :cond_9
    :goto_0
    const-string p1, "audio"

    .line 6233
    invoke-direct {p0, p2, p3, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->addAudio(Landroid/net/Uri;ZLjava/lang/String;)V

    goto :goto_3

    :cond_a
    :goto_1
    const-string p1, "video"

    .line 6229
    invoke-direct {p0, p2, p3, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->addVideo(Landroid/net/Uri;ZLjava/lang/String;)V

    goto :goto_3

    :cond_b
    :goto_2
    const-string p1, "image"

    .line 6225
    invoke-direct {p0, p2, p3, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->addImage(Landroid/net/Uri;ZLjava/lang/String;)V

    :cond_c
    :goto_3
    return-void
.end method

.method private addAttachmentFP(IZ)V
    .locals 1

    if-eqz p1, :cond_3

    const/4 v0, 0x1

    if-eq p1, v0, :cond_2

    const/4 v0, 0x2

    if-eq p1, v0, :cond_1

    const/4 p2, 0x3

    if-eq p1, p2, :cond_0

    goto :goto_0

    :cond_0
    const/16 p1, 0x6f

    .line 6603
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->pickContacts(I)V

    goto :goto_0

    :cond_1
    const/16 p1, 0x68

    .line 6599
    invoke-direct {p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getMakRequestCode(ZI)I

    move-result p1

    .line 6598
    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->selectAudio(Landroid/app/Activity;I)V

    goto :goto_0

    .line 6593
    :cond_2
    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->createVideoDialogOptions(Z)V

    goto :goto_0

    .line 6590
    :cond_3
    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->createImageDialogOptions(Z)V

    :goto_0
    return-void
.end method

.method private addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V
    .locals 9

    .line 10241
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "addAttachmentView slideid = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " uri = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " fileType = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mms"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 10242
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$100;

    move-object v2, v0

    move-object v3, p0

    move v4, p3

    move-object v5, p1

    move-object v6, p2

    move v7, p4

    move v8, p5

    invoke-direct/range {v2 .. v8}, Lcom/android/mms/ui/ComposeMessageActivity$100;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;ZLjava/lang/String;Landroid/net/Uri;II)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private addAudio(Landroid/net/Uri;ZLjava/lang/String;)V
    .locals 6

    if-eqz p1, :cond_2

    .line 5851
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    const/4 v1, 0x3

    invoke-virtual {v0, v1, p1, p2}, Lcom/android/mms/data/WorkingMessage;->setAttachment(ILandroid/net/Uri;Z)I

    move-result v0

    .line 5852
    invoke-static {}, Lcom/android/mms/MmsConfig;->isCreationModeEnabled()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, -0x6

    if-ne v0, v1, :cond_0

    .line 5854
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$65;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity$65;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V

    .line 5860
    new-instance p1, Lcom/android/mms/ui/ComposeMessageActivity$66;

    invoke-direct {p1, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$66;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/Runnable;)V

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :cond_0
    const/4 v1, -0x7

    if-ne v0, v1, :cond_1

    .line 5870
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$67;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity$67;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V

    .line 5876
    new-instance p1, Lcom/android/mms/ui/ComposeMessageActivity$68;

    invoke-direct {p1, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$68;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/Runnable;)V

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :cond_1
    const p2, 0x7f0e02e2    # @string/type_audio 'audio'

    .line 5889
    invoke-direct {p0, v0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->handleAddAttachmentError(II)V

    .line 5891
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    if-nez v0, :cond_2

    .line 5893
    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    if-eqz p2, :cond_2

    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    invoke-virtual {p2}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result p2

    if-lez p2, :cond_2

    .line 5894
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    invoke-virtual {p2}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v4

    const/4 v3, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p3

    move-object v2, p1

    .line 5895
    invoke-direct/range {v0 .. v5}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    :cond_2
    return-void
.end method

.method private addImage(Landroid/net/Uri;ZLjava/lang/String;)V
    .locals 6

    const-string v0, "Mms"

    const/4 v1, 0x2

    .line 5712
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 5713
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "addImage: append="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v3, ", uri="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 5715
    :cond_0
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    const/4 v3, 0x1

    invoke-virtual {v2, v3, p1, p2}, Lcom/android/mms/data/WorkingMessage;->setAttachment(ILandroid/net/Uri;Z)I

    move-result v2

    const/4 v4, -0x4

    if-eq v2, v4, :cond_4

    const/4 v4, -0x2

    if-ne v2, v4, :cond_1

    goto :goto_0

    .line 5729
    :cond_1
    invoke-static {}, Lcom/android/mms/MmsConfig;->isCreationModeEnabled()Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, -0x6

    if-ne v2, v0, :cond_2

    .line 5731
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$57;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity$57;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V

    .line 5737
    new-instance p1, Lcom/android/mms/ui/ComposeMessageActivity$58;

    invoke-direct {p1, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$58;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/Runnable;)V

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :cond_2
    const p2, 0x7f0e02e6    # @string/type_picture 'picture'

    .line 5747
    invoke-direct {p0, v2, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->handleAddAttachmentError(II)V

    if-nez v2, :cond_3

    .line 5751
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    if-eqz p2, :cond_3

    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    invoke-virtual {p2}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result p2

    if-lez p2, :cond_3

    .line 5752
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    invoke-virtual {p2}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v4

    const/4 v3, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p3

    move-object v2, p1

    .line 5753
    invoke-direct/range {v0 .. v5}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    :cond_3
    return-void

    .line 5718
    :cond_4
    :goto_0
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p3

    if-eqz p3, :cond_5

    .line 5719
    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "resize image "

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-static {p3}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 5721
    :cond_5
    iget p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResizeImageCount:I

    add-int/2addr p3, v3

    iput p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResizeImageCount:I

    .line 5722
    iget-object p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 5723
    invoke-virtual {p3}, Lcom/android/mms/data/WorkingMessage;->hasSlideshow()Z

    move-result p3

    if-eqz p3, :cond_6

    iget-object p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p3}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p3

    .line 5724
    invoke-virtual {p3}, Lcom/android/mms/model/SlideshowModel;->getCurrentMessageSize()I

    move-result p3

    goto :goto_1

    :cond_6
    const/4 p3, 0x0

    :goto_1
    move v2, p3

    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditorHandler:Landroid/os/Handler;

    iget-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResizeImageCallback:Lcom/android/mms/ui/MessageUtils$ResizeImageResultCallback;

    move-object v0, p0

    move-object v1, p1

    move v5, p2

    .line 5722
    invoke-static/range {v0 .. v5}, Lcom/android/mms/ui/MessageUtils;->resizeImageAsync(Landroid/content/Context;Landroid/net/Uri;ILandroid/os/Handler;Lcom/android/mms/ui/MessageUtils$ResizeImageResultCallback;Z)V

    return-void
.end method

.method private addImageAsync(Landroid/net/Uri;ZLjava/lang/String;)V
    .locals 2

    const/4 v0, 0x1

    .line 5700
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInAsyncAddAttathProcess:Z

    .line 5701
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;

    move-result-object v0

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$56;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity$56;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V

    const/4 p0, 0x0

    const p1, 0x7f0e0035    # @string/adding_attachments_title 'Adding attachments'

    invoke-virtual {v0, v1, p0, p1}, Lcom/android/mms/ui/AsyncDialog;->runAsync(Ljava/lang/Runnable;Ljava/lang/Runnable;I)V

    return-void
.end method

.method private addRecipientsListeners()V
    .locals 0

    .line 8703
    invoke-static {p0}, Lcom/android/mms/data/Contact;->addListener(Lcom/android/mms/data/Contact$UpdateListener;)V

    return-void
.end method

.method private addVcard(Ljava/lang/String;Landroid/net/Uri;)V
    .locals 7

    .line 5905
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, v1, p2, v2}, Lcom/android/mms/data/WorkingMessage;->setAttachment(ILandroid/net/Uri;Z)I

    move-result v0

    const v1, 0x7f0e02ec    # @string/type_vcard 'vCard'

    .line 5906
    invoke-direct {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->handleAddAttachmentError(II)V

    .line 5907
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    if-nez v0, :cond_0

    .line 5909
    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v0

    if-lez v0, :cond_0

    .line 5910
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v5

    const/4 v4, 0x0

    const/4 v6, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    .line 5911
    invoke-direct/range {v1 .. v6}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    :cond_0
    return-void
.end method

.method private addVideo(Landroid/net/Uri;ZLjava/lang/String;)V
    .locals 6

    .line 5774
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "addVideo uri: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " append: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, " type: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mms"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x1

    .line 5775
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInAsyncAddAttathProcess:Z

    if-eqz p1, :cond_5

    .line 5777
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    const/4 v3, 0x2

    invoke-virtual {v2, v3, p1, p2}, Lcom/android/mms/data/WorkingMessage;->setAttachment(ILandroid/net/Uri;Z)I

    move-result v2

    const/16 v4, -0xb

    if-eq v2, v4, :cond_3

    const/4 v4, -0x2

    if-ne v2, v4, :cond_0

    goto :goto_0

    .line 5796
    :cond_0
    invoke-static {}, Lcom/android/mms/MmsConfig;->isCreationModeEnabled()Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, -0x6

    if-ne v2, v0, :cond_1

    .line 5798
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$61;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity$61;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V

    .line 5805
    new-instance p1, Lcom/android/mms/ui/ComposeMessageActivity$62;

    invoke-direct {p1, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$62;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/Runnable;)V

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :cond_1
    const/4 v0, -0x7

    if-ne v2, v0, :cond_2

    .line 5815
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$63;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity$63;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V

    .line 5821
    new-instance p1, Lcom/android/mms/ui/ComposeMessageActivity$64;

    invoke-direct {p1, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$64;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/Runnable;)V

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :cond_2
    const p2, 0x7f0e02ed    # @string/type_video 'video'

    .line 5834
    invoke-direct {p0, v2, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->handleAddAttachmentError(II)V

    .line 5836
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    if-nez v2, :cond_5

    .line 5838
    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    if-eqz p2, :cond_5

    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    invoke-virtual {p2}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result p2

    if-lez p2, :cond_5

    .line 5839
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    invoke-virtual {p2}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v4

    const/4 v3, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p3

    move-object v2, p1

    .line 5840
    invoke-direct/range {v0 .. v5}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    goto :goto_1

    .line 5781
    :cond_3
    :goto_0
    invoke-static {v1, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p3

    if-eqz p3, :cond_4

    .line 5782
    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "compress video uri:  "

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-static {p3}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 5784
    :cond_4
    iget p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCompresVideoCount:I

    add-int/2addr p3, v0

    iput p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCompresVideoCount:I

    .line 5785
    new-instance p3, Lcom/android/mms/ui/ComposeMessageActivity$60;

    invoke-direct {p3, p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity$60;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;Z)V

    invoke-virtual {p0, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_5
    :goto_1
    return-void
.end method

.method private addVideoAsync(Landroid/net/Uri;ZLjava/lang/String;)V
    .locals 2

    const/4 v0, 0x1

    .line 5762
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInAsyncAddAttathProcess:Z

    .line 5763
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;

    move-result-object v0

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$59;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity$59;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;ZLjava/lang/String;)V

    const/4 p0, 0x0

    const p1, 0x7f0e0035    # @string/adding_attachments_title 'Adding attachments'

    invoke-virtual {v0, v1, p0, p1}, Lcom/android/mms/ui/AsyncDialog;->runAsync(Ljava/lang/Runnable;Ljava/lang/Runnable;I)V

    return-void
.end method

.method private alertDialog(Ljava/lang/String;Lcom/android/mms/ui/MessageItem;Ljava/lang/Runnable;)V
    .locals 8

    .line 7211
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialog:Landroid/app/AlertDialog;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/AlertDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 7212
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V

    .line 7215
    :cond_0
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 7216
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v2, 0x7f0a007a    # @layout/remove_dialog 'res/layout/remove_dialog.xml'

    const/4 v3, 0x0

    .line 7217
    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    const v2, 0x7f08008a    # @id/dialog_text

    .line 7218
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TctDialogMessage;

    .line 7220
    new-instance v4, Landroid/view/ViewGroup$LayoutParams;

    const/4 v5, -0x1

    const/4 v6, -0x2

    invoke-direct {v4, v5, v6}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 7225
    new-instance v7, Lcom/android/mms/ui/ComposeMessageActivity$83;

    invoke-direct {v7, p0, p1, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity$83;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;Lcom/android/mms/ui/MessageItem;Ljava/lang/Runnable;)V

    invoke-virtual {v0, v7}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    .line 7317
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p2

    iput-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialog:Landroid/app/AlertDialog;

    const/16 p3, 0xe

    .line 7319
    invoke-virtual {p2, p3}, Landroid/app/AlertDialog;->requestWindowFeature(I)Z

    .line 7320
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialog:Landroid/app/AlertDialog;

    invoke-virtual {p2}, Landroid/app/AlertDialog;->show()V

    .line 7321
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialog:Landroid/app/AlertDialog;

    invoke-virtual {p2, v1, v4}, Landroid/app/AlertDialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 7324
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialog:Landroid/app/AlertDialog;

    invoke-virtual {p2}, Landroid/app/AlertDialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object p2

    sput-object p2, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    const-string p2, "dialog_remove"

    .line 7326
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const p3, 0x7f0e0196    # @string/no 'Cancel'

    const/4 v0, 0x0

    if-eqz p2, :cond_2

    const p1, 0x7f0e00a9    # @string/delete_dialog 'The message will be deleted'

    .line 7327
    invoke-virtual {v2, p1}, Landroid/widget/TctDialogMessage;->setText(I)V

    .line 7329
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_1

    .line 7330
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    const p2, 0x7f0e02c4    # @string/str_no 'No'

    const p3, 0x7f0e02c5    # @string/str_yes 'Yes'

    invoke-virtual {p1, p2, v0, p3, v3}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    goto :goto_0

    .line 7332
    :cond_1
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    const p2, 0x7f0e00aa    # @string/delete_message 'Delete'

    invoke-virtual {p1, p3, v0, p2, v3}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    goto :goto_0

    :cond_2
    const-string p2, "dialog_limit"

    .line 7335
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const v1, 0x7f0e0301    # @string/yes 'OK'

    if-eqz p2, :cond_3

    const p1, 0x7f0e00e3    # @string/exceed_message_size_limitation 'Message size limit reached.'

    .line 7336
    invoke-virtual {v2, p1}, Landroid/widget/TctDialogMessage;->setText(I)V

    .line 7337
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p1, v1, v0, p3, v3}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    goto :goto_0

    :cond_3
    const-string p2, "dialog_invalid"

    .line 7340
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_4

    const p1, 0x7f0e0063    # @string/cannot_send_message_reason 'Your message has no valid recipients.'

    .line 7341
    invoke-virtual {v2, p1}, Landroid/widget/TctDialogMessage;->setText(I)V

    .line 7342
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p1, v0, v1, v0, v3}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    goto :goto_0

    :cond_4
    const-string p2, "invalid_recipient"

    .line 7343
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    const p1, 0x7f0e018f    # @string/new_has_invalid_recipient 'This message contains invalid recipient(s). Continue anyway?'

    .line 7345
    invoke-virtual {v2, p1}, Landroid/widget/TctDialogMessage;->setText(I)V

    .line 7346
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    const p2, 0x7f0e012c    # @string/menu_action_send 'Send'

    invoke-virtual {p1, p3, v0, p2, v3}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    .line 7352
    :cond_5
    :goto_0
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    .line 7354
    invoke-virtual {p1, v5, v6}, Landroid/view/Window;->setLayout(II)V

    const/16 p2, 0x50

    .line 7357
    invoke-virtual {p1, p2}, Landroid/view/Window;->setGravity(I)V

    const p2, 0x106000d    # @android:color/transparent

    .line 7358
    invoke-virtual {p1, p2}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    const/high16 p2, 0x3f000000

    .line 7359
    invoke-virtual {p1, p2}, Landroid/view/Window;->setDimAmount(F)V

    const/4 p1, 0x1

    .line 7360
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRemoveDialogShow:Z

    return-void
.end method

.method private bindPresenceService(Landroid/content/Context;)V
    .locals 3

    const-string v0, "Mms"

    const-string v1, "PresenceService BindService"

    .line 9976
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 9977
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lorg/codeaurora/presenceserv/IPresenceService;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "com.qualcomm.qti.presenceserv"

    const-string v2, "com.qualcomm.qti.presenceserv.PresenceService"

    .line 9978
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 9979
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConnection:Landroid/content/ServiceConnection;

    const/4 v2, 0x1

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result p1

    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsPresenceServiceBound:Z

    return-void
.end method

.method private buildAddAddressToContactMenuItem(Landroid/view/Menu;)V
    .locals 3

    .line 4599
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    .line 4600
    invoke-virtual {v0}, Lcom/android/mms/data/ContactList;->size()I

    move-result v1

    const/4 v2, 0x1

    if-eq v1, v2, :cond_0

    return-void

    :cond_0
    const/4 v1, 0x0

    .line 4606
    invoke-virtual {v0, v1}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/mms/data/Contact;

    .line 4607
    invoke-virtual {v0}, Lcom/android/mms/data/Contact;->existsInDatabase()Z

    move-result v2

    if-nez v2, :cond_1

    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->canAddToContacts(Lcom/android/mms/data/Contact;)Z

    move-result p0

    if-eqz p0, :cond_1

    .line 4608
    invoke-virtual {v0}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/android/mms/ui/ConversationList;->createAddContactIntent(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x1b

    const v2, 0x7f0e012f    # @string/menu_add_to_contacts 'Add to Contact'

    .line 4609
    invoke-interface {p1, v1, v0, v1, v2}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    move-result-object p1

    const v0, 0x1080033    # @android:drawable/ic_menu_add

    .line 4610
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    move-result-object p1

    .line 4611
    invoke-interface {p1, p0}, Landroid/view/MenuItem;->setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;

    :cond_1
    return-void
.end method

.method private buildUris(Ljava/util/Set;I)[Landroid/net/Uri;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;I)[",
            "Landroid/net/Uri;"
        }
    .end annotation

    .line 5444
    new-array p0, p2, [Landroid/net/Uri;

    .line 5445
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v0, 0x0

    .line 5447
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 5448
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    add-int/lit8 v2, v0, 0x1

    .line 5449
    sget-object v3, Landroid/provider/ContactsContract$CommonDataKinds$Phone;->CONTENT_URI:Landroid/net/Uri;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    int-to-long v4, v1

    invoke-static {v3, v4, v5}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v1

    aput-object v1, p0, v0

    if-ne v2, p2, :cond_0

    goto :goto_1

    :cond_0
    move v0, v2

    goto :goto_0

    :cond_1
    :goto_1
    return-object p0
.end method

.method private canAddToContacts(Lcom/android/mms/data/Contact;)Z
    .locals 3

    .line 1982
    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->getName()Ljava/lang/String;

    move-result-object v0

    .line 1983
    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    .line 1984
    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v1

    .line 1985
    invoke-direct {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->isSpecialChar(C)Z

    move-result v1

    if-eqz v1, :cond_0

    return v2

    .line 1989
    :cond_0
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 1990
    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v1

    .line 1991
    invoke-direct {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->isSpecialChar(C)Z

    move-result p0

    if-eqz p0, :cond_1

    return v2

    .line 1995
    :cond_1
    invoke-static {v0}, Lcom/android/mms/util/ContactRecipientEntryUtils;->isEmailAddress(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_2

    .line 1996
    invoke-static {v0}, Lcom/android/mmswrapper/TelephonyWrapper$Mms;->isPhoneNumber(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_2

    .line 1997
    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->isMe()Z

    move-result p0

    if-nez p0, :cond_2

    return v2

    :cond_2
    const/4 p0, 0x1

    return p0
.end method

.method private canSendMmsMobileDataOff(I)Z
    .locals 2

    const-string v0, "carrier_config"

    .line 1481
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/telephony/CarrierConfigManager;

    .line 1482
    invoke-virtual {p0, p1}, Landroid/telephony/CarrierConfigManager;->getConfigForSubId(I)Landroid/os/PersistableBundle;

    move-result-object p0

    const/4 p1, 0x0

    if-eqz p0, :cond_0

    const-string v0, "config_enable_mms_with_mobile_data_off"

    .line 1484
    invoke-virtual {p0, v0}, Landroid/os/PersistableBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    goto :goto_0

    :cond_0
    move p0, p1

    .line 1486
    :goto_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "canSendMmsMobileDataOff result: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-array p1, p1, [Ljava/lang/Object;

    invoke-static {v0, p1}, Lcom/android/mms/LogTag;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    return p0
.end method

.method private checkAttachFileState(Landroid/content/Context;)V
    .locals 5

    .line 8926
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasAttachment()Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasSlideshow()Z

    move-result v0

    if-nez v0, :cond_4

    .line 8927
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->getAttachFileUri()Ljava/util/ArrayList;

    move-result-object v0

    .line 8928
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/Uri;

    .line 8929
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Attach file uri is "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "Mms"

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    if-nez v1, :cond_1

    goto :goto_0

    .line 8933
    :cond_1
    invoke-direct {p0, p1, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getAttachFilePath(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v1

    .line 8934
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "File path is "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 8936
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x0

    if-nez v2, :cond_2

    .line 8937
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    goto :goto_1

    :cond_2
    move-object v2, v4

    :goto_1
    if-eqz v2, :cond_3

    .line 8939
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_0

    :cond_3
    const-string p1, "set attachment null"

    .line 8940
    invoke-static {v3, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const p1, 0x7f0e0061    # @string/cannot_send_attach_reason 'Can't send message because attachment can't be accessed'

    const/4 v0, 0x0

    .line 8941
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    .line 8943
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 8944
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0, v0, v4, v0}, Lcom/android/mms/data/WorkingMessage;->setAttachment(ILandroid/net/Uri;Z)I

    :cond_4
    return-void
.end method

.method private checkForMmsRecipients(Ljava/lang/String;Z)Z
    .locals 4

    .line 1895
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    .line 1896
    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    .line 1897
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->recipientCount()I

    move-result v0

    if-ge p1, v0, :cond_2

    .line 1899
    iget v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastRecipientCount:I

    const/4 v3, 0x1

    if-ne v0, v2, :cond_0

    if-eqz p2, :cond_1

    .line 1900
    :cond_0
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastRecipientCount:I

    const p2, 0x7f0e02d9    # @string/too_many_recipients 'Message has too many recipients (%1$s). There is a limit of %2$s recipients.'

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    .line 1901
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v2, v1

    .line 1902
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    .line 1901
    invoke-virtual {p0, p2, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    .line 1903
    invoke-static {p0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 1904
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :cond_1
    return v3

    .line 1908
    :cond_2
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastRecipientCount:I

    :cond_3
    return v1
.end method

.method private checkForTooManyRecipients()V
    .locals 8

    const v0, 0x7f0e017c    # @string/mms_recipient_Limit ''

    .line 1915
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    .line 1916
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->checkForMmsRecipients(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 1919
    :cond_0
    invoke-static {}, Lcom/android/mms/MmsConfig;->getRecipientLimit()I

    move-result v0

    const v1, 0x7fffffff

    if-eq v0, v1, :cond_2

    if-lez v0, :cond_2

    .line 1921
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->recipientCount()I

    move-result v1

    const/4 v3, 0x1

    if-le v1, v0, :cond_1

    move v4, v3

    goto :goto_0

    :cond_1
    move v4, v2

    .line 1923
    :goto_0
    iget-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v5}, Lcom/android/mms/ui/RecipientsEditor;->getSelectionStart()I

    move-result v5

    .line 1924
    iget-object v6, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v6}, Lcom/android/mms/ui/RecipientsEditor;->getText()Landroid/text/Editable;

    move-result-object v6

    .line 1926
    iget v7, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastRecipientCount:I

    if-eq v1, v7, :cond_2

    .line 1929
    iput v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastRecipientCount:I

    if-eqz v4, :cond_2

    if-lez v5, :cond_2

    const v4, 0x7f0e02d9    # @string/too_many_recipients 'Message has too many recipients (%1$s). There is a limit of %2$s recipients.'

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/Object;

    .line 1931
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v7, v2

    .line 1932
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v7, v3

    .line 1931
    invoke-virtual {p0, v4, v7}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 1933
    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 1934
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    add-int/lit8 p0, v5, -0x1

    .line 1935
    invoke-interface {v6, p0, v5}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    :cond_2
    return-void
.end method

.method private checkMessageSizeExceeded()Z
    .locals 7

    .line 7732
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxMessageSize()I

    move-result v0

    .line 7735
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    .line 7737
    invoke-virtual {v1}, Lcom/android/mms/model/SlideshowModel;->getTotalMessageSize()I

    move-result v4

    .line 7740
    iget-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v5}, Lcom/android/mms/data/WorkingMessage;->hasText()Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-virtual {v1}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v5

    if-ne v5, v2, :cond_0

    .line 7741
    invoke-virtual {v1}, Lcom/android/mms/model/SlideshowModel;->getTotalTextMessageSize()I

    move-result v5

    .line 7742
    iget-object v6, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v6}, Lcom/android/mms/data/WorkingMessage;->getText()Ljava/lang/CharSequence;

    move-result-object v6

    invoke-interface {v6}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->getBytes()[B

    move-result-object v6

    array-length v6, v6

    .line 7743
    invoke-virtual {v1}, Lcom/android/mms/model/SlideshowModel;->getSubjectSize()I

    move-result v1

    sub-int/2addr v4, v5

    add-int/2addr v4, v6

    add-int/2addr v1, v4

    .line 7745
    invoke-direct {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getSizeWithOverHead(I)I

    move-result v1

    .line 7746
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxMessageSize()I

    move-result v5

    div-int/lit16 v5, v5, 0x400

    if-le v1, v5, :cond_0

    move v1, v2

    goto :goto_1

    :cond_0
    :goto_0
    move v1, v3

    goto :goto_1

    .line 7748
    :cond_1
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->hasText()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 7749
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    array-length v4, v1

    goto :goto_0

    :cond_2
    move v1, v3

    move v4, v1

    .line 7751
    :goto_1
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "compose mmsCurrentSize = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, ", indicatorSizeOvered = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v6, "Mms"

    invoke-static {v6, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    if-gt v4, v0, :cond_4

    if-eqz v1, :cond_3

    goto :goto_2

    :cond_3
    return v3

    .line 7758
    :cond_4
    :goto_2
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsAttachmentErrorOnSend:Z

    const/4 v0, -0x2

    const v1, 0x7f0e02e6    # @string/type_picture 'picture'

    .line 7759
    invoke-direct {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->handleAddAttachmentError(II)V

    return v2
.end method

.method public static computeAttachmentSizeLimit(Lcom/android/mms/model/SlideshowModel;I)J
    .locals 4

    .line 4912
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxMessageSize()I

    move-result v0

    add-int/lit16 v0, v0, -0x400

    int-to-long v0, v0

    if-eqz p0, :cond_0

    .line 4914
    invoke-virtual {p0}, Lcom/android/mms/model/SlideshowModel;->getCurrentMessageSize()I

    move-result v2

    int-to-long v2, v2

    sub-long/2addr v0, v2

    .line 4915
    invoke-virtual {p0}, Lcom/android/mms/model/SlideshowModel;->getTotalTextMessageSize()I

    move-result p0

    int-to-long v2, p0

    sub-long/2addr v0, v2

    int-to-long p0, p1

    add-long/2addr v0, p0

    :cond_0
    return-wide v0
.end method

.method private confirmDeleteDialog(Landroid/content/DialogInterface$OnClickListener;Z)V
    .locals 1

    .line 7400
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/4 p0, 0x1

    .line 7401
    invoke-virtual {v0, p0}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    if-eqz p2, :cond_0

    const p0, 0x7f0e0083    # @string/confirm_delete_locked_message 'Delete locked message?'

    goto :goto_0

    :cond_0
    const p0, 0x7f0e0084    # @string/confirm_delete_message 'The message will be deleted.'

    .line 7402
    :goto_0
    invoke-virtual {v0, p0}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    const p0, 0x7f0e00a8    # @string/delete 'Delete'

    .line 7404
    invoke-virtual {v0, p0, p1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    const p0, 0x7f0e0196    # @string/no 'Cancel'

    const/4 p1, 0x0

    .line 7405
    invoke-virtual {v0, p0, p1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 7406
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private confirmDeleteThread(J)V
    .locals 1

    .line 4789
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBackgroundQueryHandler:Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;

    const/16 v0, 0x70a

    invoke-static {p0, p1, p2, v0}, Lcom/android/mms/data/Conversation;->startQueryHaveLockedMessages(Landroid/content/AsyncQueryHandler;JI)V

    return-void
.end method

.method private confirmSendMessageIfNeeded()V
    .locals 8

    const-string v0, "phone"

    .line 1524
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    .line 1526
    invoke-static {v0}, Lcom/android/mmswrapper/TelephonyManagerWrapper;->isMultiSimEnabled(Landroid/telephony/TelephonyManager;)Z

    move-result v1

    .line 1528
    invoke-static {}, Landroid/telephony/SmsManager;->getDefault()Landroid/telephony/SmsManager;

    invoke-static {}, Landroid/telephony/SmsManager;->getDefaultSmsSubscriptionId()I

    move-result v2

    .line 1527
    invoke-static {v2}, Lcom/android/mmswrapper/SubscriptionManagerWrapper;->getSlotId(I)I

    move-result v2

    if-eqz v1, :cond_0

    .line 1529
    invoke-direct {p0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->isLTEOnlyMode(I)Z

    move-result v3

    if-nez v3, :cond_1

    :cond_0
    if-nez v1, :cond_2

    .line 1530
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isLTEOnlyMode()Z

    move-result v3

    if-eqz v3, :cond_2

    .line 1531
    :cond_1
    invoke-direct {p0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->showDisableLTEOnlyDialog(I)V

    const-string p0, "return for disable LTEOnly"

    .line 1532
    invoke-static {p0}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    return-void

    .line 1538
    :cond_2
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "pref_key_mms_group_mms"

    const/4 v4, 0x1

    .line 1539
    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    .line 1540
    invoke-static {}, Lcom/android/mms/MmsConfig;->getGroupMmsEnabled()Z

    move-result v3

    .line 1541
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isATT()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->recipientCount()I

    move-result v5

    if-le v5, v4, :cond_3

    if-eqz v2, :cond_3

    if-eqz v3, :cond_3

    .line 1542
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->hasShortCode()Z

    move-result v2

    if-eqz v2, :cond_3

    .line 1543
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v1, 0x7f0e0062    # @string/cannot_send_message 'Can't send message'

    .line 1544
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const v1, 0x7f0e01a5    # @string/not_provide_short_codes 'Group messaging does not provide short code.'

    .line 1545
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const v1, 0x7f0e0301    # @string/yes 'OK'

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$CancelSendingListener;

    const/4 v3, 0x0

    invoke-direct {v2, p0, v3}, Lcom/android/mms/ui/ComposeMessageActivity$CancelSendingListener;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/ComposeMessageActivity$1;)V

    .line 1546
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 1547
    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    .line 1552
    :cond_3
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v2}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v2

    .line 1553
    invoke-static {}, Landroid/telephony/SubscriptionManager;->getDefaultSmsSubscriptionId()I

    move-result v3

    .line 1555
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_4

    .line 1556
    iget-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    const/16 v7, 0x8

    invoke-virtual {v5, v7}, Landroid/view/View;->setVisibility(I)V

    .line 1557
    iget-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContent:Landroid/widget/RelativeLayout;

    invoke-virtual {v5, v6}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 1560
    :cond_4
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v5

    if-nez v5, :cond_9

    if-eqz v1, :cond_7

    .line 1562
    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getActiveModemCount()I

    move-result v0

    if-le v0, v4, :cond_6

    .line 1563
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMsimIccCardActive()Z

    move-result v0

    if-eqz v0, :cond_6

    .line 1564
    invoke-static {}, Landroid/telephony/SmsManager;->getDefault()Landroid/telephony/SmsManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/telephony/SmsManager;->isSMSPromptEnabled()Z

    move-result v0

    if-eqz v0, :cond_5

    .line 1565
    invoke-direct {p0, v4, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->launchMsimDialog(ZZ)V

    goto :goto_0

    .line 1567
    :cond_5
    invoke-direct {p0, v4, v2, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMsimMessageNotPrompt(ZZI)V

    goto :goto_0

    .line 1570
    :cond_6
    invoke-direct {p0, v4, v2, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMsimMessageNotPrompt(ZZI)V

    goto :goto_0

    .line 1572
    :cond_7
    invoke-direct {p0, v2, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->isMmsWithMobileDataOff(ZI)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 1573
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showMobileDataDisabledDialog()V

    goto :goto_0

    .line 1575
    :cond_8
    invoke-direct {p0, v4}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMessage(Z)V

    :goto_0
    return-void

    .line 1580
    :cond_9
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v1, v2}, Lcom/android/mms/ui/RecipientsEditor;->hasInvalidRecipient(Z)Z

    move-result v1

    if-eqz v1, :cond_a

    .line 1581
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showInvalidRecipientDialog()V

    goto :goto_1

    .line 1582
    :cond_a
    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->isMultiSimEnabled()Z

    move-result v1

    if-eqz v1, :cond_d

    .line 1583
    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getActiveModemCount()I

    move-result v0

    if-le v0, v4, :cond_c

    .line 1584
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMsimIccCardActive()Z

    move-result v0

    if-eqz v0, :cond_c

    .line 1585
    invoke-static {}, Landroid/telephony/SmsManager;->getDefault()Landroid/telephony/SmsManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/telephony/SmsManager;->isSMSPromptEnabled()Z

    move-result v0

    if-eqz v0, :cond_b

    .line 1586
    invoke-direct {p0, v4, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->launchMsimDialog(ZZ)V

    goto :goto_1

    .line 1588
    :cond_b
    invoke-direct {p0, v4, v2, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMsimMessageNotPrompt(ZZI)V

    goto :goto_1

    .line 1591
    :cond_c
    invoke-direct {p0, v4, v2, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMsimMessageNotPrompt(ZZI)V

    goto :goto_1

    .line 1593
    :cond_d
    invoke-direct {p0, v2, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->isMmsWithMobileDataOff(ZI)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 1594
    invoke-direct {p0, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->showMobileDataDisabledDialog(I)V

    goto :goto_1

    :cond_e
    const v0, 0x7f0e017c    # @string/mms_recipient_Limit ''

    .line 1596
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_f

    if-eqz v2, :cond_f

    .line 1598
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, v4}, Lcom/android/mms/ui/ComposeMessageActivity;->checkForMmsRecipients(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_f

    return-void

    .line 1603
    :cond_f
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v0, v6}, Lcom/android/mms/ui/RecipientsEditor;->constructContactsFromInput(Z)Lcom/android/mms/data/ContactList;

    move-result-object v0

    .line 1604
    invoke-virtual {v0}, Lcom/android/mms/data/ContactList;->serialize()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDebugRecipients:Ljava/lang/String;

    .line 1605
    invoke-direct {p0, v4}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMessage(Z)V

    :goto_1
    return-void
.end method

.method private confirmSendMessageIfNeeded(I)V
    .locals 4

    .line 1491
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->isLTEOnlyMode(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1492
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showDisableLTEOnlyDialog(I)V

    return-void

    .line 1495
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v0

    .line 1496
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_2

    .line 1497
    invoke-direct {p0, v0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->isMmsWithMobileDataOff(ZI)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 1498
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showMobileDataDisabledDialog(I)V

    goto :goto_0

    .line 1500
    :cond_1
    invoke-direct {p0, v2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMsimMessage(ZI)V

    :goto_0
    return-void

    .line 1505
    :cond_2
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v1, v0}, Lcom/android/mms/ui/RecipientsEditor;->hasInvalidRecipient(Z)Z

    move-result v1

    if-eqz v1, :cond_3

    .line 1506
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showInvalidRecipientDialog(I)V

    goto :goto_1

    .line 1507
    :cond_3
    invoke-direct {p0, v0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->isMmsWithMobileDataOff(ZI)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 1508
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showMobileDataDisabledDialog(I)V

    goto :goto_1

    :cond_4
    const v1, 0x7f0e017c    # @string/mms_recipient_Limit ''

    .line 1510
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_5

    if-eqz v0, :cond_5

    .line 1512
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->checkForMmsRecipients(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_5

    return-void

    .line 1517
    :cond_5
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->constructContactsFromInput(Z)Lcom/android/mms/data/ContactList;

    move-result-object v0

    .line 1518
    invoke-virtual {v0}, Lcom/android/mms/data/ContactList;->serialize()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDebugRecipients:Ljava/lang/String;

    .line 1519
    invoke-direct {p0, v2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMsimMessage(ZI)V

    :goto_1
    return-void
.end method

.method private constructContactAndUpdateTitle()V
    .locals 2

    .line 1890
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->constructContactsFromInput(Z)Lcom/android/mms/data/ContactList;

    move-result-object v0

    .line 1891
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateTitle(Lcom/android/mms/data/ContactList;)V

    return-void
.end method

.method private copyMedia(J)Z
    .locals 6

    .line 2367
    :try_start_0
    sget-object v0, Landroid/provider/Telephony$Mms;->CONTENT_URI:Landroid/net/Uri;

    .line 2368
    invoke-static {v0, p1, p2}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v0

    .line 2367
    invoke-static {p0, v0}, Lcom/android/mms/model/SlideshowModel;->getPduBody(Landroid/content/Context;Landroid/net/Uri;)Lcom/google/android/mms/pdu/PduBody;

    move-result-object v0

    :try_end_0
    .catch Lcom/google/android/mms/MmsException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 2370
    :catch_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "copyMedia can\'t load pdu body: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mms"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 2376
    :cond_0
    invoke-virtual {v0}, Lcom/google/android/mms/pdu/PduBody;->getPartsNum()I

    move-result v2

    const/4 v3, 0x1

    :goto_1
    if-ge v1, v2, :cond_1

    .line 2378
    invoke-virtual {v0, v1}, Lcom/google/android/mms/pdu/PduBody;->getPart(I)Lcom/google/android/mms/pdu/PduPart;

    move-result-object v4

    .line 2381
    invoke-static {p1, p2}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v4, v5}, Lcom/android/mms/ui/ComposeMessageActivity;->copyPart(Lcom/google/android/mms/pdu/PduPart;Ljava/lang/String;)Z

    move-result v4

    and-int/2addr v3, v4

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    return v3
.end method

.method private copyPart(Lcom/google/android/mms/pdu/PduPart;Ljava/lang/String;)Z
    .locals 13

    const-string v0, "/"

    const-string v1, "IOException caught while closing stream"

    const-string v2, "Mms"

    .line 2472
    invoke-virtual {p1}, Lcom/google/android/mms/pdu/PduPart;->getDataUri()Landroid/net/Uri;

    move-result-object v3

    .line 2473
    new-instance v4, Ljava/lang/String;

    invoke-virtual {p1}, Lcom/google/android/mms/pdu/PduPart;->getContentType()[B

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/lang/String;-><init>([B)V

    .line 2474
    invoke-static {v4}, Lcom/android/mms/drm/DrmUtils;->isDrmType(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_0

    .line 2476
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/mms/MmsApp;->getDrmManagerClient()Landroid/drm/DrmManagerClient;

    move-result-object v4

    .line 2477
    invoke-virtual {p1}, Lcom/google/android/mms/pdu/PduPart;->getDataUri()Landroid/net/Uri;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/drm/DrmManagerClient;->getOriginalMimeType(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v4

    .line 2479
    :cond_0
    invoke-static {v4}, Lcom/google/android/mms/ContentType;->isImageType(Ljava/lang/String;)Z

    move-result v6

    const/4 v7, 0x1

    if-nez v6, :cond_1

    .line 2480
    invoke-static {v4}, Lcom/google/android/mms/ContentType;->isVideoType(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_1

    .line 2481
    invoke-static {v4}, Lcom/google/android/mms/ContentType;->isAudioType(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_1

    const-string v6, "text/x-vCard"

    .line 2482
    invoke-virtual {v6}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    const-string v6, "application/ogg"

    .line 2483
    invoke-virtual {v6}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    return v7

    :cond_1
    const/4 v6, 0x0

    const/4 v8, 0x0

    .line 2492
    :try_start_0
    iget-object v9, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContentResolver:Landroid/content/ContentResolver;

    invoke-virtual {v9, v3}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v3

    .line 2493
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_5
    .catchall {:try_start_0 .. :try_end_0} :catchall_2
    :try_start_1

    instance-of v9, v3, Ljava/io/FileInputStream;

    if-eqz v9, :cond_b

    .line 2494
    move-object v9, v3

    check-cast v9, Ljava/io/FileInputStream;

    .line 2496
    invoke-virtual {p1}, Lcom/google/android/mms/pdu/PduPart;->getName()[B

    move-result-object v10

    if-nez v10, :cond_2

    .line 2498
    invoke-virtual {p1}, Lcom/google/android/mms/pdu/PduPart;->getFilename()[B

    move-result-object v10

    :cond_2
    if-nez v10, :cond_3

    .line 2501
    invoke-virtual {p1}, Lcom/google/android/mms/pdu/PduPart;->getContentLocation()[B

    move-result-object v10

    :cond_3
    if-nez v10, :cond_4

    goto :goto_0

    .line 2511
    :cond_4
    new-instance p2, Ljava/lang/String;

    invoke-direct {p2, v10}, Ljava/lang/String;-><init>([B)V

    .line 2513
    :goto_0
    new-instance p1, Ljava/io/File;

    invoke-direct {p1, p2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 2514
    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p1

    .line 2524
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v10

    invoke-virtual {p2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v10, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-virtual {p2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/16 v0, 0x2e

    .line 2529
    invoke-virtual {p1, v0}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v0

    const/4 v10, -0x1

    if-ne v0, v10, :cond_5

    .line 2530
    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/webkit/MimeTypeMap;->getExtensionFromMimeType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_5
    add-int/lit8 v11, v0, 0x1

    .line 2532
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v12

    invoke-virtual {p1, v11, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v11

    .line 2533
    invoke-virtual {p1, v8, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    move-object v0, v11

    :goto_1
    if-eqz v5, :cond_6

    .line 2536
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v4}, Lcom/android/mms/drm/DrmUtils;->getConvertExtension(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2540
    :cond_6
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_7

    const-string v4, "."

    invoke-virtual {p1, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_7

    const-string v4, "[.]"

    const-string v5, ""

    .line 2541
    invoke-virtual {p1, v4, v5}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2542
    :cond_7
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getUniqueDestination(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object p1

    .line 2544
    invoke-virtual {p1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p2

    .line 2545
    invoke-virtual {p2}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_9

    invoke-virtual {p2}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-nez v0, :cond_9

    .line 2546
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "[MMS] copyPart: mkdirs for "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " failed!"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz v3, :cond_8

    .line 2570
    :try_start_2
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_2

    :catch_0
    move-exception p0

    .line 2573
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_8
    :goto_2
    return v8

    .line 2550
    :cond_9
    :try_start_3
    new-instance p2, Ljava/io/FileOutputStream;

    invoke-direct {p2, p1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/16 v0, 0x1f40

    :try_start_4
    new-array v0, v0, [B

    .line 2554
    :goto_3
    invoke-virtual {v9, v0}, Ljava/io/FileInputStream;->read([B)I

    move-result v4

    if-eq v4, v10, :cond_a

    .line 2555
    invoke-virtual {p2, v0, v8, v4}, Ljava/io/FileOutputStream;->write([BII)V

    goto :goto_3

    .line 2560
    :cond_a
    new-instance v0, Landroid/content/Intent;

    const-string v4, "android.intent.action.MEDIA_SCANNER_SCAN_FILE"

    .line 2561
    invoke-static {p1}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object p1

    invoke-direct {v0, v4, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 2560
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->sendBroadcast(Landroid/content/Intent;)V

    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    move-object v6, p2

    goto :goto_4

    :catchall_0
    move-exception p0

    goto :goto_7

    :catch_1
    move-exception p0

    goto :goto_8

    :cond_b
    :goto_4
    if-eqz v3, :cond_c

    .line 2570
    :try_start_5
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2

    goto :goto_5

    :catch_2
    move-exception p0

    .line 2573
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v8

    :cond_c
    :goto_5
    if-eqz v6, :cond_d

    .line 2579
    :try_start_6
    invoke-virtual {v6}, Ljava/io/FileOutputStream;->close()V

    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_3

    goto :goto_6

    :catch_3
    move-exception p0

    .line 2582
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v8

    :cond_d
    :goto_6
    return v7

    :catchall_1
    move-exception p0

    move-object p2, v6

    :goto_7
    move-object v6, v3

    goto :goto_c

    :catch_4
    move-exception p0

    move-object p2, v6

    :goto_8
    move-object v6, v3

    goto :goto_9

    :catchall_2
    move-exception p0

    move-object p2, v6

    goto :goto_c

    :catch_5
    move-exception p0

    move-object p2, v6

    :goto_9
    :try_start_7
    const-string p1, "IOException caught while opening or reading stream"

    .line 2565
    invoke-static {v2, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    if-eqz v6, :cond_e

    .line 2570
    :try_start_8
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_6

    goto :goto_a

    :catch_6
    move-exception p0

    .line 2573
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v8

    :cond_e
    :goto_a
    if-eqz p2, :cond_f

    .line 2579
    :try_start_9
    invoke-virtual {p2}, Ljava/io/FileOutputStream;->close()V

    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_7

    goto :goto_b

    :catch_7
    move-exception p0

    .line 2582
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_f
    :goto_b
    return v8

    :catchall_3
    move-exception p0

    :goto_c
    if-eqz v6, :cond_10

    .line 2570
    :try_start_a
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_8

    goto :goto_d

    :catch_8
    move-exception p0

    .line 2573
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v8

    :cond_10
    :goto_d
    if-eqz p2, :cond_11

    .line 2579
    :try_start_b
    invoke-virtual {p2}, Ljava/io/FileOutputStream;->close()V

    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_9

    goto :goto_e

    :catch_9
    move-exception p0

    .line 2582
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v8

    .line 2586
    :cond_11
    :goto_e
    throw p0
.end method

.method private copyToClipboard(Ljava/lang/String;)V
    .locals 1

    const-string v0, "clipboard"

    .line 2155
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/ClipboardManager;

    const/4 v0, 0x0

    .line 2156
    invoke-static {v0, p1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    return-void
.end method

.method private copyToSim(Lcom/android/mms/ui/MessageItem;)Z
    .locals 1

    .line 8861
    invoke-static {}, Landroid/telephony/SmsManager;->getDefault()Landroid/telephony/SmsManager;

    invoke-static {}, Landroid/telephony/SmsManager;->getDefaultSmsSubscriptionId()I

    move-result v0

    invoke-direct {p0, p1, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->copyToSim(Lcom/android/mms/ui/MessageItem;I)Z

    move-result p0

    return p0
.end method

.method private copyToSim(Lcom/android/mms/ui/MessageItem;I)Z
    .locals 9

    .line 8865
    iget v0, p1, Lcom/android/mms/ui/MessageItem;->mBoxId:I

    .line 8866
    iget-object v1, p1, Lcom/android/mms/ui/MessageItem;->mAddress:Ljava/lang/String;

    .line 8867
    invoke-static {v1}, Lcom/android/mms/ui/MessageUtils;->isWapPushNumber(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    const-string v2, ":"

    .line 8868
    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    .line 8869
    aget-object v1, v1, v2

    .line 8871
    :cond_0
    iget-object v2, p1, Lcom/android/mms/ui/MessageItem;->mBody:Ljava/lang/String;

    .line 8872
    iget-wide v3, p1, Lcom/android/mms/ui/MessageItem;->mDate:J

    const-wide/16 v5, 0x0

    cmp-long v3, v3, v5

    if-eqz v3, :cond_1

    iget-wide v3, p1, Lcom/android/mms/ui/MessageItem;->mDate:J

    goto :goto_0

    :cond_1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    .line 8874
    :goto_0
    invoke-static {}, Landroid/telephony/SmsManager;->getDefault()Landroid/telephony/SmsManager;

    .line 8875
    invoke-static {}, Landroid/telephony/SmsManager;->getDefault()Landroid/telephony/SmsManager;

    move-result-object p1

    invoke-virtual {p1, v2}, Landroid/telephony/SmsManager;->divideMessage(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p1

    const/4 v2, 0x1

    .line 8878
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 8879
    new-instance v6, Landroid/content/ContentValues;

    invoke-direct {v6}, Landroid/content/ContentValues;-><init>()V

    .line 8880
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const-string v8, "subscription"

    invoke-virtual {v6, v8, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string v7, "address"

    .line 8881
    invoke-virtual {v6, v7, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v7, "body"

    .line 8882
    invoke-virtual {v6, v7, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 8883
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v7, "box_id"

    invoke-virtual {v6, v7, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 8884
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    const-string v7, "date"

    invoke-virtual {v6, v7, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 8885
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    sget-object v7, Lcom/android/mms/ui/MessageUtils;->ICC_URI:Landroid/net/Uri;

    invoke-virtual {v5, v7, v6}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v5

    if-eqz v5, :cond_3

    .line 8887
    invoke-virtual {v5}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object v2

    const-string v5, "success"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    :cond_3
    if-nez v2, :cond_2

    :cond_4
    return v2
.end method

.method private createImageDialogOptions(Z)V
    .locals 7

    .line 3862
    iget p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageMode:I

    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialogMode:I

    .line 3863
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 3864
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    .line 3865
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    const v1, 0x7f0a003b    # @layout/dialog_layout_dish 'res/layout/dialog_layout_dish.xml'

    goto :goto_0

    :cond_0
    const v1, 0x7f0a003a    # @layout/dialog_layout 'res/layout/dialog_layout.xml'

    :goto_0
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    const v1, 0x7f08008c    # @id/dialog_text_one

    .line 3867
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    const v1, 0x7f08008e    # @id/dialog_text_two

    .line 3868
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    const v1, 0x7f08008d    # @id/dialog_text_three

    .line 3869
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    const v1, 0x7f08008b    # @id/dialog_text_four

    .line 3870
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    const v1, 0x7f0800cd    # @id/image_two

    .line 3872
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoImageLine:Landroid/widget/ImageView;

    const v1, 0x7f0800cc    # @id/image_three

    .line 3873
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeImageLine:Landroid/widget/ImageView;

    .line 3874
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoImageLine:Landroid/widget/ImageView;

    const/16 v3, 0x8

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 3875
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeImageLine:Landroid/widget/ImageView;

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 3878
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "1. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0045    # @string/attach_take_photo 'Capture picture'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3879
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "2. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0072    # @string/choose_from_gallery 'Choose from Gallery'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3880
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 3881
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 3884
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3885
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3887
    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x2

    invoke-direct {v1, v3, v4}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 3891
    new-instance v5, Lcom/android/mms/ui/ComposeMessageActivity$32;

    invoke-direct {v5, p0}, Lcom/android/mms/ui/ComposeMessageActivity$32;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p1, v5}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    .line 3926
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageDialog:Landroid/app/AlertDialog;

    const/16 v5, 0xe

    .line 3928
    invoke-virtual {p1, v5}, Landroid/app/AlertDialog;->requestWindowFeature(I)Z

    .line 3929
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->show()V

    .line 3930
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 3932
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageDialog:Landroid/app/AlertDialog;

    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$33;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$33;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 3940
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object p1

    .line 3942
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    const v0, 0x7f0e0126    # @string/menu_action_ok 'OK'

    goto :goto_1

    :cond_1
    const v0, 0x7f0e0128    # @string/menu_action_select 'Select'

    :goto_1
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v2, v0, v2, v2}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 3943
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    .line 3944
    invoke-virtual {p1, v3, v4}, Landroid/view/Window;->setLayout(II)V

    const v0, 0x106000d    # @android:color/transparent

    .line 3947
    invoke-virtual {p1, v0}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    const/16 v0, 0x50

    .line 3948
    invoke-virtual {p1, v0}, Landroid/view/Window;->setGravity(I)V

    const/high16 v0, 0x3f000000

    .line 3949
    invoke-virtual {p1, v0}, Landroid/view/Window;->setDimAmount(F)V

    const/4 p1, 0x1

    .line 3950
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    return-void
.end method

.method public static createIntent(Landroid/content/Context;J)Landroid/content/Intent;
    .locals 3

    .line 8711
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/ComposeMessageActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-wide/16 v1, 0x0

    cmp-long p0, p1, v1

    const/4 v1, 0x1

    if-lez p0, :cond_0

    .line 8714
    invoke-static {p1, p2}, Lcom/android/mms/data/Conversation;->getUri(J)Landroid/net/Uri;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 8715
    sput-boolean v1, Lcom/android/mms/ui/ComposeMessageActivity;->mHaveRecipients:Z

    const/4 p0, 0x0

    .line 8716
    sput-boolean p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    .line 8717
    invoke-static {}, Lcom/android/mms/util/DraftCache;->getInstance()Lcom/android/mms/util/DraftCache;

    move-result-object p0

    invoke-virtual {p0, p1, p2}, Lcom/android/mms/util/DraftCache;->hasDraft(J)Z

    move-result p0

    sput-boolean p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHasDraft:Z

    goto :goto_0

    .line 8719
    :cond_0
    sput-boolean v1, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    :goto_0
    return-object v0
.end method

.method public static createIntent(Landroid/content/Context;JLjava/lang/String;)Landroid/content/Intent;
    .locals 3

    .line 8726
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/ComposeMessageActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string p0, "start_compose_from"

    .line 8728
    invoke-virtual {v0, p0, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-wide/16 v1, 0x0

    cmp-long p0, p1, v1

    if-lez p0, :cond_0

    .line 8730
    invoke-static {p1, p2}, Lcom/android/mms/data/Conversation;->getUri(J)Landroid/net/Uri;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 p0, 0x0

    .line 8732
    sput-boolean p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    goto :goto_0

    :cond_0
    const/4 p0, 0x1

    .line 8734
    sput-boolean p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    :goto_0
    return-object v0
.end method

.method private createListDialogOptions()V
    .locals 7

    .line 6480
    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachMode:I

    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialogMode:I

    .line 6481
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 6482
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    .line 6483
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_0

    const v2, 0x7f0a003b    # @layout/dialog_layout_dish 'res/layout/dialog_layout_dish.xml'

    goto :goto_0

    :cond_0
    const v2, 0x7f0a003a    # @layout/dialog_layout 'res/layout/dialog_layout.xml'

    :goto_0
    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    const v2, 0x7f08008c    # @id/dialog_text_one

    .line 6485
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    const v2, 0x7f08008e    # @id/dialog_text_two

    .line 6486
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    const v2, 0x7f08008d    # @id/dialog_text_three

    .line 6487
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    const v2, 0x7f08008b    # @id/dialog_text_four

    .line 6488
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    .line 6490
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "1. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e003f    # @string/attach_image 'Pictures'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 6491
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "2. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0046    # @string/attach_video 'Videos'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 6492
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "3. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0131    # @string/menu_attach_audio 'Audio'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 6493
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "4. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0133    # @string/menu_attach_contact 'Contact'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 6496
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 6497
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 6498
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 6499
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 6501
    new-instance v2, Landroid/view/ViewGroup$LayoutParams;

    const/4 v4, -0x1

    const/4 v5, -0x2

    invoke-direct {v2, v4, v5}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 6506
    new-instance v6, Lcom/android/mms/ui/ComposeMessageActivity$73;

    invoke-direct {v6, p0}, Lcom/android/mms/ui/ComposeMessageActivity$73;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v6}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    .line 6559
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    const/16 v6, 0xe

    .line 6561
    invoke-virtual {v0, v6}, Landroid/app/AlertDialog;->requestWindowFeature(I)Z

    .line 6562
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

    .line 6563
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 6565
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$74;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$74;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 6573
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v0

    .line 6575
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_1

    const v1, 0x7f0e0126    # @string/menu_action_ok 'OK'

    goto :goto_1

    :cond_1
    const v1, 0x7f0e0128    # @string/menu_action_select 'Select'

    :goto_1
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v3, v1, v3, v3}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 6576
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    .line 6577
    invoke-virtual {v0, v4, v5}, Landroid/view/Window;->setLayout(II)V

    const v1, 0x106000d    # @android:color/transparent

    .line 6580
    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    const/16 v1, 0x50

    .line 6581
    invoke-virtual {v0, v1}, Landroid/view/Window;->setGravity(I)V

    const/high16 v1, 0x3f000000

    .line 6582
    invoke-virtual {v0, v1}, Landroid/view/Window;->setDimAmount(F)V

    const/4 v0, 0x1

    .line 6583
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    return-void
.end method

.method private createVideoDialogOptions(Z)V
    .locals 7

    .line 3737
    iget p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoMode:I

    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialogMode:I

    .line 3738
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 3739
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    .line 3740
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    const v1, 0x7f0a003b    # @layout/dialog_layout_dish 'res/layout/dialog_layout_dish.xml'

    goto :goto_0

    :cond_0
    const v1, 0x7f0a003a    # @layout/dialog_layout 'res/layout/dialog_layout.xml'

    :goto_0
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    const v1, 0x7f08008c    # @id/dialog_text_one

    .line 3742
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    const v1, 0x7f08008e    # @id/dialog_text_two

    .line 3743
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    const v1, 0x7f08008d    # @id/dialog_text_three

    .line 3744
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    const v1, 0x7f08008b    # @id/dialog_text_four

    .line 3745
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    const v1, 0x7f0800cd    # @id/image_two

    .line 3747
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoImageLine:Landroid/widget/ImageView;

    const v1, 0x7f0800cc    # @id/image_three

    .line 3748
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeImageLine:Landroid/widget/ImageView;

    .line 3749
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoImageLine:Landroid/widget/ImageView;

    const/16 v3, 0x8

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 3750
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeImageLine:Landroid/widget/ImageView;

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 3753
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "1. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0041    # @string/attach_record_video 'Capture video'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3754
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "2. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0072    # @string/choose_from_gallery 'Choose from Gallery'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3755
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 3756
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 3760
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3761
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3763
    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x2

    invoke-direct {v1, v3, v4}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 3767
    new-instance v5, Lcom/android/mms/ui/ComposeMessageActivity$30;

    invoke-direct {v5, p0}, Lcom/android/mms/ui/ComposeMessageActivity$30;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p1, v5}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    .line 3802
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoDialog:Landroid/app/AlertDialog;

    const/16 v5, 0xe

    .line 3804
    invoke-virtual {p1, v5}, Landroid/app/AlertDialog;->requestWindowFeature(I)Z

    .line 3805
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->show()V

    .line 3806
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 3808
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoDialog:Landroid/app/AlertDialog;

    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$31;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$31;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 3816
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object p1

    .line 3818
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    const v0, 0x7f0e0126    # @string/menu_action_ok 'OK'

    goto :goto_1

    :cond_1
    const v0, 0x7f0e0128    # @string/menu_action_select 'Select'

    :goto_1
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v2, v0, v2, v2}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 3819
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    .line 3820
    invoke-virtual {p1, v3, v4}, Landroid/view/Window;->setLayout(II)V

    const v0, 0x106000d    # @android:color/transparent

    .line 3823
    invoke-virtual {p1, v0}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    const/16 v0, 0x50

    .line 3824
    invoke-virtual {p1, v0}, Landroid/view/Window;->setGravity(I)V

    const/high16 v0, 0x3f000000

    .line 3825
    invoke-virtual {p1, v0}, Landroid/view/Window;->setDimAmount(F)V

    const/4 p1, 0x1

    .line 3826
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    return-void
.end method

.method private createsaveDraftDialogOptions(Ljava/lang/Runnable;)V
    .locals 7

    .line 3615
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRunnable:Ljava/lang/Runnable;

    .line 3616
    iget p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftMode:I

    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialogMode:I

    .line 3617
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 3618
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    .line 3619
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    const v1, 0x7f0a003b    # @layout/dialog_layout_dish 'res/layout/dialog_layout_dish.xml'

    goto :goto_0

    :cond_0
    const v1, 0x7f0a003a    # @layout/dialog_layout 'res/layout/dialog_layout.xml'

    :goto_0
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    const v1, 0x7f08008c    # @id/dialog_text_one

    .line 3621
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    const v1, 0x7f08008e    # @id/dialog_text_two

    .line 3622
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    const v1, 0x7f08008d    # @id/dialog_text_three

    .line 3623
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    const v1, 0x7f08008b    # @id/dialog_text_four

    .line 3624
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    const v1, 0x7f0800cd    # @id/image_two

    .line 3626
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoImageLine:Landroid/widget/ImageView;

    const v1, 0x7f0800cc    # @id/image_three

    .line 3627
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeImageLine:Landroid/widget/ImageView;

    .line 3628
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoImageLine:Landroid/widget/ImageView;

    const/16 v3, 0x8

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 3629
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeImageLine:Landroid/widget/ImageView;

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 3632
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "1. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0255    # @string/save_draft 'Save draft'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3633
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "2. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e00c0    # @string/discard_draft 'Discard draft'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3634
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 3635
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 3639
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3640
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3642
    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x2

    invoke-direct {v1, v3, v4}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 3646
    new-instance v5, Lcom/android/mms/ui/ComposeMessageActivity$28;

    invoke-direct {v5, p0}, Lcom/android/mms/ui/ComposeMessageActivity$28;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p1, v5}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    .line 3682
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    const/16 v5, 0xe

    .line 3683
    invoke-virtual {p1, v5}, Landroid/app/AlertDialog;->requestWindowFeature(I)Z

    .line 3684
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->show()V

    .line 3685
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 3687
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$29;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$29;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 3695
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object p1

    .line 3697
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    const v0, 0x7f0e0126    # @string/menu_action_ok 'OK'

    goto :goto_1

    :cond_1
    const v0, 0x7f0e0128    # @string/menu_action_select 'Select'

    :goto_1
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v2, v0, v2, v2}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 3698
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    .line 3699
    invoke-virtual {p1, v3, v4}, Landroid/view/Window;->setLayout(II)V

    const v0, 0x106000d    # @android:color/transparent

    .line 3702
    invoke-virtual {p1, v0}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    const/16 v0, 0x50

    .line 3703
    invoke-virtual {p1, v0}, Landroid/view/Window;->setGravity(I)V

    const/high16 v0, 0x3f000000

    .line 3704
    invoke-virtual {p1, v0}, Landroid/view/Window;->setDimAmount(F)V

    const/4 p1, 0x1

    .line 3705
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    return-void
.end method

.method private determinePalette(I)Lcom/android/mms/util/MaterialColorMapUtils$MaterialPalette;
    .locals 1

    .line 9783
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    if-eqz p1, :cond_0

    .line 9785
    new-instance v0, Lcom/android/mms/util/MaterialColorMapUtils;

    invoke-direct {v0, p0}, Lcom/android/mms/util/MaterialColorMapUtils;-><init>(Landroid/content/res/Resources;)V

    .line 9786
    invoke-virtual {v0, p1}, Lcom/android/mms/util/MaterialColorMapUtils;->calculatePrimaryAndSecondaryColor(I)Lcom/android/mms/util/MaterialColorMapUtils$MaterialPalette;

    move-result-object p0

    return-object p0

    .line 9789
    :cond_0
    invoke-static {p0}, Lcom/android/mms/util/MaterialColorMapUtils;->getDefaultPrimaryAndSecondaryColors(Landroid/content/res/Resources;)Lcom/android/mms/util/MaterialColorMapUtils$MaterialPalette;

    move-result-object p0

    return-object p0
.end method

.method private dialRecipient()V
    .locals 4

    .line 4478
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientCallable()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 4479
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/mms/data/Contact;

    invoke-virtual {v0}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object v0

    .line 4480
    new-instance v1, Landroid/content/Intent;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "tel:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const-string v2, "android.intent.action.CALL"

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 4481
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method private dismissMsimDialog()V
    .locals 1

    .line 1351
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsimDialog:Landroid/app/AlertDialog;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/AlertDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1352
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsimDialog:Landroid/app/AlertDialog;

    invoke-virtual {p0}, Landroid/app/AlertDialog;->dismiss()V

    :cond_0
    return-void
.end method

.method private drawBottomPanel()V
    .locals 2

    .line 6311
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->resetCounter()V

    .line 6313
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasSlideshow()Z

    .line 6332
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_0

    .line 6333
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setVisibility(I)V

    .line 6336
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 6339
    iget-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    if-eqz v1, :cond_1

    .line 6340
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v1, v0}, Landroid/widget/EditText;->setTextKeepState(Ljava/lang/CharSequence;)V

    .line 6343
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->length()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSelection(I)V

    goto :goto_0

    .line 6345
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 6347
    :goto_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->onKeyboardStateChanged()V

    return-void
.end method

.method private drawTopPanel(Z)V
    .locals 2

    .line 6358
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditor:Lcom/android/mms/ui/AttachmentEditor;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/AttachmentEditor;->update(Lcom/android/mms/data/WorkingMessage;)Z

    .line 6360
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditorScrollView:Landroid/view/View;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v0, 0x0

    if-nez p1, :cond_1

    .line 6363
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->hasSubject()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    move p1, v0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showSubjectEditor(Z)V

    .line 6364
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->hasSubject()Z

    move-result p1

    if-eqz p1, :cond_2

    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 6365
    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->getSubject()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    array-length v0, p1

    .line 6366
    :cond_2
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p1

    if-eqz p1, :cond_3

    .line 6367
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p1

    invoke-virtual {p1, v0}, Lcom/android/mms/model/SlideshowModel;->setSubjectSize(I)V

    .line 6369
    :cond_3
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz p1, :cond_4

    .line 6370
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditor:Lcom/android/mms/ui/AttachmentEditor;

    invoke-virtual {p1}, Lcom/android/mms/ui/AttachmentEditor;->hideSlideshowSendButton()V

    .line 6373
    :cond_4
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->invalidateOptionsMenu()V

    .line 6374
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->onKeyboardStateChanged()V

    return-void
.end method

.method private editMessageItem(Lcom/android/mms/ui/MessageItem;)V
    .locals 2

    .line 2079
    iget-object v0, p1, Lcom/android/mms/ui/MessageItem;->mType:Ljava/lang/String;

    const-string v1, "sms"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 2080
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->editSmsMessageItem(Lcom/android/mms/ui/MessageItem;)V

    goto :goto_0

    .line 2082
    :cond_0
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->editMmsMessageItem(Lcom/android/mms/ui/MessageItem;)V

    .line 2084
    :goto_0
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageItem;->isFailedMessage()Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {p1}, Lcom/android/mms/ui/MessageListAdapter;->getCount()I

    move-result p1

    const/4 v0, 0x1

    if-gt p1, v0, :cond_1

    .line 2086
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->initRecipientsEditor()V

    :cond_1
    return-void
.end method

.method private editMmsMessageItem(Landroid/net/Uri;Ljava/lang/String;)V
    .locals 1

    .line 2131
    invoke-static {p0, p1}, Lcom/android/mms/data/WorkingMessage;->load(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;)Lcom/android/mms/data/WorkingMessage;

    move-result-object p1

    if-nez p1, :cond_0

    return-void

    .line 2137
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->discard()V

    .line 2139
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 2140
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1, v0}, Lcom/android/mms/data/WorkingMessage;->setConversation(Lcom/android/mms/data/Conversation;)V

    const/4 p1, 0x0

    .line 2142
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->drawTopPanel(Z)V

    .line 2147
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0, p2, p1}, Lcom/android/mms/data/WorkingMessage;->setSubject(Ljava/lang/CharSequence;Z)V

    .line 2149
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->hasSubject()Z

    move-result p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    .line 2150
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showSubjectEditor(Z)V

    :cond_1
    return-void
.end method

.method private editMmsMessageItem(Lcom/android/mms/ui/MessageItem;)V
    .locals 1

    .line 2126
    iget-object v0, p1, Lcom/android/mms/ui/MessageItem;->mMessageUri:Landroid/net/Uri;

    iget-object p1, p1, Lcom/android/mms/ui/MessageItem;->mSubject:Ljava/lang/String;

    invoke-direct {p0, v0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->editMmsMessageItem(Landroid/net/Uri;Ljava/lang/String;)V

    return-void
.end method

.method private editSlideshow()V
    .locals 4

    .line 722
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasSubject()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 723
    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSubject()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    array-length v0, v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 729
    :goto_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;

    move-result-object v1

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$1;

    invoke-direct {v2, p0}, Lcom/android/mms/ui/ComposeMessageActivity$1;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$2;

    invoke-direct {v3, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$2;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;I)V

    const p0, 0x7f0e0054    # @string/building_slideshow_title 'Building slideshow'

    invoke-virtual {v1, v2, v3, p0}, Lcom/android/mms/ui/AsyncDialog;->runAsync(Ljava/lang/Runnable;Ljava/lang/Runnable;I)V

    return-void
.end method

.method private editSmsMessageItem(JLjava/lang/String;)V
    .locals 5

    .line 2102
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    monitor-enter v0

    .line 2103
    :try_start_0
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->getMessageCount()I

    move-result v1

    const/4 v2, 0x1

    if-gt v1, v2, :cond_0

    .line 2104
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->clearThreadId()V

    const-wide/16 v3, -0x2

    .line 2105
    invoke-static {v3, v4}, Lcom/android/mms/transaction/MessagingNotification;->setCurrentlyDisplayedThreadId(J)V

    .line 2108
    :cond_0
    monitor-exit v0

    .line 2110
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sget-object v0, Landroid/provider/Telephony$Sms;->CONTENT_URI:Landroid/net/Uri;

    invoke-static {v0, p1, p2}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object p1

    .line 2111
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContentResolver:Landroid/content/ContentResolver;

    const/4 v0, 0x0

    invoke-static {p0, p2, p1, v0, v0}, Landroid/database/sqlite/SqliteWrapper;->delete(Landroid/content/Context;Landroid/content/ContentResolver;Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I

    move-result p1

    .line 2113
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2, p3}, Lcom/android/mms/data/WorkingMessage;->setText(Ljava/lang/CharSequence;)V

    if-lez p1, :cond_1

    .line 2119
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {p1}, Lcom/android/mms/ui/MessageListAdapter;->getCount()I

    move-result p1

    if-ne p1, v2, :cond_1

    .line 2120
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessageListAdapter;->changeCursor(Landroid/database/Cursor;)V

    :cond_1
    return-void

    :catchall_0
    move-exception p0

    .line 2108
    :try_start_1
    monitor-exit v0

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method private editSmsMessageItem(Lcom/android/mms/ui/MessageItem;)V
    .locals 2

    .line 2091
    iget-wide v0, p1, Lcom/android/mms/ui/MessageItem;->mMsgId:J

    iget-object p1, p1, Lcom/android/mms/ui/MessageItem;->mBody:Ljava/lang/String;

    invoke-direct {p0, v0, v1, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->editSmsMessageItem(JLjava/lang/String;)V

    return-void
.end method

.method private ensureCorrectButtonHeight()V
    .locals 3

    .line 6771
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getLineCount()I

    move-result v0

    const/4 v1, 0x2

    const/16 v2, 0x8

    if-gt v0, v1, :cond_0

    .line 6773
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 6774
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz v0, :cond_1

    .line 6775
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounterSec:Landroid/widget/TextView;

    invoke-virtual {p0, v2}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_0

    :cond_0
    if-le v0, v1, :cond_1

    .line 6779
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getVisibility()I

    move-result v0

    if-ne v0, v2, :cond_1

    .line 6783
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_1
    :goto_0
    return-void
.end method

.method private exitComposeMessageActivity(Ljava/lang/Runnable;)V
    .locals 1

    .line 4177
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->isWorthSaving()Z

    move-result v0

    if-nez v0, :cond_0

    .line 4178
    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    .line 4179
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->discard()V

    return-void

    .line 4182
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientEmpty()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 4192
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->discardDialogShow:Z

    if-nez p1, :cond_1

    .line 4193
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showDisCardDraftDialog()V

    const/4 p1, 0x1

    .line 4194
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDiscardDialog:Z

    goto :goto_0

    .line 4196
    :cond_1
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->disCardDraftDialog:Landroid/app/TctDialog;

    if-eqz p1, :cond_2

    .line 4197
    invoke-virtual {p1}, Landroid/app/TctDialog;->dismiss()V

    const/4 p1, 0x0

    .line 4198
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->discardDialogShow:Z

    .line 4199
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDiscardDialog:Z

    :cond_2
    :goto_0
    return-void

    .line 4205
    :cond_3
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->createsaveDraftDialogOptions(Ljava/lang/Runnable;)V

    return-void
.end method

.method private forwardMessage()V
    .locals 4

    .line 9410
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v0

    .line 9412
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;

    move-result-object v1

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$92;

    invoke-direct {v2, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$92;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;)V

    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$93;

    invoke-direct {v3, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$93;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;)V

    const p0, 0x7f0e0054    # @string/building_slideshow_title 'Building slideshow'

    invoke-virtual {v1, v2, v3, p0}, Lcom/android/mms/ui/AsyncDialog;->runAsync(Ljava/lang/Runnable;Ljava/lang/Runnable;I)V

    return-void
.end method

.method private getAttachFilePath(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;
    .locals 6

    .line 8906
    sget-object p0, Lcom/android/mms/ui/ComposeMessageActivity;->URI_SCHEME_CONTENT:Ljava/lang/String;

    invoke-virtual {p2}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_2

    sget-object p0, Lcom/android/mms/ui/ComposeMessageActivity;->URI_HOST_MEDIA:Ljava/lang/String;

    .line 8907
    invoke-virtual {p2}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_2

    .line 8908
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v1, p2

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    if-eqz p0, :cond_1

    .line 8912
    :try_start_0
    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 8913
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->FILE_PATH_COLUMN:Ljava/lang/String;

    invoke-interface {p0, p1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result p1

    invoke-interface {p0, p1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 8916
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    return-object p1

    :cond_0
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    goto :goto_0

    :catchall_0
    move-exception p1

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    .line 8917
    throw p1

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return-object p0

    .line 8921
    :cond_2
    invoke-virtual {p2}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private getAttachmentMimeType(Landroid/net/Uri;)Ljava/lang/String;
    .locals 9

    .line 6146
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    .line 6148
    invoke-static {p1}, Lcom/android/mms/model/MediaModel;->isFileUri(Landroid/net/Uri;)Z

    move-result p0

    const-string v6, "getAttachmentMimeType "

    const-string v7, "Mms"

    if-eqz p0, :cond_2

    .line 6149
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/webkit/MimeTypeMap;->getFileExtensionFromUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 6150
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->is3GPP(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->is3GPP2(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const-string p0, "*/*"

    goto/16 :goto_4

    .line 6151
    :cond_1
    :goto_0
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, p0}, Lcom/android/mms/ui/MessageUtils;->getMimeType(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 6152
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "remap file "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " to "

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v7, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-object p0, v0

    goto :goto_4

    .line 6155
    :cond_2
    invoke-virtual {v0, p1}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p0

    .line 6156
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_6

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v1, p1

    .line 6159
    :try_start_0
    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v8

    if-eqz v8, :cond_3

    .line 6160
    invoke-interface {v8}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_3

    const-string v0, "mime_type"

    .line 6161
    invoke-interface {v8, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v8, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p0

    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    :cond_3

    if-eqz v8, :cond_4

    .line 6170
    :goto_1
    invoke-interface {v8}, Landroid/database/Cursor;->close()V

    goto :goto_2

    :catchall_0
    move-exception p0

    goto :goto_3

    :catch_0
    move-exception v0

    .line 6167
    :try_start_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v8, :cond_4

    goto :goto_1

    :catch_1
    move-exception v0

    .line 6165
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v8, :cond_4

    goto :goto_1

    :cond_4
    :goto_2
    if-nez p0, :cond_6

    const-string p0, ""

    goto :goto_4

    :goto_3
    if-eqz v8, :cond_5

    .line 6170
    invoke-interface {v8}, Landroid/database/Cursor;->close()V

    .line 6172
    :cond_5
    throw p0

    :cond_6
    :goto_4
    const/4 v0, 0x2

    .line 6176
    invoke-static {v7, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_7

    .line 6177
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " ="

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v7, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_7
    return-object p0
.end method

.method private getBody(Landroid/net/Uri;)Ljava/lang/String;
    .locals 4

    const/4 p0, 0x0

    if-nez p1, :cond_0

    return-object p0

    .line 8745
    :cond_0
    invoke-virtual {p1}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object p1

    const-string v0, "?"

    .line 8746
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    return-object p0

    :cond_1
    const/16 v0, 0x3f

    .line 8749
    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const-string v0, "&"

    .line 8750
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 8751
    array-length v0, p1

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_3

    aget-object v2, p1, v1

    const-string v3, "body="

    .line 8752
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, 0x5

    .line 8754
    :try_start_0
    invoke-virtual {v2, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "UTF-8"

    invoke-static {v2, v3}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    return-object p0
.end method

.method private getContactUriForEmail(Ljava/lang/String;)Landroid/net/Uri;
    .locals 7

    .line 2051
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    sget-object v0, Landroid/provider/ContactsContract$CommonDataKinds$Email;->CONTENT_LOOKUP_URI:Landroid/net/Uri;

    .line 2052
    invoke-static {p1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroid/net/Uri;->withAppendedPath(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const-string p1, "contact_id"

    const-string v0, "display_name"

    filled-new-array {p1, v0}, [Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, p0

    .line 2051
    invoke-static/range {v0 .. v6}, Landroid/database/sqlite/SqliteWrapper;->query(Landroid/content/Context;Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    if-eqz p0, :cond_2

    .line 2057
    :cond_0
    :try_start_0
    invoke-interface {p0}, Landroid/database/Cursor;->moveToNext()Z

    move-result p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    .line 2058
    invoke-interface {p0, p1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 2059
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_0

    .line 2060
    sget-object p1, Landroid/provider/ContactsContract$Contacts;->CONTENT_URI:Landroid/net/Uri;

    const/4 v0, 0x0

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    invoke-static {p1, v0, v1}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object p1

    .line 2064
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    return-object p1

    :cond_1
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    goto :goto_0

    :catchall_0
    move-exception p1

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    .line 2065
    throw p1

    :cond_2
    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method

.method private getContactUriForPhoneNumber(Ljava/lang/String;)Landroid/net/Uri;
    .locals 0

    const/4 p0, 0x0

    .line 2071
    invoke-static {p1, p0}, Lcom/android/mms/data/Contact;->get(Ljava/lang/String;Z)Lcom/android/mms/data/Contact;

    move-result-object p0

    .line 2072
    invoke-virtual {p0}, Lcom/android/mms/data/Contact;->existsInDatabase()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 2073
    invoke-virtual {p0}, Lcom/android/mms/data/Contact;->getUri()Landroid/net/Uri;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method private getContext()Landroid/content/Context;
    .locals 0

    return-object p0
.end method

.method private getDrmMimeMenuStringRsrc(J)I
    .locals 0

    .line 2345
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->isDrmRingtoneWithRights(J)Z

    move-result p0

    if-eqz p0, :cond_0

    const p0, 0x7f0e0256    # @string/save_ringtone 'Save as ringtone'

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private getDrmMimeSavedStringRsrc(JZ)I
    .locals 0

    .line 2352
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->isDrmRingtoneWithRights(J)Z

    move-result p0

    if-eqz p0, :cond_1

    if-eqz p3, :cond_0

    const p0, 0x7f0e0259    # @string/saved_ringtone 'Ringtone saved'

    goto :goto_0

    :cond_0
    const p0, 0x7f0e025a    # @string/saved_ringtone_fail 'Couldn't save ringtone'

    :goto_0
    return p0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method private getListView()Landroid/widget/ListView;
    .locals 0

    .line 8959
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    return-object p0
.end method

.method private getMakRequestCode(ZI)I
    .locals 0

    if-eqz p1, :cond_0

    const/high16 p0, 0x10000

    or-int/2addr p0, p2

    return p0

    :cond_0
    return p2
.end method

.method private getMediaStateFilter()Landroid/content/IntentFilter;
    .locals 1

    .line 8897
    new-instance p0, Landroid/content/IntentFilter;

    invoke-direct {p0}, Landroid/content/IntentFilter;-><init>()V

    const-string v0, "android.intent.action.MEDIA_BAD_REMOVAL"

    .line 8898
    invoke-virtual {p0, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v0, "android.intent.action.MEDIA_REMOVED"

    .line 8899
    invoke-virtual {p0, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v0, "android.intent.action.MEDIA_UNMOUNTED"

    .line 8900
    invoke-virtual {p0, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 8901
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->BROADCAST_DATA_SCHEME:Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroid/content/IntentFilter;->addDataScheme(Ljava/lang/String;)V

    return-object p0
.end method

.method private getMessageDate(Landroid/net/Uri;)J
    .locals 7

    if-eqz p1, :cond_1

    .line 8074
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContentResolver:Landroid/content/ContentResolver;

    const-string v0, "date"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, p0

    move-object v2, p1

    invoke-static/range {v0 .. v6}, Landroid/database/sqlite/SqliteWrapper;->query(Landroid/content/Context;Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    if-eqz p0, :cond_1

    .line 8078
    :try_start_0
    invoke-interface {p0}, Landroid/database/Cursor;->getCount()I

    move-result p1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    .line 8079
    invoke-interface {p0, p1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-wide/16 v2, 0x3e8

    mul-long/2addr v0, v2

    .line 8082
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    return-wide v0

    :cond_0
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    goto :goto_0

    :catchall_0
    move-exception p1

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    .line 8083
    throw p1

    :cond_1
    :goto_0
    const-wide/16 p0, -0x1

    return-wide p0
.end method

.method private getMessageItem(Ljava/lang/String;JZ)Lcom/android/mms/ui/MessageItem;
    .locals 0

    .line 1024
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    if-eqz p4, :cond_0

    .line 1025
    invoke-virtual {p0}, Lcom/android/mms/ui/MessageListAdapter;->getCursor()Landroid/database/Cursor;

    move-result-object p4

    goto :goto_0

    :cond_0
    const/4 p4, 0x0

    .line 1024
    :goto_0
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/android/mms/ui/MessageListAdapter;->getCachedMessageItem(Ljava/lang/String;JLandroid/database/Cursor;)Lcom/android/mms/ui/MessageItem;

    move-result-object p0

    return-object p0
.end method

.method private getRecipients()Lcom/android/mms/data/ContactList;
    .locals 1

    .line 2650
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 2651
    sget-object p0, Lcom/android/mms/ui/ComposeMessageActivity;->sEmptyContactList:Lcom/android/mms/data/ContactList;

    if-nez p0, :cond_0

    .line 2652
    new-instance p0, Lcom/android/mms/data/ContactList;

    invoke-direct {p0}, Lcom/android/mms/data/ContactList;-><init>()V

    sput-object p0, Lcom/android/mms/ui/ComposeMessageActivity;->sEmptyContactList:Lcom/android/mms/data/ContactList;

    .line 2654
    :cond_0
    sget-object p0, Lcom/android/mms/ui/ComposeMessageActivity;->sEmptyContactList:Lcom/android/mms/data/ContactList;

    return-object p0

    .line 2656
    :cond_1
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p0}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p0

    return-object p0
.end method

.method private getRequestCode(I)I
    .locals 0

    const p0, -0x10001

    and-int/2addr p0, p1

    return p0
.end method

.method private getResourcesString(ILjava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 6302
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    aput-object p2, v0, v1

    .line 6303
    invoke-virtual {p0, p1, v0}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static getSelectedCursor()Landroid/database/Cursor;
    .locals 1

    .line 10371
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mCurrentSelectedCursor:Landroid/database/Cursor;

    return-object v0
.end method

.method public static getSelectedItem()Lcom/android/mms/ui/MessageItem;
    .locals 1

    .line 10030
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    if-eqz v0, :cond_0

    .line 10031
    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method private getSelectedUriFromMessageList(Landroid/widget/ListView;I)Landroid/net/Uri;
    .locals 3

    .line 2009
    invoke-virtual {p1, p2}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    check-cast p0, Lcom/android/mms/ui/MessageListItem;

    const/4 p1, 0x0

    if-nez p0, :cond_0

    return-object p1

    .line 2025
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/MessageListItem;->getBodyTextView()Landroid/widget/TextView;

    move-result-object p0

    const/4 p2, -0x1

    if-eqz p0, :cond_1

    .line 2027
    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p2

    .line 2028
    invoke-virtual {p0}, Landroid/widget/TextView;->getSelectionStart()I

    move-result v0

    .line 2029
    invoke-virtual {p0}, Landroid/widget/TextView;->getSelectionEnd()I

    move-result p0

    move v2, v0

    move-object v0, p2

    move p2, v2

    goto :goto_0

    :cond_1
    move-object v0, p1

    move p0, p2

    :goto_0
    if-eq p2, p0, :cond_2

    .line 2035
    invoke-static {p2, p0}, Ljava/lang/Math;->min(II)I

    move-result v1

    .line 2036
    invoke-static {p2, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    .line 2038
    check-cast v0, Landroid/text/Spanned;

    const-class p2, Landroid/text/style/URLSpan;

    invoke-interface {v0, v1, p0, p2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Landroid/text/style/URLSpan;

    .line 2041
    array-length p2, p0

    const/4 v0, 0x1

    if-ne p2, v0, :cond_2

    const/4 p1, 0x0

    .line 2042
    aget-object p0, p0, p1

    invoke-virtual {p0}, Landroid/text/style/URLSpan;->getURL()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    return-object p0

    :cond_2
    return-object p1
.end method

.method public static getSendContactColor()I
    .locals 1

    .line 9797
    sget v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendContactColor:I

    return v0
.end method

.method private getSizeWithOverHead(I)I
    .locals 0

    add-int/lit16 p1, p1, 0x400

    add-int/lit8 p1, p1, -0x1

    .line 7767
    div-int/lit16 p1, p1, 0x400

    add-int/lit8 p1, p1, 0x1

    return p1
.end method

.method private getSlideNumber()I
    .locals 0

    .line 4801
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p0

    if-eqz p0, :cond_0

    .line 4803
    invoke-virtual {p0}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method private getUniqueDestination(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 4

    .line 2591
    new-instance p0, Ljava/io/File;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x2

    .line 2593
    :goto_0
    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 2594
    new-instance p0, Ljava/io/File;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "_"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-object p0
.end method

.method private getVTCapability(Ljava/lang/String;)Z
    .locals 3

    .line 10013
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "getVTCapability   number "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mms"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 10014
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mService:Lorg/codeaurora/presenceserv/IPresenceService;

    if-eqz p0, :cond_0

    .line 10017
    :try_start_0
    invoke-interface {p0, p1}, Lorg/codeaurora/presenceserv/IPresenceService;->hasVTCapability(Ljava/lang/String;)Z

    move-result p0

    .line 10018
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "getVTCapability success number "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    move-exception p0

    .line 10022
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "getVTCapability ERROR "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private getValidNumCount()I
    .locals 1

    .line 4257
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v0}, Lcom/android/mms/ui/RecipientsEditor;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 4258
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result p0

    invoke-virtual {v0, p0}, Lcom/android/mms/ui/RecipientsEditor;->getValidRecipientsCount(Z)I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, -0x2

    :goto_0
    return p0
.end method

.method private gfProcessAddRecipients(Landroid/content/Intent;)V
    .locals 8

    const/4 v0, 0x1

    .line 5345
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsProcessPickedRecipients:Z

    .line 5346
    new-instance v4, Landroid/os/Handler;

    invoke-direct {v4}, Landroid/os/Handler;-><init>()V

    .line 5347
    new-instance v6, Landroid/app/ProgressDialog;

    invoke-direct {v6, p0}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V

    const v1, 0x7f0e01bd    # @string/pick_too_many_recipients 'Too many recipients'

    .line 5348
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/app/ProgressDialog;->setTitle(Ljava/lang/CharSequence;)V

    const v1, 0x7f0e0036    # @string/adding_recipients 'Adding recipients...'

    .line 5349
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V

    .line 5350
    invoke-virtual {v6, v0}, Landroid/app/ProgressDialog;->setIndeterminate(Z)V

    const/4 v0, 0x0

    .line 5351
    invoke-virtual {v6, v0}, Landroid/app/ProgressDialog;->setCancelable(Z)V

    .line 5353
    new-instance v5, Lcom/android/mms/ui/ComposeMessageActivity$48;

    invoke-direct {v5, p0, v6}, Lcom/android/mms/ui/ComposeMessageActivity$48;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/app/ProgressDialog;)V

    const-wide/16 v0, 0x3e8

    .line 5361
    invoke-virtual {v4, v5, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 5363
    new-instance v0, Ljava/lang/Thread;

    new-instance v7, Lcom/android/mms/ui/ComposeMessageActivity$49;

    move-object v1, v7

    move-object v2, p0

    move-object v3, p1

    invoke-direct/range {v1 .. v6}, Lcom/android/mms/ui/ComposeMessageActivity$49;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/content/Intent;Landroid/os/Handler;Ljava/lang/Runnable;Landroid/app/ProgressDialog;)V

    const-string p0, "ComoseMessageActivity.processPickResult"

    invoke-direct {v0, v7, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 5424
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private goToConversationList()V
    .locals 2

    .line 4271
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->finish()V

    .line 4273
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v1, "start_compose_from"

    .line 4275
    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const-string v0, ""

    .line 4277
    :goto_0
    const-class v1, Lcom/android/mms/ui/SearchConversationActivity;

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 4278
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    goto :goto_1

    .line 4279
    :cond_1
    const-class v1, Lcom/android/mms/ui/NotificationConversationList;

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 4280
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/NotificationConversationList;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    goto :goto_1

    .line 4282
    :cond_2
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/ConversationList;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    :goto_1
    return-void
.end method

.method private handleAddAttachmentError(II)V
    .locals 2

    if-nez p1, :cond_0

    return-void

    .line 5622
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "handleAddAttachmentError: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mms"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 5624
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$54;

    invoke-direct {v0, p0, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity$54;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;II)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private handleForwardedMessage()Z
    .locals 11

    .line 5926
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    .line 5930
    iget-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mForwardMessageMode:Z

    const/4 v2, 0x0

    if-nez v1, :cond_1

    .line 5931
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    if-eqz p0, :cond_0

    .line 5932
    invoke-virtual {p0, v2}, Lcom/android/mms/data/Conversation;->setHasMmsForward(Z)V

    :cond_0
    return v2

    :cond_1
    const/4 v1, 0x1

    .line 5936
    sput-boolean v1, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    .line 5938
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    if-eqz v3, :cond_2

    .line 5939
    invoke-virtual {v3, v1}, Lcom/android/mms/data/Conversation;->setHasMmsForward(Z)V

    const-string v3, "msg_recipient"

    .line 5940
    invoke-virtual {v0, v3}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 5941
    iget-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v4, v3}, Lcom/android/mms/data/Conversation;->setForwardRecipientNumber([Ljava/lang/String;)V

    :cond_2
    const-string v3, "msg_uri"

    .line 5943
    invoke-virtual {v0, v3}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v3

    check-cast v3, Landroid/net/Uri;

    const/4 v4, 0x3

    const-string v5, "Mms"

    .line 5945
    invoke-static {v5, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v4

    if-eqz v4, :cond_3

    .line 5946
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, ""

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    :cond_3
    if-eqz v3, :cond_4

    .line 5950
    invoke-static {p0, v3}, Lcom/android/mms/data/WorkingMessage;->load(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;)Lcom/android/mms/data/WorkingMessage;

    move-result-object v3

    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    const-string v4, "subject"

    .line 5951
    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0, v2}, Lcom/android/mms/data/WorkingMessage;->setSubject(Ljava/lang/CharSequence;Z)V

    goto :goto_0

    .line 5953
    :cond_4
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    const-string v4, "sms_body"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lcom/android/mms/data/WorkingMessage;->setText(Ljava/lang/CharSequence;)V

    .line 5957
    :goto_0
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v0

    if-eqz v0, :cond_a

    .line 5958
    invoke-virtual {v0}, Lcom/android/mms/ui/MessageItem;->isMms()Z

    move-result v3

    if-eqz v3, :cond_a

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageItem;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v3

    if-eqz v3, :cond_a

    move v9, v2

    .line 5961
    :goto_1
    invoke-virtual {v0}, Lcom/android/mms/ui/MessageItem;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v3

    if-ge v2, v3, :cond_b

    .line 5962
    invoke-virtual {v0}, Lcom/android/mms/ui/MessageItem;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v10

    .line 5963
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->hasAudio()Z

    move-result v3

    if-eqz v3, :cond_5

    .line 5965
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->getAudio()Lcom/android/mms/model/AudioModel;

    move-result-object v3

    .line 5966
    invoke-virtual {v3}, Lcom/android/mms/model/AudioModel;->getMediaSize()I

    move-result v8

    .line 5967
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->getAudio()Lcom/android/mms/model/AudioModel;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/mms/model/AudioModel;->getUri()Landroid/net/Uri;

    move-result-object v5

    const/4 v6, 0x1

    const-string v4, "audio"

    move-object v3, p0

    move v7, v9

    invoke-direct/range {v3 .. v8}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    add-int/lit8 v9, v9, 0x1

    .line 5970
    :cond_5
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->hasImage()Z

    move-result v3

    if-eqz v3, :cond_6

    .line 5971
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->getImage()Lcom/android/mms/model/ImageModel;

    move-result-object v3

    .line 5972
    invoke-virtual {v3}, Lcom/android/mms/model/ImageModel;->getMediaSize()I

    move-result v8

    .line 5973
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->getImage()Lcom/android/mms/model/ImageModel;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/mms/model/ImageModel;->getUri()Landroid/net/Uri;

    move-result-object v5

    const/4 v6, 0x1

    const-string v4, "image"

    move-object v3, p0

    move v7, v9

    invoke-direct/range {v3 .. v8}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    add-int/lit8 v9, v9, 0x1

    .line 5976
    :cond_6
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->hasVideo()Z

    move-result v3

    if-eqz v3, :cond_7

    .line 5977
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->getVideo()Lcom/android/mms/model/VideoModel;

    move-result-object v3

    .line 5978
    invoke-virtual {v3}, Lcom/android/mms/model/VideoModel;->getMediaSize()I

    move-result v8

    .line 5979
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->getVideo()Lcom/android/mms/model/VideoModel;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/mms/model/VideoModel;->getUri()Landroid/net/Uri;

    move-result-object v5

    const/4 v6, 0x1

    const-string v4, "video"

    move-object v3, p0

    move v7, v9

    invoke-direct/range {v3 .. v8}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    add-int/lit8 v9, v9, 0x1

    .line 5982
    :cond_7
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->hasVcard()Z

    move-result v3

    if-eqz v3, :cond_8

    .line 5983
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->getVcard()Lcom/android/mms/model/VcardModel;

    move-result-object v3

    .line 5984
    invoke-virtual {v3}, Lcom/android/mms/model/VcardModel;->getMediaSize()I

    move-result v8

    .line 5985
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->getVcard()Lcom/android/mms/model/VcardModel;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/mms/model/VcardModel;->getUri()Landroid/net/Uri;

    move-result-object v5

    const/4 v6, 0x1

    const-string v4, "vcard"

    move-object v3, p0

    move v7, v9

    invoke-direct/range {v3 .. v8}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    add-int/lit8 v9, v9, 0x1

    .line 5991
    :cond_8
    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->hasText()Z

    move-result v3

    if-eqz v3, :cond_9

    .line 5992
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v10}, Lcom/android/mms/model/SlideModel;->getText()Lcom/android/mms/model/TextModel;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/mms/model/TextModel;->getText()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/mms/data/WorkingMessage;->setText(Ljava/lang/CharSequence;)V

    :cond_9
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_1

    .line 5998
    :cond_a
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MoreAttachmentView;->removeAllViews()V

    .line 5999
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentViewer:Landroid/widget/RelativeLayout;

    const/16 v2, 0x8

    invoke-virtual {v0, v2}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 6000
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v0, v2}, Lcom/android/mms/ui/MoreAttachmentView;->setVisibility(I)V

    .line 6005
    :cond_b
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessageListAdapter;->changeCursor(Landroid/database/Cursor;)V

    return v1
.end method

.method private handleMessageSizeExceededWarning(Ljava/lang/Runnable;)V
    .locals 3

    if-eqz p1, :cond_0

    .line 9700
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v1, 0x7f0e00e3    # @string/exceed_message_size_limitation 'Message size limit reached.'

    .line 9701
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const v1, 0x7f0e003e    # @string/attach_anyway 'Attach anyway?'

    .line 9702
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    const v1, 0x7f070102    # @drawable/ic_sms_mms_not_delivered 'res/drawable-hdpi/ic_sms_mms_not_delivered.png'

    .line 9703
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setIcon(I)Landroid/app/AlertDialog$Builder;

    const v1, 0x7f0e0301    # @string/yes 'OK'

    .line 9704
    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$95;

    invoke-direct {v2, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$95;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/Runnable;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    const p0, 0x7f0e0196    # @string/no 'Cancel'

    const/4 p1, 0x0

    .line 9714
    invoke-virtual {v0, p0, p1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 9715
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog;->show()V

    :cond_0
    return-void
.end method

.method private handleResendMessage()V
    .locals 7

    .line 3143
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "needResend"

    const/4 v2, 0x0

    .line 3144
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_0

    return-void

    :cond_0
    const-string v1, "message_id"

    const-wide/16 v3, 0x0

    .line 3148
    invoke-virtual {v0, v1, v3, v4}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v5

    const-string v1, "message_type"

    .line 3149
    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    cmp-long v3, v5, v3

    if-eqz v3, :cond_3

    .line 3150
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_3

    const-string v3, "sms"

    .line 3151
    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v1, "message_body"

    .line 3152
    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3153
    invoke-direct {p0, v5, v6, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->editSmsMessageItem(JLjava/lang/String;)V

    .line 3154
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->drawBottomPanel()V

    .line 3155
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->invalidateOptionsMenu()V

    goto :goto_1

    .line 3157
    :cond_1
    sget-object v1, Landroid/provider/Telephony$Mms;->CONTENT_URI:Landroid/net/Uri;

    invoke-static {v1, v5, v6}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v1

    const-string v3, "message_subject"

    .line 3159
    invoke-virtual {v0, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3160
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2

    const-string v4, "message_subject_charset"

    .line 3161
    invoke-virtual {v0, v4, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    .line 3162
    new-instance v2, Lcom/google/android/mms/pdu/EncodedStringValue;

    .line 3163
    invoke-static {v3}, Lcom/google/android/mms/pdu/PduPersister;->getBytes(Ljava/lang/String;)[B

    move-result-object v3

    invoke-direct {v2, v0, v3}, Lcom/google/android/mms/pdu/EncodedStringValue;-><init>(I[B)V

    .line 3164
    invoke-virtual {v2}, Lcom/google/android/mms/pdu/EncodedStringValue;->getString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/android/mms/ui/MessageUtils;->cleanseMmsSubject(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_2
    const-string v0, ""

    .line 3166
    :goto_0
    invoke-direct {p0, v1, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->editMmsMessageItem(Landroid/net/Uri;Ljava/lang/String;)V

    .line 3167
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->drawBottomPanel()V

    .line 3168
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->invalidateOptionsMenu()V

    :cond_3
    :goto_1
    return-void
.end method

.method private handleSendIntent()Z
    .locals 12

    .line 6012
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    .line 6013
    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return v2

    .line 6017
    :cond_0
    invoke-virtual {v0}, Landroid/content/Intent;->getType()Ljava/lang/String;

    move-result-object v3

    .line 6018
    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "android.intent.action.SEND"

    .line 6019
    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v6, 0x2

    const v7, 0x7f0e00f7    # @string/gf_too_many_attachments 'There is a limit of %1$s attachments. You have selected more than limit, so attachments cannot be ad ...'

    const v8, 0x7f0e0035    # @string/adding_attachments_title 'Adding attachments'

    const/4 v9, 0x0

    const-string v10, "android.intent.extra.STREAM"

    const/4 v11, 0x1

    if-eqz v5, :cond_5

    .line 6020
    invoke-virtual {v1, v10}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_4

    const-string v4, "IsMultiple"

    .line 6022
    invoke-virtual {v0, v4, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1

    .line 6024
    invoke-virtual {v1, v10}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    .line 6025
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;

    move-result-object v1

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$69;

    invoke-direct {v2, p0, v0, v3}, Lcom/android/mms/ui/ComposeMessageActivity$69;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;Ljava/lang/String;)V

    invoke-virtual {v1, v2, v9, v8}, Lcom/android/mms/ui/AsyncDialog;->runAsync(Ljava/lang/Runnable;Ljava/lang/Runnable;I)V

    goto :goto_1

    .line 6035
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    const-string v4, "MultipleStream"

    .line 6036
    invoke-virtual {v1, v4}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v0, :cond_2

    .line 6037
    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v0

    goto :goto_0

    :cond_2
    move v0, v2

    .line 6038
    :goto_0
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v4

    add-int v5, v4, v0

    .line 6039
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxSlideNumber()I

    move-result v10

    if-le v5, v10, :cond_3

    .line 6040
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxSlideNumber()I

    move-result v1

    sub-int/2addr v1, v0

    invoke-static {v1, v4}, Ljava/lang/Math;->min(II)I

    move-result v0

    new-array v1, v6, [Ljava/lang/Object;

    .line 6045
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxSlideNumber()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v1, v2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v1, v11

    .line 6044
    invoke-virtual {p0, v7, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 6042
    invoke-static {p0, v0, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 6046
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return v11

    .line 6055
    :cond_3
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;

    move-result-object v0

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$70;

    invoke-direct {v2, p0, v3, v4, v1}, Lcom/android/mms/ui/ComposeMessageActivity$70;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;ILjava/util/ArrayList;)V

    invoke-virtual {v0, v2, v9, v8}, Lcom/android/mms/ui/AsyncDialog;->runAsync(Ljava/lang/Runnable;Ljava/lang/Runnable;I)V

    :goto_1
    return v11

    :cond_4
    const-string v0, "android.intent.extra.TEXT"

    .line 6080
    invoke-virtual {v1, v0}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_8

    .line 6081
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v1, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/mms/data/WorkingMessage;->setText(Ljava/lang/CharSequence;)V

    return v11

    :cond_5
    const-string v0, "android.intent.action.SEND_MULTIPLE"

    .line 6084
    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 6085
    invoke-virtual {v1, v10}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 6086
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    .line 6087
    invoke-virtual {v1, v10}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v0, :cond_6

    .line 6088
    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v0

    goto :goto_2

    :cond_6
    move v0, v2

    .line 6089
    :goto_2
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v4

    add-int v5, v4, v0

    .line 6090
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxSlideNumber()I

    move-result v10

    if-le v5, v10, :cond_7

    .line 6091
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxSlideNumber()I

    move-result v1

    sub-int/2addr v1, v0

    invoke-static {v1, v4}, Ljava/lang/Math;->min(II)I

    move-result v0

    new-array v1, v6, [Ljava/lang/Object;

    .line 6096
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxSlideNumber()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v1, v2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v1, v11

    .line 6095
    invoke-virtual {p0, v7, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 6093
    invoke-static {p0, v0, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 6097
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return v11

    .line 6106
    :cond_7
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;

    move-result-object v0

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$71;

    invoke-direct {v2, p0, v3, v4, v1}, Lcom/android/mms/ui/ComposeMessageActivity$71;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;ILjava/util/ArrayList;)V

    invoke-virtual {v0, v2, v9, v8}, Lcom/android/mms/ui/AsyncDialog;->runAsync(Ljava/lang/Runnable;Ljava/lang/Runnable;I)V

    return v11

    :cond_8
    return v2
.end method

.method private handleUnsupportedTypeWarning(Ljava/lang/Runnable;)V
    .locals 3

    if-eqz p1, :cond_0

    .line 9679
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v1, 0x7f0e0251    # @string/restricted_format 'Restricted format'

    .line 9680
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const v1, 0x7f0e003e    # @string/attach_anyway 'Attach anyway?'

    .line 9681
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    const v1, 0x7f070102    # @drawable/ic_sms_mms_not_delivered 'res/drawable-hdpi/ic_sms_mms_not_delivered.png'

    .line 9682
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setIcon(I)Landroid/app/AlertDialog$Builder;

    const v1, 0x7f0e0301    # @string/yes 'OK'

    .line 9683
    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$94;

    invoke-direct {v2, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$94;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/Runnable;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    const p0, 0x7f0e0196    # @string/no 'Cancel'

    const/4 p1, 0x0

    .line 9693
    invoke-virtual {v0, p0, p1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 9694
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog;->show()V

    :cond_0
    return-void
.end method

.method private hasShortCode()Z
    .locals 9

    .line 1612
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    .line 1613
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/RecipientsEditor;->constructContactsFromInput(Z)Lcom/android/mms/data/ContactList;

    move-result-object p0

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p0

    .line 1614
    :goto_0
    invoke-virtual {p0}, Lcom/android/mms/data/ContactList;->getNumbers()[Ljava/lang/String;

    move-result-object p0

    array-length v0, p0

    move v2, v1

    :goto_1
    const/4 v3, 0x1

    if-ge v2, v0, :cond_6

    aget-object v4, p0, v2

    .line 1615
    invoke-static {v4}, Lcom/android/mms/ui/MessageUtils;->parseMmsAddress(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 1616
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "get group message address: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v6, "Mms"

    invoke-static {v6, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1617
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v6, 0xa

    if-ge v5, v6, :cond_2

    :cond_1
    :goto_2
    move v1, v3

    goto :goto_3

    .line 1620
    :cond_2
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v7, 0x30

    const/16 v8, 0x31

    if-ne v5, v6, :cond_3

    .line 1621
    invoke-virtual {v4, v1}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-eq v5, v7, :cond_1

    invoke-virtual {v4, v1}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-ne v5, v8, :cond_3

    goto :goto_2

    .line 1624
    :cond_3
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v6, 0xc

    if-ne v5, v6, :cond_4

    .line 1625
    invoke-virtual {v4, v1}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x2b

    if-ne v5, v6, :cond_4

    .line 1626
    invoke-virtual {v4, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-ne v5, v8, :cond_4

    const/4 v5, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/String;->charAt(I)C

    move-result v6

    if-eq v6, v8, :cond_1

    .line 1627
    invoke-virtual {v4, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-ne v5, v7, :cond_4

    goto :goto_2

    .line 1630
    :cond_4
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v6, 0xb

    if-ne v5, v6, :cond_5

    invoke-virtual {v4, v1}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-ne v5, v8, :cond_5

    .line 1631
    invoke-virtual {v4, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-eq v5, v8, :cond_1

    invoke-virtual {v4, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-ne v4, v7, :cond_5

    goto :goto_2

    :cond_5
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_1

    :cond_6
    :goto_3
    return v1
.end method

.method private haveSomethingToCopyToSDCard(J)Z
    .locals 5

    const-string v0, "Mms"

    .line 2221
    :try_start_0
    sget-object v1, Landroid/provider/Telephony$Mms;->CONTENT_URI:Landroid/net/Uri;

    .line 2222
    invoke-static {v1, p1, p2}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v1

    .line 2221
    invoke-static {p0, v1}, Lcom/android/mms/model/SlideshowModel;->getPduBody(Landroid/content/Context;Landroid/net/Uri;)Lcom/google/android/mms/pdu/PduBody;

    move-result-object p0

    :try_end_0
    .catch Lcom/google/android/mms/MmsException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 2224
    :catch_0
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "haveSomethingToCopyToSDCard can\'t load pdu body: "

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    :goto_0
    const/4 p1, 0x0

    if-nez p0, :cond_0

    return p1

    .line 2231
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/mms/pdu/PduBody;->getPartsNum()I

    move-result p2

    move v1, p1

    :goto_1
    if-ge v1, p2, :cond_4

    .line 2233
    invoke-virtual {p0, v1}, Lcom/google/android/mms/pdu/PduBody;->getPart(I)Lcom/google/android/mms/pdu/PduPart;

    move-result-object v2

    .line 2234
    new-instance v3, Ljava/lang/String;

    invoke-virtual {v2}, Lcom/google/android/mms/pdu/PduPart;->getContentType()[B

    move-result-object v2

    invoke-direct {v3, v2}, Ljava/lang/String;-><init>([B)V

    const/4 v2, 0x2

    .line 2236
    invoke-static {v0, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 2237
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "[CMA] haveSomethingToCopyToSDCard: part["

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "] contentType="

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 2240
    :cond_1
    invoke-static {v3}, Lcom/google/android/mms/ContentType;->isImageType(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_3

    invoke-static {v3}, Lcom/google/android/mms/ContentType;->isVideoType(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_3

    .line 2241
    invoke-static {v3}, Lcom/google/android/mms/ContentType;->isAudioType(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_3

    invoke-static {v3}, Lcom/android/mms/drm/DrmUtils;->isDrmType(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_2

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    const/4 p1, 0x1

    :cond_4
    return p1
.end method

.method private hideBottomPanel()V
    .locals 1

    .line 6354
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method private hideKeyboard()V
    .locals 2

    const-string v0, "input_method"

    .line 7991
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 7992
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {p0}, Landroid/widget/EditText;->getWindowToken()Landroid/os/IBinder;

    move-result-object p0

    const/4 v1, 0x0

    invoke-virtual {v0, p0, v1}, Landroid/view/inputmethod/InputMethodManager;->hideSoftInputFromWindow(Landroid/os/IBinder;I)Z

    return-void
.end method

.method private hideOrShowTopPanel()V
    .locals 1

    .line 3051
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    .line 3052
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTopPanel:Landroid/view/View;

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    const/16 v0, 0x8

    :goto_0
    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method private hideRecipientEditor()V
    .locals 2

    .line 4287
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz v0, :cond_0

    .line 4288
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->unRegRecipientsWatcher()V

    .line 4289
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setVisibility(I)V

    const/4 v0, 0x1

    .line 4290
    sput-boolean v0, Lcom/android/mms/ui/ComposeMessageActivity;->mHaveRecipients:Z

    .line 4296
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->hideOrShowTopPanel()V

    :cond_0
    return-void
.end method

.method private initActivityState(Landroid/os/Bundle;)V
    .locals 10

    .line 8090
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v1, 0x0

    .line 8091
    sput-boolean v1, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    .line 8093
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    const-string v3, "android.intent.action.SENDTO"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 8094
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContent:Landroid/widget/RelativeLayout;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 8095
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v2, 0x4

    const-string v3, "forwarded_message"

    const-string v4, "exit_on_sent"

    const/4 v5, 0x1

    if-eqz p1, :cond_2

    .line 8099
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v6, "android.intent.action.VIEW"

    invoke-virtual {v0, v6}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->setIntent(Landroid/content/Intent;)V

    const-string v0, "recipients"

    .line 8100
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 8101
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "get mConversation by recipients "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 8103
    invoke-static {v0, v1, v5}, Lcom/android/mms/data/ContactList;->getByNumbers(Ljava/lang/String;ZZ)Lcom/android/mms/data/ContactList;

    move-result-object v0

    .line 8102
    invoke-static {p0, v0, v1}, Lcom/android/mms/data/Conversation;->get(Landroid/content/Context;Lcom/android/mms/data/ContactList;Z)Lcom/android/mms/data/Conversation;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    .line 8105
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->addRecipientsListeners()V

    .line 8106
    invoke-virtual {p1, v4, v1}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    .line 8107
    invoke-virtual {p1, v3, v1}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mForwardMessageMode:Z

    .line 8109
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    if-eqz v0, :cond_1

    .line 8110
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v0, v2}, Lcom/android/mms/ui/MessageListView;->setVisibility(I)V

    .line 8112
    :cond_1
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0, p1}, Lcom/android/mms/data/WorkingMessage;->readStateFromBundle(Landroid/os/Bundle;)V

    return-void

    :cond_2
    const-string p1, "thread_id"

    const-wide/16 v6, 0x0

    .line 8118
    invoke-virtual {v0, p1, v6, v7}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v8

    cmp-long p1, v8, v6

    if-lez p1, :cond_3

    .line 8120
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "get mConversation by threadId "

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 8121
    invoke-static {p0, v8, v9, v1}, Lcom/android/mms/data/Conversation;->get(Landroid/content/Context;JZ)Lcom/android/mms/data/Conversation;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    goto :goto_0

    .line 8123
    :cond_3
    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    if-eqz p1, :cond_4

    .line 8126
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "get mConversation by intentData "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 8127
    invoke-static {p0, p1, v1}, Lcom/android/mms/data/Conversation;->get(Landroid/content/Context;Landroid/net/Uri;Z)Lcom/android/mms/data/Conversation;

    move-result-object v5

    iput-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    .line 8128
    iget-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getBody(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v5, p1}, Lcom/android/mms/data/WorkingMessage;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_4
    const-string p1, "address"

    .line 8131
    invoke-virtual {v0, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 8132
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_5

    .line 8133
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "get mConversation by address "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 8134
    invoke-static {p1, v1, v5}, Lcom/android/mms/data/ContactList;->getByNumbers(Ljava/lang/String;ZZ)Lcom/android/mms/data/ContactList;

    move-result-object p1

    invoke-static {p0, p1, v1}, Lcom/android/mms/data/Conversation;->get(Landroid/content/Context;Lcom/android/mms/data/ContactList;Z)Lcom/android/mms/data/Conversation;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    goto :goto_0

    :cond_5
    const-string p1, "create new conversation"

    .line 8137
    invoke-static {p1}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 8138
    sput-boolean v5, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    .line 8139
    invoke-static {p0}, Lcom/android/mms/data/Conversation;->createNew(Landroid/content/Context;)Lcom/android/mms/data/Conversation;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    .line 8143
    :goto_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->addRecipientsListeners()V

    .line 8144
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateThreadIdIfRunning()V

    .line 8146
    invoke-virtual {v0, v4, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    .line 8147
    invoke-virtual {v0, v3, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mForwardMessageMode:Z

    const-string p1, "reply_message"

    .line 8148
    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mReplyMessageMode:Z

    .line 8149
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    if-eqz p1, :cond_6

    .line 8150
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {p1, v2}, Lcom/android/mms/ui/MessageListView;->setVisibility(I)V

    :cond_6
    const-string p1, "sms_body"

    .line 8152
    invoke-virtual {v0, p1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_7

    .line 8153
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Lcom/android/mms/data/WorkingMessage;->setText(Ljava/lang/CharSequence;)V

    .line 8155
    :cond_7
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    const-string p1, "subject"

    invoke-virtual {v0, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v1}, Lcom/android/mms/data/WorkingMessage;->setSubject(Ljava/lang/CharSequence;Z)V

    return-void
.end method

.method private initFocus()V
    .locals 2

    .line 8159
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsKeyboardOpen:Z

    if-nez v0, :cond_0

    return-void

    .line 8166
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    .line 8167
    invoke-virtual {v0}, Landroid/widget/EditText;->isFocused()Z

    move-result v0

    if-nez v0, :cond_2

    .line 8168
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v0}, Lcom/android/mms/ui/RecipientsEditor;->requestFocus()Z

    .line 8170
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "input_method"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    if-eqz v0, :cond_1

    .line 8172
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    const/4 v1, 0x1

    invoke-virtual {v0, p0, v1}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    :cond_1
    return-void

    .line 8179
    :cond_2
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {p0}, Landroid/widget/EditText;->requestFocus()Z

    return-void
.end method

.method private initMenuBar()V
    .locals 1

    .line 7934
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    if-nez v0, :cond_0

    .line 7935
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v0

    sput-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    .line 7936
    invoke-virtual {v0, p0}, Landroid/widget/MenuBar;->setMenuBarListener(Landroid/widget/MenuBar$MenuBarListener;)V

    :cond_0
    return-void
.end method

.method private initMessageList()V
    .locals 7

    .line 7495
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    if-eqz v0, :cond_0

    const-string v0, "setOnDataSetChangedListener"

    .line 7496
    invoke-static {v0}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    .line 7497
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDataSetChangedListener:Lcom/android/mms/ui/MessageListAdapter$OnDataSetChangedListener;

    invoke-virtual {v0, p0}, Lcom/android/mms/ui/MessageListAdapter;->setOnDataSetChangedListener(Lcom/android/mms/ui/MessageListAdapter$OnDataSetChangedListener;)V

    return-void

    .line 7501
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "highlight"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const/4 v0, 0x0

    goto :goto_0

    .line 7502
    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\\b"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 7504
    invoke-static {v0}, Ljava/util/regex/Pattern;->quote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    invoke-static {v0, v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;I)Ljava/util/regex/Pattern;

    move-result-object v0

    :goto_0
    move-object v6, v0

    .line 7507
    new-instance v0, Lcom/android/mms/ui/MessageListAdapter;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    const/4 v5, 0x1

    move-object v1, v0

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/android/mms/ui/MessageListAdapter;-><init>(Landroid/content/Context;Landroid/database/Cursor;Landroid/widget/ListView;ZLjava/util/regex/Pattern;)V

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    .line 7508
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMsimIccCardActive()Z

    move-result v1

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListAdapter;->setIsMsimIccCardActived(Z)V

    .line 7509
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDataSetChangedListener:Lcom/android/mms/ui/MessageListAdapter$OnDataSetChangedListener;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListAdapter;->setOnDataSetChangedListener(Lcom/android/mms/ui/MessageListAdapter$OnDataSetChangedListener;)V

    .line 7510
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessageListItemHandler:Landroid/os/Handler;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListAdapter;->setMsgListItemHandler(Landroid/os/Handler;)V

    .line 7511
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMMSAudioPlayer:Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListAdapter;->setMMSAudioPlayer(Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;)V

    .line 7512
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 7514
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListView;->setItemsCanFocus(Z)V

    .line 7515
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    iget-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    if-nez v2, :cond_2

    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMailboxMode()Z

    move-result v2

    if-eqz v2, :cond_3

    :cond_2
    const/4 v1, 0x4

    :cond_3
    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListView;->setVisibility(I)V

    .line 7517
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$86;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$86;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    return-void
.end method

.method private initRecipientsEditor()V
    .locals 5

    .line 2769
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 2774
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    .line 2775
    invoke-virtual {v0}, Lcom/android/mms/data/ContactList;->size()I

    move-result v1

    const/4 v2, 0x0

    if-lez v1, :cond_1

    .line 2776
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "initRecipientsEditor() recipients = "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/android/mms/data/ContactList;->getNumbers()[Ljava/lang/String;

    move-result-object v3

    aget-object v3, v3, v2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "mmsTest"

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const v1, 0x7f08014b    # @id/recipients_editor_stub

    .line 2779
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/view/ViewStub;

    const v3, 0x7f08006d    # @id/clear

    const v4, 0x7f08014a    # @id/recipients_editor

    if-eqz v1, :cond_2

    .line 2781
    invoke-virtual {v1}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    move-result-object v1

    .line 2782
    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/android/mms/ui/RecipientsEditor;

    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    .line 2785
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mClearButton:Landroid/widget/ImageButton;

    goto :goto_0

    .line 2787
    :cond_2
    invoke-virtual {p0, v4}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lcom/android/mms/ui/RecipientsEditor;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    .line 2788
    invoke-virtual {v1, v2}, Lcom/android/mms/ui/RecipientsEditor;->setVisibility(I)V

    .line 2789
    sput-boolean v2, Lcom/android/mms/ui/ComposeMessageActivity;->mHaveRecipients:Z

    .line 2792
    invoke-virtual {p0, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mClearButton:Landroid/widget/ImageButton;

    .line 2794
    :goto_0
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mClearButton:Landroid/widget/ImageButton;

    const/16 v3, 0x8

    invoke-virtual {v1, v3}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 2795
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mClearButton:Landroid/widget/ImageButton;

    invoke-virtual {v1, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2797
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->regRecipientsWatcher()V

    .line 2798
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    new-instance v3, Lcom/android/mms/ui/ChipsRecipientAdapter;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ChipsRecipientAdapter;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1, v3}, Lcom/android/mms/ui/RecipientsEditor;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 2799
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v1, p0}, Lcom/android/mms/ui/RecipientsEditor;->setRecipientChipInvalidDialogListener(Lcom/android/ex/chips/RecipientEditTextView$RecipientChipInvalidDialogListener;)V

    .line 2801
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_3

    .line 2802
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    const/high16 v3, 0x41400000

    invoke-virtual {v1, v3}, Lcom/android/mms/ui/RecipientsEditor;->setTextSize(F)V

    .line 2805
    :cond_3
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    const v3, 0x7f0e0242    # @string/recipients_hint_text 'Add contact or number'

    invoke-virtual {v1, v3}, Lcom/android/mms/ui/RecipientsEditor;->setHint(I)V

    .line 2809
    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$18;

    invoke-direct {v1, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$18;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/data/ContactList;)V

    .line 2824
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHandler:Landroid/os/Handler;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 2834
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$19;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$19;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setOnSelectChipRunnable(Ljava/lang/Runnable;)V

    .line 2853
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$20;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$20;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 2868
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-static {p0, v0}, Lcom/android/mms/util/PhoneNumberFormatter;->setPhoneNumberFormattingTextWatcher(Landroid/content/Context;Landroid/widget/TextView;)V

    .line 2870
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz v0, :cond_5

    .line 2871
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_4

    .line 2873
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    sget-object v1, Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;->PORTRAIT:Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setOrientation(Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;)V

    goto :goto_1

    .line 2875
    :cond_4
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    sget-object v1, Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;->LANDSCAPE:Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setOrientation(Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;)V

    .line 2878
    :cond_5
    :goto_1
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTopPanel:Landroid/view/View;

    invoke-virtual {p0, v2}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method private initResourceRefs()V
    .locals 7

    .line 6858
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 6859
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const v2, 0x7f0a002a    # @layout/compose_message_activity_dish 'res/layout/compose_message_activity_dish.xml'

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    goto :goto_0

    .line 6861
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const v2, 0x7f0a0029    # @layout/compose_message_activity 'res/layout/compose_message_activity.xml'

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 6864
    :goto_0
    new-instance v2, Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;

    invoke-direct {v2, p0}, Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mZoomGestureOverlayView:Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;

    .line 6865
    invoke-virtual {v2, p0}, Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;->addZoomListener(Lcom/android/mms/ui/zoom/ZoomGestureOverlayView$IZoomListener;)V

    .line 6866
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mZoomGestureOverlayView:Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;

    invoke-virtual {v2, v0}, Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;->addView(Landroid/view/View;)V

    .line 6867
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mZoomGestureOverlayView:Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;->setEventsInterceptionEnabled(Z)V

    .line 6868
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mZoomGestureOverlayView:Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;

    const/4 v3, 0x0

    invoke-virtual {v0, v3}, Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;->setGestureVisible(Z)V

    .line 6869
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mZoomGestureOverlayView:Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->setContentView(Landroid/view/View;)V

    const v0, 0x7f080043    # @id/attachment_viewer_layout

    .line 6871
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RelativeLayout;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentViewer:Landroid/widget/RelativeLayout;

    const v0, 0x7f08010d    # @id/more_attachment_view

    .line 6872
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/android/mms/ui/MoreAttachmentView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    const v0, 0x7f08003f    # @id/attachment_size

    .line 6873
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSize:Landroid/widget/TextView;

    .line 6879
    sget v0, Lcom/android/mms/ui/ComposeMessageActivity;->sPrimaryColorDark:I

    if-nez v0, :cond_1

    .line 6880
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v4, 0x7f05007e    # @color/primary_color_dark '#0277bd'

    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    sput v0, Lcom/android/mms/ui/ComposeMessageActivity;->sPrimaryColorDark:I

    :cond_1
    const v0, 0x7f0801cf    # @id/title_text

    .line 6882
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTitleText:Landroid/widget/TextView;

    const v0, 0x7f0801af    # @id/subject_text_editor_divider

    .line 6884
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDeviderView:Landroid/view/View;

    const v0, 0x7f0800be    # @id/history

    .line 6885
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/android/mms/ui/MessageListView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    .line 6890
    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListView;->setDivider(Landroid/graphics/drawable/Drawable;)V

    .line 6891
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v0, v2}, Lcom/android/mms/ui/MessageListView;->setItemsCanFocus(Z)V

    .line 6896
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v0, v3}, Lcom/android/mms/ui/MessageListView;->setClipToPadding(Z)V

    .line 6897
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$77;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$77;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListView;->setOnSizeChangedListener(Lcom/android/mms/ui/MessageListView$OnSizeChangedListener;)V

    .line 6919
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$78;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$78;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListView;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 6942
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$79;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$79;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 6964
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    const/16 v1, 0x8

    if-eqz v0, :cond_2

    .line 6965
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->initTwoSendButton()V

    goto :goto_1

    :cond_2
    const v0, 0x7f080058    # @id/bottom_panel

    .line 6967
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    .line 6969
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_3

    const v0, 0x7f08011a    # @id/new_bottom_panel

    .line 6970
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    .line 6973
    :cond_3
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    const v0, 0x7f08009a    # @id/embedded_text_editor

    .line 6974
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    const v0, 0x7f0801c3    # @id/text_counter

    .line 6975
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    const v0, 0x7f080029    # @id/add_attachment

    .line 6976
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentButton:Landroid/widget/LinearLayout;

    const v0, 0x7f080189    # @id/send_button_mms

    .line 6977
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    const v0, 0x7f08018a    # @id/send_button_mms_text

    .line 6978
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMmsText:Landroid/widget/TextView;

    const v0, 0x7f08018b    # @id/send_button_sms

    .line 6979
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    .line 6980
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentButton:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 6981
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentButton:Landroid/widget/LinearLayout;

    invoke-virtual {v0, p0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 6982
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 6983
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 6986
    :goto_1
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_6

    const v0, 0x7f0800df    # @id/list

    .line 6987
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RelativeLayout;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContent:Landroid/widget/RelativeLayout;

    .line 6988
    sget-boolean v4, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    if-nez v4, :cond_5

    sget-boolean v4, Lcom/android/mms/ui/ComposeMessageActivity;->mHasDraft:Z

    if-eqz v4, :cond_4

    goto :goto_2

    .line 6992
    :cond_4
    invoke-virtual {v0, v3}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 6993
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    goto :goto_3

    .line 6989
    :cond_5
    :goto_2
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContent:Landroid/widget/RelativeLayout;

    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 6990
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 6998
    :cond_6
    :goto_3
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentButton:Landroid/widget/LinearLayout;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$80;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$80;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 7006
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0, p0}, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    .line 7007
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditorWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 7009
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$81;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$81;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 7078
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "pref_key_enable_selectable_copy"

    .line 7079
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsEnableSelectCopy:Z

    const/high16 v1, 0x41600000

    const-string v4, "pref_key_zoom_message"

    .line 7081
    invoke-interface {v0, v4, v1}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    .line 7084
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->getMaxTextLength()I

    move-result v0

    const v1, 0x7f09000a    # @integer/slide_text_limit_size '0'

    if-nez v0, :cond_7

    .line 7085
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    new-array v4, v2, [Landroid/text/InputFilter;

    new-instance v5, Landroid/text/InputFilter$LengthFilter;

    .line 7086
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxTextLimit()I

    move-result v6

    invoke-direct {v5, v6}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    aput-object v5, v4, v3

    .line 7085
    invoke-virtual {v0, v4}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    goto :goto_4

    .line 7087
    :cond_7
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v0

    if-eqz v0, :cond_8

    .line 7088
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    new-array v4, v2, [Landroid/text/InputFilter;

    new-instance v5, Landroid/text/InputFilter$LengthFilter;

    .line 7089
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v6

    invoke-direct {v5, v6}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    aput-object v5, v4, v3

    .line 7088
    invoke-virtual {v0, v4}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    .line 7091
    :cond_8
    :goto_4
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->getMaxTextLength()I

    move-result v0

    if-nez v0, :cond_9

    .line 7092
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    new-array v1, v2, [Landroid/text/InputFilter;

    new-instance v2, Landroid/text/InputFilter$LengthFilter;

    .line 7093
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxTextLimit()I

    move-result v4

    invoke-direct {v2, v4}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    aput-object v2, v1, v3

    .line 7092
    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    goto :goto_5

    .line 7094
    :cond_9
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v0

    if-eqz v0, :cond_a

    .line 7095
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    new-array v2, v2, [Landroid/text/InputFilter;

    new-instance v4, Landroid/text/InputFilter$LengthFilter;

    .line 7096
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v1

    invoke-direct {v4, v1}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    aput-object v4, v2, v3

    .line 7095
    invoke-virtual {v0, v2}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    :cond_a
    :goto_5
    const v0, 0x7f0800f7    # @id/message_text

    .line 7098
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessageText:Landroid/widget/LinearLayout;

    const v0, 0x7f0800f5    # @id/message_lable

    .line 7099
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextLable:Landroid/widget/TextView;

    .line 7100
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$82;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$82;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    const v0, 0x7f08014c    # @id/recipients_subject_linear

    .line 7142
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTopPanel:Landroid/view/View;

    .line 7143
    invoke-virtual {v0, v3}, Landroid/view/View;->setFocusable(Z)V

    const v0, 0x7f080035    # @id/attachment_editor

    .line 7144
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/android/mms/ui/AttachmentEditor;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditor:Lcom/android/mms/ui/AttachmentEditor;

    .line 7145
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditorHandler:Landroid/os/Handler;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/AttachmentEditor;->setHandler(Landroid/os/Handler;)V

    const v0, 0x7f080036    # @id/attachment_editor_scroll_view

    .line 7146
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditorScrollView:Landroid/view/View;

    const v0, 0x7f080045    # @id/attachments_selector

    .line 7147
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    const-string v0, "audio"

    .line 7151
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAudioManager:Landroid/media/AudioManager;

    .line 7152
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v0

    sput-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    .line 7153
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 7154
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    const v1, 0x7f07014f    # @drawable/option_menu_item_selector_dish 'res/drawable/option_menu_item_selector_dish.xml'

    invoke-virtual {v0, v1}, Landroid/widget/MenuBar;->setOptionMenuItemBackground(I)V

    goto :goto_6

    .line 7156
    :cond_b
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    const v1, 0x7f07014e    # @drawable/option_menu_item_selector 'res/drawable/option_menu_item_selector.xml'

    invoke-virtual {v0, v1}, Landroid/widget/MenuBar;->setOptionMenuItemBackground(I)V

    .line 7158
    :goto_6
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {v0, p0}, Landroid/widget/MenuBar;->setMenuBarListener(Landroid/widget/MenuBar$MenuBarListener;)V

    return-void
.end method

.method private initTwoSendButton()V
    .locals 3

    const v0, 0x7f080059    # @id/bottom_panel_btnstyle

    .line 7174
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    const/4 v1, 0x0

    .line 7175
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const v0, 0x7f08009b    # @id/embedded_text_editor_btnstyle

    .line 7176
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    const v0, 0x7f0800b0    # @id/first_text_counter

    .line 7177
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    const v0, 0x7f0800ab    # @id/first_send_button_mms_view

    .line 7179
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    const v0, 0x7f0800ad    # @id/first_send_button_sms_view

    .line 7180
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    const v0, 0x7f0800aa    # @id/first_send_button_mms

    .line 7181
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutMmsFir:Landroid/view/View;

    const v0, 0x7f0800ac    # @id/first_send_button_sms

    .line 7182
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutSmsFir:Landroid/view/View;

    const v0, 0x7f0800ae    # @id/first_sim_card_indicator_mms

    .line 7183
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIndicatorForSimMmsFir:Landroid/widget/ImageView;

    const v0, 0x7f0800af    # @id/first_sim_card_indicator_sms

    .line 7184
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIndicatorForSimSmsFir:Landroid/widget/ImageView;

    .line 7185
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIndicatorForSimMmsFir:Landroid/widget/ImageView;

    .line 7186
    invoke-static {p0, v1}, Lcom/android/mms/ui/MessageUtils;->getMultiSimIcon(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 7185
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 7187
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIndicatorForSimSmsFir:Landroid/widget/ImageView;

    .line 7188
    invoke-static {p0, v1}, Lcom/android/mms/ui/MessageUtils;->getMultiSimIcon(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    .line 7187
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 7189
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentButton:Landroid/widget/LinearLayout;

    invoke-virtual {v0, p0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 7190
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 7191
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f08017d    # @id/second_text_counter

    .line 7193
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounterSec:Landroid/widget/TextView;

    const v0, 0x7f080178    # @id/second_send_button_mms_view

    .line 7194
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMmsViewSec:Landroid/widget/TextView;

    const v0, 0x7f08017a    # @id/second_send_button_sms_view

    .line 7195
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSmsViewSec:Landroid/widget/ImageButton;

    const v0, 0x7f080177    # @id/second_send_button_mms

    .line 7196
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutMmsSec:Landroid/view/View;

    const v0, 0x7f080179    # @id/second_send_button_sms

    .line 7197
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutSmsSec:Landroid/view/View;

    const v0, 0x7f08017b    # @id/second_sim_card_indicator_mms

    .line 7198
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIndicatorForSimMmsSec:Landroid/widget/ImageView;

    const v0, 0x7f08017c    # @id/second_sim_card_indicator_sms

    .line 7199
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIndicatorForSimSmsSec:Landroid/widget/ImageView;

    .line 7200
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIndicatorForSimMmsSec:Landroid/widget/ImageView;

    const/4 v1, 0x1

    .line 7201
    invoke-static {p0, v1}, Lcom/android/mms/ui/MessageUtils;->getMultiSimIcon(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 7200
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 7202
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIndicatorForSimSmsSec:Landroid/widget/ImageView;

    .line 7203
    invoke-static {p0, v1}, Lcom/android/mms/ui/MessageUtils;->getMultiSimIcon(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    .line 7202
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 7204
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMmsViewSec:Landroid/widget/TextView;

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 7205
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSmsViewSec:Landroid/widget/ImageButton;

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method private inputNumbers(Landroid/os/Bundle;Ljava/util/Set;I)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Bundle;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;I)V"
        }
    .end annotation

    .line 5431
    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    const/4 v0, 0x0

    move v1, v0

    .line 5433
    :cond_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    add-int/lit8 v1, v1, 0x1

    .line 5435
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getStringArray(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v0

    .line 5436
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ","

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcom/android/mms/ui/RecipientsEditor;->append(Ljava/lang/CharSequence;)V

    if-ne v1, p3, :cond_0

    :cond_1
    return-void
.end method

.method private is911Recipient()Z
    .locals 3

    .line 1158
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getWorkingRecipients()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    .line 1159
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->getWorkingRecipients()Ljava/lang/String;

    move-result-object p0

    const-string v0, ";"

    .line 1160
    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    .line 1161
    array-length v0, p0

    if-ne v0, v1, :cond_0

    aget-object p0, p0, v2

    const-string v0, "911"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    return v1
.end method

.method private isAllowForwardMessage(Lcom/android/mms/ui/MessageItem;)Z
    .locals 6

    .line 2192
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageItem;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 2195
    :cond_0
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageItem;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->getTotalMessageSize()I

    move-result v0

    .line 2198
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageItem;->isSentMms()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 2200
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageItem;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/mms/model/SlideshowModel;->getSMILSize()I

    move-result v2

    goto :goto_0

    :cond_1
    move v2, v1

    :goto_0
    const v3, 0x7f0e00f1    # @string/forward_prefix 'Fwd: '

    .line 2203
    invoke-virtual {p0, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    array-length p0, p0

    .line 2204
    iget-object v3, p1, Lcom/android/mms/ui/MessageItem;->mSubject:Ljava/lang/String;

    if-nez v3, :cond_2

    move p1, v1

    goto :goto_1

    :cond_2
    iget-object p1, p1, Lcom/android/mms/ui/MessageItem;->mSubject:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    array-length p1, p1

    :goto_1
    add-int v3, v0, p0

    add-int/2addr v3, p1

    add-int/2addr v3, v2

    .line 2207
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "isAllowForwardMessage messageSize = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ", forwardStrSize = "

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ", subjectSize = "

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ", totalSize = "

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ", smilSize = "

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "Mms"

    invoke-static {p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2211
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxMessageSize()I

    move-result p0

    add-int/lit16 p0, p0, -0x400

    if-gt v3, p0, :cond_3

    const/4 v1, 0x1

    :cond_3
    return v1
.end method

.method private isAppendRequest(I)Z
    .locals 0

    const/high16 p0, 0x10000

    and-int/2addr p0, p1

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method private isAudioFile(Landroid/net/Uri;)Z
    .locals 0

    .line 6183
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p0

    .line 6184
    invoke-static {p0}, Lcom/android/mmswrapper/MediaFileWrapper;->getMimeTypeForFile(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 6185
    invoke-static {p0}, Lcom/android/mmswrapper/MediaFileWrapper;->getFileTypeForMimeType(Ljava/lang/String;)I

    move-result p0

    .line 6186
    invoke-static {p0}, Lcom/android/mmswrapper/MediaFileWrapper;->isAudioFileType(I)Z

    move-result p0

    return p0
.end method

.method private isCdmaNVMode()Z
    .locals 6

    const-string v0, "phone"

    .line 7698
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    .line 7700
    invoke-static {v0}, Lcom/android/mmswrapper/TelephonyManagerWrapper;->isMultiSimEnabled(Landroid/telephony/TelephonyManager;)Z

    move-result v1

    const/4 v2, 0x0

    const-string v3, "Mms"

    if-eqz v1, :cond_0

    const-string p0, "isCdmaNVMode: CDMA NV mode just for single SIM"

    .line 7701
    invoke-static {v3, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return v2

    .line 7704
    :cond_0
    invoke-static {v0}, Lcom/android/mmswrapper/TelephonyManagerWrapper;->getCurrentPhoneType(Landroid/telephony/TelephonyManager;)I

    move-result v0

    .line 7705
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string v1, "subscription_mode"

    const/4 v4, 0x1

    invoke-static {p0, v1, v4}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result p0

    .line 7707
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "isCdmaNVMode: activePhoneType="

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, " cdmaSubscriptionMode="

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_1

    if-ne p0, v4, :cond_1

    return v4

    :cond_1
    return v2
.end method

.method private isCursorValid()Z
    .locals 2

    .line 1030
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {p0}, Lcom/android/mms/ui/MessageListAdapter;->getCursor()Landroid/database/Cursor;

    move-result-object p0

    .line 1031
    invoke-interface {p0}, Landroid/database/Cursor;->isClosed()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-interface {p0}, Landroid/database/Cursor;->isBeforeFirst()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-interface {p0}, Landroid/database/Cursor;->isAfterLast()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x1

    return p0

    .line 1032
    :cond_1
    :goto_0
    new-instance p0, Ljava/lang/RuntimeException;

    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    const-string v0, "Mms"

    const-string v1, "Bad cursor."

    invoke-static {v0, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 p0, 0x0

    return p0
.end method

.method private isDrmRingtoneWithRights(J)Z
    .locals 4

    .line 2288
    :try_start_0
    sget-object v0, Landroid/provider/Telephony$Mms;->CONTENT_URI:Landroid/net/Uri;

    .line 2289
    invoke-static {v0, p1, p2}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v0

    .line 2288
    invoke-static {p0, v0}, Lcom/android/mms/model/SlideshowModel;->getPduBody(Landroid/content/Context;Landroid/net/Uri;)Lcom/google/android/mms/pdu/PduBody;

    move-result-object p0

    :try_end_0
    .catch Lcom/google/android/mms/MmsException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 2291
    :catch_0
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "isDrmRingtoneWithRights can\'t load pdu body: "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "Mms"

    invoke-static {p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    :goto_0
    const/4 p1, 0x0

    if-nez p0, :cond_0

    return p1

    .line 2297
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/mms/pdu/PduBody;->getPartsNum()I

    move-result p2

    move v0, p1

    :goto_1
    if-ge v0, p2, :cond_2

    .line 2299
    invoke-virtual {p0, v0}, Lcom/google/android/mms/pdu/PduBody;->getPart(I)Lcom/google/android/mms/pdu/PduPart;

    move-result-object v1

    .line 2300
    new-instance v2, Ljava/lang/String;

    invoke-virtual {v1}, Lcom/google/android/mms/pdu/PduPart;->getContentType()[B

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/String;-><init>([B)V

    .line 2302
    invoke-static {v2}, Lcom/android/mms/drm/DrmUtils;->isDrmType(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 2303
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/mms/MmsApp;->getDrmManagerClient()Landroid/drm/DrmManagerClient;

    move-result-object v2

    .line 2304
    invoke-virtual {v1}, Lcom/google/android/mms/pdu/PduPart;->getDataUri()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/drm/DrmManagerClient;->getOriginalMimeType(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v2

    .line 2305
    invoke-static {v2}, Lcom/google/android/mms/ContentType;->isAudioType(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {v1}, Lcom/google/android/mms/pdu/PduPart;->getDataUri()Landroid/net/Uri;

    move-result-object v1

    const/4 v2, 0x2

    invoke-static {v1, v2}, Lcom/android/mms/drm/DrmUtils;->haveRightsForAction(Landroid/net/Uri;I)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    return p1
.end method

.method private isForwardable(J)Z
    .locals 4

    .line 2322
    :try_start_0
    sget-object v0, Landroid/provider/Telephony$Mms;->CONTENT_URI:Landroid/net/Uri;

    .line 2323
    invoke-static {v0, p1, p2}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v0

    .line 2322
    invoke-static {p0, v0}, Lcom/android/mms/model/SlideshowModel;->getPduBody(Landroid/content/Context;Landroid/net/Uri;)Lcom/google/android/mms/pdu/PduBody;

    move-result-object p0

    :try_end_0
    .catch Lcom/google/android/mms/MmsException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 2325
    :catch_0
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "getDrmMimeType can\'t load pdu body: "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "Mms"

    invoke-static {p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    :goto_0
    const/4 p1, 0x0

    if-nez p0, :cond_0

    return p1

    .line 2331
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/mms/pdu/PduBody;->getPartsNum()I

    move-result p2

    move v0, p1

    :goto_1
    if-ge v0, p2, :cond_2

    .line 2333
    invoke-virtual {p0, v0}, Lcom/google/android/mms/pdu/PduBody;->getPart(I)Lcom/google/android/mms/pdu/PduPart;

    move-result-object v1

    .line 2334
    new-instance v2, Ljava/lang/String;

    invoke-virtual {v1}, Lcom/google/android/mms/pdu/PduPart;->getContentType()[B

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/String;-><init>([B)V

    .line 2336
    invoke-static {v2}, Lcom/android/mms/drm/DrmUtils;->isDrmType(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {v1}, Lcom/google/android/mms/pdu/PduPart;->getDataUri()Landroid/net/Uri;

    move-result-object v1

    const/4 v2, 0x3

    invoke-static {v1, v2}, Lcom/android/mms/drm/DrmUtils;->haveRightsForAction(Landroid/net/Uri;I)Z

    move-result v1

    if-nez v1, :cond_1

    return p1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    const/4 p0, 0x1

    return p0
.end method

.method private isHasSomeTosend()Z
    .locals 1

    .line 10837
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasText()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasAttachment()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->hasSubject()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method private isImageFile(Landroid/net/Uri;)Z
    .locals 0

    .line 6190
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p0

    .line 6191
    invoke-static {p0}, Lcom/android/mmswrapper/MediaFileWrapper;->getMimeTypeForFile(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 6192
    invoke-static {p0}, Lcom/android/mmswrapper/MediaFileWrapper;->getFileTypeForMimeType(Ljava/lang/String;)I

    move-result p0

    .line 6193
    invoke-static {p0}, Lcom/android/mmswrapper/MediaFileWrapper;->isImageFileType(I)Z

    move-result p0

    return p0
.end method

.method private isLTEOnlyMode()Z
    .locals 3

    const/4 v0, 0x0

    .line 1446
    :try_start_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "network_band"

    invoke-static {v1, v2}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    move-result v1

    .line 1447
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string v2, "preferred_network_mode"

    invoke-static {p0, v2}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    move-result p0

    :try_end_0
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/16 v2, 0xb

    if-ne p0, v2, :cond_0

    const/4 p0, 0x2

    if-ne v1, p0, :cond_0

    const/4 v0, 0x1

    :cond_0
    return v0

    :catch_0
    const-string p0, "Mms"

    const-string v1, "isLTEOnlyMode: Could not find PREFERRED_NETWORK_MODE!"

    .line 1452
    invoke-static {p0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return v0
.end method

.method private isLTEOnlyMode(I)Z
    .locals 3

    const/4 v0, 0x0

    .line 1459
    :try_start_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "network_band"

    invoke-static {v1, v2, p1}, Lcom/android/mmswrapper/TelephonyManagerWrapper;->getIntAtIndex(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    .line 1461
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string v2, "preferred_network_mode"

    invoke-static {p0, v2, p1}, Lcom/android/mmswrapper/TelephonyManagerWrapper;->getIntAtIndex(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result p0

    :try_end_0
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/16 p1, 0xb

    if-ne p0, p1, :cond_0

    const/4 p0, 0x2

    if-ne v1, p0, :cond_0

    const/4 v0, 0x1

    :cond_0
    return v0

    :catch_0
    const-string p0, "Mms"

    const-string p1, "isLTEOnlyMode: Could not find PREFERRED_NETWORK_MODE!"

    .line 1466
    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return v0
.end method

.method private isMessageForwardable(I)Z
    .locals 1

    .line 9607
    sget-object p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    const/4 p1, 0x0

    if-nez p0, :cond_0

    return p1

    .line 9610
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object p0

    if-nez p0, :cond_1

    return p1

    .line 9615
    :cond_1
    invoke-virtual {p0}, Lcom/android/mms/ui/MessageItem;->isSms()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p0}, Lcom/android/mms/ui/MessageItem;->isDownloaded()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-boolean p0, p0, Lcom/android/mms/ui/MessageItem;->mIsForwardable:Z

    if-eqz p0, :cond_3

    :cond_2
    const/4 p1, 0x1

    :cond_3
    return p1
.end method

.method private isMmsWithMobileDataOff(ZI)Z
    .locals 3

    .line 1680
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "isMmsWithMobileDataOff subscription: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/Object;

    invoke-static {v0, v2}, Lcom/android/mms/LogTag;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    if-eqz p1, :cond_0

    .line 1681
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendMmsSupportViaWiFi:Z

    if-nez p1, :cond_0

    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->canSendMmsMobileDataOff(I)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 1682
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0, p2}, Lcom/android/mms/ui/MessageUtils;->isMobileDataEnabled(Landroid/content/Context;I)Z

    move-result p0

    if-nez p0, :cond_0

    const/4 v1, 0x1

    :cond_0
    return v1
.end method

.method private isPreparedForSending()Z
    .locals 5

    const-string v0, "phone"

    .line 7660
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    .line 7662
    invoke-static {}, Lcom/android/mms/util/ImsConnectionManager;->isImsRegistered()Z

    move-result v0

    .line 7663
    iget-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsAirplaneModeOn:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    if-nez v0, :cond_0

    const-string p0, "airplane mode on and ims not registered"

    .line 7664
    invoke-static {p0}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    return v2

    .line 7668
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->recipientCount()I

    move-result v1

    .line 7670
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f040029    # @bool/enable_send_blank_message 'false'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v3

    const/4 v4, 0x1

    if-eqz v3, :cond_3

    const-string v0, "Mms"

    const-string v3, "Blank SMS"

    .line 7671
    invoke-static {v0, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 7672
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->getActivatedIccCardCount()I

    move-result v0

    if-gtz v0, :cond_1

    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isCdmaNVMode()Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    if-lez v1, :cond_2

    .line 7673
    invoke-static {}, Lcom/android/mms/MmsConfig;->getRecipientLimit()I

    move-result v0

    if-gt v1, v0, :cond_2

    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    if-eqz p0, :cond_2

    move v2, v4

    :cond_2
    return v2

    .line 7676
    :cond_3
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->getActivatedIccCardCount()I

    move-result v3

    if-gtz v3, :cond_4

    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isCdmaNVMode()Z

    move-result v3

    if-nez v3, :cond_4

    if-eqz v0, :cond_6

    :cond_4
    if-lez v1, :cond_6

    .line 7678
    invoke-static {}, Lcom/android/mms/MmsConfig;->getRecipientLimit()I

    move-result v0

    if-gt v1, v0, :cond_6

    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    if-eqz v0, :cond_6

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 7680
    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasAttachment()Z

    move-result v0

    if-nez v0, :cond_5

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasText()Z

    move-result v0

    if-nez v0, :cond_5

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 7681
    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->hasSubject()Z

    move-result p0

    if-eqz p0, :cond_6

    :cond_5
    move v2, v4

    :cond_6
    return v2
.end method

.method private isRecipientCallable()Z
    .locals 3

    .line 4472
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p0

    .line 4473
    invoke-virtual {p0}, Lcom/android/mms/data/ContactList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    invoke-virtual {p0}, Lcom/android/mms/data/ContactList;->containsEmail()Z

    move-result v0

    if-nez v0, :cond_0

    .line 4474
    invoke-virtual {p0, v1}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/android/mms/data/Contact;

    invoke-virtual {p0}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->isWapPushNumber(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_0

    move v1, v2

    :cond_0
    return v1
.end method

.method private isRecipientEmpty()Z
    .locals 2

    .line 4264
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 4265
    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v1

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->getValidRecipientsCount(Z)I

    move-result v0

    if-nez v0, :cond_0

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    .line 4267
    invoke-virtual {p0}, Lcom/android/mms/ui/RecipientsEditor;->getRecipientCount()I

    move-result p0

    if-nez p0, :cond_1

    :cond_0
    const/4 p0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method private isRecipientsEditorVisible()Z
    .locals 0

    .line 4301
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz p0, :cond_0

    .line 4302
    invoke-virtual {p0}, Lcom/android/mms/ui/RecipientsEditor;->getVisibility()I

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method private isSpecialChar(C)Z
    .locals 0

    const/16 p0, 0x2a

    if-eq p1, p0, :cond_1

    const/16 p0, 0x25

    if-eq p1, p0, :cond_1

    const/16 p0, 0x24

    if-ne p1, p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method private isSubjectEditorVisible()Z
    .locals 0

    .line 4307
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    if-eqz p0, :cond_0

    .line 4308
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method private isVcardFile(Landroid/net/Uri;)Z
    .locals 0

    .line 8954
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_0

    .line 8955
    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const-string p1, ".vcf"

    invoke-virtual {p0, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method private isVideoFile(Landroid/net/Uri;)Z
    .locals 0

    .line 6197
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p0

    .line 6198
    invoke-static {p0}, Lcom/android/mmswrapper/MediaFileWrapper;->getMimeTypeForFile(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 6199
    invoke-static {p0}, Lcom/android/mmswrapper/MediaFileWrapper;->getFileTypeForMimeType(Ljava/lang/String;)I

    move-result p0

    .line 6200
    invoke-static {p0}, Lcom/android/mmswrapper/MediaFileWrapper;->isVideoFileType(I)Z

    move-result p0

    return p0
.end method

.method private launchMsimDialog(ZZ)V
    .locals 12

    .line 1357
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsimDialog:Landroid/app/AlertDialog;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/AlertDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1358
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsimDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V

    :cond_0
    const-string v0, "LaunchMsimDialog"

    .line 1360
    invoke-static {v0}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    .line 1361
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "layout_inflater"

    .line 1362
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/LayoutInflater;

    const v2, 0x7f0a0066    # @layout/multi_sim_sms_sender 'res/layout/multi_sim_sms_sender.xml'

    const v3, 0x7f0800da    # @id/layout_root

    .line 1364
    invoke-virtual {p0, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/view/ViewGroup;

    .line 1363
    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    .line 1365
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 1366
    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$9;

    invoke-direct {v2, p0}, Lcom/android/mms/ui/ComposeMessageActivity$9;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    const v2, 0x7f0e0196    # @string/no 'Cancel'

    .line 1382
    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$10;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ComposeMessageActivity$10;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 1388
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1

    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    .line 1389
    invoke-virtual {v2, v3}, Lcom/android/mms/ui/RecipientsEditor;->constructContactsFromInput(Z)Lcom/android/mms/data/ContactList;

    move-result-object v2

    goto :goto_0

    :cond_1
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v2

    .line 1390
    :goto_0
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e02d4    # @string/to_address_label 'To: '

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ","

    .line 1391
    invoke-virtual {v2, v5}, Lcom/android/mms/data/ContactList;->formatNamesAndNumbers(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1390
    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 1393
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsimDialog:Landroid/app/AlertDialog;

    const/4 v2, 0x1

    .line 1394
    invoke-virtual {v0, v2}, Landroid/app/AlertDialog;->setCanceledOnTouchOutside(Z)V

    const/4 v0, 0x3

    new-array v0, v0, [I

    .line 1396
    fill-array-data v0, :array_0

    .line 1397
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->getActiveModemCount()I

    move-result v2

    .line 1398
    new-array v4, v2, [Landroid/widget/Button;

    .line 1400
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    .line 1399
    invoke-static {v5}, Landroid/telephony/SubscriptionManager;->from(Landroid/content/Context;)Landroid/telephony/SubscriptionManager;

    move-result-object v5

    .line 1400
    invoke-virtual {v5}, Landroid/telephony/SubscriptionManager;->getActiveSubscriptionInfoList()Ljava/util/List;

    move-result-object v5

    const/4 v6, 0x0

    move v7, v3

    :goto_1
    if-ge v7, v2, :cond_4

    .line 1404
    aget v8, v0, v7

    invoke-virtual {v1, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/Button;

    aput-object v8, v4, v7

    .line 1405
    aget-object v8, v4, v7

    invoke-virtual {v8, v3}, Landroid/widget/Button;->setVisibility(I)V

    if-eqz v5, :cond_3

    .line 1407
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "SIM "

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v8, v7, 0x1

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 1408
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_2
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_3

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/telephony/SubscriptionInfo;

    .line 1409
    invoke-virtual {v10}, Landroid/telephony/SubscriptionInfo;->getSimSlotIndex()I

    move-result v11

    if-ne v11, v7, :cond_2

    .line 1410
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, ": "

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Landroid/telephony/SubscriptionInfo;->getDisplayName()Ljava/lang/CharSequence;

    move-result-object v8

    invoke-interface {v8}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 1415
    :cond_3
    aget-object v8, v4, v7

    invoke-virtual {v8, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1416
    aget-object v8, v4, v7

    new-instance v9, Lcom/android/mms/ui/ComposeMessageActivity$11;

    invoke-direct {v9, p0, v7, p2, p1}, Lcom/android/mms/ui/ComposeMessageActivity$11;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;IZZ)V

    invoke-virtual {v8, v9}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 1435
    :cond_4
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsimDialog:Landroid/app/AlertDialog;

    invoke-virtual {p0}, Landroid/app/AlertDialog;->show()V

    return-void

    :array_0
    .array-data 4
        0x7f080001    # @id/BtnSimOne
        0x7f080003    # @id/BtnSimTwo
        0x7f080002    # @id/BtnSimThree
    .end array-data
.end method

.method private launchMultipleGroupPicker()V
    .locals 3

    .line 6613
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v0}, Lcom/android/mms/ui/RecipientsEditor;->getExsitNumbers()Ljava/lang/String;

    move-result-object v0

    .line 6614
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.PICK"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "com.android.cursor.dir/vzwgroup"

    .line 6615
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 6616
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    const-string v2, "com.android.contacts.extra.PHONE_URIS"

    .line 6617
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/16 v0, 0x78

    .line 6620
    :try_start_0
    invoke-virtual {p0, v1, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivityForResult(Landroid/content/Intent;I)V

    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const v0, 0x7f0e0089    # @string/contact_app_not_found 'Can not find Contact application'

    const/4 v1, 0x0

    .line 6622
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method

.method private launchMultiplePhonePicker()V
    .locals 3

    .line 6630
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v0}, Lcom/android/mms/ui/RecipientsEditor;->getExsitNumbers()Ljava/lang/String;

    move-result-object v0

    .line 6631
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.PICK"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "com.android.cursor.dir/phone_email"

    .line 6634
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 6637
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    const-string v2, "com.android.contacts.extra.PHONE_URIS"

    .line 6638
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/16 v0, 0x6d

    .line 6641
    :try_start_0
    invoke-virtual {p0, v1, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivityForResult(Landroid/content/Intent;I)V

    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const v0, 0x7f0e0089    # @string/contact_app_not_found 'Can not find Contact application'

    const/4 v1, 0x0

    .line 6643
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method

.method private loadDraft()Z
    .locals 2

    .line 7546
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->isWorthSaving()Z

    move-result v0

    const-string v1, "Mms"

    if-eqz v0, :cond_1

    const-string v0, "CMA.loadDraft: called with non-empty working message, bail"

    .line 7547
    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 7548
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->hasDraft()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    .line 7549
    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getMessageCount()I

    move-result v0

    if-nez v0, :cond_0

    .line 7550
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0, v1}, Lcom/android/mms/data/WorkingMessage;->asyncDeleteDraftSmsMessage(Lcom/android/mms/data/Conversation;)V

    .line 7551
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->clearThreadId()V

    .line 7552
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0, p0}, Lcom/android/mms/data/WorkingMessage;->setConversation(Lcom/android/mms/data/Conversation;)V

    :cond_0
    const/4 p0, 0x0

    return p0

    :cond_1
    const/4 v0, 0x2

    .line 7557
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "CMA.loadDraft"

    .line 7558
    invoke-static {v0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 7560
    :cond_2
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$87;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$87;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-static {p0, v0, v1}, Lcom/android/mms/data/WorkingMessage;->loadDraft(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/data/Conversation;Ljava/lang/Runnable;)Lcom/android/mms/data/WorkingMessage;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 7585
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0, p0}, Lcom/android/mms/data/WorkingMessage;->setConversation(Lcom/android/mms/data/Conversation;)V

    const/4 p0, 0x1

    return p0
.end method

.method private loadMessagesAndDraft(I)V
    .locals 3

    .line 3409
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessagesAndDraftLoaded:Z

    if-nez v0, :cond_3

    const/4 v0, 0x2

    const-string v1, "Mms"

    .line 3410
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 3411
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "### CMA.loadMessagesAndDraft: flag="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 3413
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->loadMessageContent()V

    .line 3415
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->getConversation()Lcom/android/mms/data/Conversation;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v0

    .line 3417
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShouldLoadDraft:Z

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    sget-object p1, Lcom/android/mms/ui/MessageUtils;->sSameRecipientList:Ljava/util/ArrayList;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1

    .line 3418
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->loadDraft()Z

    move-result p1

    if-eqz p1, :cond_1

    const/4 p1, 0x0

    goto :goto_0

    :cond_1
    move p1, v2

    :goto_0
    if-eqz p1, :cond_2

    .line 3423
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->drawBottomPanel()V

    .line 3425
    :cond_2
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessagesAndDraftLoaded:Z

    :cond_3
    return-void
.end method

.method public static log(Ljava/lang/String;)V
    .locals 5

    .line 708
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    .line 709
    invoke-virtual {v0}, Ljava/lang/Thread;->getId()J

    move-result-wide v1

    .line 710
    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v3, 0x3

    .line 711
    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljava/lang/StackTraceElement;->getMethodName()Ljava/lang/String;

    move-result-object v0

    .line 713
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "] ["

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "] "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "Mms"

    .line 714
    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private logMultiChoice(Ljava/lang/String;)V
    .locals 0

    const-string p0, "Mms"

    .line 8964
    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private onKeyboardStateChanged()V
    .locals 2

    .line 4065
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    iget-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 4066
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    const/4 v1, 0x0

    if-nez v0, :cond_2

    .line 4067
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz v0, :cond_0

    .line 4068
    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setFocusableInTouchMode(Z)V

    .line 4070
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    if-eqz v0, :cond_1

    .line 4071
    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setFocusableInTouchMode(Z)V

    .line 4073
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setFocusableInTouchMode(Z)V

    .line 4074
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    const v0, 0x7f0e027f    # @string/sending_disabled_not_default_app 'Sending disabled'

    invoke-virtual {p0, v0}, Landroid/widget/EditText;->setHint(I)V

    goto :goto_0

    .line 4075
    :cond_2
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsKeyboardOpen:Z

    if-eqz v0, :cond_5

    .line 4076
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    const/4 v1, 0x1

    if-eqz v0, :cond_3

    .line 4077
    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setFocusableInTouchMode(Z)V

    .line 4079
    :cond_3
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    if-eqz v0, :cond_4

    .line 4080
    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setFocusableInTouchMode(Z)V

    .line 4082
    :cond_4
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setFocusableInTouchMode(Z)V

    .line 4083
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    const v0, 0x7f0e0077    # @string/compose_hint_text 'Type a message...'

    invoke-virtual {p0, v0}, Landroid/widget/EditText;->setHint(I)V

    goto :goto_0

    .line 4085
    :cond_5
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz v0, :cond_6

    .line 4086
    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setFocusable(Z)V

    .line 4088
    :cond_6
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    if-eqz v0, :cond_7

    .line 4089
    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setFocusable(Z)V

    .line 4091
    :cond_7
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setFocusable(Z)V

    .line 4092
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    const v0, 0x7f0e01b8    # @string/open_keyboard_to_compose_message 'Open keyboard to type message'

    invoke-virtual {p0, v0}, Landroid/widget/EditText;->setHint(I)V

    :goto_0
    return-void
.end method

.method private pickContacts(I)V
    .locals 2

    .line 760
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.PICK"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "vnd.android.cursor.dir/contact"

    .line 761
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 762
    invoke-virtual {p0, v0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method private pickContacts(II)V
    .locals 3

    .line 753
    new-instance v0, Landroid/content/Intent;

    sget-object v1, Landroid/provider/ContactsContract$Contacts;->CONTENT_URI:Landroid/net/Uri;

    const-string v2, "com.android.contacts.action.MULTI_PICK"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const-string v1, "mode"

    .line 754
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 755
    invoke-virtual {p0, v0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method private previewAttach(Landroid/net/Uri;Ljava/lang/String;)V
    .locals 4

    .line 10142
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    .line 10143
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 10144
    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "image/*"

    .line 10146
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const-string v2, "SingleItemOnly"

    const-string v3, "com.android.gallery3d"

    if-eqz p1, :cond_0

    .line 10147
    new-instance p1, Landroid/content/ComponentName;

    const-string p2, "com.android.gallery3d.app.GalleryActivity"

    invoke-direct {p1, v3, p2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 10149
    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 10150
    invoke-virtual {v0, p1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    goto :goto_0

    :cond_0
    const-string p1, "audio/*"

    .line 10151
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    .line 10152
    new-instance p1, Landroid/content/ComponentName;

    const-string p2, "com.android.music"

    const-string v1, "com.android.music.AudioPreview"

    invoke-direct {p1, p2, v1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 10153
    invoke-virtual {v0, p1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    goto :goto_0

    :cond_1
    const-string p1, "video/*"

    .line 10154
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    .line 10155
    new-instance p1, Landroid/content/ComponentName;

    const-string p2, "com.android.gallery3d.app.MovieActivity"

    invoke-direct {p1, v3, p2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 10156
    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 10158
    invoke-virtual {v0, p1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 10161
    :cond_2
    :goto_0
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private previewVcard(Landroid/net/Uri;)V
    .locals 5

    .line 10109
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListView;->isFocused()Z

    move-result v0

    const-string v1, "Mms"

    const-string v2, "contacts"

    if-eqz v0, :cond_0

    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v0

    iget-object v0, v0, Lcom/android/mms/ui/MessageItem;->mSlideshow:Lcom/android/mms/model/SlideshowModel;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v0

    iget-object v0, v0, Lcom/android/mms/ui/MessageItem;->mSlideshow:Lcom/android/mms/model/SlideshowModel;

    const/4 v3, 0x0

    invoke-virtual {v0, v3}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getVcard()Lcom/android/mms/model/VcardModel;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 10110
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v0

    iget-object v0, v0, Lcom/android/mms/ui/MessageItem;->mSlideshow:Lcom/android/mms/model/SlideshowModel;

    invoke-virtual {v0, v3}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getVcard()Lcom/android/mms/model/VcardModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/VcardModel;->getLookupUri()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 10112
    :cond_0
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 10113
    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object v0

    .line 10114
    sget-object v3, Landroid/provider/ContactsContract$Contacts;->CONTENT_LOOKUP_URI:Landroid/net/Uri;

    invoke-static {v3, v0}, Landroid/net/Uri;->withAppendedPath(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 10117
    :cond_1
    :try_start_0
    new-instance v0, Lcom/android/mms/model/VcardModel;

    invoke-direct {v0, p0, p1}, Lcom/android/mms/model/VcardModel;-><init>(Landroid/content/Context;Landroid/net/Uri;)V

    invoke-virtual {v0}, Lcom/android/mms/model/VcardModel;->getLookupUri()Ljava/lang/String;

    move-result-object v0

    :try_end_0
    .catch Lcom/google/android/mms/MmsException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 10119
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "previewVcard failed>>>"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/google/android/mms/MmsException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    .line 10123
    :goto_0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "previewVcard lookupUri : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 10125
    new-instance v1, Landroid/content/Intent;

    const-string v3, "android.intent.action.VIEW"

    invoke-direct {v1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 10126
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v4, 0x1

    if-nez v3, :cond_2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_2

    .line 10128
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const-string p1, "SingleItemOnly"

    .line 10129
    invoke-virtual {v1, p1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    goto :goto_1

    :cond_2
    const-string v0, "text/x-vCard"

    .line 10132
    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, p1, v0}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    .line 10133
    invoke-virtual {v1, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :goto_1
    const-string p1, "VIEW_VCARD_FROM_MMS"

    .line 10137
    invoke-virtual {v1, p1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 10138
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private processAddRecipients(Ljava/util/Set;I)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;I)V"
        }
    .end annotation

    const/4 v0, 0x1

    .line 5459
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsProcessPickedRecipients:Z

    .line 5460
    new-instance v5, Landroid/os/Handler;

    invoke-direct {v5}, Landroid/os/Handler;-><init>()V

    .line 5461
    new-instance v7, Landroid/app/ProgressDialog;

    invoke-direct {v7, p0}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V

    const v1, 0x7f0e01bd    # @string/pick_too_many_recipients 'Too many recipients'

    .line 5462
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v7, v1}, Landroid/app/ProgressDialog;->setTitle(Ljava/lang/CharSequence;)V

    const v1, 0x7f0e0036    # @string/adding_recipients 'Adding recipients...'

    .line 5463
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v7, v1}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V

    .line 5464
    invoke-virtual {v7, v0}, Landroid/app/ProgressDialog;->setIndeterminate(Z)V

    const/4 v0, 0x0

    .line 5465
    invoke-virtual {v7, v0}, Landroid/app/ProgressDialog;->setCancelable(Z)V

    .line 5467
    new-instance v6, Lcom/android/mms/ui/ComposeMessageActivity$50;

    invoke-direct {v6, p0, v7}, Lcom/android/mms/ui/ComposeMessageActivity$50;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/app/ProgressDialog;)V

    const-wide/16 v0, 0x3e8

    .line 5475
    invoke-virtual {v5, v6, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 5477
    new-instance v0, Ljava/lang/Thread;

    new-instance v8, Lcom/android/mms/ui/ComposeMessageActivity$51;

    move-object v1, v8

    move-object v2, p0

    move-object v3, p1

    move v4, p2

    invoke-direct/range {v1 .. v7}, Lcom/android/mms/ui/ComposeMessageActivity$51;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/util/Set;ILandroid/os/Handler;Ljava/lang/Runnable;Landroid/app/ProgressDialog;)V

    const-string p0, "ComoseMessageActivity.processPickResult"

    invoke-direct {v0, v8, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 5524
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private processPickGroupResult(Landroid/content/Intent;)V
    .locals 1

    const-string v0, "PHONE_IDS"

    .line 5279
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getLongArrayExtra(Ljava/lang/String;)[J

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 5283
    :cond_0
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->processPickResult(Landroid/content/Intent;)V

    return-void
.end method

.method private processPickResult(Landroid/content/Intent;)V
    .locals 7

    .line 5304
    invoke-static {}, Lcom/android/mms/MmsConfig;->getRecipientLimit()I

    move-result v0

    .line 5305
    iget v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mExistsRecipientsCount:I

    const/4 v2, 0x1

    add-int/2addr v1, v2

    const v3, 0x7fffffff

    if-eq v0, v3, :cond_0

    if-le v1, v0, :cond_0

    .line 5308
    new-instance v3, Landroid/app/AlertDialog$Builder;

    invoke-direct {v3, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v4, 0x7f0e02d9    # @string/too_many_recipients 'Message has too many recipients (%1$s). There is a limit of %2$s recipients.'

    const/4 v5, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    .line 5309
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v6

    .line 5310
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v2

    .line 5309
    invoke-virtual {p0, v4, v5}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const v2, 0x104000a    # @android:string/ok

    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$47;

    invoke-direct {v3, p0, v0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$47;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;ILandroid/content/Intent;)V

    .line 5311
    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    const/high16 p1, 0x1040000    # @android:string/cancel

    const/4 v0, 0x0

    .line 5333
    invoke-virtual {p0, p1, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 5334
    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog;->show()V

    return-void

    .line 5338
    :cond_0
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->gfProcessAddRecipients(Landroid/content/Intent;)V

    return-void
.end method

.method private reUpdateAttachmentView(Lcom/android/mms/data/WorkingMessage;)V
    .locals 7

    .line 10168
    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->DraftSlideShow:Lcom/android/mms/model/SlideshowModel;

    if-eqz p1, :cond_5

    .line 10170
    invoke-virtual {p1}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result p1

    if-lez p1, :cond_5

    const/4 p1, 0x0

    move v6, p1

    .line 10171
    :goto_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->DraftSlideShow:Lcom/android/mms/model/SlideshowModel;

    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v0

    if-ge v6, v0, :cond_5

    .line 10172
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->DraftSlideShow:Lcom/android/mms/model/SlideshowModel;

    invoke-virtual {v0, v6}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v0

    const/4 v1, 0x0

    .line 10177
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->hasAudio()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 10178
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getAudio()Lcom/android/mms/model/AudioModel;

    move-result-object v1

    .line 10179
    invoke-virtual {v1}, Lcom/android/mms/model/AudioModel;->getMediaSize()I

    move-result v1

    .line 10180
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getAudio()Lcom/android/mms/model/AudioModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/AudioModel;->getUri()Landroid/net/Uri;

    move-result-object v0

    const-string v2, "audio"

    :goto_1
    move v5, v1

    move-object v1, v2

    move-object v2, v0

    goto :goto_2

    .line 10182
    :cond_0
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->hasImage()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 10183
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getImage()Lcom/android/mms/model/ImageModel;

    move-result-object v1

    .line 10184
    invoke-virtual {v1}, Lcom/android/mms/model/ImageModel;->getMediaSize()I

    move-result v1

    .line 10185
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getImage()Lcom/android/mms/model/ImageModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/ImageModel;->getUri()Landroid/net/Uri;

    move-result-object v0

    const-string v2, "image"

    goto :goto_1

    .line 10187
    :cond_1
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->hasVideo()Z

    move-result v2

    if-eqz v2, :cond_2

    .line 10188
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getVideo()Lcom/android/mms/model/VideoModel;

    move-result-object v1

    .line 10189
    invoke-virtual {v1}, Lcom/android/mms/model/VideoModel;->getMediaSize()I

    move-result v1

    .line 10190
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getVideo()Lcom/android/mms/model/VideoModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/VideoModel;->getUri()Landroid/net/Uri;

    move-result-object v0

    const-string v2, "video"

    goto :goto_1

    .line 10192
    :cond_2
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->hasVcard()Z

    move-result v2

    if-eqz v2, :cond_3

    .line 10193
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getVcard()Lcom/android/mms/model/VcardModel;

    move-result-object v1

    .line 10194
    invoke-virtual {v1}, Lcom/android/mms/model/VcardModel;->getMediaSize()I

    move-result v1

    .line 10195
    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getVcard()Lcom/android/mms/model/VcardModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/VcardModel;->getUri()Landroid/net/Uri;

    move-result-object v0

    const-string v2, "vcard"

    goto :goto_1

    :cond_3
    const-string v0, ""

    move v5, p1

    move-object v2, v1

    move-object v1, v0

    :goto_2
    if-eqz v2, :cond_4

    .line 10198
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4

    const/4 v3, 0x1

    move-object v0, p0

    move v4, v6

    .line 10199
    invoke-direct/range {v0 .. v5}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentView(Ljava/lang/String;Landroid/net/Uri;ZII)V

    goto :goto_3

    .line 10202
    :cond_4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Do not reUpdateAttachmentView type = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " tempuri = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mms"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :goto_3
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_0

    :cond_5
    return-void
.end method

.method private recipientCount()I
    .locals 1

    .line 7723
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 7724
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {p0}, Lcom/android/mms/ui/RecipientsEditor;->getRecipientCount()I

    move-result p0

    goto :goto_0

    .line 7726
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p0

    invoke-virtual {p0}, Lcom/android/mms/data/ContactList;->size()I

    move-result p0

    :goto_0
    return p0
.end method

.method private declared-synchronized regRecipientsWatcher()V
    .locals 2

    monitor-enter p0

    .line 10842
    :try_start_0
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRegistered:Z

    if-nez v0, :cond_0

    .line 10843
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/4 v0, 0x1

    .line 10844
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRegistered:Z

    .line 10846
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    :cond_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private removeMessageItem(Lcom/android/mms/ui/MessageItem;)V
    .locals 1

    .line 7367
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$84;

    invoke-direct {v0, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$84;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;)V

    const/4 p0, 0x0

    new-array p0, p0, [Ljava/lang/Void;

    .line 7395
    invoke-virtual {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$84;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method private removeRecipientsListeners()V
    .locals 0

    .line 8707
    invoke-static {p0}, Lcom/android/mms/data/Contact;->removeListener(Lcom/android/mms/data/Contact$UpdateListener;)V

    return-void
.end method

.method private resendMessage(Lcom/android/mms/ui/MessageItem;)V
    .locals 3

    .line 2160
    invoke-static {}, Landroid/telephony/SmsManager;->getDefault()Landroid/telephony/SmsManager;

    move-result-object v0

    invoke-static {v0}, Lcom/android/mmswrapper/SmsManagerWrapper;->isSMSPromptEnabled(Landroid/telephony/SmsManager;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 2161
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    iget v1, p1, Lcom/android/mms/ui/MessageItem;->mSubId:I

    invoke-virtual {v0, v1}, Lcom/android/mms/data/WorkingMessage;->setWorkingMessageSub(I)V

    .line 2163
    :cond_0
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageItem;->isMms()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_2

    .line 2166
    iget-object v0, p1, Lcom/android/mms/ui/MessageItem;->mMessageUri:Landroid/net/Uri;

    invoke-static {p0, v0}, Lcom/android/mms/data/WorkingMessage;->load(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;)Lcom/android/mms/data/WorkingMessage;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    .line 2171
    :cond_1
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v2}, Lcom/android/mms/data/WorkingMessage;->discard()V

    .line 2173
    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 2174
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0, v2}, Lcom/android/mms/data/WorkingMessage;->setConversation(Lcom/android/mms/data/Conversation;)V

    .line 2175
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    iget-object p1, p1, Lcom/android/mms/ui/MessageItem;->mSubject:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-virtual {v0, p1, v2}, Lcom/android/mms/data/WorkingMessage;->setSubject(Ljava/lang/CharSequence;Z)V

    goto :goto_0

    .line 2177
    :cond_2
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/data/ContactList;->size()I

    move-result v0

    if-le v0, v1, :cond_3

    .line 2181
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0, v1}, Lcom/android/mms/data/WorkingMessage;->setResendMultiRecipients(Z)V

    .line 2182
    iget-object v0, p1, Lcom/android/mms/ui/MessageItem;->mAddress:Ljava/lang/String;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResendSmsRecipient:Ljava/lang/String;

    .line 2185
    :cond_3
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->editSmsMessageItem(Lcom/android/mms/ui/MessageItem;)V

    .line 2188
    :goto_0
    invoke-direct {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMessage(Z)V

    return-void
.end method

.method private resetConfiguration(Landroid/content/res/Configuration;)Z
    .locals 3

    .line 4053
    iget v0, p1, Landroid/content/res/Configuration;->keyboardHidden:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsKeyboardOpen:Z

    .line 4054
    iget p1, p1, Landroid/content/res/Configuration;->orientation:I

    const/4 v0, 0x2

    if-ne p1, v0, :cond_1

    move p1, v2

    goto :goto_1

    :cond_1
    move p1, v1

    .line 4055
    :goto_1
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsLandscape:Z

    if-eq v0, p1, :cond_2

    .line 4056
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsLandscape:Z

    return v2

    :cond_2
    return v1
.end method

.method private resetCounter()V
    .locals 4

    .line 1040
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1041
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v0

    const/16 v1, 0x8

    const-string v2, ""

    if-eqz v0, :cond_0

    .line 1043
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    const v3, 0x7f0e016e    # @string/mms 'MMS'

    invoke-virtual {p0, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 1045
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1046
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1049
    :goto_0
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz v0, :cond_1

    .line 1050
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounterSec:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1051
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounterSec:Landroid/widget/TextView;

    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_1
    return-void
.end method

.method private resetEditorText()V
    .locals 2

    .line 3178
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditorWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->removeTextChangedListener(Landroid/text/TextWatcher;)V

    .line 3180
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-static {v0}, Landroid/text/method/TextKeyListener;->clear(Landroid/text/Editable;)V

    .line 3181
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditorWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v0, p0}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    return-void
.end method

.method private resetGridColumnsCount()V
    .locals 4

    .line 5021
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    .line 5022
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPagerAdapter:Lcom/android/mms/ui/AttachmentPagerAdapter;

    invoke-virtual {p0}, Lcom/android/mms/ui/AttachmentPagerAdapter;->getPagerGridViews()Ljava/util/ArrayList;

    move-result-object p0

    .line 5023
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/GridView;

    .line 5024
    iget v2, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    const/4 v2, 0x3

    goto :goto_1

    :cond_0
    const/4 v2, 0x6

    :goto_1
    invoke-virtual {v1, v2}, Landroid/widget/GridView;->setNumColumns(I)V

    goto :goto_0

    :cond_1
    return-void
.end method

.method private resetMessage()V
    .locals 4

    const-string v0, "Mms"

    const/4 v1, 0x2

    .line 7872
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "resetMessage"

    .line 7873
    invoke-static {v0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 7877
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditor:Lcom/android/mms/ui/AttachmentEditor;

    invoke-virtual {v0}, Lcom/android/mms/ui/AttachmentEditor;->hideView()V

    .line 7878
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditorScrollView:Landroid/view/View;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 7881
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MoreAttachmentView;->removeAllViews()V

    .line 7882
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MoreAttachmentView;->setVisibility(I)V

    .line 7883
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentViewer:Landroid/widget/RelativeLayout;

    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    const/4 v0, 0x0

    .line 7887
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->showSubjectEditor(Z)V

    .line 7891
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->isVisibleToUser()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 7892
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->requestFocus()Z

    .line 7900
    :cond_1
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditorWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->removeTextChangedListener(Landroid/text/TextWatcher;)V

    .line 7903
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-static {v2}, Landroid/text/method/TextKeyListener;->clear(Landroid/text/Editable;)V

    .line 7905
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v2, v3, v0}, Lcom/android/mms/data/WorkingMessage;->clearConversation(Lcom/android/mms/data/Conversation;Z)V

    .line 7906
    invoke-static {p0}, Lcom/android/mms/data/WorkingMessage;->createEmpty(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/data/WorkingMessage;

    move-result-object v2

    iput-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 7907
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v2, v3}, Lcom/android/mms/data/WorkingMessage;->setConversation(Lcom/android/mms/data/Conversation;)V

    .line 7909
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->hideRecipientEditor()V

    .line 7910
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->drawBottomPanel()V

    .line 7913
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateSendButtonState()V

    .line 7916
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditorWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 7917
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateMenuOption()V

    .line 7921
    iget-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsLandscape:Z

    if-nez v2, :cond_2

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isInMultiWindowMode()Z

    move-result v2

    if-eqz v2, :cond_3

    .line 7922
    :cond_2
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->hideKeyboard()V

    .line 7925
    :cond_3
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastRecipientCount:I

    .line 7926
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendingMessage:Z

    .line 7927
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->invalidateOptionsMenu()V

    .line 7928
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_4

    .line 7929
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    invoke-virtual {p0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_4
    return-void
.end method

.method private sanityCheckConversation()V
    .locals 2

    .line 3266
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getConversation()Lcom/android/mms/data/Conversation;

    move-result-object v0

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    if-eq v0, v1, :cond_0

    .line 3267
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "ComposeMessageActivity: mWorkingMessage.mConversation="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 3269
    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->getConversation()Lcom/android/mms/data/Conversation;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", mConversation="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", MISMATCH!"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 3267
    invoke-static {v0, p0}, Lcom/android/mms/LogTag;->warnPossibleRecipientMismatch(Ljava/lang/String;Landroid/app/Activity;)V

    :cond_0
    return-void
.end method

.method private saveAttachment(J)V
    .locals 0

    .line 9194
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->copyMedia(J)Z

    move-result p1

    if-eqz p1, :cond_0

    const p1, 0x7f0e0099    # @string/copy_to_sdcard_success 'Attachment saved'

    goto :goto_0

    :cond_0
    const p1, 0x7f0e0098    # @string/copy_to_sdcard_fail 'Couldn't save attachment'

    :goto_0
    const/4 p2, 0x0

    .line 9196
    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    .line 9197
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private saveDraft(Z)V
    .locals 3

    const-string v0, "Mms"

    const/4 v1, 0x2

    .line 7591
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    new-array v0, v1, [Ljava/lang/Object;

    const-string v2, "saveDraft"

    .line 7592
    invoke-static {v2, v0}, Lcom/android/mms/LogTag;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 7597
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->isDiscarded()Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    .line 7601
    :cond_1
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWaitingForSubActivity:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 7605
    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->isWorthSaving()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 7607
    :cond_2
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->checkIsPhoneMemoryFull(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_4

    :cond_3
    const-string p1, "not worth saving, discard WorkingMessage and bail"

    .line 7609
    invoke-static {p1}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 7611
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->discard()V

    return-void

    .line 7614
    :cond_4
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0, p1}, Lcom/android/mms/data/WorkingMessage;->saveDraft(Z)V

    .line 7616
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToastForDraftSave:Z

    if-eqz p1, :cond_5

    const p1, 0x7f0e0164    # @string/message_saved_as_draft 'Message saved as draft.'

    .line 7617
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    .line 7618
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :cond_5
    return-void
.end method

.method private savePicAndVideo(Landroid/net/Uri;Ljava/lang/String;)Z
    .locals 10

    const-string v0, "/"

    const-string v1, "IOException caught while closing stream"

    const-string v2, "Mms"

    .line 2390
    new-instance v3, Ljava/util/Date;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-direct {v3, v4, v5}, Ljava/util/Date;-><init>(J)V

    .line 2391
    new-instance v4, Ljava/text/SimpleDateFormat;

    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v6, "\'MMS\'_yyyyMMdd_HHmmss"

    invoke-direct {v4, v6, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v5, 0x0

    const/4 v6, 0x0

    .line 2393
    :try_start_0
    iget-object v7, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContentResolver:Landroid/content/ContentResolver;

    invoke-virtual {v7, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p1

    .line 2394
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_5
    .catchall {:try_start_0 .. :try_end_0} :catchall_2
    :try_start_1

    instance-of v7, p1, Ljava/io/FileInputStream;

    if-eqz v7, :cond_7

    .line 2395
    move-object v7, p1

    check-cast v7, Ljava/io/FileInputStream;

    const-string v8, ""

    const-string v9, "image/jpeg"

    if-ne p2, v9, :cond_0

    .line 2398
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".jpeg"

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    goto :goto_0

    :cond_0
    const-string v9, "video/mp4"

    if-ne p2, v9, :cond_1

    .line 2400
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".mp4"

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 2402
    :cond_1
    :goto_0
    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v8}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 2403
    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    .line 2409
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v8

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2410
    invoke-static {p2}, Lcom/google/android/mms/ContentType;->isAudioType(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_2

    sget-object v8, Landroid/os/Environment;->DIRECTORY_RINGTONES:Ljava/lang/String;

    goto :goto_1

    :cond_2
    sget-object v8, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    :goto_1
    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/16 v4, 0x2e

    .line 2414
    invoke-virtual {v3, v4}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v4

    const/4 v8, -0x1

    if-ne v4, v8, :cond_3

    .line 2415
    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    move-result-object v4

    invoke-virtual {v4, p2}, Landroid/webkit/MimeTypeMap;->getExtensionFromMimeType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    goto :goto_2

    :cond_3
    add-int/lit8 p2, v4, 0x1

    .line 2417
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v9

    invoke-virtual {v3, p2, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    .line 2418
    invoke-virtual {v3, v6, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    .line 2421
    :goto_2
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->getUniqueDestination(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object p2

    .line 2424
    invoke-virtual {p2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0

    .line 2425
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_5

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v3

    if-nez v3, :cond_5

    .line 2426
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "[MMS] SavePicAndVideo: mkdirs for "

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, " failed!"

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz p1, :cond_4

    .line 2450
    :try_start_2
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V

    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_3

    :catch_0
    move-exception p0

    .line 2453
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_4
    :goto_3
    return v6

    .line 2430
    :cond_5
    :try_start_3
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, p2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/16 v3, 0x1f40

    :try_start_4
    new-array v3, v3, [B

    .line 2434
    :goto_4
    invoke-virtual {v7, v3}, Ljava/io/FileInputStream;->read([B)I

    move-result v4

    if-eq v4, v8, :cond_6

    .line 2435
    invoke-virtual {v0, v3, v6, v4}, Ljava/io/FileOutputStream;->write([BII)V

    goto :goto_4

    .line 2440
    :cond_6
    new-instance v3, Landroid/content/Intent;

    const-string v4, "android.intent.action.MEDIA_SCANNER_SCAN_FILE"

    .line 2441
    invoke-static {p2}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object p2

    invoke-direct {v3, v4, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 2440
    invoke-virtual {p0, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->sendBroadcast(Landroid/content/Intent;)V

    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    move-object v5, v0

    goto :goto_5

    :catchall_0
    move-exception p0

    goto :goto_8

    :catch_1
    move-exception p0

    goto :goto_9

    :cond_7
    :goto_5
    if-eqz p1, :cond_8

    .line 2450
    :try_start_5
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V

    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2

    goto :goto_6

    :catch_2
    move-exception p0

    .line 2453
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v6

    :cond_8
    :goto_6
    if-eqz v5, :cond_9

    .line 2459
    :try_start_6
    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V

    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_3

    goto :goto_7

    :catch_3
    move-exception p0

    .line 2462
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v6

    :cond_9
    :goto_7
    const/4 p0, 0x1

    return p0

    :catchall_1
    move-exception p0

    move-object v0, v5

    :goto_8
    move-object v5, p1

    goto :goto_d

    :catch_4
    move-exception p0

    move-object v0, v5

    :goto_9
    move-object v5, p1

    goto :goto_a

    :catchall_2
    move-exception p0

    move-object v0, v5

    goto :goto_d

    :catch_5
    move-exception p0

    move-object v0, v5

    :goto_a
    :try_start_7
    const-string p1, "IOException caught while opening or reading stream"

    .line 2445
    invoke-static {v2, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    if-eqz v5, :cond_a

    .line 2450
    :try_start_8
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_6

    goto :goto_b

    :catch_6
    move-exception p0

    .line 2453
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v6

    :cond_a
    :goto_b
    if-eqz v0, :cond_b

    .line 2459
    :try_start_9
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V

    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_7

    goto :goto_c

    :catch_7
    move-exception p0

    .line 2462
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_b
    :goto_c
    return v6

    :catchall_3
    move-exception p0

    :goto_d
    if-eqz v5, :cond_c

    .line 2450
    :try_start_a
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_8

    goto :goto_e

    :catch_8
    move-exception p0

    .line 2453
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v6

    :cond_c
    :goto_e
    if-eqz v0, :cond_d

    .line 2459
    :try_start_b
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V

    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_9

    goto :goto_f

    :catch_9
    move-exception p0

    .line 2462
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v6

    .line 2466
    :cond_d
    :goto_f
    throw p0
.end method

.method private saveRingtone(J)Z
    .locals 7

    .line 2257
    :try_start_0
    sget-object v0, Landroid/provider/Telephony$Mms;->CONTENT_URI:Landroid/net/Uri;

    .line 2258
    invoke-static {v0, p1, p2}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v0

    .line 2257
    invoke-static {p0, v0}, Lcom/android/mms/model/SlideshowModel;->getPduBody(Landroid/content/Context;Landroid/net/Uri;)Lcom/google/android/mms/pdu/PduBody;

    move-result-object v0

    :try_end_0
    .catch Lcom/google/android/mms/MmsException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 2260
    :catch_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "copyToDrmProvider can\'t load pdu body: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mms"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 2266
    :cond_0
    invoke-virtual {v0}, Lcom/google/android/mms/pdu/PduBody;->getPartsNum()I

    move-result v2

    const/4 v3, 0x1

    :goto_1
    if-ge v1, v2, :cond_2

    .line 2268
    invoke-virtual {v0, v1}, Lcom/google/android/mms/pdu/PduBody;->getPart(I)Lcom/google/android/mms/pdu/PduPart;

    move-result-object v4

    .line 2269
    new-instance v5, Ljava/lang/String;

    invoke-virtual {v4}, Lcom/google/android/mms/pdu/PduPart;->getContentType()[B

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/String;-><init>([B)V

    .line 2271
    invoke-static {v5}, Lcom/android/mms/drm/DrmUtils;->isDrmType(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1

    .line 2274
    invoke-static {p1, p2}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v4, v5}, Lcom/android/mms/ui/ComposeMessageActivity;->copyPart(Lcom/google/android/mms/pdu/PduPart;Ljava/lang/String;)Z

    move-result v4

    and-int/2addr v3, v4

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    return v3
.end method

.method private sendMessage(Z)V
    .locals 6
    .line 7772
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->checkMessageSizeExceeded()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p0, "MessageSizeExceeded"

    .line 7773
    invoke-static {p0}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    return-void

    :cond_0
    const/4 v0, 0x1

    if-eqz p1, :cond_1

    const-string p1, "ril.cdma.inecmmode"

    .line 7779
    invoke-static {p1}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 7780
    invoke-static {p1}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_1

    .line 7783
    :try_start_0
    new-instance p1, Landroid/content/Intent;

    const-string v1, "com.android.internal.intent.action.ACTION_SHOW_NOTICE_ECM_BLOCK_OTHERS"

    const/4 v2, 0x0

    invoke-direct {p1, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const-string v1, "EXIT_ECBM"

    .line 7784
    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/16 v1, 0x6b

    .line 7785
    invoke-virtual {p0, p1, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivityForResult(Landroid/content/Intent;I)V

    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    const-string v1, "Mms"

    const-string v2, "Cannot find EmergencyCallbackModeExitDialog"

    .line 7792
    invoke-static {v1, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 7799
    :cond_1
    :goto_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result p1

    if-eqz p1, :cond_2

    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    .line 7800
    invoke-virtual {p1}, Lcom/android/mms/ui/RecipientsEditor;->isFocused()Z

    move-result p1

    if-eqz p1, :cond_2

    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 7801
    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result p1

    if-nez p1, :cond_2

    .line 7802
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->requestFocus()Z

    .line 7805
    :cond_2
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendingMessage:Z

    if-nez p1, :cond_8

    .line 7807
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/mms/data/ContactList;->serialize()Ljava/lang/String;

    move-result-object p1

    .line 7808
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDebugRecipients:Ljava/lang/String;

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    .line 7809
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->getWorkingRecipients()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_3

    .line 7810
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDebugRecipients:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    .line 7811
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "ComposeMessageActivity.sendMessage recipients in window: \""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDebugRecipients:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\" differ from recipients from conv: \""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\" and working recipients: "

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, p0}, Lcom/android/mms/LogTag;->warnPossibleRecipientMismatch(Ljava/lang/String;Landroid/app/Activity;)V

    .line 7818
    :cond_3
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->sanityCheckConversation()V

    .line 7823
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->removeRecipientsListeners()V

    .line 7827
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->getResendMultiRecipients()Z

    move-result p1

    if-eqz p1, :cond_4

    .line 7833
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResendSmsRecipient:Ljava/lang/String;

    goto :goto_1

    .line 7841
    :cond_4
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDebugRecipients:Ljava/lang/String;

    :goto_1
    const-string v1, ";"

    .line 7846
    invoke-static {p1, v1}, Landroid/text/TextUtils;->split(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 7848
    array-length v2, v1

    const/4 v3, 0x0

    if-le v2, v0, :cond_5

    .line 7849
    invoke-static {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getIsGroupMmsEnabled(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_5

    move v2, v0

    goto :goto_2

    :cond_5
    move v2, v3

    .line 7848
    :goto_2
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .line 7851
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "numbers length = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length v5, v1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, " ,isMMS ="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v5}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v5, " ,isGroupMMS"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v5, "TAG"

    invoke-static {v5, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 7852
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_6

    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v2}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v2

    if-eqz v2, :cond_7

    :cond_6
    invoke-static {v1, v3}, Lcom/android/mms/util/FdnUtils;->isMMSAllowedByFdn([Ljava/lang/String;I)Z

    move-result v1

    if-nez v1, :cond_7

    .line 7853
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object p0

    invoke-virtual {p0}, Lcom/android/mms/MmsApp;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const p1, 0x7f0e00ea    # @string/fdn_check_failure 'You can only send messages to your Fixed Dialling Numbers'

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void

    .line 7857
    :cond_7
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v1, p1}, Lcom/android/mms/data/WorkingMessage;->send(Ljava/lang/String;)V

    .line 7859
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSentMessage:Z

    .line 7860
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendingMessage:Z

    .line 7861
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->addRecipientsListeners()V

    .line 7863
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mScrollOnSend:Z

    .line 7866
    :cond_8
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    if-nez p1, :cond_9

    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMailboxMode()Z

    move-result p1

    if-eqz p1, :cond_a

    .line 7867
    :cond_9
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->finish()V

    :cond_a
    return-void
.end method

.method public static sendMms(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const-wide/16 v0, 0x0

    .line 10391
    invoke-static {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->createIntent(Landroid/content/Context;J)Landroid/content/Intent;

    move-result-object v0

    .line 10392
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "mmsto:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    .line 10393
    invoke-virtual {v0, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const-string p1, "com.android.mms.ui.ForwardMessageActivity"

    .line 10394
    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 10396
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private sendMsimMessage(ZI)V
    .locals 2

    .line 1439
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "sendMsimMessage subscription: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    .line 1440
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0, p2}, Lcom/android/mms/data/WorkingMessage;->setWorkingMessageSub(I)V

    .line 1441
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMessage(Z)V

    return-void
.end method

.method private sendMsimMessageNotPrompt(ZZI)V
    .locals 0

    .line 1672
    invoke-direct {p0, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->isMmsWithMobileDataOff(ZI)Z

    move-result p2

    if-eqz p2, :cond_0

    .line 1673
    invoke-direct {p0, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->showMobileDataDisabledDialog(I)V

    goto :goto_0

    .line 1675
    :cond_0
    invoke-direct {p0, p1, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMsimMessage(ZI)V

    :goto_0
    return-void
.end method

.method public static sendSms(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const-wide/16 v0, 0x0

    .line 10382
    invoke-static {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->createIntent(Landroid/content/Context;J)Landroid/content/Intent;

    move-result-object v0

    .line 10383
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "smsto:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    .line 10384
    invoke-virtual {v0, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const-string p1, "com.android.mms.ui.ForwardMessageActivity"

    .line 10385
    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 10387
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private setActionBarColor(I)V
    .locals 0

    .line 9793
    sput p1, Lcom/android/mms/ui/ComposeMessageActivity;->mActionBarColor:I

    return-void
.end method

.method private setAttachmentSelectorHeight()V
    .locals 4

    .line 5011
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    .line 5012
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPager:Landroidx/viewpager/widget/ViewPager;

    invoke-virtual {v1}, Landroidx/viewpager/widget/ViewPager;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout$LayoutParams;

    .line 5014
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    const/high16 v3, 0x42b60000    # 91.0f

    mul-float/2addr v2, v3

    const/high16 v3, 0x3f000000    # 0.5f

    add-float/2addr v2, v3

    float-to-int v2, v2

    .line 5015
    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v3, 0x1

    if-ne v0, v3, :cond_0

    mul-int/lit8 v2, v2, 0x2

    :cond_0
    iput v2, v1, Landroid/widget/FrameLayout$LayoutParams;->height:I

    .line 5017
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPager:Landroidx/viewpager/widget/ViewPager;

    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private setBackgroundWallpaper()V
    .locals 4

    .line 9721
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "chat_wallpaper"

    const/4 v2, 0x0

    .line 9722
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 9724
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_0

    .line 9726
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 9725
    invoke-static {v0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 9729
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    new-instance v1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-direct {v1, v0}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/graphics/Bitmap;)V

    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessageListView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    return-void
.end method

.method private setFocusToAttachmentView(I)V
    .locals 0

    .line 10306
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/MoreAttachmentView;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_0

    .line 10309
    invoke-virtual {p0}, Landroid/view/View;->requestFocus()Z

    :cond_0
    return-void
.end method

.method private setImageLoadedCallback()V
    .locals 1

    .line 8329
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0, p0}, Lcom/android/mms/ui/MessageListAdapter;->setOnImageLoaded(Lcom/android/mms/ui/MessageListAdapter$OnImageLoaded;)V

    return-void
.end method

.method private setMessageBodyLoadedCallback()V
    .locals 1

    .line 8335
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0, p0}, Lcom/android/mms/ui/MessageListAdapter;->setOnMessageBodyLoaded(Lcom/android/mms/ui/MessageListAdapter$OnMessageBodyLoaded;)V

    return-void
.end method

.method private setNewMessageSubject(Lcom/android/mms/data/WorkingMessage;)V
    .locals 1

    if-eqz p1, :cond_0

    .line 5257
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasSubject()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 5258
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->getSubject()Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v0, 0x1

    invoke-virtual {p1, p0, v0}, Lcom/android/mms/data/WorkingMessage;->setSubject(Ljava/lang/CharSequence;Z)V

    :cond_0
    return-void
.end method

.method private setSendButtonImage()V
    .locals 4

    const/4 v0, 0x0

    .line 8026
    invoke-static {v0}, Lcom/android/mms/data/Contact;->getMe(Z)Lcom/android/mms/data/Contact;

    move-result-object v0

    .line 8027
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->sDefaultContactImage:Landroid/graphics/drawable/Drawable;

    if-nez v1, :cond_0

    .line 8028
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f070075    # @drawable/default_avatar 'res/drawable/default_avatar.xml'

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    sput-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->sDefaultContactImage:Landroid/graphics/drawable/Drawable;

    .line 8030
    :cond_0
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->sDefaultContactImage:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p0, v1}, Lcom/android/mms/data/Contact;->getAvatar(Landroid/content/Context;Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAvatarDrawable:Landroid/graphics/drawable/Drawable;

    .line 8031
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->sDefaultContactImage:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const v1, 0x7f070169    # @drawable/send_arrow_background 'res/drawable/send_arrow_background.xml'

    if-eqz v0, :cond_2

    .line 8032
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v0

    const v2, 0x7f07016a    # @drawable/send_button_selector 'res/drawable/send_button_selector.xml'

    if-eqz v0, :cond_1

    .line 8033
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 8035
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 8037
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    sget-object v0, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {p0, v0}, Landroid/widget/ImageButton;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    goto/16 :goto_0

    .line 8039
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 8041
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 8043
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    sget-object v0, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {p0, v0}, Landroid/widget/ImageButton;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    goto/16 :goto_0

    .line 8046
    :cond_2
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v0

    const v2, 0x7f0700fb    # @drawable/ic_send 'res/drawable/ic_send.xml'

    const/4 v3, 0x0

    if-eqz v0, :cond_4

    .line 8047
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 8048
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    sget-object v3, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, v3}, Landroid/widget/ImageButton;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 8049
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 8050
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    .line 8053
    :cond_3
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    sget-object v1, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 8054
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAvatarDrawable:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 8055
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {p0, v3}, Landroid/widget/ImageButton;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    .line 8058
    :cond_4
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_5

    .line 8059
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    sget-object v3, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, v3}, Landroid/widget/ImageButton;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 8060
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 8061
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    .line 8064
    :cond_5
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    sget-object v1, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 8065
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAvatarDrawable:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 8066
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {p0, v3}, Landroid/widget/ImageButton;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    return-void
.end method

.method private setTextFontsize()V
    .locals 5

    .line 9734
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->getFontSize()I

    move-result v0

    .line 9735
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    if-eqz v1, :cond_0

    int-to-float v2, v0

    .line 9736
    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setTextSize(F)V

    .line 9738
    :cond_0
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    if-eqz v1, :cond_1

    int-to-float v2, v0

    .line 9739
    invoke-virtual {v1, v2}, Lcom/android/mms/ui/MessageListAdapter;->setTextSize(F)V

    .line 9742
    :cond_1
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    if-eqz v1, :cond_3

    .line 9743
    invoke-virtual {v1}, Lcom/android/mms/ui/MessageListView;->getVisibility()I

    move-result v1

    if-nez v1, :cond_3

    .line 9744
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v1}, Lcom/android/mms/ui/MessageListView;->getChildCount()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_3

    .line 9746
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    .line 9747
    invoke-virtual {v3, v2}, Lcom/android/mms/ui/MessageListView;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Lcom/android/mms/ui/MessageListItem;

    if-eqz v3, :cond_2

    int-to-float v4, v0

    .line 9749
    invoke-virtual {v3, v4}, Lcom/android/mms/ui/MessageListItem;->setBodyTextSize(F)V

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method

.method private showAddAttachementButton()Z
    .locals 2

    .line 4809
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowAttachIcon:Z

    const/4 v1, 0x1

    if-nez v0, :cond_0

    .line 4810
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->hasAttachment()Z

    move-result p0

    xor-int/2addr p0, v1

    return p0

    .line 4812
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->hasVcard()Z

    move-result v0

    if-nez v0, :cond_1

    .line 4813
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSlideNumber()I

    move-result p0

    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxSlideNumber()I

    move-result v0

    if-ge p0, v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method private showAirplaneModeDialog()V
    .locals 8

    const/4 v0, 0x0

    new-array v1, v0, [Ljava/lang/Object;

    const-string v2, "showAirplaneModeDialog"

    .line 1691
    invoke-static {v2, v1}, Lcom/android/mms/LogTag;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1692
    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 1693
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v2

    const v3, 0x7f0a001e    # @layout/airplane_dialog 'res/layout/airplane_dialog.xml'

    const/4 v4, 0x0

    .line 1694
    invoke-virtual {v2, v3, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v2

    const v3, 0x7f0801d4    # @id/tv_title

    .line 1695
    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    .line 1696
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0038    # @string/airplane_on_title 'No Network Connection'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v3, 0x7f0801d3    # @id/tv_content

    .line 1697
    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TctDialogMessage;

    .line 1698
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0037    # @string/airplane_on_text 'Would you like to send when digital service is unavailable?'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/TctDialogMessage;->setText(Ljava/lang/CharSequence;)V

    .line 1700
    new-instance v3, Landroid/view/ViewGroup$LayoutParams;

    const/4 v5, -0x1

    const/4 v6, -0x2

    invoke-direct {v3, v5, v6}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 1704
    new-instance v7, Lcom/android/mms/ui/ComposeMessageActivity$12;

    invoke-direct {v7, p0}, Lcom/android/mms/ui/ComposeMessageActivity$12;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v1, v7}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    .line 1731
    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    const/16 v7, 0xe

    .line 1733
    invoke-virtual {v1, v7}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 1734
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    .line 1736
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {v1, v2, v3}, Landroid/app/Dialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1737
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {v1, p0}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 1739
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v1

    const v2, 0x7f0e0196    # @string/no 'Cancel'

    const v3, 0x7f0e0301    # @string/yes 'OK'

    .line 1740
    invoke-virtual {v1, v2, v0, v3, v4}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    .line 1742
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    .line 1743
    invoke-virtual {p0, v5, v6}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x50

    .line 1746
    invoke-virtual {p0, v0}, Landroid/view/Window;->setGravity(I)V

    const v0, 0x106000d    # @android:color/transparent

    .line 1747
    invoke-virtual {p0, v0}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    const/high16 v0, 0x3f000000

    .line 1748
    invoke-virtual {p0, v0}, Landroid/view/Window;->setDimAmount(F)V

    return-void
.end method

.method private showAttachmentSelector(Z)V
    .locals 8

    const v0, 0x7f080046    # @id/attachments_selector_pager

    .line 4928
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/viewpager/widget/ViewPager;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPager:Landroidx/viewpager/widget/ViewPager;

    .line 4929
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsReplaceAttachment:Z

    const/4 v0, 0x0

    .line 4930
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCurrentAttachmentPager:I

    .line 4931
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->hideKeyboard()V

    .line 4932
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPagerAdapter:Lcom/android/mms/ui/AttachmentPagerAdapter;

    if-nez v1, :cond_0

    .line 4933
    new-instance v1, Lcom/android/mms/ui/AttachmentPagerAdapter;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/AttachmentPagerAdapter;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPagerAdapter:Lcom/android/mms/ui/AttachmentPagerAdapter;

    .line 4936
    :cond_0
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMmsEnabled()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    if-eqz v1, :cond_1

    .line 4937
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isSubjectEditorVisible()Z

    move-result v1

    if-nez v1, :cond_1

    const/4 v1, 0x1

    move v7, v1

    goto :goto_0

    :cond_1
    move v7, v0

    .line 4941
    :goto_0
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPagerAdapter:Lcom/android/mms/ui/AttachmentPagerAdapter;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->hasAttachment()Z

    move-result v3

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 4942
    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->hasVcard()Z

    move-result v4

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->hasSlideshow()Z

    move-result v5

    move v6, p1

    .line 4941
    invoke-virtual/range {v2 .. v7}, Lcom/android/mms/ui/AttachmentPagerAdapter;->setExistAttachmentType(ZZZZZ)V

    .line 4943
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPagerAdapter:Lcom/android/mms/ui/AttachmentPagerAdapter;

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$43;

    invoke-direct {v2, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$43;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Z)V

    invoke-virtual {v1, v2}, Lcom/android/mms/ui/AttachmentPagerAdapter;->setGridItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 4957
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setAttachmentSelectorHeight()V

    .line 4958
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPager:Landroidx/viewpager/widget/ViewPager;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPagerAdapter:Lcom/android/mms/ui/AttachmentPagerAdapter;

    invoke-virtual {p1, v1}, Landroidx/viewpager/widget/ViewPager;->setAdapter(Landroidx/viewpager/widget/PagerAdapter;)V

    .line 4959
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPager:Landroidx/viewpager/widget/ViewPager;

    iget-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRTL:Z

    invoke-virtual {p1, v1}, Landroidx/viewpager/widget/ViewPager;->setCurrentItem(I)V

    .line 4960
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRTL:Z

    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCurrentAttachmentPager:I

    .line 4961
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPager:Landroidx/viewpager/widget/ViewPager;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentPagerChangeListener:Landroidx/viewpager/widget/ViewPager$OnPageChangeListener;

    invoke-virtual {p1, v1}, Landroidx/viewpager/widget/ViewPager;->setOnPageChangeListener(Landroidx/viewpager/widget/ViewPager$OnPageChangeListener;)V

    .line 4962
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 4964
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHandler:Landroid/os/Handler;

    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$44;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$44;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    const-wide/16 v1, 0xc8

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private showConvertToMmsToast()V
    .locals 2

    const v0, 0x7f0e0090    # @string/converting_to_picture_message 'Converting to multimedia message...'

    .line 1188
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 1189
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    if-nez v1, :cond_0

    const/4 v1, 0x0

    .line 1190
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    goto :goto_0

    .line 1192
    :cond_0
    invoke-virtual {v1, v0}, Landroid/widget/Toast;->setText(Ljava/lang/CharSequence;)V

    .line 1194
    :goto_0
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private showConvertToSmsToast()V
    .locals 2

    const v0, 0x7f0e0091    # @string/converting_to_text_message 'Converting to text message...'

    .line 1198
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 1199
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    if-nez v1, :cond_0

    const/4 v1, 0x0

    .line 1200
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    goto :goto_0

    .line 1202
    :cond_0
    invoke-virtual {v1, v0}, Landroid/widget/Toast;->setText(Ljava/lang/CharSequence;)V

    .line 1204
    :goto_0
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private showDeliveryReport(JLjava/lang/String;)V
    .locals 2

    .line 2600
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/DeliveryReportActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "message_id"

    .line 2601
    invoke-virtual {v0, v1, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string p1, "message_type"

    .line 2602
    invoke-virtual {v0, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 2603
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private showDisCardDraftDialog()V
    .locals 5

    .line 4215
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->disCardDraftDialog:Landroid/app/TctDialog;

    if-eqz v0, :cond_0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/app/TctDialog;->isShowing()Z

    move-result v0

    if-nez v0, :cond_1

    .line 4216
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->DialogKeyListener:Landroid/content/DialogInterface$OnKeyListener;

    .line 4217
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getValidNumCount()I

    move-result v1

    .line 4216
    invoke-static {p0, v0, v1}, Lcom/android/mms/ui/MessageUtils;->getDiscardDraftConfirmDialog(Landroid/content/Context;Landroid/content/DialogInterface$OnKeyListener;I)Landroid/app/TctDialog;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->disCardDraftDialog:Landroid/app/TctDialog;

    .line 4218
    invoke-virtual {v0}, Landroid/app/TctDialog;->show()V

    .line 4219
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->disCardDraftDialog:Landroid/app/TctDialog;

    invoke-virtual {v0}, Landroid/app/TctDialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v0

    const v1, 0x7f0e0196    # @string/no 'Cancel'

    const/4 v2, 0x0

    const v3, 0x7f0e0301    # @string/yes 'OK'

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    const/4 v0, 0x1

    .line 4220
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->discardDialogShow:Z

    :cond_1
    return-void
.end method

.method private showDisableLTEOnlyDialog(I)V
    .locals 2

    .line 1472
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "com.qualcomm.qti.phonefeature.DISABLE_TDD_LTE"

    .line 1473
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "slot"

    .line 1474
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 1475
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private showEmptyTextError()Z
    .locals 4

    .line 7624
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v0

    const v1, 0x7f0e02ce    # @string/text_empty_error 'Please enter the content to send'

    const-string v2, ""

    const/4 v3, 0x0

    if-nez v0, :cond_1

    .line 7626
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 7628
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 7629
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    if-nez v1, :cond_0

    .line 7630
    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    goto :goto_0

    .line 7632
    :cond_0
    invoke-virtual {v1, v0}, Landroid/widget/Toast;->setText(Ljava/lang/CharSequence;)V

    .line 7634
    :goto_0
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return v3

    .line 7640
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    if-eqz v0, :cond_2

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    :cond_2
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 7641
    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    if-nez v0, :cond_4

    .line 7643
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 7644
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    if-nez v1, :cond_3

    .line 7645
    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    goto :goto_1

    .line 7647
    :cond_3
    invoke-virtual {v1, v0}, Landroid/widget/Toast;->setText(Ljava/lang/CharSequence;)V

    .line 7649
    :goto_1
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return v3

    :cond_4
    const/4 p0, 0x1

    return p0
.end method

.method private showImportTemplateDialog()Landroid/app/Dialog;
    .locals 7

    const-string v0, "content://com.android.mms.MessageTemplateProvider/messages"

    .line 4729
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const/4 v0, 0x0

    .line 4732
    :try_start_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-eqz v1, :cond_1

    .line 4733
    :try_start_1
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v0, 0x0

    .line 4735
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    new-array v2, v2, [Ljava/lang/String;

    :goto_0
    const-string v3, "message"

    .line 4738
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    add-int/lit8 v4, v0, 0x1

    .line 4739
    aput-object v3, v2, v0

    .line 4740
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-nez v0, :cond_0

    move-object v0, v2

    goto :goto_1

    :cond_0
    move v0, v4

    goto :goto_0

    :catchall_0
    move-exception p0

    move-object v0, v1

    goto :goto_2

    :cond_1
    :goto_1
    if-eqz v1, :cond_2

    .line 4744
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 4748
    :cond_2
    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$TemplateSelectListener;

    invoke-direct {v1, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$TemplateSelectListener;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;[Ljava/lang/String;)V

    .line 4749
    new-instance v2, Landroid/app/AlertDialog$Builder;

    invoke-direct {v2, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const p0, 0x7f0e0168    # @string/message_template 'Message template'

    .line 4750
    invoke-virtual {v2, p0}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 4751
    invoke-virtual {p0, v0, v1}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 4752
    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p0

    return-object p0

    :catchall_1
    move-exception p0

    :goto_2
    if-eqz v0, :cond_3

    .line 4744
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 4746
    :cond_3
    throw p0
.end method

.method private showInvalidCopyDialog()V
    .locals 2

    .line 8821
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const p0, 0x7f0e009b    # @string/copy_to_sim_fail 'Saved failed'

    .line 8822
    invoke-virtual {v0, p0}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    const v0, 0x7f0e005b    # @string/cannot_copy_to_sim_reason 'Your message has no valid recipients.'

    .line 8823
    invoke-virtual {p0, v0}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    const v0, 0x7f0e0301    # @string/yes 'OK'

    const/4 v1, 0x0

    .line 8824
    invoke-virtual {p0, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 8825
    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private showInvalidRecipientDialog()V
    .locals 1

    const/4 v0, -0x1

    .line 1642
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->showInvalidRecipientDialog(I)V

    return-void
.end method

.method private showInvalidRecipientDialog(I)V
    .locals 3

    .line 1646
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result p1

    .line 1647
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {v0, p1}, Lcom/android/mms/ui/RecipientsEditor;->getValidRecipientsCount(Z)I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, -0x1

    if-le v0, v2, :cond_0

    const v0, 0x7f0e00fb    # @string/has_invalid_recipient 'Invalid recipient(s): <%1$s>'

    .line 1649
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    .line 1650
    invoke-virtual {v2, p1}, Lcom/android/mms/ui/RecipientsEditor;->formatInvalidNumbers(Z)Ljava/lang/String;

    move-result-object p1

    .line 1649
    invoke-direct {p0, v0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getResourcesString(ILjava/lang/String;)Ljava/lang/String;

    const-string p1, "invalid_recipient"

    .line 1659
    invoke-direct {p0, p1, v1, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->alertDialog(Ljava/lang/String;Lcom/android/mms/ui/MessageItem;Ljava/lang/Runnable;)V

    goto :goto_0

    :cond_0
    const-string p1, "dialog_invalid"

    .line 1666
    invoke-direct {p0, p1, v1, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->alertDialog(Ljava/lang/String;Lcom/android/mms/ui/MessageItem;Ljava/lang/Runnable;)V

    :goto_0
    return-void
.end method

.method private showMessageDetails(Lcom/android/mms/ui/MessageItem;)Z
    .locals 4

    .line 934
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0, p1}, Lcom/android/mms/ui/MessageListAdapter;->getCursorForItem(Lcom/android/mms/ui/MessageItem;)Landroid/database/Cursor;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 938
    :cond_0
    iget-object v2, p1, Lcom/android/mms/ui/MessageItem;->mSubject:Ljava/lang/String;

    if-nez v2, :cond_1

    goto :goto_0

    :cond_1
    iget-object v1, p1, Lcom/android/mms/ui/MessageItem;->mSubject:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    array-length v1, v1

    .line 939
    :goto_0
    iget p1, p1, Lcom/android/mms/ui/MessageItem;->mMessageSize:I

    add-int/2addr p1, v1

    .line 941
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "showMessageDetails subjectSize = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Mms"

    invoke-static {v2, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 942
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "showMessageDetails messageSize = "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 944
    invoke-static {p0, v0, p1}, Lcom/android/mms/ui/MessageUtils;->getMessageDetails(Landroid/content/Context;Landroid/database/Cursor;I)Ljava/lang/String;

    move-result-object p1

    .line 946
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v1, 0x7f0e015c    # @string/message_details_title 'Message details'

    .line 947
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 948
    invoke-virtual {v0, p1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const/4 v0, 0x1

    .line 949
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    .line 950
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgDetailDialog:Landroid/app/AlertDialog;

    return v0
.end method

.method private showMessageReport(Lcom/android/mms/ui/MessageItem;)V
    .locals 4

    .line 10037
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/MessageReportActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 10038
    iget v1, p1, Lcom/android/mms/ui/MessageItem;->mMessageSize:I

    const-string v2, "message_size"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 10039
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageItem;->getMessageId()J

    move-result-wide v1

    const-string v3, "message_id"

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 10040
    iget-object v1, p1, Lcom/android/mms/ui/MessageItem;->mType:Ljava/lang/String;

    const-string v2, "message_type"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 10041
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageItem;->isSending()Z

    move-result v1

    const-string v2, "is_sending"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 10042
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v1, p1}, Lcom/android/mms/ui/MessageListAdapter;->getCursorForItem(Lcom/android/mms/ui/MessageItem;)Landroid/database/Cursor;

    move-result-object p1

    if-nez p1, :cond_0

    return-void

    .line 10048
    :cond_0
    sput-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mCurrentSelectedCursor:Landroid/database/Cursor;

    .line 10049
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private showMobileDataDisabledDialog()V
    .locals 1

    const/4 v0, -0x1

    .line 1686
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->showMobileDataDisabledDialog(I)V

    return-void
.end method

.method private showMobileDataDisabledDialog(I)V
    .locals 3

    .line 1755
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "showMobileDataDisabledDialog subscription: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v1}, Lcom/android/mms/LogTag;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1757
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowMobileDataDialog:Landroid/app/TctDialog;

    if-eqz v0, :cond_0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/app/TctDialog;->isShowing()Z

    move-result v0

    if-nez v0, :cond_1

    .line 1758
    :cond_0
    new-instance v0, Landroid/app/TctDialog;

    invoke-direct {v0, p0}, Landroid/app/TctDialog;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowMobileDataDialog:Landroid/app/TctDialog;

    const v1, 0x7f0e0185    # @string/mobile_data_disable 'Mobile data is turned off. Still send MMS? If yes, it will generate mobile data traffic.'

    .line 1759
    invoke-virtual {v0, v1}, Landroid/app/TctDialog;->setMessage(I)Landroid/app/TctDialog;

    .line 1760
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowMobileDataDialog:Landroid/app/TctDialog;

    const v1, 0x7f0e0196    # @string/no 'Cancel'

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$13;

    invoke-direct {v2, p0}, Lcom/android/mms/ui/ComposeMessageActivity$13;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/TctDialog;->setLeftButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/TctDialog;

    .line 1766
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowMobileDataDialog:Landroid/app/TctDialog;

    const v1, 0x7f0e0301    # @string/yes 'OK'

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$14;

    invoke-direct {v2, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$14;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;I)V

    invoke-virtual {v0, v1, v2}, Landroid/app/TctDialog;->setRightButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/TctDialog;

    .line 1779
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowMobileDataDialog:Landroid/app/TctDialog;

    invoke-virtual {p0}, Landroid/app/TctDialog;->show()V

    :cond_1
    return-void
.end method

.method private showSmsOrMmsSendButton(Z)Landroid/view/View;
    .locals 3

    const/16 v0, 0x8

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    .line 4370
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    .line 4371
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    .line 4372
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMmsText:Landroid/widget/TextView;

    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_0

    .line 4374
    :cond_0
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    .line 4375
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    .line 4376
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMmsText:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 4378
    :goto_0
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 4379
    invoke-virtual {v2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 4380
    invoke-virtual {v2, v1}, Landroid/view/View;->setEnabled(Z)V

    return-object p1
.end method

.method private showSubjectEditor(Z)V
    .locals 5

    const-string v0, "Mms"

    const/4 v1, 0x2

    .line 2996
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 2997
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 3001
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    if-nez v0, :cond_2

    if-nez p1, :cond_1

    return-void

    :cond_1
    const v0, 0x7f0801ae    # @id/subject_text

    .line 3007
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    const v0, 0x7f0801ab    # @id/subject

    .line 3008
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    const/4 v2, 0x1

    new-array v2, v2, [Landroid/text/InputFilter;

    .line 3009
    new-instance v3, Landroid/text/InputFilter$LengthFilter;

    sget v4, Lcom/android/mms/ui/ComposeMessageActivity;->SUBJECT_MAX_LENGTH:I

    invoke-direct {v3, v4}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    aput-object v3, v2, v1

    invoke-virtual {v0, v2}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    :cond_2
    const v0, 0x7f0801ad    # @id/subject_lable

    .line 3012
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectLable:Landroid/widget/TextView;

    .line 3013
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    if-eqz p1, :cond_3

    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectKeyListener:Landroid/view/View$OnKeyListener;

    goto :goto_0

    :cond_3
    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0, v2}, Landroid/widget/EditText;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 3015
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$25;

    invoke-direct {v2, p0}, Lcom/android/mms/ui/ComposeMessageActivity$25;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    if-eqz p1, :cond_4

    .line 3038
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectEditorWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v0, v2}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    goto :goto_1

    .line 3040
    :cond_4
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectEditorWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v0, v2}, Landroid/widget/EditText;->removeTextChangedListener(Landroid/text/TextWatcher;)V

    .line 3041
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-static {v0}, Landroid/text/method/TextKeyListener;->clear(Landroid/text/Editable;)V

    .line 3044
    :goto_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v2}, Lcom/android/mms/data/WorkingMessage;->getSubject()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 3045
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    const/16 v2, 0x8

    if-eqz p1, :cond_5

    move v3, v1

    goto :goto_2

    :cond_5
    move v3, v2

    :goto_2
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 3046
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDeviderView:Landroid/view/View;

    if-eqz p1, :cond_6

    goto :goto_3

    :cond_6
    move v1, v2

    :goto_3
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 3047
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->hideOrShowTopPanel()V

    return-void
.end method

.method private showTwoSmsOrMmsSendButton(Z)[Landroid/view/View;
    .locals 4

    const/4 v0, 0x2

    new-array v1, v0, [Landroid/view/View;

    new-array v0, v0, [Landroid/view/View;

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    .line 4389
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutMmsFir:Landroid/view/View;

    aput-object p1, v1, v3

    .line 4390
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutMmsSec:Landroid/view/View;

    aput-object p1, v1, v2

    .line 4391
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutSmsFir:Landroid/view/View;

    aput-object p1, v0, v3

    .line 4392
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutSmsSec:Landroid/view/View;

    aput-object p0, v0, v2

    goto :goto_0

    .line 4394
    :cond_0
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutSmsFir:Landroid/view/View;

    aput-object p1, v1, v3

    .line 4395
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutSmsSec:Landroid/view/View;

    aput-object p1, v1, v2

    .line 4396
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutMmsFir:Landroid/view/View;

    aput-object p1, v0, v3

    .line 4397
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutMmsSec:Landroid/view/View;

    aput-object p0, v0, v2

    .line 4399
    :goto_0
    aget-object p0, v1, v3

    invoke-virtual {p0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 4400
    aget-object p0, v1, v2

    invoke-virtual {p0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 4401
    aget-object p0, v0, v3

    const/16 p1, 0x8

    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 4402
    aget-object p0, v0, v2

    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    return-object v1
.end method

.method private smoothScrollToEnd(ZI)V
    .locals 11

    .line 8217
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-boolean v0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    if-nez v0, :cond_0

    .line 8218
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListView;->requestFocus()Z

    .line 8221
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "listSizeChange = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "mmsjump"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 8222
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListView;->getLastVisiblePosition()I

    move-result v0

    .line 8223
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v1}, Lcom/android/mms/ui/MessageListAdapter;->getCount()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    .line 8225
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 8226
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v3, v1}, Lcom/android/mms/ui/MessageListView;->setSelection(I)V

    .line 8227
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v3, v1}, Lcom/android/mms/ui/MessageListView;->smoothScrollToPosition(I)V

    :cond_1
    const-string v3, "Mms"

    if-ltz v0, :cond_f

    if-gez v1, :cond_2

    goto/16 :goto_6

    .line 8238
    :cond_2
    iget-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    .line 8239
    invoke-virtual {v4}, Lcom/android/mms/ui/MessageListView;->getFirstVisiblePosition()I

    move-result v5

    sub-int v5, v0, v5

    invoke-virtual {v4, v5}, Lcom/android/mms/ui/MessageListView;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v5, 0x0

    if-eqz v4, :cond_3

    .line 8243
    invoke-virtual {v4}, Landroid/view/View;->getBottom()I

    move-result v6

    .line 8244
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result v4

    goto :goto_0

    :cond_3
    move v4, v5

    move v6, v4

    .line 8248
    :goto_0
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "smoothScrollToEnd newPosition: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, " mLastSmoothScrollPosition: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v8, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastSmoothScrollPosition:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, " first: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v8, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    .line 8250
    invoke-virtual {v8}, Lcom/android/mms/ui/MessageListView;->getFirstVisiblePosition()I

    move-result v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, " lastItemVisible: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, " lastVisibleItemBottom: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, " lastVisibleItemBottom + listSizeChange: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int v8, v6, p2

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, " mMsgListView.getHeight() - mMsgListView.getPaddingBottom(): "

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v9, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    .line 8256
    invoke-virtual {v9}, Lcom/android/mms/ui/MessageListView;->getHeight()I

    move-result v9

    iget-object v10, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v10}, Lcom/android/mms/ui/MessageListView;->getPaddingBottom()I

    move-result v10

    sub-int/2addr v9, v10

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, " listSizeChange: "

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 8248
    invoke-static {v3, v7}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 8272
    iget-object v7, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v7}, Lcom/android/mms/ui/MessageListView;->getHeight()I

    move-result v7

    if-le v4, v7, :cond_4

    move v9, v2

    goto :goto_1

    :cond_4
    move v9, v5

    :goto_1
    if-nez p1, :cond_7

    if-nez p2, :cond_5

    .line 8274
    iget p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastSmoothScrollPosition:I

    if-eq v1, p1, :cond_6

    :cond_5
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    .line 8277
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageListView;->getPaddingBottom()I

    move-result p1

    sub-int p1, v7, p1

    if-gt v8, p1, :cond_6

    goto :goto_2

    :cond_6
    move v2, v5

    :cond_7
    :goto_2
    if-nez v2, :cond_9

    if-eqz v9, :cond_8

    if-ne v1, v0, :cond_8

    goto :goto_3

    :cond_8
    if-ne v6, v7, :cond_e

    if-nez p2, :cond_e

    .line 8321
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setImageLoadedCallback()V

    .line 8322
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setMessageBodyLoadedCallback()V

    goto/16 :goto_5

    .line 8279
    :cond_9
    :goto_3
    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result p1

    const/16 p2, 0xc8

    if-le p1, p2, :cond_b

    .line 8284
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "keyboard state changed. setSelection="

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v9, :cond_a

    .line 8291
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    sub-int/2addr v7, v4

    invoke-virtual {p0, v1, v7}, Lcom/android/mms/ui/MessageListView;->setSelectionFromTop(II)V

    goto :goto_5

    .line 8294
    :cond_a
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessageListView;->setSelection(I)V

    goto :goto_5

    :cond_b
    sub-int p1, v1, v0

    const/16 p2, 0x14

    if-le p1, p2, :cond_c

    .line 8298
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "too many to scroll, setSelection="

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 8300
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessageListView;->setSelection(I)V

    goto :goto_5

    .line 8303
    :cond_c
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "smooth scroll to "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v9, :cond_d

    .line 8311
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    sub-int/2addr v7, v4

    invoke-virtual {p1, v1, v7}, Lcom/android/mms/ui/MessageListView;->setSelectionFromTop(II)V

    goto :goto_4

    .line 8314
    :cond_d
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {p1, v1}, Lcom/android/mms/ui/MessageListView;->smoothScrollToPosition(I)V

    .line 8316
    :goto_4
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setImageLoadedCallback()V

    .line 8317
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setMessageBodyLoadedCallback()V

    .line 8318
    iput v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastSmoothScrollPosition:I

    :cond_e
    :goto_5
    return-void

    .line 8232
    :cond_f
    :goto_6
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "smoothScrollToEnd: lastItemVisible="

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ", lastItemInList="

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ", mMsgListView not ready"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v3, p0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private startAvailabilityFetch(Ljava/lang/String;)Z
    .locals 2

    .line 9999
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "startAvailabilityFetch   number "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mms"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 10000
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mService:Lorg/codeaurora/presenceserv/IPresenceService;

    if-eqz p0, :cond_0

    .line 10003
    :try_start_0
    invoke-interface {p0, p1}, Lorg/codeaurora/presenceserv/IPresenceService;->invokeAvailabilityFetch(Ljava/lang/String;)Z

    move-result p0

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    move-exception p0

    .line 10006
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "getVTCapOfContact ERROR "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private startMsgListQuery()V
    .locals 3

    .line 7432
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->messageListQueryRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 7434
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->isFirstQuery:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mLastItemDeleted:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 7437
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHandler:Landroid/os/Handler;

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->messageListQueryRunnable:Ljava/lang/Runnable;

    const-wide/16 v1, 0xc8

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_1

    .line 7435
    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHandler:Landroid/os/Handler;

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->messageListQueryRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_1
    return-void
.end method

.method private startMsgListQuery(I)V
    .locals 9

    .line 7443
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    if-nez v0, :cond_2

    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMailboxMode()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 7446
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getUri()Landroid/net/Uri;

    move-result-object v4

    if-nez v4, :cond_1

    const-string p0, "##### startMsgListQuery: conversationUri is null, bail!"

    .line 7449
    invoke-static {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    return-void

    .line 7453
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v0

    .line 7460
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBackgroundQueryHandler:Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;

    invoke-virtual {v2, p1}, Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;->cancelOperation(I)V

    .line 7463
    :try_start_0
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBackgroundQueryHandler:Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;

    .line 7465
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    sget-object v5, Lcom/android/mms/ui/MessageListAdapter;->PROJECTION:[Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v1, v2

    move v2, p1

    .line 7463
    invoke-virtual/range {v1 .. v8}, Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;->startQuery(ILjava/lang/Object;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 7470
    invoke-static {p0, p1}, Landroid/database/sqlite/SqliteWrapper;->checkSQLiteException(Landroid/content/Context;Landroid/database/sqlite/SQLiteException;)V

    :cond_2
    :goto_0
    return-void
.end method

.method private toSendWhenInvalidSim()V
    .locals 2

    const-string v0, "phone"

    .line 7164
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    .line 7166
    invoke-static {}, Lcom/android/mms/util/ImsConnectionManager;->isImsRegistered()Z

    move-result v0

    .line 7167
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isIccCardActivated()Z

    move-result v1

    if-eqz v1, :cond_0

    if-nez v0, :cond_1

    .line 7168
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded()V

    :cond_1
    return-void
.end method

.method private declared-synchronized unRegRecipientsWatcher()V
    .locals 2

    monitor-enter p0

    .line 10849
    :try_start_0
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRegistered:Z

    if-eqz v0, :cond_0

    .line 10850
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->removeTextChangedListener(Landroid/text/TextWatcher;)V

    const/4 v0, 0x0

    .line 10851
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRegistered:Z

    .line 10853
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    :cond_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private unbindPresenceService(Landroid/content/Context;)V
    .locals 4

    const-string v0, "Mms"

    const-string v1, "PresenceService unbindService"

    .line 9983
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 9984
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mService:Lorg/codeaurora/presenceserv/IPresenceService;

    if-eqz v1, :cond_0

    .line 9986
    :try_start_0
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCallback:Lorg/codeaurora/presenceserv/IPresenceServiceCB;

    invoke-interface {v1, v2}, Lorg/codeaurora/presenceserv/IPresenceService;->unregisterCallback(Lorg/codeaurora/presenceserv/IPresenceServiceCB;)V

    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    .line 9988
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "PresenceService unregister error "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 9991
    :cond_0
    :goto_0
    iget-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsPresenceServiceBound:Z

    if-eqz v1, :cond_1

    const-string v1, "PresenceService unbind"

    .line 9992
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 9993
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConnection:Landroid/content/ServiceConnection;

    invoke-virtual {p1, v0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 p1, 0x0

    .line 9994
    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsPresenceServiceBound:Z

    :cond_1
    return-void
.end method

.method private updateAttachmentSelectorIndicator(I)V
    .locals 4

    .line 4990
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    const v1, 0x7f08012b    # @id/pager_indicator_first

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    .line 4992
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    const v2, 0x7f08012c    # @id/pager_indicator_second

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    .line 4995
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRTL:Z

    const v2, 0x7f07007c    # @drawable/dot_chosen 'res/drawable-hdpi/dot_chosen.png'

    const v3, 0x7f07007d    # @drawable/dot_unchosen 'res/drawable-hdpi/dot_unchosen.png'

    if-eqz p0, :cond_2

    if-nez p1, :cond_0

    move p0, v2

    goto :goto_0

    :cond_0
    move p0, v3

    .line 4996
    :goto_0
    invoke-virtual {v1, p0}, Landroid/widget/ImageView;->setImageResource(I)V

    if-nez p1, :cond_1

    move v2, v3

    .line 4998
    :cond_1
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void

    :cond_2
    if-nez p1, :cond_3

    move p0, v2

    goto :goto_1

    :cond_3
    move p0, v3

    .line 5003
    :goto_1
    invoke-virtual {v0, p0}, Landroid/widget/ImageView;->setImageResource(I)V

    if-nez p1, :cond_4

    move v2, v3

    .line 5005
    :cond_4
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void
.end method

.method private updateAttachmentSize(I)V
    .locals 1

    .line 10356
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateAttachmentViewPosition()V

    .line 10359
    div-int/lit16 p1, p1, 0x400

    if-nez p1, :cond_0

    const/4 p1, 0x1

    .line 10363
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "KB"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 10365
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/MoreAttachmentView;->setSize(Ljava/lang/String;)V

    return-void
.end method

.method private updateAttachmentView(I)V
    .locals 3

    .line 10315
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MoreAttachmentView;->getCount()I

    move-result v0

    .line 10316
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "updateAttachmentView count = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Mms"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x0

    if-lez v0, :cond_1

    .line 10318
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentViewer:Landroid/widget/RelativeLayout;

    invoke-virtual {v2, v1}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 10319
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v2, v1}, Lcom/android/mms/ui/MoreAttachmentView;->setVisibility(I)V

    .line 10320
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateAttachmentViewPosition()V

    :goto_0
    if-ge v1, v0, :cond_2

    if-gt p1, v1, :cond_0

    .line 10324
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v2, v1}, Lcom/android/mms/ui/MoreAttachmentView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 10326
    invoke-virtual {v2, v1}, Landroid/view/View;->setId(I)V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 10333
    :cond_1
    iput v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->attachsizeTemp:I

    .line 10334
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentViewer:Landroid/widget/RelativeLayout;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 10335
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MoreAttachmentView;->setVisibility(I)V

    :cond_2
    return-void
.end method

.method private updateAttachmentViewPosition()V
    .locals 3

    .line 10341
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 10343
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    .line 10344
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    const/16 v0, 0x42

    invoke-virtual {p0, v0, v2, v2, v2}, Lcom/android/mms/ui/MoreAttachmentView;->setPadding(IIII)V

    goto :goto_0

    .line 10345
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_1

    .line 10346
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    const/16 v0, 0x27

    invoke-virtual {p0, v0, v2, v2, v2}, Lcom/android/mms/ui/MoreAttachmentView;->setPadding(IIII)V

    goto :goto_0

    .line 10347
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result v0

    if-le v0, v1, :cond_2

    .line 10348
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {p0, v1, v2, v2, v2}, Lcom/android/mms/ui/MoreAttachmentView;->setPadding(IIII)V

    :cond_2
    :goto_0
    return-void
.end method

.method private updateColorPalette(I)V
    .locals 1

    .line 9756
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->determinePalette(I)Lcom/android/mms/util/MaterialColorMapUtils$MaterialPalette;

    move-result-object p1

    .line 9759
    iget v0, p1, Lcom/android/mms/util/MaterialColorMapUtils$MaterialPalette;->mPrimaryColor:I

    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAccentColor:I

    .line 9760
    iget p1, p1, Lcom/android/mms/util/MaterialColorMapUtils$MaterialPalette;->mSecondaryColor:I

    iput p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mStatusBarColor:I

    .line 9761
    iget p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAccentColor:I

    sput p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendContactColor:I

    return-void
.end method

.method private updateCounter(Ljava/lang/CharSequence;III)V
    .locals 3

    .line 1056
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 1057
    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    if-le p3, p4, :cond_0

    move p3, v2

    goto :goto_0

    :cond_0
    move p3, v1

    :goto_0
    if-nez p3, :cond_2

    .line 1063
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz p1, :cond_1

    .line 1064
    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result p1

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showTwoSmsOrMmsSendButton(Z)[Landroid/view/View;

    goto :goto_1

    .line 1066
    :cond_1
    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result p1

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showSmsOrMmsSendButton(Z)Landroid/view/View;

    :goto_1
    return-void

    .line 1073
    :cond_2
    invoke-static {p1, v1}, Landroid/telephony/SmsMessage;->calculateLength(Ljava/lang/CharSequence;Z)[I

    move-result-object p1

    .line 1080
    aget p3, p1, v1

    const/4 p4, 0x2

    .line 1081
    aget p1, p1, p4

    .line 1082
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMultipartSmsEnabled()Z

    move-result p4

    if-nez p4, :cond_4

    .line 1085
    iget-object p4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    if-le p3, v2, :cond_3

    move v0, v2

    goto :goto_2

    :cond_3
    move v0, v1

    :goto_2
    invoke-virtual {p4, v0, v2}, Lcom/android/mms/data/WorkingMessage;->setLengthRequiresMms(ZZ)V

    goto :goto_4

    .line 1087
    :cond_4
    invoke-static {p0}, Lcom/android/mms/MmsConfig;->getSmsToMmsTextThreshold(Landroid/content/Context;)I

    move-result p4

    .line 1090
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isTMO()Z

    move-result v0

    if-nez v0, :cond_5

    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isDISH()Z

    move-result v0

    if-eqz v0, :cond_6

    :cond_5
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->is911Recipient()Z

    move-result v0

    if-eqz v0, :cond_6

    const/4 p4, -0x1

    .line 1095
    :cond_6
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    if-lez p4, :cond_7

    if-le p3, p4, :cond_7

    move p4, v2

    goto :goto_3

    :cond_7
    move p4, v1

    :goto_3
    invoke-virtual {v0, p4, v2}, Lcom/android/mms/data/WorkingMessage;->setLengthRequiresMms(ZZ)V

    .line 1104
    :goto_4
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isUSCC()Z

    move-result p4

    if-eqz p4, :cond_8

    if-ne p3, v2, :cond_8

    move p4, v2

    goto :goto_5

    :cond_8
    move p4, v1

    .line 1109
    :goto_5
    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v0

    if-nez v0, :cond_a

    if-gt p3, v2, :cond_9

    const/16 v0, 0xa

    if-gt p1, v0, :cond_a

    :cond_9
    move p4, v2

    .line 1115
    :cond_a
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz v0, :cond_b

    .line 1116
    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result p2

    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->showTwoSmsOrMmsSendButton(Z)[Landroid/view/View;

    goto :goto_6

    .line 1118
    :cond_b
    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result p2

    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->showSmsOrMmsSendButton(Z)Landroid/view/View;

    :goto_6
    if-eqz p4, :cond_d

    if-le p3, v2, :cond_c

    .line 1123
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " / "

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_7

    .line 1124
    :cond_c
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    .line 1133
    :goto_7
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1134
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1135
    iget-boolean p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz p2, :cond_f

    .line 1136
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounterSec:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1137
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounterSec:Landroid/widget/TextView;

    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_9

    .line 1141
    :cond_d
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result p1

    const/16 p2, 0x8

    if-eqz p1, :cond_e

    .line 1143
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    const p3, 0x7f0e016e    # @string/mms 'MMS'

    invoke-virtual {p0, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1144
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_8

    .line 1146
    :cond_e
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    const-string p3, ""

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1147
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1149
    :goto_8
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz p1, :cond_f

    .line 1150
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounterSec:Landroid/widget/TextView;

    invoke-virtual {p0, p2}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_f
    :goto_9
    return-void
.end method

.method private updateMenuOption()V
    .locals 16

    move-object/from16 v0, p0

    .line 7942
    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    if-eqz v1, :cond_7

    invoke-virtual {v1}, Landroid/widget/EditText;->hasFocus()Z

    move-result v1

    if-eqz v1, :cond_7

    iget-boolean v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mDiscardDialog:Z

    if-nez v1, :cond_7

    iget-boolean v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mErrorDiscardDialog:Z

    if-nez v1, :cond_7

    .line 7943
    invoke-direct/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->initMenuBar()V

    .line 7944
    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->canSending()Z

    move-result v1

    const/16 v3, 0x12

    const v4, 0x7f0e0136    # @string/menu_call 'Call'

    const/16 v5, 0xd

    const/16 v6, 0x8

    const v7, 0x7f0e0031    # @string/add_subject 'Add subject'

    const/16 v8, 0xe

    const v9, 0x7f0e002c    # @string/add_attachment_go 'Add attachment'

    const/4 v10, 0x5

    const v11, 0x7f0e011e    # @string/menu_action_cancel_edit 'Cancel edit'

    const/4 v12, 0x4

    const v13, 0x7f0e0120    # @string/menu_action_clear_all 'Clear all'

    const/4 v14, 0x2

    const/4 v15, 0x1

    if-eqz v1, :cond_3

    .line 7945
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 7946
    new-instance v2, Landroid/util/Pair;

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-direct {v2, v14, v13}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7948
    new-instance v2, Landroid/util/Pair;

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-direct {v2, v12, v11}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7949
    new-instance v2, Landroid/util/Pair;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-direct {v2, v10, v9}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7950
    iget-object v2, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_0

    if-eqz v2, :cond_1

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v2

    if-ne v2, v6, :cond_1

    .line 7951
    :cond_0
    new-instance v2, Landroid/util/Pair;

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v2, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7953
    :cond_1
    new-instance v2, Landroid/util/Pair;

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v7, 0x7f0e012c    # @string/menu_action_send 'Send'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v2, v6, v8}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7954
    sget-boolean v2, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    if-nez v2, :cond_2

    invoke-direct/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientCallable()Z

    move-result v2

    if-eqz v2, :cond_2

    .line 7955
    new-instance v2, Landroid/util/Pair;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-direct {v2, v5, v4}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7957
    invoke-static/range {p0 .. p0}, Lcom/android/mms/ui/MessageUtils;->shouldShowRttCallMenu(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_2

    .line 7958
    new-instance v2, Landroid/util/Pair;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const v4, 0x7f0e014e    # @string/menu_rtt_call 'RTT Call'

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7962
    :cond_2
    sget-object v2, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v7}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v15, v0}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    .line 7963
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {v0, v1}, Landroid/widget/MenuBar;->setOptionMenu(Ljava/util/List;)V

    goto/16 :goto_0

    .line 7965
    :cond_3
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 7966
    new-instance v2, Landroid/util/Pair;

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-direct {v2, v14, v13}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7968
    new-instance v2, Landroid/util/Pair;

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-direct {v2, v12, v11}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7969
    new-instance v2, Landroid/util/Pair;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-direct {v2, v10, v9}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7970
    iget-object v2, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_4

    if-eqz v2, :cond_5

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v2

    if-ne v2, v6, :cond_5

    .line 7971
    :cond_4
    new-instance v2, Landroid/util/Pair;

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v2, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7973
    :cond_5
    sget-boolean v2, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    if-nez v2, :cond_6

    invoke-direct/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientCallable()Z

    move-result v2

    if-eqz v2, :cond_6

    .line 7974
    new-instance v2, Landroid/util/Pair;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-direct {v2, v5, v4}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7976
    invoke-static/range {p0 .. p0}, Lcom/android/mms/ui/MessageUtils;->shouldShowRttCallMenu(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 7977
    new-instance v0, Landroid/util/Pair;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const v3, 0x7f0e014e    # @string/menu_rtt_call 'RTT Call'

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-direct {v0, v2, v3}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7981
    :cond_6
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    const/4 v2, 0x0

    invoke-virtual {v0, v15, v2}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    .line 7982
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {v0, v1}, Landroid/widget/MenuBar;->setOptionMenu(Ljava/util/List;)V

    :cond_7
    :goto_0
    return-void
.end method

.method private updateMmsSizeIndicator()V
    .locals 1

    .line 5263
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentEditorHandler:Landroid/os/Handler;

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mUpdateMmsSizeIndRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private updateSendButtonState()V
    .locals 6

    .line 7997
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result v0

    .line 8001
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->requiresMms()Z

    move-result v1

    .line 8002
    iget-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz v2, :cond_1

    .line 8003
    invoke-direct {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->showTwoSmsOrMmsSendButton(Z)[Landroid/view/View;

    move-result-object v1

    const/4 v2, 0x0

    .line 8004
    aget-object v3, v1, v2

    iget-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutMmsFir:Landroid/view/View;

    const/4 v5, 0x1

    if-ne v3, v4, :cond_0

    aget-object v3, v1, v5

    iget-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutMmsSec:Landroid/view/View;

    if-ne v3, v4, :cond_0

    .line 8006
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {v1, v0}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 8007
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMmsViewSec:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 8008
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    invoke-virtual {v1, v0}, Landroid/widget/ImageButton;->setFocusable(Z)V

    .line 8009
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMmsViewSec:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setFocusable(Z)V

    goto :goto_0

    .line 8010
    :cond_0
    aget-object v2, v1, v2

    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutSmsFir:Landroid/view/View;

    if-ne v2, v3, :cond_2

    aget-object v1, v1, v5

    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendLayoutSmsSec:Landroid/view/View;

    if-ne v1, v2, :cond_2

    .line 8012
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {v1, v0}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 8013
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSmsViewSec:Landroid/widget/ImageButton;

    invoke-virtual {v1, v0}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 8014
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    invoke-virtual {v1, v0}, Landroid/widget/ImageButton;->setFocusable(Z)V

    .line 8015
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSmsViewSec:Landroid/widget/ImageButton;

    invoke-virtual {v1, v0}, Landroid/widget/ImageButton;->setFocusable(Z)V

    goto :goto_0

    .line 8018
    :cond_1
    invoke-direct {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->showSmsOrMmsSendButton(Z)Landroid/view/View;

    move-result-object v1

    .line 8019
    invoke-virtual {v1, v0}, Landroid/view/View;->setEnabled(Z)V

    .line 8020
    invoke-virtual {v1, v0}, Landroid/view/View;->setFocusable(Z)V

    .line 8022
    :cond_2
    :goto_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setSendButtonImage()V

    return-void
.end method

.method private updateSendFailedNotification()V
    .locals 4

    .line 3430
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-gtz v2, :cond_0

    return-void

    .line 3436
    :cond_0
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lcom/android/mms/ui/ComposeMessageActivity$26;

    invoke-direct {v3, p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity$26;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;J)V

    const-string p0, "ComposeMessageActivity.updateSendFailedNotification"

    invoke-direct {v2, v3, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 3442
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private updateThemeColors(II)V
    .locals 7

    .line 9766
    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/ColorDrawable;-><init>()V

    const/4 v1, 0x2

    new-array v2, v1, [I

    .line 9767
    iget v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAccentColor:I

    const/4 v4, 0x0

    aput v3, v2, v4

    const/4 v3, 0x1

    aput p1, v2, v3

    const-string p1, "color"

    invoke-static {v0, p1, v2}, Landroid/animation/ObjectAnimator;->ofInt(Ljava/lang/Object;Ljava/lang/String;[I)Landroid/animation/ObjectAnimator;

    move-result-object p1

    .line 9769
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getWindow()Landroid/view/Window;

    move-result-object v2

    new-array v5, v1, [I

    iget v6, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mStatusBarColor:I

    aput v6, v5, v4

    aput p2, v5, v3

    const-string p2, "statusBarColor"

    invoke-static {v2, p2, v5}, Landroid/animation/ObjectAnimator;->ofInt(Ljava/lang/Object;Ljava/lang/String;[I)Landroid/animation/ObjectAnimator;

    move-result-object p2

    .line 9772
    new-instance v2, Landroid/animation/ArgbEvaluator;

    invoke-direct {v2}, Landroid/animation/ArgbEvaluator;-><init>()V

    invoke-virtual {p1, v2}, Landroid/animation/ObjectAnimator;->setEvaluator(Landroid/animation/TypeEvaluator;)V

    .line 9773
    new-instance v2, Landroid/animation/ArgbEvaluator;

    invoke-direct {v2}, Landroid/animation/ArgbEvaluator;-><init>()V

    invoke-virtual {p2, v2}, Landroid/animation/ObjectAnimator;->setEvaluator(Landroid/animation/TypeEvaluator;)V

    const v2, 0x7f0800bd    # @id/header

    .line 9774
    invoke-virtual {p0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 9776
    new-instance v0, Landroid/animation/AnimatorSet;

    invoke-direct {v0}, Landroid/animation/AnimatorSet;-><init>()V

    new-array v1, v1, [Landroid/animation/Animator;

    aput-object p1, v1, v4

    aput-object p2, v1, v3

    .line 9777
    invoke-virtual {v0, v1}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    .line 9778
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isResumed()Z

    move-result p0

    if-eqz p0, :cond_0

    const-wide/16 p0, 0xc8

    goto :goto_0

    :cond_0
    const-wide/16 p0, 0x0

    :goto_0
    invoke-virtual {v0, p0, p1}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    .line 9779
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    return-void
.end method

.method private updateThreadAttachType()V
    .locals 4

    .line 8667
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v0

    .line 8668
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object v2

    .line 8669
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3, v0, v1}, Lcom/android/mms/data/Conversation;->getLatestMessageAttachmentUri(Landroid/content/Context;J)Landroid/net/Uri;

    move-result-object v3

    .line 8668
    invoke-static {v2, v3}, Lcom/android/mms/data/Conversation;->getAttachmentInfo(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v2

    .line 8670
    invoke-static {v0, v1}, Lcom/android/mms/data/Conversation;->getUri(J)Landroid/net/Uri;

    move-result-object v0

    .line 8671
    new-instance v1, Landroid/content/ContentValues;

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    const-string v3, "attachment_info"

    .line 8672
    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 8673
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v2, 0x0

    invoke-virtual {p0, v0, v1, v2, v2}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    return-void
.end method

.method private updateThreadIdIfRunning()V
    .locals 3

    .line 8762
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRunning:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    if-eqz v0, :cond_0

    .line 8764
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "updateThreadIdIfRunning: threadId: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    .line 8765
    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mms"

    .line 8764
    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 8767
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p0}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v0

    invoke-static {v0, v1}, Lcom/android/mms/transaction/MessagingNotification;->setCurrentlyDisplayedThreadId(J)V

    :cond_0
    return-void
.end method

.method private updateTitle(Lcom/android/mms/data/ContactList;)V
    .locals 8

    .line 2663
    invoke-virtual {p1}, Lcom/android/mms/data/ContactList;->size()I

    move-result v0

    const v1, 0x7f09000c    # @integer/wap_push_address_index '1'

    const-string v2, ":"

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_5

    if-eq v0, v3, :cond_0

    const-string v1, ", "

    .line 2727
    invoke-virtual {p1, v1}, Lcom/android/mms/data/ContactList;->formatNames(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2728
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v5, 0x7f0d0005    # @plurals/recipient_count

    new-array v6, v3, [Ljava/lang/Object;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v6, v4

    invoke-virtual {v2, v5, v0, v6}, Landroid/content/res/Resources;->getQuantityString(II[Ljava/lang/Object;)Ljava/lang/String;

    goto/16 :goto_3

    .line 2688
    :cond_0
    invoke-virtual {p1, v4}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/mms/data/Contact;

    invoke-virtual {v5}, Lcom/android/mms/data/Contact;->getName()Ljava/lang/String;

    move-result-object v5

    .line 2690
    invoke-virtual {p1, v4}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/android/mms/data/Contact;

    invoke-virtual {v6}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object v6

    .line 2691
    invoke-static {v6}, Lcom/android/mms/ui/MessageUtils;->isWapPushNumber(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    .line 2692
    invoke-virtual {v6, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    .line 2693
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v7

    aget-object v6, v6, v7

    .line 2696
    :cond_1
    invoke-static {v5}, Lcom/android/mms/ui/MessageUtils;->isWapPushNumber(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_2

    .line 2697
    invoke-virtual {v5, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 2698
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v1

    aget-object v1, v2, v1

    goto :goto_0

    :cond_2
    move-object v1, v5

    .line 2701
    :goto_0
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextCounter:Landroid/widget/TextView;

    invoke-virtual {v2}, Landroid/widget/TextView;->isLayoutRtl()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_4

    .line 2704
    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/16 v5, 0x202d

    if-eqz v2, :cond_3

    .line 2706
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/mms/MmsApp;->getCurrentCountryIso()Ljava/lang/String;

    move-result-object v1

    .line 2705
    invoke-static {v6, v6, v1}, Landroid/telephony/PhoneNumberUtils;->formatNumber(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2707
    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-eq v2, v5, :cond_a

    .line 2708
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x202c

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_3

    .line 2712
    :cond_3
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/mms/MmsApp;->getCurrentCountryIso()Ljava/lang/String;

    move-result-object v2

    .line 2711
    invoke-static {v6, v6, v2}, Landroid/telephony/PhoneNumberUtils;->formatNumber(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2713
    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v2

    goto :goto_3

    .line 2718
    :cond_4
    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_a

    .line 2720
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/mms/MmsApp;->getCurrentCountryIso()Ljava/lang/String;

    move-result-object v2

    .line 2719
    invoke-static {v6, v6, v2}, Landroid/telephony/PhoneNumberUtils;->formatNumber(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    goto :goto_3

    :cond_5
    const/4 v5, 0x0

    .line 2667
    iget-object v6, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz v6, :cond_6

    .line 2668
    invoke-virtual {v6}, Lcom/android/mms/ui/RecipientsEditor;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    .line 2670
    :cond_6
    invoke-static {v5}, Lcom/android/mms/ui/MessageUtils;->isWapPushNumber(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_7

    .line 2671
    invoke-virtual {v5, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 2672
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v1

    aget-object v1, v2, v1

    goto :goto_3

    .line 2676
    :cond_7
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_9

    const-string v1, ","

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    const-string v1, ";"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8

    goto :goto_1

    :cond_8
    move-object v1, v5

    goto :goto_2

    :cond_9
    :goto_1
    const v1, 0x7f0e0190    # @string/new_message 'New message'

    .line 2677
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 2679
    :goto_2
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_a

    .line 2680
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContent:Landroid/widget/RelativeLayout;

    const/16 v5, 0x8

    invoke-virtual {v2, v5}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 2681
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    .line 2732
    :cond_a
    :goto_3
    invoke-virtual {p1}, Lcom/android/mms/data/ContactList;->serialize()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDebugRecipients:Ljava/lang/String;

    .line 2735
    iput v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mExistsRecipientsCount:I

    if-lt v0, v3, :cond_c

    .line 2739
    invoke-virtual {p1, v4}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/mms/data/Contact;

    .line 2740
    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->getContactColor()I

    move-result p1

    if-nez p1, :cond_b

    .line 2743
    sget p1, Lcom/android/mms/ui/ComposeMessageActivity;->sPrimaryColorDark:I

    .line 2746
    :cond_b
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->updateColorPalette(I)V

    .line 2747
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->setActionBarColor(I)V

    goto :goto_4

    .line 2749
    :cond_c
    sget p1, Lcom/android/mms/ui/ComposeMessageActivity;->sPrimaryColorDark:I

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->updateColorPalette(I)V

    .line 2750
    sget p1, Lcom/android/mms/ui/ComposeMessageActivity;->sPrimaryColorDark:I

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->setActionBarColor(I)V

    .line 2759
    :goto_4
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTitleText:Landroid/widget/TextView;

    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private updateTitleForRecipientsChange(Landroid/text/Editable;)V
    .locals 3

    .line 1870
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1871
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->constructContactAndUpdateTitle()V

    .line 1876
    :cond_0
    invoke-interface {p1}, Landroid/text/Editable;->length()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_2

    .line 1877
    invoke-interface {p1, v0}, Landroid/text/Editable;->charAt(I)C

    move-result v1

    const/16 v2, 0x20

    if-ne v1, v2, :cond_1

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    const/16 p1, 0x2c

    if-ne v1, p1, :cond_2

    .line 1882
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->constructContactAndUpdateTitle()V

    :cond_2
    return-void
.end method

.method private videoCallRecipient()V
    .locals 3

    .line 4486
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/mms/data/Contact;

    invoke-virtual {v0}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object v0

    .line 4487
    new-instance v1, Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getCallUri(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const-string v2, "android.intent.action.CALL"

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const-string v0, "android.telecom.extra.START_CALL_WITH_VIDEO_STATE"

    const/4 v2, 0x3

    .line 4488
    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4490
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private viewMmsMessageAttachment(I)V
    .locals 3

    .line 821
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 825
    invoke-virtual {v0}, Lcom/android/mms/model/SlideshowModel;->isSimple()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 826
    invoke-static {p0, v0}, Lcom/android/mms/ui/MessageUtils;->viewSimpleSlideshow(Landroid/content/Context;Lcom/android/mms/model/SlideshowModel;)V

    goto :goto_0

    .line 833
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;

    move-result-object v0

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$4;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$4;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    new-instance v2, Lcom/android/mms/ui/ComposeMessageActivity$5;

    invoke-direct {v2, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$5;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;I)V

    const p0, 0x7f0e0054    # @string/building_slideshow_title 'Building slideshow'

    invoke-virtual {v0, v1, v2, p0}, Lcom/android/mms/ui/AsyncDialog;->runAsync(Ljava/lang/Runnable;Ljava/lang/Runnable;I)V

    :goto_0
    return-void

    .line 823
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "mWorkingMessage.getSlideshow() == null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private waitForResizeImagesOrCompressVideo()V
    .locals 3

    const-string v0, "wait for "

    .line 6136
    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResizeImageCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " resize image finish. "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 6137
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mCompresVideoCount:I

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " compress video finish. "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 6138
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mObjectLock:Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/lang/Object;->wait()V

    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string p0, "Mms"

    const-string v0, "waitForResizeImagesOrCompressVideo InterruptedException"

    .line 6141
    invoke-static {p0, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    return-void
.end method


# virtual methods
.method public canSending()Z
    .locals 1

    .line 10376
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->recipientCount()I

    move-result v0

    if-lez v0, :cond_2

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    .line 10377
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-gtz v0, :cond_1

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getSubject()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-gtz v0, :cond_1

    :cond_0
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0}, Lcom/android/mms/data/WorkingMessage;->hasAttachment()Z

    move-result p0

    if-eqz p0, :cond_2

    :cond_1
    const/4 p0, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;
    .locals 1

    .line 5919
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

    if-nez v0, :cond_0

    .line 5920
    new-instance v0, Lcom/android/mms/ui/AsyncDialog;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/AsyncDialog;-><init>(Landroid/app/Activity;)V

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

    .line 5922
    :cond_0
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

    return-object p0
.end method

.method public getCallUri(Ljava/lang/String;)Landroid/net/Uri;
    .locals 1

    .line 4494
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->isUriNumber(Ljava/lang/String;)Z

    move-result p0

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    const-string p0, "sip"

    .line 4495
    invoke-static {p0, p1, v0}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    return-object p0

    :cond_0
    const-string p0, "tel"

    .line 4497
    invoke-static {p0, p1, v0}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    return-object p0
.end method

.method public initialize(Landroid/os/Bundle;J)V
    .locals 4

    .line 3058
    invoke-static {p0}, Lcom/android/mms/data/WorkingMessage;->createEmpty(Lcom/android/mms/ui/ComposeMessageActivity;)Lcom/android/mms/data/WorkingMessage;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 3060
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isAllowSendMmsOverWifi()Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendMmsSupportViaWiFi:Z

    .line 3064
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->initActivityState(Landroid/os/Bundle;)V

    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-eqz v2, :cond_0

    .line 3066
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    .line 3067
    invoke-virtual {v2}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v2

    cmp-long v2, p2, v2

    if-nez v2, :cond_0

    .line 3068
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "ComposeMessageActivity.initialize:  threadId didn\'t change from: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2, p0}, Lcom/android/mms/LogTag;->warnPossibleRecipientMismatch(Ljava/lang/String;Landroid/app/Activity;)V

    .line 3077
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object p2

    invoke-static {p2, p0}, Lcom/android/mms/ui/MessageUtils;->cancelFailedToDeliverNotification(Landroid/content/Intent;Landroid/content/Context;)Z

    move-result p2

    if-eqz p2, :cond_1

    const/4 p2, 0x0

    .line 3080
    invoke-direct {p0, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->getMessageDate(Landroid/net/Uri;)J

    move-result-wide p2

    invoke-virtual {p0, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->undeliveredMessageDialog(J)V

    .line 3082
    :cond_1
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object p2

    invoke-static {p2, p0}, Lcom/android/mms/ui/MessageUtils;->cancelFailedDownloadNotification(Landroid/content/Intent;Landroid/content/Context;)Z

    .line 3085
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->initMessageList()V

    const/4 p2, 0x1

    .line 3087
    iput-boolean p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShouldLoadDraft:Z

    const/4 p3, 0x0

    if-nez p1, :cond_3

    .line 3095
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->handleSendIntent()Z

    move-result p1

    if-nez p1, :cond_2

    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->handleForwardedMessage()Z

    move-result p1

    if-eqz p1, :cond_3

    .line 3096
    :cond_2
    iput-boolean p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShouldLoadDraft:Z

    .line 3100
    :cond_3
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1, v2}, Lcom/android/mms/data/WorkingMessage;->setConversation(Lcom/android/mms/data/Conversation;)V

    .line 3102
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->handleResendMessage()V

    .line 3105
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v2

    cmp-long p1, v2, v0

    if-gtz p1, :cond_4

    .line 3108
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->hideRecipientEditor()V

    .line 3109
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->initRecipientsEditor()V

    .line 3110
    sget p1, Lcom/android/mms/ui/ComposeMessageActivity;->sPrimaryColorDark:I

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->updateColorPalette(I)V

    .line 3111
    sget p1, Lcom/android/mms/ui/ComposeMessageActivity;->sPrimaryColorDark:I

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->setActionBarColor(I)V

    goto :goto_0

    .line 3113
    :cond_4
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->hideRecipientEditor()V

    .line 3116
    :goto_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateSendButtonState()V

    .line 3118
    invoke-direct {p0, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->drawTopPanel(Z)V

    .line 3119
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShouldLoadDraft:Z

    if-nez p1, :cond_5

    .line 3121
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->drawBottomPanel()V

    .line 3124
    :cond_5
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->onKeyboardStateChanged()V

    const/4 p1, 0x2

    const-string v0, "Mms"

    .line 3126
    invoke-static {v0, p1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_6

    .line 3127
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "update title, mConversation="

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 3130
    :cond_6
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->updateTitle(Lcom/android/mms/data/ContactList;)V

    .line 3138
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p0}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p0

    invoke-virtual {p0}, Lcom/android/mms/data/ContactList;->size()I

    move-result p0

    if-le p0, p2, :cond_7

    goto :goto_1

    :cond_7
    move p2, p3

    :goto_1
    invoke-virtual {p1, p2}, Lcom/android/mms/ui/MessageListAdapter;->setIsGroupConversation(Z)V

    return-void
.end method

.method public isUriNumber(Ljava/lang/String;)Z
    .locals 0

    if-eqz p1, :cond_1

    const-string p0, "@"

    .line 4501
    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_0

    const-string p0, "%40"

    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_1

    :cond_0
    const/4 p0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public loadMessageContent()V
    .locals 2

    .line 3398
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/android/mms/data/Conversation;->blockMarkAsRead(Z)V

    .line 3399
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->markAsRead()V

    .line 3400
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->startMsgListQuery()V

    .line 3401
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateSendFailedNotification()V

    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 7

    .line 5033
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_1

    .line 5034
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v0

    sput-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    .line 5035
    invoke-virtual {v0, p0}, Landroid/widget/MenuBar;->setMenuBarListener(Landroid/widget/MenuBar$MenuBarListener;)V

    .line 5037
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->recipientCount()I

    move-result v0

    if-lez v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    sput-boolean v0, Lcom/android/mms/ui/ComposeMessageActivity;->mHaveRecipients:Z

    .line 5041
    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "onActivityResult: requestCode="

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getRequestCode(I)I

    move-result v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, ", resultCode="

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, ", data="

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 5044
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWaitingForSubActivity:Z

    .line 5045
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShouldLoadDraft:Z

    .line 5046
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getRequestCode(I)I

    move-result v0

    .line 5047
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->isAppendRequest(I)Z

    move-result p1

    .line 5048
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v3}, Lcom/android/mms/data/WorkingMessage;->isFakeMmsForDraft()Z

    move-result v3

    if-eqz v3, :cond_2

    .line 5051
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v3}, Lcom/android/mms/data/WorkingMessage;->removeFakeMmsForDraft()V

    :cond_2
    const/16 v3, 0x6d

    if-ne v0, v3, :cond_3

    .line 5055
    iget-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    iget-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v4, v5}, Lcom/android/mms/data/WorkingMessage;->asyncDeleteDraftSmsMessage(Lcom/android/mms/data/Conversation;)V

    :cond_3
    const/16 v4, 0x6c

    if-ne v0, v4, :cond_5

    .line 5066
    iget-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddContactIntent:Landroid/content/Intent;

    if-eqz v5, :cond_5

    const-string v6, "email"

    .line 5068
    invoke-virtual {v5, v6}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_4

    .line 5070
    iget-object v5, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddContactIntent:Landroid/content/Intent;

    const-string v6, "phone"

    .line 5071
    invoke-virtual {v5, v6}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :cond_4
    if-eqz v5, :cond_5

    .line 5074
    invoke-static {v5, v2}, Lcom/android/mms/data/Contact;->get(Ljava/lang/String;Z)Lcom/android/mms/data/Contact;

    move-result-object v5

    if-eqz v5, :cond_5

    .line 5076
    invoke-virtual {v5}, Lcom/android/mms/data/Contact;->reload()V

    :cond_5
    const/4 v5, -0x1

    if-eq p2, v5, :cond_6

    .line 5083
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "bail due to resultCode="

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    return-void

    .line 5087
    :cond_6
    invoke-static {}, Lcom/android/mms/MmsConfig;->isCreationModeEnabled()Z

    move-result p2

    if-eqz p2, :cond_7

    .line 5088
    invoke-static {}, Lcom/android/mms/model/ContentRestrictionFactory;->reset()V

    :cond_7
    if-eq v0, v4, :cond_9

    if-eq v0, v3, :cond_9

    .line 5092
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    if-eqz p2, :cond_9

    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getSlideshow()Lcom/android/mms/model/SlideshowModel;

    move-result-object p2

    invoke-virtual {p2}, Lcom/android/mms/model/SlideshowModel;->size()I

    move-result p2

    const/16 v3, 0xa

    if-lt p2, v3, :cond_9

    const p1, 0x7f0e0056    # @string/can_not_add_attachments 'You are already at limit of %1$s attachments, no more may be added.'

    const/4 p2, 0x2

    new-array p2, p2, [Ljava/lang/Object;

    .line 5094
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMaxSlideNumber()I

    move-result p3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    aput-object p3, p2, v2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    aput-object p3, p2, v1

    .line 5093
    invoke-virtual {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    .line 5095
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    if-nez p2, :cond_8

    .line 5096
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    goto :goto_1

    .line 5098
    :cond_8
    invoke-virtual {p2, p1}, Landroid/widget/Toast;->setText(Ljava/lang/CharSequence;)V

    .line 5100
    :goto_1
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mToast:Landroid/widget/Toast;

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_9
    const/16 p2, 0x78

    if-eq v0, p2, :cond_f

    const-string p2, "audio"

    const-string v3, "video"

    const-string v4, "image"

    packed-switch v0, :pswitch_data_0

    packed-switch v0, :pswitch_data_1

    .line 5246
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "bail due to unknown requestCode="

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    goto/16 :goto_4

    :pswitch_0    # 0x70
    if-eqz p3, :cond_a

    .line 5226
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1, v1}, Lcom/android/mms/data/WorkingMessage;->removeAttachment(Z)V

    goto :goto_2

    :pswitch_1    # 0x6f
    if-eqz p3, :cond_10

    const-string p1, "vcard"

    .line 5239
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    .line 5240
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    invoke-static {p0, p2}, Lcom/android/mms/ui/MessageUtils;->getVcardUri(Landroid/content/Context;Landroid/net/Uri;)Landroid/net/Uri;

    move-result-object p2

    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->addVcard(Ljava/lang/String;Landroid/net/Uri;)V

    goto/16 :goto_4

    :cond_a
    :goto_2
    :pswitch_2    # 0x6e
    if-eqz p3, :cond_10

    .line 5230
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p2}, Lcom/android/mms/data/WorkingMessage;->getText()Ljava/lang/CharSequence;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, "info"

    .line 5231
    invoke-virtual {p3, p2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 5232
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p0, p1}, Lcom/android/mms/data/WorkingMessage;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_4

    :pswitch_3    # 0x6d
    if-eqz p3, :cond_10

    .line 5217
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz p1, :cond_10

    .line 5218
    invoke-direct {p0, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->processPickResult(Landroid/content/Intent;)V

    goto/16 :goto_4

    :pswitch_4    # 0x6b
    const-string p1, "exit_ecm_result"

    .line 5201
    invoke-virtual {p3, p1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    .line 5202
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "outOfEmergencyMode:"

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    if-eqz p1, :cond_10

    .line 5204
    invoke-direct {p0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->sendMessage(Z)V

    goto/16 :goto_4

    :pswitch_5    # 0x6a
    if-eqz p3, :cond_10

    .line 5108
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/android/mms/data/WorkingMessage;->load(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/net/Uri;)Lcom/android/mms/data/WorkingMessage;

    move-result-object p1

    if-eqz p1, :cond_10

    .line 5111
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->setNewMessageSubject(Lcom/android/mms/data/WorkingMessage;)V

    .line 5112
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    .line 5113
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1, p2}, Lcom/android/mms/data/WorkingMessage;->setConversation(Lcom/android/mms/data/Conversation;)V

    .line 5114
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateThreadIdIfRunning()V

    .line 5115
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateMmsSizeIndicator()V

    .line 5116
    invoke-direct {p0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->drawTopPanel(Z)V

    .line 5117
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->drawBottomPanel()V

    .line 5118
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateSendButtonState()V

    goto/16 :goto_4

    :pswitch_6    # 0x69
    if-eqz p3, :cond_10

    .line 5194
    iput-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    .line 5195
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    iget-object p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    invoke-direct {p0, p2, p1, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->addAudio(Landroid/net/Uri;ZLjava/lang/String;)V

    goto/16 :goto_4

    :pswitch_7    # 0x68
    const-string v0, "android.intent.extra.ringtone.PICKED_URI"

    .line 5179
    invoke-virtual {p3, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    if-nez v0, :cond_b

    .line 5181
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    goto :goto_3

    .line 5182
    :cond_b
    sget-object p3, Landroid/provider/Settings$System;->DEFAULT_RINGTONE_URI:Landroid/net/Uri;

    invoke-virtual {p3, v0}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_c

    goto/16 :goto_4

    .line 5186
    :cond_c
    :goto_3
    iput-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    .line 5187
    invoke-direct {p0, v0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->addAudio(Landroid/net/Uri;ZLjava/lang/String;)V

    .line 5188
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->drawBottomPanel()V

    goto/16 :goto_4

    .line 5156
    :pswitch_8    # 0x67
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSlideNumber()I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p2

    const-string p3, ".3gp"

    .line 5155
    invoke-static {p3, p2, p0}, Lcom/android/mms/TempFileProvider;->renameScrapFile(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)Landroid/net/Uri;

    move-result-object p2

    .line 5158
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object p3

    invoke-virtual {p3}, Lcom/android/mms/MmsApp;->getThumbnailManager()Lcom/android/mms/util/ThumbnailManager;

    move-result-object p3

    invoke-virtual {p3, p2}, Lcom/android/mms/util/ThumbnailManager;->removeThumbnail(Landroid/net/Uri;)V

    .line 5160
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isUSCC()Z

    move-result p3

    if-eqz p3, :cond_d

    const-string p3, "video/mp4"

    .line 5161
    invoke-direct {p0, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->savePicAndVideo(Landroid/net/Uri;Ljava/lang/String;)Z

    .line 5165
    :cond_d
    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    .line 5166
    invoke-direct {p0, p2, p1, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->addVideoAsync(Landroid/net/Uri;ZLjava/lang/String;)V

    goto :goto_4

    :pswitch_9    # 0x66
    if-eqz p3, :cond_10

    .line 5171
    iput-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    .line 5172
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    iget-object p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    invoke-direct {p0, p2, p1, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->addVideoAsync(Landroid/net/Uri;ZLjava/lang/String;)V

    goto :goto_4

    .line 5129
    :pswitch_a    # 0x65
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getSlideNumber()I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p2

    const-string p3, ".jpg"

    .line 5128
    invoke-static {p3, p2, p0}, Lcom/android/mms/TempFileProvider;->renameScrapFile(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)Landroid/net/Uri;

    move-result-object p2

    .line 5133
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isUSCC()Z

    move-result p3

    if-eqz p3, :cond_e

    const-string p3, "image/jpeg"

    .line 5134
    invoke-direct {p0, p2, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->savePicAndVideo(Landroid/net/Uri;Ljava/lang/String;)Z

    .line 5138
    :cond_e
    invoke-static {}, Lcom/android/mms/MmsApp;->getApplication()Lcom/android/mms/MmsApp;

    move-result-object p3

    invoke-virtual {p3}, Lcom/android/mms/MmsApp;->getThumbnailManager()Lcom/android/mms/util/ThumbnailManager;

    move-result-object p3

    invoke-virtual {p3, p2}, Lcom/android/mms/util/ThumbnailManager;->removeThumbnail(Landroid/net/Uri;)V

    .line 5140
    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    .line 5141
    invoke-direct {p0, p2, p1, v4}, Lcom/android/mms/ui/ComposeMessageActivity;->addImageAsync(Landroid/net/Uri;ZLjava/lang/String;)V

    goto :goto_4

    :pswitch_b    # 0x64
    if-eqz p3, :cond_10

    .line 5147
    iput-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    .line 5148
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    iget-object p3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttach_type:Ljava/lang/String;

    invoke-direct {p0, p2, p1, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->addImageAsync(Landroid/net/Uri;ZLjava/lang/String;)V

    goto :goto_4

    :cond_f
    if-eqz p3, :cond_10

    .line 5210
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz p1, :cond_10

    .line 5211
    invoke-direct {p0, p3}, Lcom/android/mms/ui/ComposeMessageActivity;->processPickGroupResult(Landroid/content/Intent;)V

    :cond_10
    :goto_4
    return-void

    :pswitch_data_0
    .packed-switch 0x64
        :pswitch_b    # 0x64
        :pswitch_a    # 0x65
        :pswitch_9    # 0x66
        :pswitch_8    # 0x67
        :pswitch_7    # 0x68
        :pswitch_6    # 0x69
        :pswitch_5    # 0x6a
        :pswitch_4    # 0x6b
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x6d
        :pswitch_3    # 0x6d
        :pswitch_2    # 0x6e
        :pswitch_1    # 0x6f
        :pswitch_0    # 0x70
    .end packed-switch
.end method

# overrides: Lcom/android/mms/data/WorkingMessage$MessageStatusListener;
.method public onAttachmentChanged()V
    .locals 1

    .line 4316
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$35;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$35;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

# overrides: Lcom/android/mms/data/WorkingMessage$MessageStatusListener;
.method public onAttachmentError(I)V
    .locals 1

    .line 4459
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$40;

    invoke-direct {v0, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$40;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;I)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 3

    .line 6384
    invoke-virtual {p1}, Landroid/view/View;->getLayoutDirection()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRTL:Z

    .line 6385
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    if-eq p1, v0, :cond_1

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMms:Landroid/widget/ImageButton;

    if-ne p1, v0, :cond_5

    :cond_1
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result v0

    if-eqz v0, :cond_5

    .line 6386
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSms:Landroid/widget/ImageButton;

    if-ne p1, v0, :cond_2

    const-string p1, "send SMS button clicked"

    .line 6387
    invoke-static {p1}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    goto :goto_1

    :cond_2
    const-string p1, "send MMS button clicked"

    .line 6389
    invoke-static {p1}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    .line 6392
    :goto_1
    :try_start_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/ui/MessageUtils;->isWfcUnavailable(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_3

    .line 6393
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/ui/MessageUtils;->pupConnectWifiAlertDialog(Landroid/content/Context;)V

    .line 6394
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/ui/MessageUtils;->pupConnectWifiNotification(Landroid/content/Context;)V

    const-string p1, "not send for pupConnectWifiAlertDialog"

    .line 6395
    invoke-static {p1}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    :try_end_0
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    .line 6399
    invoke-virtual {p1}, Landroid/provider/Settings$SettingNotFoundException;->printStackTrace()V

    .line 6401
    :cond_3
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz p1, :cond_4

    .line 6403
    invoke-static {v2}, Lcom/android/mmswrapper/SubscriptionManagerWrapper;->getSubId(I)[I

    move-result-object p1

    aget p1, p1, v2

    .line 6402
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded(I)V

    goto/16 :goto_2

    .line 6405
    :cond_4
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded()V

    goto/16 :goto_2

    .line 6407
    :cond_5
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonSmsViewSec:Landroid/widget/ImageButton;

    if-eq p1, v0, :cond_6

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendButtonMmsViewSec:Landroid/widget/TextView;

    if-ne p1, v0, :cond_7

    :cond_6
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    if-eqz v0, :cond_7

    .line 6408
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result v0

    if-eqz v0, :cond_7

    .line 6410
    invoke-static {v1}, Lcom/android/mmswrapper/SubscriptionManagerWrapper;->getSubId(I)[I

    move-result-object p1

    aget p1, p1, v2

    .line 6409
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded(I)V

    goto/16 :goto_2

    .line 6411
    :cond_7
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentButton:Landroid/widget/LinearLayout;

    if-ne p1, v0, :cond_8

    .line 6413
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->createListDialogOptions()V

    goto/16 :goto_2

    .line 6423
    :cond_8
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mClearButton:Landroid/widget/ImageButton;

    if-ne p1, v0, :cond_9

    .line 6424
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    const-string p1, ""

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/RecipientsEditor;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_2

    .line 6426
    :cond_9
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mOneText:Landroid/widget/TextView;

    if-ne p1, v0, :cond_d

    .line 6427
    iget p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialogMode:I

    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachMode:I

    if-ne p1, v0, :cond_a

    .line 6428
    invoke-direct {p0, v2, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentFP(IZ)V

    .line 6429
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6430
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    goto/16 :goto_2

    .line 6431
    :cond_a
    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageMode:I

    if-ne p1, v0, :cond_b

    .line 6432
    invoke-direct {p0, v2, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->ImaeAttach(IZ)V

    .line 6433
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6434
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    goto/16 :goto_2

    .line 6435
    :cond_b
    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoMode:I

    if-ne p1, v0, :cond_c

    .line 6436
    invoke-direct {p0, v2, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->VideoAttach(IZ)V

    .line 6437
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6438
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    goto/16 :goto_2

    .line 6439
    :cond_c
    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftMode:I

    if-ne p1, v0, :cond_13

    .line 6440
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v2, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftFP(ILjava/lang/Runnable;)V

    .line 6441
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6442
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    goto :goto_2

    .line 6444
    :cond_d
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTwoText:Landroid/widget/TextView;

    if-ne p1, v0, :cond_11

    .line 6445
    iget p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialogMode:I

    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachMode:I

    if-ne p1, v0, :cond_e

    .line 6446
    invoke-direct {p0, v1, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentFP(IZ)V

    .line 6447
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6448
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    goto :goto_2

    .line 6449
    :cond_e
    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageMode:I

    if-ne p1, v0, :cond_f

    .line 6450
    invoke-direct {p0, v1, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->ImaeAttach(IZ)V

    .line 6451
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6452
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    goto :goto_2

    .line 6453
    :cond_f
    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoMode:I

    if-ne p1, v0, :cond_10

    .line 6454
    invoke-direct {p0, v1, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->VideoAttach(IZ)V

    .line 6455
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6456
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    goto :goto_2

    .line 6457
    :cond_10
    iget v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftMode:I

    if-ne p1, v0, :cond_13

    .line 6458
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v1, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftFP(ILjava/lang/Runnable;)V

    .line 6459
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6460
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    goto :goto_2

    .line 6462
    :cond_11
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mThreeText:Landroid/widget/TextView;

    if-ne p1, v0, :cond_12

    const/4 p1, 0x2

    .line 6463
    invoke-direct {p0, p1, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentFP(IZ)V

    .line 6464
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6466
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    goto :goto_2

    .line 6468
    :cond_12
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mFourText:Landroid/widget/TextView;

    if-ne p1, v0, :cond_13

    const/4 p1, 0x3

    .line 6469
    invoke-direct {p0, p1, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->addAttachmentFP(IZ)V

    .line 6470
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 6471
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    :cond_13
    :goto_2
    return-void
.end method

.method public onClickCSK()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public onClickLSK()Z
    .locals 3

    .line 10630
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const v0, 0x7f0e014c    # @string/menu_reply 'Reply'

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {v2, v1}, Landroid/widget/MenuBar;->getSoftKeyName(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 10631
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContent:Landroid/widget/RelativeLayout;

    const/16 v2, 0x8

    invoke-virtual {v0, v2}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 10632
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBottomPanel:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 10633
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {p0}, Landroid/widget/EditText;->requestFocus()Z

    const/4 p0, 0x1

    return p0

    :cond_0
    return v1
.end method

.method public onClickRSK()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    .line 4016
    invoke-super {p0, p1}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 4018
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz v0, :cond_1

    .line 4019
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 4021
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    sget-object v1, Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;->PORTRAIT:Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setOrientation(Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;)V

    goto :goto_0

    .line 4023
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    sget-object v1, Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;->LANDSCAPE:Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/RecipientsEditor;->setOrientation(Lcom/android/ex/chips/RecipientEditTextView$ScreenOrientation;)V

    .line 4027
    :cond_1
    :goto_0
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->resetConfiguration(Landroid/content/res/Configuration;)Z

    move-result p1

    if-eqz p1, :cond_2

    .line 4030
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isSubjectEditorVisible()Z

    move-result p1

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->drawTopPanel(Z)V

    .line 4036
    :cond_2
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->onKeyboardStateChanged()V

    .line 4040
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInvalidRecipientDialog:Landroid/app/AlertDialog;

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Landroid/app/AlertDialog;->isShowing()Z

    move-result p1

    if-eqz p1, :cond_3

    .line 4041
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInvalidRecipientDialog:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 4042
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showInvalidRecipientDialog()V

    :cond_3
    const/4 p1, 0x0

    .line 4044
    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInvalidRecipientDialog:Landroid/app/AlertDialog;

    .line 4045
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    if-nez p1, :cond_4

    .line 4046
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setAttachmentSelectorHeight()V

    .line 4047
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->resetGridColumnsCount()V

    :cond_4
    return-void
.end method

# implemented-by: Lcom/android/mms/ui/ComposeMessageActivityNoLockScreen;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    .line 2884
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "composemessage oncreate() time is "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "mmstime"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2885
    invoke-static {p0}, Lcom/android/mms/MmsConfig;->isSmsEnabled(Landroid/content/Context;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    .line 2886
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 2887
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->checkPermissionsIfNeeded(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 2890
    :cond_0
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->checkIsPhoneMemoryFull(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 2891
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->finish()V

    return-void

    .line 2895
    :cond_1
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->resetConfiguration(Landroid/content/res/Configuration;)Z

    .line 2896
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0xe

    .line 2902
    invoke-virtual {v0, v1}, Landroid/view/Window;->requestFeature(I)Z

    const/4 v0, 0x0

    .line 2904
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->setProgressBarVisibility(Z)V

    .line 2905
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f040014    # @bool/config_show_attach_icon_always 'false'

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v1

    iput-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowAttachIcon:Z

    .line 2907
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f040005    # @bool/config_btnstyle 'false'

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_2

    .line 2908
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMsimIccCardActive()Z

    move-result v1

    if-eqz v1, :cond_2

    move v0, v2

    :cond_2
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    .line 2910
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->initResourceRefs()V

    .line 2912
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContentResolver:Landroid/content/ContentResolver;

    .line 2913
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mContentResolver:Landroid/content/ContentResolver;

    invoke-direct {v0, p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Landroid/content/ContentResolver;)V

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBackgroundQueryHandler:Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;

    const-wide/16 v0, 0x0

    .line 2915
    invoke-virtual {p0, p1, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->initialize(Landroid/os/Bundle;J)V

    .line 2917
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isVZW()Z

    move-result p1

    iput-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mEnablePresence:Z

    if-eqz p1, :cond_4

    .line 2919
    iget-boolean p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsPresenceServiceBound:Z

    if-nez p1, :cond_3

    .line 2920
    invoke-direct {p0, p0}, Lcom/android/mms/ui/ComposeMessageActivity;->bindPresenceService(Landroid/content/Context;)V

    .line 2922
    :cond_3
    new-instance p1, Lcom/android/mms/ui/ComposeMessageActivity$21;

    invoke-direct {p1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$21;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAvailabilityfetchHandler:Landroid/os/Handler;

    .line 2943
    :cond_4
    invoke-direct {p0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->loadMessagesAndDraft(I)V

    .line 2956
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->initFocus()V

    return-void
.end method

.method protected onCreateDialog(I)Landroid/app/Dialog;
    .locals 1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_0

    .line 4714
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreateDialog(I)Landroid/app/Dialog;

    move-result-object p0

    return-object p0

    .line 4712
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showImportTemplateDialog()Landroid/app/Dialog;

    move-result-object p0

    return-object p0
.end method

.method protected onDestroy()V
    .locals 2

    .line 3975
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mZoomGestureOverlayView:Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;

    if-eqz v0, :cond_0

    .line 3976
    invoke-virtual {v0, p0}, Lcom/android/mms/ui/zoom/ZoomGestureOverlayView;->removeZoomListener(Lcom/android/mms/ui/zoom/ZoomGestureOverlayView$IZoomListener;)V

    .line 3979
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    .line 3980
    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListAdapter;->changeCursor(Landroid/database/Cursor;)V

    .line 3981
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListAdapter;->cancelBackgroundLoading()V

    .line 3983
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListAdapter;->setOnMessageBodyLoaded(Lcom/android/mms/ui/MessageListAdapter$OnMessageBodyLoaded;)V

    .line 3984
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessageListAdapter;->setOnImageLoaded(Lcom/android/mms/ui/MessageListAdapter$OnImageLoaded;)V

    .line 3987
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInvalidRecipientDialog:Landroid/app/AlertDialog;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/app/AlertDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 3988
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInvalidRecipientDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V

    .line 3989
    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInvalidRecipientDialog:Landroid/app/AlertDialog;

    .line 3991
    :cond_2
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgDetailDialog:Landroid/app/AlertDialog;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/app/AlertDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 3992
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgDetailDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V

    .line 3993
    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgDetailDialog:Landroid/app/AlertDialog;

    .line 3996
    :cond_3
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mEnablePresence:Z

    if-eqz v0, :cond_4

    .line 3997
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsPresenceServiceBound:Z

    if-eqz v0, :cond_4

    .line 3998
    invoke-direct {p0, p0}, Lcom/android/mms/ui/ComposeMessageActivity;->unbindPresenceService(Landroid/content/Context;)V

    .line 4002
    :cond_4
    sput-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    .line 4003
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    if-eqz v0, :cond_5

    .line 4004
    invoke-virtual {v0, v1}, Landroid/widget/MenuBar;->setMenuBarListener(Landroid/widget/MenuBar$MenuBarListener;)V

    .line 4005
    sput-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    .line 4008
    :cond_5
    invoke-static {}, Lcom/android/mms/ui/VideoUtils;->getInstance()Lcom/android/mms/ui/VideoUtils;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/ui/VideoUtils;->clearData()V

    .line 4009
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 4011
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMMSAudioPlayer:Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;

    invoke-interface {p0}, Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;->releaseMediaPlayer()V

    return-void
.end method

.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 0

    .line 10831
    sget-object p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Landroid/widget/MenuBar;->refreshMenuBar()V

    return-void
.end method

.method public onEditorAction(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 5

    const/16 v0, 0x17

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eq p1, v0, :cond_2

    const/16 v0, 0x43

    if-eq p1, v0, :cond_0

    goto :goto_0

    .line 4100
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    if-eqz v0, :cond_6

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListView;->isFocused()Z

    move-result v0

    if-eqz v0, :cond_6

    .line 4103
    :try_start_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListView;->getSelectedItem()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/database/Cursor;

    :try_end_0
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v0, :cond_6

    .line 4110
    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 4111
    invoke-interface {v0, v2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v3

    .line 4112
    iget-object p2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {p2, p1, v3, v4, v0}, Lcom/android/mms/ui/MessageListAdapter;->getCachedMessageItem(Ljava/lang/String;JLandroid/database/Cursor;)Lcom/android/mms/ui/MessageItem;

    move-result-object p1

    if-eqz p1, :cond_1

    .line 4115
    new-instance p2, Lcom/android/mms/ui/ComposeMessageActivity$DeleteMessageListener;

    invoke-direct {p2, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$DeleteMessageListener;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;)V

    const/4 p2, 0x0

    const-string v0, "dialog_remove"

    .line 4118
    invoke-direct {p0, v0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->alertDialog(Ljava/lang/String;Lcom/android/mms/ui/MessageItem;Ljava/lang/Runnable;)V

    :cond_1
    return v2

    :catch_0
    move-exception v0

    const-string v1, "Mms"

    const-string v2, "Unexpected ClassCastException."

    .line 4105
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 4106
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p0

    return p0

    .line 4127
    :cond_2
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->canSending()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result v0

    if-lez v0, :cond_3

    goto :goto_1

    .line 4130
    :cond_3
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showEmptyTextError()Z

    move-result v0

    if-nez v0, :cond_4

    return v2

    .line 4136
    :cond_4
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->isAirplaneModeOnWithoutIms(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 4137
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showAirplaneModeDialog()V

    return v2

    .line 4140
    :cond_5
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->toSendWhenInvalidSim()V

    .line 4144
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result v0

    if-eqz v0, :cond_6

    .line 4145
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded()V

    return v2

    .line 4171
    :cond_6
    :goto_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p0

    return p0

    :cond_7
    :goto_1
    return v1
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .locals 1

    const/4 v0, 0x4

    if-eq p1, v0, :cond_0

    goto :goto_0

    .line 10806
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_1

    .line 10807
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    goto :goto_0

    .line 10808
    :cond_1
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    if-eqz v0, :cond_2

    .line 10809
    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V

    const/4 v0, 0x0

    .line 10810
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    .line 10811
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateMenuBar()V

    goto :goto_0

    .line 10814
    :cond_2
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$101;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$101;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->exitComposeMessageActivity(Ljava/lang/Runnable;)V

    .line 10823
    :goto_0
    sget-object p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0, p1, p2}, Landroid/widget/MenuBar;->onKeyUp(ILandroid/view/KeyEvent;)Z

    const/4 p0, 0x1

    return p0
.end method

# overrides: Lcom/android/mms/data/WorkingMessage$MessageStatusListener;
.method public onMaxPendingMessagesReached()V
    .locals 1

    const/4 v0, 0x0

    .line 4446
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->saveDraft(Z)V

    .line 4448
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$39;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$39;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

# overrides: Lcom/android/mms/data/WorkingMessage$MessageStatusListener;
.method public onMessageSent()V
    .locals 1

    .line 4423
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$38;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$38;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .locals 10

    .line 3186
    invoke-super {p0, p1}, Landroid/app/Activity;->onNewIntent(Landroid/content/Intent;)V

    .line 3187
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->hasBasicPermissions()Z

    move-result v0

    if-eqz v0, :cond_8

    sget-object v0, Lcom/android/mms/ui/MessageUtils;->sSMSExtendPermissions:[Ljava/lang/String;

    .line 3188
    invoke-static {v0}, Lcom/android/mms/ui/MessageUtils;->hasPermissions([Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_2

    .line 3192
    :cond_0
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->setIntent(Landroid/content/Intent;)V

    const/4 v0, 0x0

    .line 3195
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSentMessage:Z

    const-string v1, "thread_id"

    const-wide/16 v2, 0x0

    .line 3202
    invoke-virtual {p1, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    .line 3203
    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    .line 3204
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    if-nez v1, :cond_1

    .line 3205
    invoke-static {p0, p1, v0}, Lcom/android/mms/data/Conversation;->get(Landroid/content/Context;Landroid/net/Uri;Z)Lcom/android/mms/data/Conversation;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    .line 3207
    :cond_1
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v6

    cmp-long v1, v4, v2

    if-lez v1, :cond_2

    .line 3210
    invoke-static {p0, v4, v5, v0}, Lcom/android/mms/data/Conversation;->get(Landroid/content/Context;JZ)Lcom/android/mms/data/Conversation;

    move-result-object v1

    goto :goto_0

    .line 3212
    :cond_2
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v8

    cmp-long v1, v8, v2

    if-nez v1, :cond_3

    .line 3216
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    if-eqz v1, :cond_3

    .line 3217
    invoke-virtual {v1}, Lcom/android/mms/data/WorkingMessage;->syncWorkingRecipients()V

    .line 3229
    :cond_3
    invoke-static {p0, p1, v0}, Lcom/android/mms/data/Conversation;->get(Landroid/content/Context;Landroid/net/Uri;Z)Lcom/android/mms/data/Conversation;

    move-result-object v1

    .line 3232
    :goto_0
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "onNewIntent: data="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, ", thread_id extra is "

    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p1, ", new conversation="

    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, ", mConversation="

    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    .line 3241
    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v4

    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v8

    cmp-long p1, v4, v8

    if-nez p1, :cond_4

    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    .line 3242
    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v4

    cmp-long p1, v4, v2

    if-eqz p1, :cond_4

    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v1, p1}, Lcom/android/mms/data/Conversation;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    const/4 p1, 0x1

    goto :goto_1

    :cond_4
    move p1, v0

    .line 3243
    :goto_1
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "sameThread:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    if-nez p1, :cond_7

    const-string p1, "onNewIntent: different conversation"

    .line 3246
    invoke-static {p1}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    .line 3247
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessagesAndDraftLoaded:Z

    .line 3248
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v4

    cmp-long p1, v4, v2

    const/4 v4, 0x0

    if-eqz p1, :cond_5

    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v8

    cmp-long p1, v8, v2

    if-nez p1, :cond_6

    .line 3249
    :cond_5
    iput-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    .line 3250
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1, v1}, Lcom/android/mms/data/WorkingMessage;->setConversation(Lcom/android/mms/data/Conversation;)V

    .line 3251
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateThreadIdIfRunning()V

    .line 3252
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->invalidateOptionsMenu()V

    .line 3253
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    if-eqz p1, :cond_6

    .line 3254
    invoke-virtual {p1, v4}, Lcom/android/mms/ui/MessageListAdapter;->changeCursor(Landroid/database/Cursor;)V

    .line 3255
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {p1}, Lcom/android/mms/ui/MessageListAdapter;->cancelBackgroundLoading()V

    .line 3258
    :cond_6
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->saveDraft(Z)V

    .line 3259
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->resetEditorText()V

    .line 3260
    invoke-virtual {p0, v4, v6, v7}, Lcom/android/mms/ui/ComposeMessageActivity;->initialize(Landroid/os/Bundle;J)V

    .line 3262
    :cond_7
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->loadMessagesAndDraft(I)V

    :cond_8
    :goto_2
    return-void
.end method

.method public onOptionMenuClick(I)V
    .locals 4

    # tzib inbox options: paste action
    invoke-static/range {p0 .. p1}, Lcom/android/mms/tzib/TzibClipboard;->option(Landroid/app/Activity;I)Z
    move-result v0
    if-eqz v0, :tzib_original_option
    return-void
    :tzib_original_option

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v3, ""

    packed-switch p1, :pswitch_data_0

    :pswitch_0    # 0x3
    goto/16 :goto_0

    .line 10790
    :pswitch_1    # 0x12
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/mms/data/ContactList;->serialize()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->rttCallContact(Landroid/content/Context;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 10702
    :pswitch_2    # 0x11
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->launchMultipleGroupPicker()V

    goto/16 :goto_0

    .line 10782
    :pswitch_3    # 0x10
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->saveAttachment()V

    goto/16 :goto_0

    .line 10776
    :pswitch_4    # 0xf
    invoke-direct {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->showSubjectEditor(Z)V

    .line 10777
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1, v0, v2}, Lcom/android/mms/data/WorkingMessage;->setSubject(Ljava/lang/CharSequence;Z)V

    .line 10778
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {p0}, Landroid/widget/EditText;->requestFocus()Z

    goto/16 :goto_0

    .line 10770
    :pswitch_5    # 0xe
    invoke-direct {p0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->showSubjectEditor(Z)V

    .line 10771
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1, v3, v2}, Lcom/android/mms/data/WorkingMessage;->setSubject(Ljava/lang/CharSequence;Z)V

    .line 10772
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateSendButtonState()V

    .line 10773
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    invoke-virtual {p0}, Landroid/widget/EditText;->requestFocus()Z

    goto/16 :goto_0

    .line 10786
    :pswitch_6    # 0xd
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/mms/data/ContactList;->serialize()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/android/mms/ui/MessageUtils;->callContact(Landroid/content/Context;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 10766
    :pswitch_7    # 0xc
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->viewAttachment()V

    goto/16 :goto_0

    .line 10757
    :pswitch_8    # 0xb
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    if-eqz p1, :cond_5

    .line 10758
    new-instance p1, Lcom/android/mms/ui/ComposeMessageActivity$DeleteMessageListener;

    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v1}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v1

    invoke-direct {p1, p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity$DeleteMessageListener;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/ui/MessageItem;)V

    .line 10761
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {p1}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object p1

    const-string v1, "dialog_remove"

    invoke-direct {p0, v1, p1, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->alertDialog(Ljava/lang/String;Lcom/android/mms/ui/MessageItem;Ljava/lang/Runnable;)V

    goto/16 :goto_0

    .line 10754
    :pswitch_9    # 0xa
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {p1}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->resendMessage(Lcom/android/mms/ui/MessageItem;)V

    goto/16 :goto_0

    .line 10751
    :pswitch_a    # 0x9
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->removeAttachment()V

    goto/16 :goto_0

    .line 10742
    :pswitch_b    # 0x8
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {p1}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 10743
    invoke-virtual {p1}, Lcom/android/mms/ui/MessageItem;->isMms()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->isAllowForwardMessage(Lcom/android/mms/ui/MessageItem;)Z

    move-result p1

    if-nez p1, :cond_0

    const p1, 0x7f0e00f2    # @string/forward_size_over 'Forbid forwarding, new message size over 300K.'

    .line 10744
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    .line 10745
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    goto/16 :goto_0

    .line 10748
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->forwardMessage()V

    goto/16 :goto_0

    .line 10739
    :pswitch_c    # 0x7
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->viewAttachment()V

    goto/16 :goto_0

    .line 10735
    :pswitch_d    # 0x6
    sget-object p1, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {p1}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->showMessageReport(Lcom/android/mms/ui/MessageItem;)V

    goto :goto_0

    .line 10731
    :pswitch_e    # 0x5
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->createListDialogOptions()V

    goto :goto_0

    .line 10722
    :pswitch_f    # 0x4
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->discard()V

    .line 10723
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->finish()V

    goto :goto_0

    .line 10710
    :pswitch_10    # 0x2
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lcom/android/mms/ui/RecipientsEditor;->isFocused()Z

    move-result p1

    if-eqz p1, :cond_1

    .line 10711
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {p0, v3}, Lcom/android/mms/ui/RecipientsEditor;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 10712
    :cond_1
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/widget/EditText;->isFocused()Z

    move-result p1

    if-eqz p1, :cond_2

    .line 10714
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {p0, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 10716
    :cond_2
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    if-eqz p1, :cond_5

    invoke-virtual {p1}, Landroid/widget/EditText;->isFocused()Z

    move-result p1

    if-eqz p1, :cond_5

    .line 10717
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    invoke-virtual {p0, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 10682
    :pswitch_11    # 0x1
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showEmptyTextError()Z

    move-result p1

    if-nez p1, :cond_3

    goto :goto_0

    .line 10688
    :cond_3
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->isAirplaneModeOnWithoutIms(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_4

    .line 10689
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showAirplaneModeDialog()V

    goto :goto_0

    .line 10692
    :cond_4
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->toSendWhenInvalidSim()V

    .line 10696
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result p1

    if-eqz p1, :cond_5

    .line 10697
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded()V

    goto :goto_0

    .line 10707
    :pswitch_12    # 0x0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->launchMultiplePhonePicker()V

    :cond_5
    :goto_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12    # 0x0
        :pswitch_11    # 0x1
        :pswitch_10    # 0x2
        :pswitch_0    # 0x3
        :pswitch_f    # 0x4
        :pswitch_e    # 0x5
        :pswitch_d    # 0x6
        :pswitch_c    # 0x7
        :pswitch_b    # 0x8
        :pswitch_a    # 0x9
        :pswitch_9    # 0xa
        :pswitch_8    # 0xb
        :pswitch_7    # 0xc
        :pswitch_6    # 0xd
        :pswitch_5    # 0xe
        :pswitch_4    # 0xf
        :pswitch_3    # 0x10
        :pswitch_2    # 0x11
        :pswitch_1    # 0x12
    .end packed-switch
.end method

.method public onOptionMenuDismiss()V
    .locals 0

    return-void
.end method

.method public onOptionMenuShow()V
    .locals 0

    return-void
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 4

    # tzib inbox options: paste action
    invoke-static/range {p0 .. p1}, Lcom/android/mms/tzib/TzibClipboard;->optionItem(Landroid/app/Activity;Landroid/view/MenuItem;)Z
    move-result v0
    if-eqz v0, :tzib_original_option
    return v0
    :tzib_original_option

    .line 4617
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_c

    if-eq v0, v1, :cond_b

    const/4 v2, 0x3

    if-eq v0, v2, :cond_a

    const/4 v2, 0x4

    if-eq v0, v2, :cond_9

    const/4 v2, 0x5

    if-eq v0, v2, :cond_8

    const/4 v2, 0x6

    if-eq v0, v2, :cond_7

    const/4 v2, 0x7

    if-eq v0, v2, :cond_6

    const/16 v2, 0x9

    const/4 v3, 0x0

    if-eq v0, v2, :cond_5

    const/16 v2, 0xa

    if-eq v0, v2, :cond_4

    const/16 v2, 0xc

    if-eq v0, v2, :cond_3

    const/16 v2, 0x13

    if-eq v0, v2, :cond_2

    const/16 v2, 0x1b

    if-eq v0, v2, :cond_1

    const/16 p1, 0x25

    if-eq v0, p1, :cond_0

    const p1, 0x102002c    # @android:id/home

    if-eq v0, p1, :cond_7

    packed-switch v0, :pswitch_data_0

    goto/16 :goto_0

    .line 4669
    :pswitch_0    # 0x21
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->showDialog(I)V

    goto/16 :goto_0

    .line 4673
    :pswitch_1    # 0x20
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/android/mms/ui/RecipientListActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4674
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v2

    const-string v0, "thread_id"

    invoke-virtual {p1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 4675
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4694
    :pswitch_2    # 0x1f
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/android/mms/ui/MessagingPreferenceActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v0, -0x1

    .line 4695
    invoke-virtual {p0, p1, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivityIfNeeded(Landroid/content/Intent;I)Z

    goto/16 :goto_0

    .line 4666
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->videoCallRecipient()V

    goto/16 :goto_0

    .line 4690
    :cond_1
    invoke-interface {p1}, Landroid/view/MenuItem;->getIntent()Landroid/content/Intent;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddContactIntent:Landroid/content/Intent;

    const/16 v0, 0x6c

    .line 4691
    invoke-virtual {p0, p1, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_0

    .line 4648
    :cond_2
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->onSearchRequested()Z

    goto/16 :goto_0

    .line 4680
    :cond_3
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p1

    .line 4681
    invoke-virtual {p1}, Lcom/android/mms/data/ContactList;->size()I

    move-result v0

    if-ne v0, v1, :cond_d

    invoke-virtual {p1, v3}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/mms/data/Contact;

    invoke-virtual {v0}, Lcom/android/mms/data/Contact;->existsInDatabase()Z

    move-result v0

    if-eqz v0, :cond_d

    .line 4682
    invoke-virtual {p1, v3}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/mms/data/Contact;

    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->getUri()Landroid/net/Uri;

    move-result-object p1

    .line 4683
    new-instance v0, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v0, v2, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 p1, 0x80000

    .line 4684
    invoke-virtual {v0, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 4685
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 4641
    :cond_4
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result p1

    if-eqz p1, :cond_d

    .line 4643
    invoke-static {v1}, Lcom/android/mmswrapper/SubscriptionManagerWrapper;->getSubId(I)[I

    move-result-object p1

    aget p1, p1, v3

    .line 4642
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded(I)V

    goto :goto_0

    .line 4634
    :cond_5
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result p1

    if-eqz p1, :cond_d

    .line 4636
    invoke-static {v3}, Lcom/android/mmswrapper/SubscriptionManagerWrapper;->getSubId(I)[I

    move-result-object p1

    aget p1, p1, v3

    .line 4635
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded(I)V

    goto :goto_0

    .line 4699
    :cond_6
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->dump()V

    .line 4700
    invoke-static {}, Lcom/android/mms/data/Conversation;->dump()V

    .line 4701
    invoke-static {p0}, Lcom/android/mms/LogTag;->dumpInternalTables(Landroid/content/Context;)V

    goto :goto_0

    .line 4655
    :cond_7
    new-instance p1, Lcom/android/mms/ui/ComposeMessageActivity$42;

    invoke-direct {p1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$42;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->exitComposeMessageActivity(Ljava/lang/Runnable;)V

    goto :goto_0

    .line 4663
    :cond_8
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->dialRecipient()V

    goto :goto_0

    .line 4629
    :cond_9
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result p1

    if-eqz p1, :cond_d

    .line 4630
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmSendMessageIfNeeded()V

    goto :goto_0

    .line 4625
    :cond_a
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {p1}, Lcom/android/mms/data/WorkingMessage;->discard()V

    .line 4626
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->finish()V

    goto :goto_0

    .line 4651
    :cond_b
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v2

    invoke-direct {p0, v2, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->confirmDeleteThread(J)V

    goto :goto_0

    .line 4619
    :cond_c
    invoke-direct {p0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->showSubjectEditor(Z)V

    .line 4620
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    const-string v0, ""

    invoke-virtual {p1, v0, v1}, Lcom/android/mms/data/WorkingMessage;->setSubject(Ljava/lang/CharSequence;Z)V

    .line 4621
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateSendButtonState()V

    .line 4622
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    invoke-virtual {p0}, Landroid/widget/EditText;->requestFocus()Z

    :cond_d
    :goto_0
    return v1

    :pswitch_data_0
    .packed-switch 0x1f
        :pswitch_2    # 0x1f
        :pswitch_1    # 0x20
        :pswitch_0    # 0x21
    .end packed-switch
.end method

.method protected onPause()V
    .locals 5

    .line 3515
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    const-string v0, "Mms"

    const-string v1, "onPause: setCurrentlyDisplayedThreadId: -2"

    .line 3518
    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x1

    .line 3521
    iput-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsActvityPause:Z

    const-wide/16 v2, -0x2

    .line 3522
    invoke-static {v2, v3}, Lcom/android/mms/transaction/MessagingNotification;->setCurrentlyDisplayedThreadId(J)V

    .line 3529
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->removeRecipientsListeners()V

    .line 3530
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 3531
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->unRegRecipientsWatcher()V

    .line 3535
    :cond_0
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

    if-eqz v2, :cond_1

    .line 3536
    invoke-virtual {v2}, Lcom/android/mms/ui/AsyncDialog;->clearPendingProgressDialog()V

    .line 3541
    :cond_1
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    const-string v3, "mmsjump"

    if-eqz v2, :cond_2

    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    .line 3542
    invoke-virtual {v2}, Lcom/android/mms/ui/MessageListView;->getLastVisiblePosition()I

    move-result v2

    iget-object v4, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v4}, Lcom/android/mms/ui/MessageListAdapter;->getCount()I

    move-result v4

    sub-int/2addr v4, v1

    if-lt v2, v4, :cond_2

    const v1, 0x7fffffff

    .line 3543
    iput v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSavedScrollPosition:I

    .line 3544
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "onPause: mSavedScrollPosition Integer.MAX_VALUE "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSavedScrollPosition:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 3546
    :cond_2
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v1}, Lcom/android/mms/ui/MessageListView;->getFirstVisiblePosition()I

    move-result v1

    iput v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSavedScrollPosition:I

    .line 3547
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "onPause: mSavedScrollPosition getFirstVisiblePosition "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSavedScrollPosition:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 3550
    :goto_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "onPause: mSavedScrollPosition="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSavedScrollPosition:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 3553
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->markAsRead()V

    const/4 v0, 0x0

    .line 3554
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRunning:Z

    .line 3556
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMMSAudioPlayer:Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;

    if-eqz v1, :cond_3

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMediaPlayer:Landroid/media/MediaPlayer;

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v1

    if-eqz v1, :cond_3

    .line 3557
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMMSAudioPlayer:Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;

    invoke-interface {p0}, Lcom/android/mms/ui/ComposeMessageActivity$IMMSAudioPlayer;->pause()V

    .line 3559
    :cond_3
    invoke-static {}, Lcom/android/mms/ui/VideoUtils;->getInstance()Lcom/android/mms/ui/VideoUtils;

    move-result-object p0

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/VideoUtils;->setFocus(Z)V

    return-void
.end method

# overrides: Lcom/android/mms/data/WorkingMessage$MessageStatusListener;
.method public onPreMessageSent()V
    .locals 1

    .line 4416
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mResetMessageRunnable:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method protected onPrepareDialog(ILandroid/app/Dialog;)V
    .locals 1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_0

    goto :goto_0

    .line 4721
    :cond_0
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->removeDialog(I)V

    .line 4724
    :goto_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onPrepareDialog(ILandroid/app/Dialog;)V

    return-void
.end method

.method public onPrepareOptionsMenu(Landroid/view/Menu;)Z
    .locals 8

    .line 4506
    invoke-super {p0, p1}, Landroid/app/Activity;->onPrepareOptionsMenu(Landroid/view/Menu;)Z

    .line 4508
    invoke-interface {p1}, Landroid/view/Menu;->clear()V

    .line 4510
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mForwardMessageMode:Z

    if-nez v0, :cond_0

    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mReplyMessageMode:Z

    if-nez v0, :cond_0

    return v1

    .line 4516
    :cond_0
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mEnablePresence:Z

    const/4 v2, 0x2

    const v3, 0x7f0e0136    # @string/menu_call 'Call'

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    .line 4517
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientCallable()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 4518
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/mms/data/Contact;

    invoke-virtual {v0}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object v0

    const/16 v5, 0x25

    .line 4519
    invoke-interface {p1, v4, v5, v4, v3}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    move-result-object v5

    .line 4520
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->getVTCapability(Ljava/lang/String;)Z

    move-result v6

    iput-boolean v6, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mVideoCapable:Z

    .line 4521
    new-instance v6, Ljava/lang/Thread;

    new-instance v7, Lcom/android/mms/ui/ComposeMessageActivity$41;

    invoke-direct {v7, p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity$41;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Ljava/lang/String;)V

    invoke-direct {v6, v7}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 4531
    invoke-virtual {v6}, Ljava/lang/Thread;->start()V

    .line 4532
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mVideoCapable:Z

    if-eqz v0, :cond_1

    const v0, 0x7f0700b6    # @drawable/ic_attach_capture_video_holo_light 'res/drawable/ic_attach_capture_video_holo_light.xml'

    .line 4533
    invoke-interface {v5, v0}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    .line 4534
    invoke-interface {v5, v1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    goto :goto_0

    :cond_1
    const v0, 0x7f0700b5    # @drawable/ic_attach_capture_video_disable 'res/drawable/ic_attach_capture_video_disable.xml'

    .line 4536
    invoke-interface {v5, v0}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    .line 4537
    invoke-interface {v5, v4}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    .line 4539
    :goto_0
    invoke-interface {v5, v2}, Landroid/view/MenuItem;->setShowAsAction(I)V

    .line 4545
    :cond_2
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientCallable()Z

    move-result v0

    if-eqz v0, :cond_3

    const/4 v0, 0x5

    .line 4546
    invoke-interface {p1, v4, v0, v4, v3}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    move-result-object v0

    const v5, 0x7f070068    # @drawable/call 'res/drawable/call.xml'

    .line 4547
    invoke-interface {v0, v5}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    move-result-object v0

    .line 4548
    invoke-interface {v0, v3}, Landroid/view/MenuItem;->setTitle(I)Landroid/view/MenuItem;

    move-result-object v0

    .line 4549
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v3

    if-nez v3, :cond_3

    .line 4551
    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setShowAsAction(I)V

    .line 4555
    :cond_3
    invoke-static {}, Lcom/android/mms/MmsConfig;->getMmsEnabled()Z

    move-result v0

    if-eqz v0, :cond_4

    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    if-eqz v0, :cond_4

    .line 4556
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->showAddAttachementButton()Z

    move-result v0

    if-eqz v0, :cond_4

    .line 4557
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAddAttachmentButton:Landroid/widget/LinearLayout;

    const/16 v2, 0x8

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 4560
    :cond_4
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isPreparedForSending()Z

    move-result v0

    if-eqz v0, :cond_6

    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    if-eqz v0, :cond_6

    .line 4561
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mShowTwoButtons:Z

    const v2, 0x1080050    # @android:drawable/ic_menu_send

    if-eqz v0, :cond_5

    const/16 v0, 0x9

    const v3, 0x7f0e0277    # @string/send_by_slot1 'Send by slot1'

    .line 4562
    invoke-interface {p1, v4, v0, v4, v3}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    move-result-object v0

    .line 4563
    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    const/16 v0, 0xa

    const v3, 0x7f0e0278    # @string/send_by_slot2 'Send by slot2'

    .line 4564
    invoke-interface {p1, v4, v0, v4, v3}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    move-result-object v0

    .line 4565
    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    goto :goto_1

    :cond_5
    const/4 v0, 0x4

    const v3, 0x7f0e0276    # @string/send 'Send'

    .line 4567
    invoke-interface {p1, v4, v0, v4, v3}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    move-result-object v0

    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    .line 4571
    :cond_6
    :goto_1
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/data/ContactList;->size()I

    move-result v0

    if-le v0, v1, :cond_7

    const/16 v0, 0x20

    const v2, 0x7f0e0146    # @string/menu_group_participants 'Group participants'

    .line 4572
    invoke-interface {p1, v4, v0, v4, v2}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    .line 4575
    :cond_7
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListAdapter;->getCount()I

    move-result v0

    const v2, 0x108003c    # @android:drawable/ic_menu_delete

    if-lez v0, :cond_8

    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    if-eqz v0, :cond_8

    .line 4579
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListAdapter;->getCursor()Landroid/database/Cursor;

    move-result-object v0

    if-eqz v0, :cond_9

    .line 4580
    invoke-interface {v0}, Landroid/database/Cursor;->getCount()I

    move-result v0

    if-lez v0, :cond_9

    const v0, 0x7f0e00ac    # @string/delete_thread 'Delete thread'

    .line 4581
    invoke-interface {p1, v4, v1, v4, v0}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    move-result-object v0

    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    goto :goto_2

    .line 4584
    :cond_8
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    if-eqz v0, :cond_9

    const/4 v0, 0x3

    const v3, 0x7f0e00bf    # @string/discard 'Discard'

    .line 4585
    invoke-interface {p1, v4, v0, v4, v3}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    move-result-object v0

    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    .line 4587
    :cond_9
    :goto_2
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->buildAddAddressToContactMenuItem(Landroid/view/Menu;)V

    # tzib inbox options: paste framework
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibClipboard;->prepare(Landroid/app/Activity;Landroid/view/Menu;)V
    return v1
.end method

# overrides: Lcom/android/mms/data/WorkingMessage$MessageStatusListener;
.method public onProtocolChanged(Z)V
    .locals 1

    .line 4332
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$36;

    invoke-direct {v0, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$36;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Z)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 0

    const/16 p2, 0x7e0

    if-ne p1, p2, :cond_1

    .line 9944
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->hasStoragePermission()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const p1, 0x7f0e01a0    # @string/no_permission_save_attachment_to_storage 'No permission for saving attachment to external storage'

    const/4 p2, 0x0

    .line 9947
    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :cond_1
    :goto_0
    return-void
.end method

.method protected onRestart()V
    .locals 3

    .line 3276
    invoke-super {p0}, Landroid/app/Activity;->onRestart()V

    .line 3278
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->isDiscarded()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 3284
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->isWorthSaving()Z

    move-result v0

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mInAsyncAddAttathProcess:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 3291
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->recipientCount()I

    move-result v0

    if-lez v0, :cond_3

    const/4 v0, 0x0

    .line 3294
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    if-eqz v1, :cond_1

    const/4 v0, 0x1

    const-string v2, "isFromAnswerCall"

    .line 3297
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    :cond_1
    const-string v1, "onRestart: goToConversationList"

    .line 3300
    invoke-static {v1}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 3302
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "onRestart isFromAnswerCall = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Mms"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    if-nez v0, :cond_3

    .line 3304
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->goToConversationList()V

    goto :goto_1

    :cond_2
    :goto_0
    const-string v0, "onRestart: mWorkingMessage.unDiscard()"

    .line 3286
    invoke-static {v0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 3288
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->unDiscard()V

    .line 3290
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->sanityCheckConversation()V

    :cond_3
    :goto_1
    return-void
.end method

.method protected onResume()V
    .locals 4

    .line 3463
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    const/4 v0, 0x0

    .line 3464
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsActvityPause:Z

    .line 3470
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    const-string v2, "Mms"

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/widget/MenuBar;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getWindow()Landroid/view/Window;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    if-eq v1, v3, :cond_1

    :cond_0
    const-string v1, "onResume update menubar"

    .line 3472
    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 3473
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v1

    sput-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    .line 3474
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateMenuBar()V

    .line 3478
    :cond_1
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsPickingContact:Z

    .line 3479
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->addRecipientsListeners()V

    .line 3480
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setSendButtonImage()V

    .line 3481
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 3482
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->regRecipientsWatcher()V

    :cond_2
    const/4 v0, 0x2

    .line 3485
    invoke-static {v2, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 3486
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "update title, mConversation="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 3492
    :cond_3
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessageListItemHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$27;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ComposeMessageActivity$27;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    const-wide/16 v2, 0x64

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v0, 0x1

    .line 3501
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRunning:Z

    .line 3502
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateThreadIdIfRunning()V

    .line 3503
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->isAirplaneModeOn(Landroid/content/Context;)Z

    move-result v1

    iput-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsAirplaneModeOn:Z

    .line 3505
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f040018    # @bool/def_custom_preferences_settings 'false'

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 3506
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setBackgroundWallpaper()V

    .line 3507
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->setTextFontsize()V

    .line 3509
    :cond_4
    invoke-static {}, Lcom/android/mms/ui/VideoUtils;->getInstance()Lcom/android/mms/ui/VideoUtils;

    move-result-object p0

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/VideoUtils;->setFocus(Z)V

    .line 3510
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, " end composemessage onResume() time is "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "mmstime"

    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 3447
    invoke-super {p0, p1}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 3449
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/data/ContactList;->serialize()Ljava/lang/String;

    move-result-object v0

    const-string v1, "recipients"

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 3451
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0, p1}, Lcom/android/mms/data/WorkingMessage;->writeStateToBundle(Landroid/os/Bundle;)V

    .line 3453
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSendDiscreetMode:Z

    if-eqz v0, :cond_0

    const-string v1, "exit_on_sent"

    .line 3454
    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 3456
    :cond_0
    iget-boolean p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mForwardMessageMode:Z

    if-eqz p0, :cond_1

    const-string v0, "forwarded_message"

    .line 3457
    invoke-virtual {p1, v0, p0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    :cond_1
    return-void
.end method

# overrides: Lcom/android/ex/chips/RecipientEditTextView$RecipientChipInvalidDialogListener;
.method public onShouldShowDialog(Ljava/lang/String;)V
    .locals 7

    .line 1211
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 1212
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v2, 0x7f0a001e    # @layout/airplane_dialog 'res/layout/airplane_dialog.xml'

    const/4 v3, 0x0

    .line 1213
    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    const v2, 0x7f0801d4    # @id/tv_title

    .line 1214
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    .line 1215
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f0e0106    # @string/invalid_contact 'Invalid Contact'

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v2, 0x7f0801d3    # @id/tv_content

    .line 1216
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TctDialogMessage;

    .line 1217
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    aput-object p1, v5, v6

    const p1, 0x7f0e0107    # @string/invalid_contact_content 'Contact %1$s is invalid contact'

    invoke-virtual {v4, p1, v5}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Landroid/widget/TctDialogMessage;->setText(Ljava/lang/CharSequence;)V

    .line 1219
    new-instance p1, Landroid/view/ViewGroup$LayoutParams;

    const/4 v2, -0x1

    const/4 v4, -0x2

    invoke-direct {p1, v2, v4}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 1223
    new-instance v5, Lcom/android/mms/ui/ComposeMessageActivity$8;

    invoke-direct {v5, p0}, Lcom/android/mms/ui/ComposeMessageActivity$8;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {v0, v5}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    .line 1245
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    const/16 v5, 0xe

    .line 1247
    invoke-virtual {v0, v5}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 1248
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    .line 1250
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {v0, v1, p1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1251
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {p1, p0}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 1253
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object p1

    const v0, 0x7f0e0301    # @string/yes 'OK'

    .line 1254
    invoke-virtual {p1, v6, v0, v6, v3}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    .line 1256
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mDialog:Landroid/app/Dialog;

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    .line 1257
    invoke-virtual {p0, v2, v4}, Landroid/view/Window;->setLayout(II)V

    const/16 p1, 0x50

    .line 1260
    invoke-virtual {p0, p1}, Landroid/view/Window;->setGravity(I)V

    const p1, 0x106000d    # @android:color/transparent

    .line 1261
    invoke-virtual {p0, p1}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    const/high16 p1, 0x3f000000

    .line 1262
    invoke-virtual {p0, p1}, Landroid/view/Window;->setDimAmount(F)V

    return-void
.end method

.method protected onStart()V
    .locals 6

    .line 3313
    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    .line 3314
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "mmsrecipientchip"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/provider/Settings$System;->putInt(Landroid/content/ContentResolver;Ljava/lang/String;I)Z

    .line 3315
    invoke-static {p0}, Lcom/android/mms/MmsConfig;->isSmsEnabled(Landroid/content/Context;)Z

    move-result v0

    .line 3316
    iget-boolean v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    if-eq v0, v1, :cond_0

    .line 3317
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsSmsEnabled:Z

    .line 3318
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->invalidateOptionsMenu()V

    .line 3323
    :cond_0
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientsEditorVisible()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 3324
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->regRecipientsWatcher()V

    .line 3328
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHttpProgressReceiver:Landroid/content/BroadcastReceiver;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHttpProgressFilter:Landroid/content/IntentFilter;

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 3331
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMediaStateReceiver:Landroid/content/BroadcastReceiver;

    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getMediaStateFilter()Landroid/content/IntentFilter;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 3333
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAirplaneModeBroadcastReceiver:Landroid/content/BroadcastReceiver;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAirplaneModeFilter:Landroid/content/IntentFilter;

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 3334
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSimBroadcastReceiver:Landroid/content/BroadcastReceiver;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSIMStatusChangeFilter:Landroid/content/IntentFilter;

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 3336
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHomeWatcherReceiver:Landroid/content/BroadcastReceiver;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHomeWatcherFilter:Landroid/content/IntentFilter;

    invoke-virtual {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 3343
    invoke-static {}, Lcom/android/mms/util/DraftCache;->getInstance()Lcom/android/mms/util/DraftCache;

    move-result-object v0

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lcom/android/mms/util/DraftCache;->hasDraft(J)Z

    move-result v0

    const/16 v1, 0x14

    if-eqz v0, :cond_2

    goto :goto_0

    .line 3346
    :cond_2
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v2

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-ltz v0, :cond_3

    goto :goto_0

    :cond_3
    const/16 v1, 0x12

    .line 3354
    :goto_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/Window;->setSoftInputMode(I)V

    const/4 v0, 0x0

    .line 3357
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessagesAndDraftLoaded:Z

    .line 3359
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_4

    .line 3361
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {v1, v0}, Landroid/widget/EditText;->setTextKeepState(Ljava/lang/CharSequence;)V

    .line 3383
    :cond_4
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWorkingMessage:Lcom/android/mms/data/WorkingMessage;

    invoke-virtual {v0}, Lcom/android/mms/data/WorkingMessage;->syncWorkingRecipients()V

    const/4 v0, 0x2

    const-string v1, "Mms"

    .line 3385
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 3386
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "update title, mConversation="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v1}, Lcom/android/mms/data/Conversation;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 3389
    :cond_5
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->updateTitle(Lcom/android/mms/data/ContactList;)V

    return-void
.end method

.method protected onStop()V
    .locals 3

    .line 3564
    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    .line 3565
    invoke-virtual {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "mmsrecipientchip"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/provider/Settings$System;->putInt(Landroid/content/ContentResolver;Ljava/lang/String;I)Z

    .line 3567
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mBackgroundQueryHandler:Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;

    const/16 v1, 0x2537

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity$BackgroundQueryHandler;->cancelOperation(I)V

    .line 3570
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v0, v2}, Lcom/android/mms/data/Conversation;->blockMarkAsRead(Z)V

    const/4 v0, 0x2

    const-string v1, "Mms"

    .line 3583
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "save draft"

    .line 3584
    invoke-static {v0}, Lcom/android/mms/ui/ComposeMessageActivity;->log(Ljava/lang/String;)V

    .line 3586
    :cond_0
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->isAvoidingSavingDraft:Z

    if-nez v0, :cond_1

    const/4 v0, 0x1

    .line 3588
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->saveDraft(Z)V

    .line 3593
    iput-boolean v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->isAvoidingSavingDraft:Z

    .line 3597
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHttpProgressReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 3598
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMediaStateReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 3599
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAirplaneModeBroadcastReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 3600
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mSimBroadcastReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 3601
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mHomeWatcherReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 3603
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_2

    .line 3604
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mAttachmentSelector:Landroid/view/View;

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_2
    return-void
.end method

# overrides: Lcom/android/mms/data/Contact$UpdateListener;
.method public onUpdate(Lcom/android/mms/data/Contact;)V
    .locals 2

    .line 8679
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMessageListItemHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/mms/ui/ComposeMessageActivity$90;

    invoke-direct {v1, p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity$90;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;Lcom/android/mms/data/Contact;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .locals 3

    .line 10657
    invoke-super {p0, p1}, Landroid/app/Activity;->onWindowFocusChanged(Z)V

    .line 10659
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    const/4 v0, 0x1

    const-string v1, "input_method"

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/widget/EditText;->hasFocus()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 10660
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/inputmethod/InputMethodManager;

    if-eqz p1, :cond_0

    .line 10662
    iget-object v2, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    invoke-virtual {p1, v2, v0}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    .line 10667
    :cond_0
    iget-object p1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lcom/android/mms/ui/RecipientsEditor;->hasFocus()Z

    move-result p1

    if-eqz p1, :cond_1

    .line 10668
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/inputmethod/InputMethodManager;

    if-eqz p1, :cond_1

    .line 10670
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    invoke-virtual {p1, p0, v0}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    :cond_1
    return-void
.end method

# overrides: Lcom/android/mms/ui/zoom/ZoomGestureOverlayView$IZoomListener;
.method public onZoomWithScale(F)V
    .locals 2

    .line 2987
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    .line 2988
    invoke-virtual {v0, p1, v1}, Lcom/android/mms/ui/MessageListView;->handleZoomWithScale(FZ)V

    .line 2990
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    if-eqz v0, :cond_1

    const/4 v1, 0x1

    .line 2991
    invoke-static {p0, v0, p1, v1}, Lcom/android/mms/ui/zoom/ZoomMessageListItem;->zoomViewByScale(Landroid/content/Context;Landroid/widget/TextView;FZ)V

    :cond_1
    return-void
.end method

.method public removeAttachment()V
    .locals 1

    .line 10212
    new-instance v0, Lcom/android/mms/ui/ComposeMessageActivity$99;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ComposeMessageActivity$99;-><init>(Lcom/android/mms/ui/ComposeMessageActivity;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public saveAttachment()V
    .locals 2

    .line 9389
    :try_start_0
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v0

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 9391
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_0

    .line 9394
    iget-wide v0, v0, Lcom/android/mms/ui/MessageItem;->mMsgId:J

    invoke-direct {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->saveAttachment(J)V

    :cond_0
    return-void
.end method

# overrides: Lcom/android/mms/ui/MessageListAdapter$OnMessageBodyLoaded;
.method public scrollToLastItem(I)V
    .locals 1

    .line 8348
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListAdapter;->getCount()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    if-ne p1, v0, :cond_0

    .line 8349
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/MessageListView;->setSelection(I)V

    :cond_0
    return-void
.end method

.method public setListViewHeightBasedOnChildren(Landroid/widget/ListView;)V
    .locals 5

    .line 7477
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    move v1, v0

    move v2, v1

    .line 7481
    :goto_0
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v3}, Lcom/android/mms/ui/MessageListAdapter;->getCount()I

    move-result v3

    if-ge v1, v3, :cond_1

    .line 7482
    iget-object v3, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    const/4 v4, 0x0

    invoke-virtual {v3, v1, v4, p1}, Lcom/android/mms/ui/MessageListAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v3

    .line 7483
    invoke-virtual {v3, v0, v0}, Landroid/view/View;->measure(II)V

    .line 7484
    invoke-virtual {v3}, Landroid/view/View;->getMeasuredHeight()I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 7486
    :cond_1
    invoke-virtual {p1}, Landroid/widget/ListView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 7488
    invoke-virtual {p1}, Landroid/widget/ListView;->getDividerHeight()I

    move-result v1

    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {p0}, Lcom/android/mms/ui/MessageListAdapter;->getCount()I

    move-result p0

    add-int/lit8 p0, p0, -0x1

    mul-int/2addr v1, p0

    add-int/2addr v2, v1

    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 7489
    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

# overrides: Lcom/android/mms/ui/MessageListAdapter$OnImageLoaded;
.method public setScrollToEnd(I)V
    .locals 1

    .line 8340
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    invoke-virtual {v0}, Lcom/android/mms/ui/MessageListAdapter;->getCount()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    if-ne p1, v0, :cond_0

    .line 8341
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v0, p1}, Lcom/android/mms/ui/MessageListView;->setSelection(I)V

    .line 8342
    iget-object p0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListAdapter:Lcom/android/mms/ui/MessageListAdapter;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/MessageListAdapter;->setOnImageLoaded(Lcom/android/mms/ui/MessageListAdapter$OnImageLoaded;)V

    :cond_0
    return-void
.end method

.method public startActivityForResult(Landroid/content/Intent;I)V
    .locals 2

    if-ltz p2, :cond_0

    const/4 v0, 0x1

    .line 1174
    iput-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mWaitingForSubActivity:Z

    .line 1179
    :cond_0
    iget-boolean v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsKeyboardOpen:Z

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const-string v1, "android.provider.action.QUICK_CONTACT"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 1180
    invoke-direct {p0}, Lcom/android/mms/ui/ComposeMessageActivity;->hideKeyboard()V

    .line 1183
    :cond_1
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method undeliveredMessageDialog(J)V
    .locals 4

    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    const/4 v1, 0x1

    if-ltz v0, :cond_0

    const v0, 0x7f0e02ee    # @string/undelivered_msg_dialog_body 'Couldn't send this message.\nAttempt made: %s.'

    new-array v2, v1, [Ljava/lang/Object;

    const/4 v3, 0x0

    .line 7414
    invoke-static {p0, p1, p2}, Lcom/android/mms/ui/MessageUtils;->formatTimeStampString(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object p1

    aput-object p1, v2, v3

    .line 7413
    invoke-virtual {p0, v0, v2}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    const p1, 0x7f0e02f0    # @string/undelivered_sms_dialog_body 'Couldn't send this message.'

    .line 7417
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 7420
    :goto_0
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public updateMenuBar()V
    .locals 16

    move-object/from16 v0, p0

    .line 10403
    iget-boolean v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsChooseDialogShow:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseVideoDialog:Landroid/app/AlertDialog;

    if-nez v1, :cond_0

    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseImageDialog:Landroid/app/AlertDialog;

    if-nez v1, :cond_0

    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->ChooseAttachDialog:Landroid/app/AlertDialog;

    if-nez v1, :cond_0

    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->SaveDraftDialog:Landroid/app/AlertDialog;

    if-eqz v1, :cond_2

    .line 10405
    :cond_0
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_1

    const v3, 0x7f0e0126    # @string/menu_action_ok 'OK'

    goto :goto_0

    :cond_1
    const v3, 0x7f0e0128    # @string/menu_action_select 'Select'

    :goto_0
    invoke-virtual {v0, v3}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v2, v0, v2, v2}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    return-void

    .line 10407
    :cond_2
    iget-boolean v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mIsRemoveDialogShow:Z

    if-eqz v1, :cond_3

    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialog:Landroid/app/AlertDialog;

    if-eqz v1, :cond_3

    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    if-eqz v1, :cond_3

    .line 10408
    invoke-virtual {v1}, Landroid/widget/MenuBar;->refreshMenuBar()V

    return-void

    .line 10410
    :cond_3
    iget-boolean v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mDiscardDialog:Z

    const v3, 0x7f0e0301    # @string/yes 'OK'

    const/4 v4, 0x0

    if-eqz v1, :cond_4

    .line 10411
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    const v1, 0x7f0e0196    # @string/no 'Cancel'

    invoke-virtual {v0, v1, v4, v3, v2}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    return-void

    .line 10413
    :cond_4
    iget-boolean v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mErrorDiscardDialog:Z

    if-eqz v1, :cond_5

    .line 10414
    sget-object v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {v0, v4, v3, v4, v2}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    return-void

    .line 10419
    :cond_5
    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->canSending()Z

    move-result v1

    const v3, 0x7f0e011e    # @string/menu_action_cancel_edit 'Cancel edit'

    const/4 v5, 0x4

    const v6, 0x7f0e012a    # @string/menu_action_select_group 'Select contact group'

    const/16 v7, 0x11

    const v8, 0x7f0e0129    # @string/menu_action_select_contact 'Select from contact'

    const/16 v13, 0x8

    const v14, 0x7f0e002c    # @string/add_attachment_go 'Add attachment'

    const v15, 0x7f0e0120    # @string/menu_action_clear_all 'Clear all'

    const/4 v9, 0x5

    const v10, 0x7f0700f8    # @drawable/ic_options 'res/drawable/ic_options.png'

    const v11, 0x7f0e0127    # @string/menu_action_options 'Options'

    const/4 v12, 0x2

    if-eqz v1, :cond_b

    .line 10420
    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz v1, :cond_6

    invoke-virtual {v1}, Lcom/android/mms/ui/RecipientsEditor;->isFocused()Z

    move-result v1

    if-eqz v1, :cond_6

    .line 10421
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 10422
    new-instance v3, Landroid/util/Pair;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v3, v5, v8}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10423
    new-instance v3, Landroid/util/Pair;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10424
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v2, v5, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10425
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_11

    .line 10426
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v1, v12, v3}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    goto/16 :goto_1

    .line 10428
    :cond_6
    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    const v6, 0x7f0e012c    # @string/menu_action_send 'Send'

    if-eqz v1, :cond_a

    invoke-virtual {v1}, Landroid/widget/EditText;->isFocused()Z

    move-result v1

    if-eqz v1, :cond_a

    .line 10429
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 10430
    new-instance v7, Landroid/util/Pair;

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-direct {v7, v8, v15}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10432
    new-instance v7, Landroid/util/Pair;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-direct {v7, v5, v3}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10433
    new-instance v3, Landroid/util/Pair;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10434
    iget-object v3, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    if-eqz v3, :cond_7

    if-eqz v3, :cond_8

    invoke-virtual {v3}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v3

    if-ne v3, v13, :cond_8

    .line 10435
    :cond_7
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0xe

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v7, 0x7f0e0031    # @string/add_subject 'Add subject'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10437
    :cond_8
    new-instance v3, Landroid/util/Pair;

    const/4 v5, 0x1

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10439
    sget-boolean v3, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    if-nez v3, :cond_9

    invoke-direct/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientCallable()Z

    move-result v3

    if-eqz v3, :cond_9

    .line 10440
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0xd

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const v5, 0x7f0e0136    # @string/menu_call 'Call'

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v3, v7, v8}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10442
    invoke-static/range {p0 .. p0}, Lcom/android/mms/ui/MessageUtils;->shouldShowRttCallMenu(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_9

    .line 10443
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0x12

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const v5, 0x7f0e014e    # @string/menu_rtt_call 'RTT Call'

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v3, v7, v8}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10449
    :cond_9
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v6

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v5, v6, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10450
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_11

    .line 10451
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v1, v12, v3}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    goto/16 :goto_1

    .line 10454
    :cond_a
    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    if-eqz v1, :cond_11

    invoke-virtual {v1}, Landroid/widget/EditText;->isFocused()Z

    move-result v1

    if-eqz v1, :cond_11

    .line 10455
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 10456
    new-instance v3, Landroid/util/Pair;

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10457
    new-instance v3, Landroid/util/Pair;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10458
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0xf

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v7, 0x7f0e0248    # @string/remove_subject 'Remove subject'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10459
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v6

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v5, v6, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10460
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_11

    .line 10461
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v1, v12, v3}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    goto/16 :goto_1

    .line 10467
    :cond_b
    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mRecipientsEditor:Lcom/android/mms/ui/RecipientsEditor;

    if-eqz v1, :cond_c

    invoke-virtual {v1}, Lcom/android/mms/ui/RecipientsEditor;->isFocused()Z

    move-result v1

    if-eqz v1, :cond_c

    .line 10468
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 10469
    new-instance v3, Landroid/util/Pair;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v3, v5, v8}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10470
    new-instance v3, Landroid/util/Pair;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10471
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v2, v5, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10472
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_11

    .line 10473
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v1, v12, v3}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    goto/16 :goto_1

    .line 10475
    :cond_c
    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mTextEditor:Landroid/widget/EditText;

    if-eqz v1, :cond_10

    invoke-virtual {v1}, Landroid/widget/EditText;->isFocused()Z

    move-result v1

    if-eqz v1, :cond_10

    .line 10477
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 10478
    new-instance v6, Landroid/util/Pair;

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v6, v7, v8}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10480
    new-instance v6, Landroid/util/Pair;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-direct {v6, v5, v3}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10481
    new-instance v3, Landroid/util/Pair;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10482
    iget-object v3, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectText:Landroid/widget/LinearLayout;

    if-eqz v3, :cond_d

    if-eqz v3, :cond_e

    invoke-virtual {v3}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v3

    if-ne v3, v13, :cond_e

    .line 10483
    :cond_d
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0xe

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v6, 0x7f0e0031    # @string/add_subject 'Add subject'

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10486
    :cond_e
    sget-boolean v3, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    if-nez v3, :cond_f

    invoke-direct/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientCallable()Z

    move-result v3

    if-eqz v3, :cond_f

    .line 10487
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0xd

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v5, 0x7f0e0136    # @string/menu_call 'Call'

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10489
    invoke-static/range {p0 .. p0}, Lcom/android/mms/ui/MessageUtils;->shouldShowRttCallMenu(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_f

    .line 10490
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0x12

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v5, 0x7f0e014e    # @string/menu_rtt_call 'RTT Call'

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10495
    :cond_f
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v2, v5, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10496
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_11

    .line 10497
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v1, v12, v3}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    goto :goto_1

    .line 10499
    :cond_10
    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mSubjectTextEditor:Landroid/widget/EditText;

    if-eqz v1, :cond_11

    invoke-virtual {v1}, Landroid/widget/EditText;->isFocused()Z

    move-result v1

    if-eqz v1, :cond_11

    .line 10500
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 10501
    new-instance v3, Landroid/util/Pair;

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10502
    new-instance v3, Landroid/util/Pair;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10503
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0xf

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v6, 0x7f0e0248    # @string/remove_subject 'Remove subject'

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10504
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v2, v5, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10505
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_11

    .line 10506
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v1, v12, v3}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    .line 10510
    :cond_11
    :goto_1
    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    if-eqz v1, :cond_1c

    invoke-virtual {v1}, Lcom/android/mms/ui/MessageListView;->isFocused()Z

    move-result v1

    if-eqz v1, :cond_1c

    .line 10511
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 10512
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0xb

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v6, 0x7f0e00a8    # @string/delete 'Delete'

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10513
    new-instance v3, Landroid/util/Pair;

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v6, 0x7f0e0144    # @string/menu_forward 'Forward'

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10514
    new-instance v3, Landroid/util/Pair;

    const/4 v5, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v6, 0x7f0e0163    # @string/message_report_title 'Message Report'

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10515
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    const v5, 0x7f0e02f6    # @string/view 'View'

    if-eqz v3, :cond_17

    .line 10517
    invoke-virtual {v3}, Lcom/android/mms/ui/MessageListItem;->actionType()I

    move-result v3

    const/16 v6, 0xd

    if-eq v3, v6, :cond_12

    .line 10518
    new-instance v3, Landroid/util/Pair;

    const/16 v6, 0x10

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v7, 0x7f0e0097    # @string/copy_to_sdcard 'Save attachment'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10521
    :cond_12
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v3}, Lcom/android/mms/ui/MessageListItem;->actionType()I

    move-result v3

    const/4 v6, 0x1

    if-eq v3, v6, :cond_16

    if-eq v3, v12, :cond_15

    const/4 v6, 0x3

    if-eq v3, v6, :cond_14

    if-eq v3, v9, :cond_13

    goto :goto_2

    .line 10526
    :cond_13
    new-instance v3, Landroid/util/Pair;

    const/4 v6, 0x7

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 10532
    :cond_14
    new-instance v3, Landroid/util/Pair;

    const/16 v6, 0xc

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v7, 0x7f0e01be    # @string/play 'Play'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 10529
    :cond_15
    new-instance v3, Landroid/util/Pair;

    const/16 v6, 0xc

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v7, 0x7f0e01be    # @string/play 'Play'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 10523
    :cond_16
    new-instance v3, Landroid/util/Pair;

    const/4 v6, 0x7

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10536
    :goto_2
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v3}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v3

    if-eqz v3, :cond_17

    .line 10537
    invoke-virtual {v3}, Lcom/android/mms/ui/MessageItem;->isFailedMessage()Z

    move-result v6

    if-eqz v6, :cond_17

    invoke-virtual {v3}, Lcom/android/mms/ui/MessageItem;->isOutgoingMessage()Z

    move-result v3

    if-eqz v3, :cond_17

    .line 10538
    new-instance v3, Landroid/util/Pair;

    const/16 v6, 0xa

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v7, 0x7f0e014d    # @string/menu_resend 'Resend'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10543
    :cond_17
    sget-boolean v3, Lcom/android/mms/ui/ComposeMessageActivity;->mIsNewMessageUi:Z

    if-nez v3, :cond_18

    invoke-direct/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->isRecipientCallable()Z

    move-result v3

    if-eqz v3, :cond_18

    .line 10544
    new-instance v3, Landroid/util/Pair;

    const/16 v6, 0xd

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v7, 0x7f0e0136    # @string/menu_call 'Call'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10546
    invoke-static/range {p0 .. p0}, Lcom/android/mms/ui/MessageUtils;->shouldShowRttCallMenu(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_18

    .line 10547
    new-instance v3, Landroid/util/Pair;

    const/16 v6, 0x12

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const v7, 0x7f0e014e    # @string/menu_rtt_call 'RTT Call'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10552
    :cond_18
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    const v6, 0x7f0e014c    # @string/menu_reply 'Reply'

    if-eqz v3, :cond_19

    invoke-virtual {v3}, Lcom/android/mms/ui/MessageListItem;->canShowingMore()Z

    move-result v3

    if-eqz v3, :cond_19

    .line 10554
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    if-eqz v3, :cond_1c

    .line 10555
    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v7

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v5, v7, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10556
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_1c

    .line 10557
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v12, v2}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    .line 10559
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {v0, v6}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v4, v2}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    goto/16 :goto_3

    .line 10565
    :cond_19
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    if-eqz v3, :cond_1b

    invoke-virtual {v3}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v3

    iget v3, v3, Lcom/android/mms/ui/MessageItem;->mMessageType:I

    const/16 v5, 0x82

    if-ne v3, v5, :cond_1b

    .line 10567
    new-instance v3, Landroid/util/Pair;

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v7, 0x7f0e0144    # @string/menu_forward 'Forward'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 10568
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v3}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/mms/ui/MessageItem;->getMmsDownloadStatus()I

    move-result v3

    const/16 v5, 0x83

    if-eq v3, v5, :cond_1a

    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    .line 10570
    invoke-virtual {v3}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/mms/ui/MessageItem;->getMmsDownloadStatus()I

    move-result v3

    const/16 v5, 0x81

    if-eq v3, v5, :cond_1a

    .line 10573
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    if-eqz v3, :cond_1c

    .line 10574
    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v7, 0x7f0e01a6    # @string/notification_download 'Download'

    invoke-virtual {v5, v7}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v7

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v5, v7, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10575
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_1c

    .line 10576
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v12, v2}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    .line 10578
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {v0, v6}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v4, v2}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    goto/16 :goto_3

    .line 10584
    :cond_1a
    new-instance v3, Landroid/util/Pair;

    const/16 v5, 0xb

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v7, 0x7f0e00a8    # @string/delete 'Delete'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 10585
    new-instance v3, Landroid/util/Pair;

    const/4 v5, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const v7, 0x7f0e0163    # @string/message_report_title 'Message Report'

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 10587
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    if-eqz v3, :cond_1c

    .line 10588
    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v2, v5, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10589
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_1c

    .line 10590
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v12, v2}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    .line 10592
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {v0, v6}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v4, v2}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    goto :goto_3

    .line 10601
    :cond_1b
    sget-object v3, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    if-eqz v3, :cond_1c

    .line 10605
    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    # tzib inbox options: paste
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibClipboard;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v3, v2, v2, v5, v1}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 10606
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_1c

    .line 10607
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual/range {p0 .. p0}, Lcom/android/mms/ui/ComposeMessageActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v12, v2}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    .line 10608
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {v0, v6}, Lcom/android/mms/ui/ComposeMessageActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v4, v2}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    .line 10618
    :cond_1c
    :goto_3
    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    if-eqz v1, :cond_1d

    invoke-virtual {v1}, Lcom/android/mms/ui/MoreAttachmentView;->getVisibility()I

    move-result v1

    if-nez v1, :cond_1d

    iget-object v1, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v1}, Lcom/android/mms/ui/MoreAttachmentView;->hasFocus()Z

    move-result v1

    if-eqz v1, :cond_1d

    .line 10619
    iget-object v0, v0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MoreAttachmentView;->setMenubar()V

    :cond_1d
    return-void
.end method

.method public viewAttachment()V
    .locals 12

    const/4 v0, 0x0

    .line 10055
    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    .line 10057
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMsgListView:Lcom/android/mms/ui/MessageListView;

    invoke-virtual {v1}, Lcom/android/mms/ui/MessageListView;->isFocused()Z

    move-result v1

    const-string v2, "vcard"

    const-string v3, "audio"

    const-string v4, "video"

    const-string v5, "image"

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v1, :cond_4

    .line 10058
    sget-object v1, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v1}, Lcom/android/mms/ui/MessageListItem;->getMessageItem()Lcom/android/mms/ui/MessageItem;

    move-result-object v1

    .line 10059
    iget-object v10, v1, Lcom/android/mms/ui/MessageItem;->mType:Ljava/lang/String;

    const-string v11, "mms"

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_5

    .line 10060
    sget-object v10, Lcom/android/mms/ui/ComposeMessageActivity;->mSelectedMsgItem:Lcom/android/mms/ui/MessageListItem;

    invoke-virtual {v10}, Lcom/android/mms/ui/MessageListItem;->actionType()I

    move-result v10

    if-eq v10, v8, :cond_3

    if-eq v10, v7, :cond_2

    if-eq v10, v6, :cond_1

    const/4 v11, 0x5

    if-eq v10, v11, :cond_0

    goto :goto_0

    .line 10066
    :cond_0
    iget-object v0, v1, Lcom/android/mms/ui/MessageItem;->mSlideshow:Lcom/android/mms/model/SlideshowModel;

    invoke-virtual {v0, v9}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getVcard()Lcom/android/mms/model/VcardModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/VcardModel;->getUri()Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    move-object v0, v2

    goto :goto_0

    .line 10074
    :cond_1
    iget-object v0, v1, Lcom/android/mms/ui/MessageItem;->mSlideshow:Lcom/android/mms/model/SlideshowModel;

    invoke-virtual {v0, v9}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getAudio()Lcom/android/mms/model/AudioModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/AudioModel;->getUri()Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    move-object v0, v3

    goto :goto_0

    .line 10070
    :cond_2
    iget-object v0, v1, Lcom/android/mms/ui/MessageItem;->mSlideshow:Lcom/android/mms/model/SlideshowModel;

    invoke-virtual {v0, v9}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getVideo()Lcom/android/mms/model/VideoModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/VideoModel;->getUri()Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    move-object v0, v4

    goto :goto_0

    .line 10062
    :cond_3
    iget-object v0, v1, Lcom/android/mms/ui/MessageItem;->mSlideshow:Lcom/android/mms/model/SlideshowModel;

    invoke-virtual {v0, v9}, Lcom/android/mms/model/SlideshowModel;->get(I)Lcom/android/mms/model/SlideModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/SlideModel;->getImage()Lcom/android/mms/model/ImageModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/mms/model/ImageModel;->getUri()Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    move-object v0, v5

    goto :goto_0

    .line 10080
    :cond_4
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    if-eqz v1, :cond_5

    invoke-virtual {v1}, Lcom/android/mms/ui/MoreAttachmentView;->isGetFocused()Z

    move-result v1

    if-eqz v1, :cond_5

    .line 10081
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MoreAttachmentView;->getUri()Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    .line 10082
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mMoreAttachemntView:Lcom/android/mms/ui/MoreAttachmentView;

    invoke-virtual {v0}, Lcom/android/mms/ui/MoreAttachmentView;->getType()Ljava/lang/String;

    move-result-object v0

    .line 10085
    :cond_5
    :goto_0
    iget-object v1, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    if-eqz v1, :cond_b

    const/4 v1, -0x1

    .line 10086
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v10

    sparse-switch v10, :sswitch_data_0

    goto :goto_1

    :sswitch_0    # 0x6b0147b
    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    move v9, v7

    goto :goto_2

    :sswitch_1    # 0x6ad5086
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    move v9, v8

    goto :goto_2

    :sswitch_2    # 0x5faa95b
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    goto :goto_2

    :sswitch_3    # 0x58d9bd6
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    move v9, v6

    goto :goto_2

    :cond_6
    :goto_1
    move v9, v1

    :goto_2
    if-eqz v9, :cond_a

    if-eq v9, v8, :cond_9

    if-eq v9, v7, :cond_8

    if-eq v9, v6, :cond_7

    goto :goto_3

    .line 10097
    :cond_7
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    const-string v1, "audio/*"

    invoke-direct {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->previewAttach(Landroid/net/Uri;Ljava/lang/String;)V

    goto :goto_3

    .line 10094
    :cond_8
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    const-string v1, "video/*"

    invoke-direct {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->previewAttach(Landroid/net/Uri;Ljava/lang/String;)V

    goto :goto_3

    .line 10091
    :cond_9
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    invoke-direct {p0, v0}, Lcom/android/mms/ui/ComposeMessageActivity;->previewVcard(Landroid/net/Uri;)V

    goto :goto_3

    .line 10088
    :cond_a
    iget-object v0, p0, Lcom/android/mms/ui/ComposeMessageActivity;->mTempMmsUri:Landroid/net/Uri;

    const-string v1, "image/*"

    invoke-direct {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->previewAttach(Landroid/net/Uri;Ljava/lang/String;)V

    :cond_b
    :goto_3
    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x58d9bd6 -> :sswitch_3
        0x5faa95b -> :sswitch_2
        0x6ad5086 -> :sswitch_1
        0x6b0147b -> :sswitch_0

    .end sparse-switch
.end method
