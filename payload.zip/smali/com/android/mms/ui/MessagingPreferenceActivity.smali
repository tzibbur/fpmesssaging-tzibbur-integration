.class public Lcom/android/mms/ui/MessagingPreferenceActivity;
.super Landroid/preference/PreferenceActivity;
.source "MessagingPreferenceActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/mms/ui/MessagingPreferenceActivity$MyAlertDialogFragment;,
        Lcom/android/mms/ui/MessagingPreferenceActivity$MyEditDialogFragment;,
        Lcom/android/mms/ui/MessagingPreferenceActivity$SmscHandler;
    }
.end annotation


# static fields
.field private static final ACTION_CONFIGURE_MESSAGE:Ljava/lang/String; = "org.codeaurora.CONFIGURE_MESSAGE"

.field public static final AUTO_DELETE:Ljava/lang/String; = "pref_key_auto_delete"

.field public static final AUTO_RETRIEVAL:Ljava/lang/String; = "pref_key_mms_auto_retrieval"

.field public static final CELL_BROADCAST:Ljava/lang/String; = "pref_key_cell_broadcast"

.field public static final CHAT_WALLPAPER:Ljava/lang/String; = "chat_wallpaper"

.field public static final CHAT_WALLPAPER_SETTING:Ljava/lang/String; = "pref_key_chat_wallpaper"

.field public static final CONFIGURATION_MESSAGE:Ljava/lang/String; = "pref_key_configuration_message"

.field private static final CONFIRM_CLEAR_SEARCH_HISTORY_DIALOG:I = 0x3

.field public static final CREATION_MODE_FREE:I = 0x3

.field public static final CREATION_MODE_RESTRICTED:I = 0x1

.field public static final CREATION_MODE_WARNING:I = 0x2

.field public static final ENABLE_GESTURE:Ljava/lang/String; = "pref_key_enable_gesture"

.field public static final ENABLE_SELECTABLE_COPY:Ljava/lang/String; = "pref_key_enable_selectable_copy"

.field public static final ENABLE_SELECTABLE_COPY_DEFAULT_VALUE:Z = true

.field private static final EVENT_GET_SMSC_DONE:I = 0x1

.field private static final EVENT_SET_SMSC_DONE:I = 0x0

.field private static final EVENT_SET_SMSC_PREF_DONE:I = 0x2

.field private static final EXPIRY_ONE_WEEK:Ljava/lang/String; = "604800"

.field public static final EXPIRY_TIME:Ljava/lang/String; = "pref_key_mms_expiry"

.field public static final EXPIRY_TIME_SLOT1:Ljava/lang/String; = "pref_key_mms_expiry_slot1"

.field public static final EXPIRY_TIME_SLOT2:Ljava/lang/String; = "pref_key_mms_expiry_slot2"

.field private static final EXPIRY_TWO_DAYS:Ljava/lang/String; = "172800"

.field public static final FIRST_BOOST:Ljava/lang/String; = "key_first_boost"

.field public static final FONT_SIZE_SETTING:Ljava/lang/String; = "pref_key_message_font_size"

.field public static final GROUP_MMS_MODE:Ljava/lang/String; = "pref_key_mms_group_mms"

.field private static final MENU_RESTORE_DEFAULTS:I = 0x1

.field public static final MESSAGE_FONT_SIZE:Ljava/lang/String; = "message_font_size"

.field public static final MMS_CREATION_MODE:Ljava/lang/String; = "pref_key_creation_mode"

.field public static final MMS_DELIVERY_REPORT_MODE:Ljava/lang/String; = "pref_key_mms_delivery_reports"

.field public static final NOTIFICATIONS:Ljava/lang/String; = "pref_settings_notification"

.field public static final NOTIFICATION_ENABLED:Ljava/lang/String; = "pref_key_enable_notifications"

.field public static final NOTIFICATION_RINGTONE:Ljava/lang/String; = "pref_key_ringtone"

.field public static final NOTIFICATION_VIBRATE:Ljava/lang/String; = "pref_key_vibrate"

.field public static final NOTIFICATION_VIBRATE_WHEN:Ljava/lang/String; = "pref_key_vibrateWhen"

.field public static final OMACP_CONFIGURATION_CATEGORY:Ljava/lang/String; = "pref_key_sms_omacp_configuration"

.field private static final PICK_FROM_CAMERA:I = 0x0

.field private static final PICK_FROM_GALLERY:I = 0x1

.field public static final PRIORITY:Ljava/lang/String; = "pref_key_mms_priority"

.field public static final READ_REPORT_MODE:Ljava/lang/String; = "pref_key_mms_read_reports"

.field public static final RETRIEVAL_DURING_ROAMING:Ljava/lang/String; = "pref_key_mms_retrieval_during_roaming"

.field public static final SEPERATE_NOTIFI_MSG:Ljava/lang/String; = "pref_key_seperate_notification_msg"

.field public static final SMSC_DEFAULT:Ljava/lang/String; = "pref_key_default_smsc"

.field private static final SMSC_DIALOG_NUMBER:Ljava/lang/String; = "smsc"

.field private static final SMSC_DIALOG_SUB:Ljava/lang/String; = "sub"

.field private static final SMSC_DIALOG_TITLE:Ljava/lang/String; = "title"

.field public static final SMS_DELIVERY_REPORT_MODE:Ljava/lang/String; = "pref_key_sms_delivery_reports"

.field public static final SMS_DELIVERY_REPORT_SUB1:Ljava/lang/String; = "pref_key_sms_delivery_reports_slot1"

.field public static final SMS_DELIVERY_REPORT_SUB2:Ljava/lang/String; = "pref_key_sms_delivery_reports_slot2"

.field public static final SMS_ENCODING_FORMAT:Ljava/lang/String; = "pref_key_sms_encoding_mode"

.field public static final SMS_VALIDITY_FOR_SIM1:Ljava/lang/String; = "pref_key_sms_validity_period_for_sim1"

.field public static final SMS_VALIDITY_FOR_SIM2:Ljava/lang/String; = "pref_key_sms_validity_period_for_sim2"

.field public static final SMS_VALIDITY_NO_MULTI:Ljava/lang/String; = "pref_key_sms_validity_period_no_multi"

.field public static final SMS_VALIDITY_SIM1:Ljava/lang/String; = "pref_key_sms_validity_period_sim1"

.field public static final SMS_VALIDITY_SIM2:Ljava/lang/String; = "pref_key_sms_validity_period_sim2"

.field private static final TAG:Ljava/lang/String; = "MessagingPreferenceActivity"

.field public static final WIRELESS_EMERGENCY_ALERT:Ljava/lang/String; = "pref_key_wea"

.field public static final ZOOM_MESSAGE:Ljava/lang/String; = "pref_key_zoom_message"

.field private static mHandler:Lcom/android/mms/ui/MessagingPreferenceActivity$SmscHandler;


# instance fields
.field private PREFERENCE_POSITION_AUTO_DELETE:I

.field private PREFERENCE_POSITION_AUTO_RETRIEVAL:I

.field private PREFERENCE_POSITION_DELETE_LIMIT:I

.field private PREFERENCE_POSITION_GROUP_MMS:I

.field private PREFERENCE_POSITION_NOTIFICATION:I

.field private PREFERENCE_POSITION_REQUEST_RECEIPT:I

.field private PREFERENCE_POSITION_RETRIEVAL_DURING_ROAMING:I

.field private PREFERENCE_POSITION_SIGNATURE:I

.field private PREFERENCE_POSITION_SMS_ENCODING:I

.field private PREFERENCE_POSITION_START:I

.field private PREFERENCE_POSITION_WEA:I

.field public fixedPosition:I

.field private mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

.field private mAudioManager:Landroid/media/AudioManager;

.field private mAutoDeleteMessage:Landroid/preference/Preference;

.field private mIsSmsEnabled:Z

.field private mMenuBar:Landroid/widget/MenuBar;

.field private mMmsAutoRetrievialPref:Landroid/preference/Preference;

.field private mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

.field private mMmsGroupMmsPref:Landroid/preference/Preference;

.field private mMmsRecycler:Lcom/android/mms/util/Recycler;

.field private mNotificationPref:Landroid/preference/Preference;

.field private mPreferenceList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mReceiver:Landroid/content/BroadcastReceiver;

.field private mRequestReceiptPref:Landroid/preference/Preference;

.field private mSmsEncodingPref:Landroid/preference/Preference;

.field mSmsLimitListener:Lcom/android/mms/ui/NumberPickerDialog$OnNumberSetListener;

.field private mSmsLimitPref:Landroid/preference/Preference;

.field private mSmsRecycler:Lcom/android/mms/util/Recycler;

.field private mSmsSignatureEditPref:Landroid/preference/Preference;

.field private mSmscPrefList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/preference/Preference;",
            ">;"
        }
    .end annotation
.end field

.field private mWeaPref:Landroid/preference/Preference;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 92
    invoke-direct {p0}, Landroid/preference/PreferenceActivity;-><init>()V

    .line 169
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmscPrefList:Ljava/util/ArrayList;

    const/4 v0, 0x1

    .line 196
    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    .line 211
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mPreferenceList:Ljava/util/List;

    const/4 v0, 0x0

    .line 214
    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 216
    new-instance v0, Lcom/android/mms/ui/MessagingPreferenceActivity$1;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/MessagingPreferenceActivity$1;-><init>(Lcom/android/mms/ui/MessagingPreferenceActivity;)V

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mReceiver:Landroid/content/BroadcastReceiver;

    .line 564
    new-instance v0, Lcom/android/mms/ui/MessagingPreferenceActivity$3;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/MessagingPreferenceActivity$3;-><init>(Lcom/android/mms/ui/MessagingPreferenceActivity;)V

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitListener:Lcom/android/mms/ui/NumberPickerDialog$OnNumberSetListener;

    return-void
.end method

.method public static IsShowGroupMMSSetting()Z
    .locals 2

    .line 882
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "IsShowGroupMMSSetting GroupMmsEnabled = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/android/mms/MmsConfig;->getGroupMmsEnabled()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, " local number isEmpty = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->getLocalNumber()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "MessagingPreferenceActivity"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 883
    invoke-static {}, Lcom/android/mms/MmsConfig;->getGroupMmsEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->getLocalNumber()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method static synthetic access$000(Lcom/android/mms/ui/MessagingPreferenceActivity;)V
    .locals 0

    .line 92
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->updateSMSCPref()V

    return-void
.end method

.method static synthetic access$100(Lcom/android/mms/ui/MessagingPreferenceActivity;)Lcom/android/mms/util/Recycler;
    .locals 0

    .line 92
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsRecycler:Lcom/android/mms/util/Recycler;

    return-object p0
.end method

.method static synthetic access$1000(Landroid/content/Context;ILjava/lang/String;Landroid/os/Message;)V
    .locals 0

    .line 92
    invoke-static {p0, p1, p2, p3}, Lcom/android/mms/ui/MessagingPreferenceActivity;->putSmscIntoPref(Landroid/content/Context;ILjava/lang/String;Landroid/os/Message;)V

    return-void
.end method

.method static synthetic access$1100(Lcom/android/mms/ui/MessagingPreferenceActivity;)Landroid/widget/MenuBar;
    .locals 0

    .line 92
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMenuBar:Landroid/widget/MenuBar;

    return-object p0
.end method

.method static synthetic access$1200(Lcom/android/mms/ui/MessagingPreferenceActivity;)Lcom/android/mms/util/Recycler;
    .locals 0

    .line 92
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsRecycler:Lcom/android/mms/util/Recycler;

    return-object p0
.end method

.method static synthetic access$200(Lcom/android/mms/ui/MessagingPreferenceActivity;)V
    .locals 0

    .line 92
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->setSmsDisplayLimit()V

    return-void
.end method

.method static synthetic access$300(Lcom/android/mms/ui/MessagingPreferenceActivity;I)V
    .locals 0

    .line 92
    invoke-direct {p0, p1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->showToast(I)V

    return-void
.end method

.method static synthetic access$400(Lcom/android/mms/ui/MessagingPreferenceActivity;Landroid/os/Bundle;)V
    .locals 0

    .line 92
    invoke-direct {p0, p1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->updateSmscFromBundle(Landroid/os/Bundle;)V

    return-void
.end method

.method static synthetic access$500(Lcom/android/mms/ui/MessagingPreferenceActivity;I)V
    .locals 0

    .line 92
    invoke-direct {p0, p1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->updateSmscFromPreference(I)V

    return-void
.end method

.method static synthetic access$700(Lcom/android/mms/ui/MessagingPreferenceActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 92
    invoke-direct {p0, p1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->adjustSMSC(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$800()Lcom/android/mms/ui/MessagingPreferenceActivity$SmscHandler;
    .locals 1

    .line 92
    sget-object v0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mHandler:Lcom/android/mms/ui/MessagingPreferenceActivity$SmscHandler;

    return-object v0
.end method

.method private addMenuBarInBottom()V
    .locals 4

    .line 999
    new-instance v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v1, -0x1

    invoke-direct {v0, v1, v1}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/16 v1, 0xc

    .line 1001
    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 1002
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v2, 0x7f0a004a    # @layout/menubar_setting_bottom 'res/layout/menubar_setting_bottom.xml'

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    .line 1003
    invoke-virtual {p0, v1, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1005
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMenuBar:Landroid/widget/MenuBar;

    .line 1007
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result p0

    if-eqz p0, :cond_0

    const p0, 0x7f0e0126    # @string/menu_action_ok 'OK'

    goto :goto_0

    :cond_0
    const p0, 0x7f0e0135    # @string/menu_bar_select 'Select'

    :goto_0
    const/4 v1, 0x0

    invoke-virtual {v0, v1, p0, v1, v3}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    return-void
.end method

.method private adjustSMSC(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 858
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "\""

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static enableNotifications(ZLandroid/content/Context;)V
    .locals 1

    .line 622
    invoke-static {p1}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string v0, "pref_key_enable_notifications"

    .line 624
    invoke-interface {p1, v0, p0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 626
    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static getIsGroupMmsEnabled(Landroid/content/Context;)Z
    .locals 3

    .line 867
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "pref_key_mms_group_mms"

    const/4 v1, 0x1

    .line 868
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    .line 871
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "getIsGroupMmsEnabled groupMmsPrefOn = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, " GroupMmsEnabled() = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 872
    invoke-static {}, Lcom/android/mms/MmsConfig;->getGroupMmsEnabled()Z

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, " LocalNumber is null = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 873
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->getLocalNumber()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "MessagingPreferenceActivity"

    .line 871
    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 875
    invoke-static {}, Lcom/android/mms/MmsConfig;->getGroupMmsEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    if-eqz p0, :cond_0

    .line 877
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->getLocalNumber()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public static getNotificationEnabled(Landroid/content/Context;)Z
    .locals 2

    .line 613
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "pref_key_enable_notifications"

    const/4 v1, 0x1

    .line 615
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method private handleAutoDeleteMessage()V
    .locals 2

    .line 1095
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_AUTO_DELETE:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1096
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/MessagingDeleteOldActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private handleMmsAutoRetrievialPref()V
    .locals 2

    .line 1113
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_AUTO_RETRIEVAL:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1114
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/AutoRetrieveActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private handleMmsAutoRetrievialRoamingPref()V
    .locals 3

    .line 1118
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_RETRIEVAL_DURING_ROAMING:I

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1120
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v2, "pref_key_mms_auto_retrieval"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1121
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/RoamingAutoRetrieveActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method private handleMmsGroupMmsPref()V
    .locals 2

    .line 1126
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_GROUP_MMS:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1127
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/GroupMmsActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private handleNotificationPref()V
    .locals 3

    .line 1081
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_NOTIFICATION:I

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1082
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "android.settings.CHANNEL_NOTIFICATION_SETTINGS"

    .line 1083
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 1084
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "android.provider.extra.APP_PACKAGE"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "android.provider.extra.CHANNEL_ID"

    const-string v2, "DefaultChannel"

    .line 1085
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 1086
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private handleRequestReceiptPref()V
    .locals 2

    .line 1108
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_REQUEST_RECEIPT:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1109
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/RequestReceiptActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private handleSmsEncodingPref()V
    .locals 2

    .line 1131
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SMS_ENCODING:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1132
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/SmsEncodingActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private handleSmsLimitPref()V
    .locals 3

    .line 1100
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_DELETE_LIMIT:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1102
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "pref_key_auto_delete"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1103
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->showLimitNumberPicker()V

    :cond_0
    return-void
.end method

.method private handleSmsSignatureEditPref()V
    .locals 2

    .line 1090
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SIGNATURE:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1091
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/MessagingAutoSignatureActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private handleWeaPref()V
    .locals 4

    .line 1136
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_WEA:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 1137
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.MAIN"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 1138
    new-instance v1, Landroid/content/ComponentName;

    const-string v2, "com.android.cellbroadcastreceiver"

    const-string v3, "com.android.cellbroadcastreceiver.FeaturephoneWeaListActivity"

    invoke-direct {v1, v2, v3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const/high16 v1, 0x10000000

    .line 1141
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 1142
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private hanldeKeyUpEvent(I)V
    .locals 1

    .line 1057
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_NOTIFICATION:I

    if-ne p1, v0, :cond_0

    .line 1058
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleNotificationPref()V

    goto :goto_0

    .line 1059
    :cond_0
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SIGNATURE:I

    if-ne p1, v0, :cond_1

    .line 1060
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleSmsSignatureEditPref()V

    goto :goto_0

    .line 1061
    :cond_1
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_AUTO_DELETE:I

    if-ne p1, v0, :cond_2

    .line 1062
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleAutoDeleteMessage()V

    goto :goto_0

    .line 1063
    :cond_2
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_DELETE_LIMIT:I

    if-ne p1, v0, :cond_3

    .line 1064
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleSmsLimitPref()V

    goto :goto_0

    .line 1065
    :cond_3
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_REQUEST_RECEIPT:I

    if-ne p1, v0, :cond_4

    .line 1066
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleRequestReceiptPref()V

    goto :goto_0

    .line 1067
    :cond_4
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_AUTO_RETRIEVAL:I

    if-ne p1, v0, :cond_5

    .line 1068
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleMmsAutoRetrievialPref()V

    goto :goto_0

    .line 1069
    :cond_5
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_RETRIEVAL_DURING_ROAMING:I

    if-ne p1, v0, :cond_6

    .line 1070
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleMmsAutoRetrievialRoamingPref()V

    goto :goto_0

    .line 1071
    :cond_6
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_GROUP_MMS:I

    if-ne p1, v0, :cond_7

    .line 1072
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleMmsGroupMmsPref()V

    goto :goto_0

    .line 1073
    :cond_7
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SMS_ENCODING:I

    if-ne p1, v0, :cond_8

    .line 1074
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleSmsEncodingPref()V

    goto :goto_0

    .line 1075
    :cond_8
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_WEA:I

    if-ne p1, v0, :cond_9

    .line 1076
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleWeaPref()V

    :cond_9
    :goto_0
    return-void
.end method

.method private initCustomActionBar()V
    .locals 4

    .line 249
    new-instance v0, Landroid/app/ActionBar$LayoutParams;

    const/4 v1, -0x1

    const/16 v2, 0x11

    invoke-direct {v0, v1, v1, v2}, Landroid/app/ActionBar$LayoutParams;-><init>(III)V

    .line 251
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v2, 0x7f0a001d    # @layout/actionbar_title 'res/layout/actionbar_title.xml'

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    .line 252
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getActionBar()Landroid/app/ActionBar;

    move-result-object p0

    if-nez p0, :cond_0

    return-void

    .line 256
    :cond_0
    invoke-virtual {p0, v1, v0}, Landroid/app/ActionBar;->setCustomView(Landroid/view/View;Landroid/app/ActionBar$LayoutParams;)V

    const/16 v0, 0x10

    .line 257
    invoke-virtual {p0, v0}, Landroid/app/ActionBar;->setDisplayOptions(I)V

    const/4 v0, 0x0

    .line 259
    invoke-virtual {p0, v0}, Landroid/app/ActionBar;->setDisplayHomeAsUpEnabled(Z)V

    const/4 v2, 0x1

    .line 261
    invoke-virtual {p0, v2}, Landroid/app/ActionBar;->setHomeButtonEnabled(Z)V

    .line 263
    invoke-virtual {p0, v0}, Landroid/app/ActionBar;->setDisplayShowHomeEnabled(Z)V

    .line 265
    invoke-virtual {p0, v0}, Landroid/app/ActionBar;->setDisplayShowTitleEnabled(Z)V

    .line 267
    invoke-virtual {p0, v2}, Landroid/app/ActionBar;->setDisplayShowCustomEnabled(Z)V

    .line 269
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    check-cast p0, Landroid/widget/Toolbar;

    .line 270
    invoke-virtual {p0, v0, v0}, Landroid/widget/Toolbar;->setContentInsetsAbsolute(II)V

    return-void
.end method

.method private initPreferenceList()V
    .locals 3

    .line 276
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SIGNATURE:I

    .line 280
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isATT()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 281
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SMS_ENCODING:I

    goto :goto_0

    .line 284
    :cond_0
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isDISH()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isAttSimCard()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 285
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_WEA:I

    goto :goto_0

    .line 289
    :cond_1
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_REQUEST_RECEIPT:I

    add-int/lit8 v0, v1, 0x1

    .line 290
    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    iput v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_AUTO_RETRIEVAL:I

    add-int/lit8 v1, v0, 0x1

    .line 291
    iput v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_RETRIEVAL_DURING_ROAMING:I

    add-int/lit8 v0, v1, 0x1

    .line 292
    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    iput v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_WEA:I

    .line 295
    :goto_0
    invoke-static {}, Lcom/android/mms/ui/MessagingPreferenceActivity;->IsShowGroupMMSSetting()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 296
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_GROUP_MMS:I

    .line 299
    :cond_2
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SIGNATURE:I

    :goto_1
    iget v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_START:I

    if-ge v0, v1, :cond_3

    .line 300
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mPreferenceList:Ljava/util/List;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    return-void
.end method

.method private isAirPlaneModeOn()Z
    .locals 2

    .line 491
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string v0, "airplane_mode_on"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result p0

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    :cond_0
    return v1
.end method

.method private loadPrefs()V
    .locals 2

    .line 372
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f040018    # @bool/def_custom_preferences_settings 'false'

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v0

    if-eqz v0, :cond_0

    const/high16 v0, 0x7f110000    # @xml/custom_preferences 'res/xml/custom_preferences.xml'

    .line 373
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->addPreferencesFromResource(I)V

    goto :goto_0

    .line 375
    :cond_0
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isATT()Z

    move-result v0

    if-eqz v0, :cond_1

    const v0, 0x7f110002    # @xml/gflip_preferences_att 'res/xml/gflip_preferences_att.xml'

    .line 376
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->addPreferencesFromResource(I)V

    goto :goto_0

    :cond_1
    const v0, 0x7f110001    # @xml/gflip_preferences 'res/xml/gflip_preferences.xml'

    .line 378
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->addPreferencesFromResource(I)V

    :goto_0
    const-string v0, "pref_key_sms_delete_limit"

    .line 382
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitPref:Landroid/preference/Preference;

    const-string v0, "pref_key_edit_signature"

    .line 383
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsSignatureEditPref:Landroid/preference/Preference;

    const-string v0, "pref_settings_notification"

    .line 384
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mNotificationPref:Landroid/preference/Preference;

    const-string v0, "vibrator"

    .line 385
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Vibrator;

    const-string v0, "pref_key_root"

    .line 386
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v0

    check-cast v0, Landroid/preference/PreferenceScreen;

    const-string v1, "pref_key_auto_delete"

    .line 387
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAutoDeleteMessage:Landroid/preference/Preference;

    const-string v1, "pref_key_request_receipt"

    .line 389
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mRequestReceiptPref:Landroid/preference/Preference;

    const-string v1, "pref_key_mms_auto_retrieval"

    .line 390
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialPref:Landroid/preference/Preference;

    const-string v1, "pref_key_mms_retrieval_during_roaming"

    .line 391
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

    const-string v1, "pref_key_wea"

    .line 392
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mWeaPref:Landroid/preference/Preference;

    const-string v1, "pref_key_sms_encoding_mode"

    .line 393
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsEncodingPref:Landroid/preference/Preference;

    .line 397
    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isATT()Z

    move-result v1

    if-nez v1, :cond_2

    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isDISH()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-static {}, Lcom/android/mms/util/BuildProperties;->isAttSimCard()Z

    move-result v1

    if-eqz v1, :cond_3

    .line 398
    :cond_2
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mRequestReceiptPref:Landroid/preference/Preference;

    invoke-virtual {v0, v1}, Landroid/preference/PreferenceScreen;->removePreference(Landroid/preference/Preference;)Z

    .line 399
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialPref:Landroid/preference/Preference;

    invoke-virtual {v0, v1}, Landroid/preference/PreferenceScreen;->removePreference(Landroid/preference/Preference;)Z

    .line 400
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

    invoke-virtual {v0, v1}, Landroid/preference/PreferenceScreen;->removePreference(Landroid/preference/Preference;)Z

    :cond_3
    const-string v1, "pref_key_mms_group_mms"

    .line 405
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsGroupMmsPref:Landroid/preference/Preference;

    .line 406
    invoke-static {}, Lcom/android/mms/ui/MessagingPreferenceActivity;->IsShowGroupMMSSetting()Z

    move-result v1

    if-nez v1, :cond_4

    .line 407
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsGroupMmsPref:Landroid/preference/Preference;

    invoke-virtual {v0, v1}, Landroid/preference/PreferenceScreen;->removePreference(Landroid/preference/Preference;)Z

    .line 410
    :cond_4
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mNotificationPref:Landroid/preference/Preference;

    invoke-virtual {v0, v1}, Landroid/preference/PreferenceScreen;->removePreference(Landroid/preference/Preference;)Z

    .line 411
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAutoDeleteMessage:Landroid/preference/Preference;

    invoke-virtual {v0, v1}, Landroid/preference/PreferenceScreen;->removePreference(Landroid/preference/Preference;)Z

    .line 412
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitPref:Landroid/preference/Preference;

    invoke-virtual {v0, v1}, Landroid/preference/PreferenceScreen;->removePreference(Landroid/preference/Preference;)Z

    .line 415
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->setPreferenceTitle()V

    .line 416
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->setMessagePreferences()V

    .line 417
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->addMenuBarInBottom()V

    # tzib unified: settings
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->install(Landroid/preference/PreferenceActivity;)V

    return-void
.end method

.method private static putSmscIntoPref(Landroid/content/Context;ILjava/lang/String;Landroid/os/Message;)V
    .locals 1

    .line 980
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "pref_key_default_smsc"

    .line 981
    invoke-interface {p0, v0, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 982
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 983
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 985
    new-instance p0, Landroid/os/Bundle;

    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    const-string v0, "slot"

    .line 986
    invoke-virtual {p0, v0, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string p1, "smsc"

    .line 987
    invoke-virtual {p0, p1, p2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 989
    iget-object p1, p3, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Landroid/os/Parcelable;

    const-string p2, "userobj"

    invoke-virtual {p0, p2, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 990
    iput-object p0, p3, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 992
    invoke-virtual {p3}, Landroid/os/Message;->getTarget()Landroid/os/Handler;

    move-result-object p0

    if-eqz p0, :cond_0

    .line 993
    invoke-virtual {p3}, Landroid/os/Message;->sendToTarget()V

    :cond_0
    return-void
.end method

.method private registerListeners()V
    .locals 2

    .line 631
    new-instance v0, Landroid/content/IntentFilter;

    const-string v1, "android.intent.action.SIM_STATE_CHANGED"

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const-string v1, "android.intent.action.AIRPLANE_MODE"

    .line 633
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 634
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v1, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    return-void
.end method

.method private restoreDefaultPreferences()V
    .locals 1

    .line 441
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v0, 0x0

    .line 442
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->setPreferenceScreen(Landroid/preference/PreferenceScreen;)V

    .line 444
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmscPrefList:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 445
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->loadPrefs()V

    .line 446
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->updateSmsEnabledState()V

    return-void
.end method

.method private setMessagePreferences()V
    .locals 4

    .line 458
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->updateSignatureStatus()V

    .line 462
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "pref_key_vibrateWhen"

    .line 463
    invoke-interface {v0, v1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x0

    .line 465
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "always"

    .line 466
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    .line 467
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v3, "pref_key_vibrate"

    .line 468
    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 469
    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 470
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 473
    :cond_0
    invoke-static {}, Lcom/android/mms/util/Recycler;->getSmsRecycler()Lcom/android/mms/util/Recycler$SmsRecycler;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsRecycler:Lcom/android/mms/util/Recycler;

    .line 474
    invoke-static {}, Lcom/android/mms/util/Recycler;->getMmsRecycler()Lcom/android/mms/util/Recycler$MmsRecycler;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsRecycler:Lcom/android/mms/util/Recycler;

    .line 477
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->setSmsDisplayLimit()V

    return-void
.end method

.method private setPreferenceTitle()V
    .locals 5

    .line 423
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsSignatureEditPref:Landroid/preference/Preference;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SIGNATURE:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ". "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e01db    # @string/pref_settings_signature_title 'Auto Signature'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    .line 427
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsEncodingPref:Landroid/preference/Preference;

    if-eqz v0, :cond_0

    .line 428
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SMS_ENCODING:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e0229    # @string/pref_title_sms_encoding_mode 'Sms encoding'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    .line 430
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mRequestReceiptPref:Landroid/preference/Preference;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_REQUEST_RECEIPT:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e01d9    # @string/pref_settings_request_receipt_title 'Request receipt'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    .line 431
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialPref:Landroid/preference/Preference;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_AUTO_RETRIEVAL:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e020e    # @string/pref_title_mms_auto_retrieval 'Auto-retrieve'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    .line 432
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_RETRIEVAL_DURING_ROAMING:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e0217    # @string/pref_title_mms_retrieval_during_roaming 'Roaming auto-retrieve'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    .line 434
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mWeaPref:Landroid/preference/Preference;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_WEA:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e0233    # @string/pref_wea_settings_title 'Wireless emergency alerts'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    .line 435
    invoke-static {}, Lcom/android/mms/ui/MessagingPreferenceActivity;->IsShowGroupMMSSetting()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 436
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsGroupMmsPref:Landroid/preference/Preference;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_GROUP_MMS:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const v2, 0x7f0e0213    # @string/pref_title_mms_group_mms 'Group messaging'

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/preference/Preference;->setTitle(Ljava/lang/CharSequence;)V

    :cond_1
    return-void
.end method

.method private setSMSCPrefState(IZ)V
    .locals 3

    if-eqz p2, :cond_1

    .line 651
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "get SMSC from sub= "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "MessagingPreferenceActivity"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 652
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f040019    # @bool/def_enable_reset_smsc 'false'

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 653
    invoke-direct {p0, p1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->updateSmscFromPreference(I)V

    goto :goto_0

    .line 655
    :cond_0
    sget-object v0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mHandler:Lcom/android/mms/ui/MessagingPreferenceActivity$SmscHandler;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity$SmscHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 656
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const-string v2, "slot"

    .line 657
    invoke-virtual {v1, v2, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 658
    iput-object v1, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 659
    invoke-static {p0, p1, v0}, Lcom/android/mms/ui/MessageUtils;->getSmscFromSub(Landroid/content/Context;ILandroid/os/Message;)V

    goto :goto_0

    .line 662
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmscPrefList:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/preference/Preference;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    .line 664
    :goto_0
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmscPrefList:Ljava/util/ArrayList;

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/preference/Preference;

    invoke-virtual {p0, p2}, Landroid/preference/Preference;->setEnabled(Z)V

    return-void
.end method

.method private setSignatureSummary()V
    .locals 3

    .line 482
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "pref_key_edit_signature"

    const-string v2, ""

    .line 483
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, " "

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    .line 484
    iget-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsSignatureEditPref:Landroid/preference/Preference;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const v0, 0x7f0e01da    # @string/pref_settings_signature_summary 'Signature contents'

    .line 485
    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 484
    :cond_0
    invoke-virtual {v1, v0}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private setSmsDisplayLimit()V
    .locals 4

    .line 496
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitPref:Landroid/preference/Preference;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    iget-object v2, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsRecycler:Lcom/android/mms/util/Recycler;

    .line 498
    invoke-virtual {v2, p0}, Lcom/android/mms/util/Recycler;->getMessageLimit(Landroid/content/Context;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const v2, 0x7f0e01ec    # @string/pref_summary_delete_limit '%1$s messages per conversation'

    .line 497
    invoke-virtual {p0, v2, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    .line 496
    invoke-virtual {v0, p0}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private showLimitNumberPicker()V
    .locals 8

    .line 1174
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 1175
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v2, 0x7f0a0040    # @layout/gflip_number_picker_dialog 'res/layout/gflip_number_picker_dialog.xml'

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    const v2, 0x7f080073    # @id/content_number_picker

    .line 1177
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    .line 1179
    iget-object v4, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsRecycler:Lcom/android/mms/util/Recycler;

    invoke-virtual {v4, p0}, Lcom/android/mms/util/Recycler;->getMessageLimit(Landroid/content/Context;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1180
    new-instance v4, Landroid/view/ViewGroup$LayoutParams;

    const/4 v5, -0x1

    const/4 v6, -0x2

    invoke-direct {v4, v5, v6}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 1185
    new-instance v7, Lcom/android/mms/ui/MessagingPreferenceActivity$5;

    invoke-direct {v7, p0, v2}, Lcom/android/mms/ui/MessagingPreferenceActivity$5;-><init>(Lcom/android/mms/ui/MessagingPreferenceActivity;Landroid/widget/TextView;)V

    invoke-virtual {v0, v7}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    .line 1246
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    const/16 v2, 0xe

    .line 1248
    invoke-virtual {v0, v2}, Landroid/app/AlertDialog;->requestWindowFeature(I)Z

    .line 1249
    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

    .line 1250
    invoke-virtual {v0, v1, v4}, Landroid/app/AlertDialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1252
    invoke-virtual {v0}, Landroid/app/AlertDialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v1

    iput-object v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMenuBar:Landroid/widget/MenuBar;

    const p0, 0x7f0e02c4    # @string/str_no 'No'

    const/4 v2, 0x0

    const v4, 0x7f0e0286    # @string/set 'Set'

    .line 1253
    invoke-virtual {v1, p0, v2, v4, v3}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    .line 1254
    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    .line 1255
    invoke-virtual {p0, v5, v6}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x50

    .line 1258
    invoke-virtual {p0, v0}, Landroid/view/Window;->setGravity(I)V

    const v0, 0x106000d    # @android:color/transparent

    .line 1259
    invoke-virtual {p0, v0}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    return-void
.end method

.method private showToast(I)V
    .locals 1

    const/4 v0, 0x0

    .line 638
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private updateSMSCPref()V
    .locals 5

    .line 668
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmscPrefList:Ljava/util/ArrayList;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_3

    .line 671
    :cond_0
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->getActiveModemCount()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_3

    .line 674
    invoke-static {v2}, Lcom/android/mmswrapper/SubscriptionManagerWrapper;->getSubId(I)[I

    move-result-object v3

    if-eqz v3, :cond_1

    .line 675
    array-length v4, v3

    if-eqz v4, :cond_1

    .line 676
    aget v3, v3, v1

    invoke-static {v3}, Lcom/android/mms/ui/MessageUtils;->isCDMAPhone(I)Z

    move-result v3

    goto :goto_1

    :cond_1
    move v3, v1

    :goto_1
    if-nez v3, :cond_2

    .line 678
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->isAirPlaneModeOn()Z

    move-result v3

    if-nez v3, :cond_2

    .line 679
    invoke-static {v2}, Lcom/android/mms/ui/MessageUtils;->hasActivatedIccCard(I)Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, 0x1

    goto :goto_2

    :cond_2
    move v3, v1

    .line 678
    :goto_2
    invoke-direct {p0, v2, v3}, Lcom/android/mms/ui/MessagingPreferenceActivity;->setSMSCPrefState(IZ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    :goto_3
    return-void
.end method

.method private updateSignatureStatus()V
    .locals 0

    return-void
.end method

.method private updateSmsEnabledState()V
    .locals 2

    .line 351
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    .line 352
    invoke-static {p0}, Landroid/provider/Telephony$Sms;->getDefaultSmsPackage(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    .line 355
    :try_start_0
    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    :catch_0

    return-void
.end method

.method private updateSmscFromBundle(Landroid/os/Bundle;)V
    .locals 3

    if-eqz p1, :cond_2

    const-string v0, "slot"

    const/4 v1, -0x1

    .line 685
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    if-eq v0, v1, :cond_2

    const/4 v1, 0x0

    const-string v2, "smsc"

    .line 687
    invoke-virtual {p1, v2, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_0

    return-void

    .line 691
    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Update SMSC: sub= "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " SMSC= "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "MessagingPreferenceActivity"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const-string v1, "\""

    .line 692
    invoke-virtual {p1, v1}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v1

    .line 693
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmscPrefList:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/preference/Preference;

    if-lez v1, :cond_1

    const/4 v0, 0x1

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    :cond_1
    invoke-virtual {p0, p1}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    :cond_2
    return-void
.end method

.method private updateSmscFromPreference(I)V
    .locals 3

    .line 968
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "pref_key_default_smsc"

    const-string v2, ""

    .line 969
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, -0x1

    if-eq p1, v1, :cond_0

    .line 972
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmscPrefList:Ljava/util/ArrayList;

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/preference/Preference;

    invoke-virtual {p0, v0}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public getAbsolutePath(Landroid/net/Uri;)Ljava/lang/String;
    .locals 7

    const-string v0, "_data"

    .line 944
    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    .line 948
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p1

    move-object v3, v0

    invoke-virtual/range {v1 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    if-eqz p0, :cond_2

    .line 951
    :try_start_0
    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p1

    if-eqz p1, :cond_2

    const/4 p1, 0x0

    .line 952
    aget-object p1, v0, p1

    .line 953
    invoke-interface {p0, p1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result p1

    .line 954
    invoke-interface {p0, p1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p0, :cond_0

    .line 961
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    :cond_0
    return-object p1

    :catchall_0
    move-exception p1

    goto :goto_0

    :catch_0
    move-exception p1

    .line 958
    :try_start_1
    invoke-virtual {p1}, Ljava/lang/IllegalArgumentException;->printStackTrace()V

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz p0, :cond_3

    goto :goto_1

    :goto_0
    if-eqz p0, :cond_1

    .line 961
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    .line 963
    :cond_1
    throw p1

    :cond_2
    if-eqz p0, :cond_3

    .line 961
    :goto_1
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    :cond_3
    const/4 p0, 0x0

    return-object p0
.end method

.method getAsyncDialog()Lcom/android/mms/ui/AsyncDialog;
    .locals 1

    .line 582
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

    if-nez v0, :cond_0

    .line 583
    new-instance v0, Lcom/android/mms/ui/AsyncDialog;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/AsyncDialog;-><init>(Landroid/app/Activity;)V

    iput-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

    .line 585
    :cond_0
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

    return-object p0
.end method

.method public getImageUri(Landroid/content/Context;Landroid/graphics/Bitmap;)Landroid/net/Uri;
    .locals 3

    .line 921
    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object p0

    invoke-virtual {p0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p0

    .line 922
    new-instance p1, Ljava/io/File;

    const-string v0, "temp"

    invoke-direct {p1, p0, v0}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 924
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result p0

    if-nez p0, :cond_0

    .line 925
    invoke-virtual {p1}, Ljava/io/File;->mkdirs()Z

    :cond_0
    const/4 p0, 0x0

    .line 929
    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "/"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 930
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p1, ".png"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 932
    new-instance p1, Ljava/io/FileOutputStream;

    invoke-direct {p1, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    .line 933
    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v1, 0x64

    invoke-virtual {p2, v0, v1, p1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 934
    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V

    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 938
    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0

    :catch_1
    move-exception p1

    .line 936
    invoke-virtual {p1}, Ljava/io/FileNotFoundException;->printStackTrace()V

    .line 940
    :goto_0
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    return-object p0
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    .line 889
    invoke-super {p0, p1, p2, p3}, Landroid/preference/PreferenceActivity;->onActivityResult(IILandroid/content/Intent;)V

    const/4 v0, -0x1

    if-ne p2, v0, :cond_2

    const-string p2, "chat_wallpaper"

    if-eqz p1, :cond_1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_0

    goto :goto_0

    :cond_0
    if-eqz p3, :cond_2

    .line 905
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    .line 906
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getAbsolutePath(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    .line 907
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 908
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    .line 909
    invoke-interface {p0, p2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    .line 910
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    goto :goto_0

    .line 893
    :cond_1
    invoke-virtual {p3}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_2

    .line 894
    invoke-virtual {p3}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    const-string p3, "data"

    invoke-virtual {p1, p3}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/graphics/Bitmap;

    .line 895
    invoke-virtual {p0, p0, p1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getImageUri(Landroid/content/Context;Landroid/graphics/Bitmap;)Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getAbsolutePath(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    .line 897
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 898
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    .line 899
    invoke-interface {p0, p2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    .line 900
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    :cond_2
    :goto_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 227
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0xe

    .line 234
    invoke-virtual {v0, v1}, Landroid/view/Window;->requestFeature(I)Z

    .line 235
    invoke-super {p0, p1}, Landroid/preference/PreferenceActivity;->onCreate(Landroid/os/Bundle;)V

    .line 236
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->checkPermissionsIfNeeded(Landroid/app/Activity;)Z

    move-result p1

    if-eqz p1, :cond_0

    return-void

    .line 239
    :cond_0
    new-instance p1, Lcom/android/mms/ui/MessagingPreferenceActivity$SmscHandler;

    invoke-direct {p1, p0}, Lcom/android/mms/ui/MessagingPreferenceActivity$SmscHandler;-><init>(Lcom/android/mms/ui/MessagingPreferenceActivity;)V

    sput-object p1, Lcom/android/mms/ui/MessagingPreferenceActivity;->mHandler:Lcom/android/mms/ui/MessagingPreferenceActivity$SmscHandler;

    .line 240
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->initPreferenceList()V

    .line 241
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->loadPrefs()V

    .line 243
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->initCustomActionBar()V

    .line 244
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getListView()Landroid/widget/ListView;

    move-result-object p1

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setDivider(Landroid/graphics/drawable/Drawable;)V

    const-string p1, "audio"

    .line 245
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/media/AudioManager;

    iput-object p1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAudioManager:Landroid/media/AudioManager;

    return-void
.end method

.method protected onCreateDialog(I)Landroid/app/Dialog;
    .locals 2

    const/4 v0, 0x3

    if-eq p1, v0, :cond_0

    .line 609
    invoke-super {p0, p1}, Landroid/preference/PreferenceActivity;->onCreateDialog(I)Landroid/app/Dialog;

    move-result-object p0

    return-object p0

    .line 592
    :cond_0
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v0, 0x7f0e007e    # @string/confirm_clear_search_title 'Clear'

    .line 593
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const v0, 0x7f0e007d    # @string/confirm_clear_search_text 'Search history will be cleared.'

    .line 594
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const v0, 0x104000a    # @android:string/ok

    new-instance v1, Lcom/android/mms/ui/MessagingPreferenceActivity$4;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/MessagingPreferenceActivity$4;-><init>(Lcom/android/mms/ui/MessagingPreferenceActivity;)V

    .line 595
    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    const/high16 p1, 0x1040000    # @android:string/cancel

    const/4 v0, 0x0

    .line 605
    invoke-virtual {p0, p1, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    const p1, 0x1010355    # @android:attr/alertDialogIcon

    .line 606
    invoke-virtual {p0, p1}, Landroid/app/AlertDialog$Builder;->setIconAttribute(I)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 607
    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p0

    return-object p0
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 0

    .line 509
    invoke-super {p0, p1}, Landroid/preference/PreferenceActivity;->onCreateOptionsMenu(Landroid/view/Menu;)Z

    .line 510
    invoke-interface {p1}, Landroid/view/Menu;->clear()V

    const/4 p0, 0x1

    return p0
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 2

    const/4 p2, 0x4

    const/4 v0, 0x0

    if-eq p1, p2, :cond_4

    const/16 p2, 0x13

    const/4 v1, 0x1

    if-eq p1, p2, :cond_2

    const/16 p2, 0x14

    if-eq p1, p2, :cond_0

    goto :goto_0

    .line 1158
    :cond_0
    # tzib unified: navigate all visible preferences, including the Tzibbur section
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getListView()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/ListView;->getCount()I

    move-result p1

    sub-int/2addr p1, v1

    .line 1159
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getListView()Landroid/widget/ListView;

    move-result-object p2

    invoke-virtual {p2}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result p2

    if-ne p2, p1, :cond_1

    .line 1160
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getListView()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setSelection(I)V

    .line 1161
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAudioManager:Landroid/media/AudioManager;

    invoke-virtual {p0, v0}, Landroid/media/AudioManager;->playSoundEffect(I)V

    return v1

    :cond_1
    return v0

    .line 1149
    :cond_2
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getListView()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result p1

    if-nez p1, :cond_3

    .line 1150
    # tzib unified: navigate all visible preferences, including the Tzibbur section
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getListView()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/ListView;->getCount()I

    move-result p1

    sub-int/2addr p1, v1

    .line 1151
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getListView()Landroid/widget/ListView;

    move-result-object p2

    invoke-virtual {p2, p1}, Landroid/widget/ListView;->setSelection(I)V

    .line 1152
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAudioManager:Landroid/media/AudioManager;

    invoke-virtual {p0, v0}, Landroid/media/AudioManager;->playSoundEffect(I)V

    return v1

    :cond_3
    return v0

    .line 1166
    :cond_4
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->finish()V

    :goto_0
    return v0
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .locals 4

    # tzib public screens: numbered settings
    invoke-static {p0, p1, p2}, Lcom/android/mms/tzib/TzibSettings;->numberKey(Landroid/preference/PreferenceActivity;ILandroid/view/KeyEvent;)Z
    move-result v0
    if-eqz v0, :tzib_stock_number
    return v0
    :tzib_stock_number

    const/4 v0, 0x0

    packed-switch p1, :pswitch_data_0

    return v0

    :pswitch_0    # 0x10
    const/16 v1, 0x9

    goto :goto_0

    :pswitch_1    # 0xf
    const/16 v1, 0x8

    .line 1041
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleMmsAutoRetrievialRoamingPref()V

    goto :goto_0

    :pswitch_2    # 0xe
    const/4 v1, 0x7

    goto :goto_0

    :pswitch_3    # 0xd
    const/4 v1, 0x6

    goto :goto_0

    :pswitch_4    # 0xc
    const/4 v1, 0x5

    goto :goto_0

    :pswitch_5    # 0xb
    const/4 v1, 0x4

    goto :goto_0

    :pswitch_6    # 0xa
    const/4 v1, 0x3

    goto :goto_0

    :pswitch_7    # 0x9
    const/4 v1, 0x2

    goto :goto_0

    :pswitch_8    # 0x8
    const/4 v1, 0x1

    goto :goto_0

    :pswitch_9    # 0x7
    move v1, v0

    .line 1049
    :goto_0
    iget-object v2, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mPreferenceList:Ljava/util/List;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 1050
    iget-object v2, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAudioManager:Landroid/media/AudioManager;

    invoke-virtual {v2, v0}, Landroid/media/AudioManager;->playSoundEffect(I)V

    .line 1051
    invoke-direct {p0, v1}, Lcom/android/mms/ui/MessagingPreferenceActivity;->hanldeKeyUpEvent(I)V

    .line 1053
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/preference/PreferenceActivity;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result p0

    return p0

    :pswitch_data_0
    .packed-switch 0x7
        :pswitch_9    # 0x7
        :pswitch_8    # 0x8
        :pswitch_7    # 0x9
        :pswitch_6    # 0xa
        :pswitch_5    # 0xb
        :pswitch_4    # 0xc
        :pswitch_3    # 0xd
        :pswitch_2    # 0xe
        :pswitch_1    # 0xf
        :pswitch_0    # 0x10
    .end packed-switch
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 2

    .line 519
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_1

    const v1, 0x102002c    # @android:id/home

    if-eq p1, v1, :cond_0

    const/4 p0, 0x0

    return p0

    .line 527
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->finish()V

    return v0

    .line 521
    :cond_1
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->restoreDefaultPreferences()V

    return v0
.end method

.method protected onPause()V
    .locals 1

    .line 363
    invoke-super {p0}, Landroid/preference/PreferenceActivity;->onPause()V

    .line 364
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 366
    iget-object p0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAsyncDialog:Lcom/android/mms/ui/AsyncDialog;

    if-eqz p0, :cond_0

    .line 367
    invoke-virtual {p0}, Lcom/android/mms/ui/AsyncDialog;->clearPendingProgressDialog()V

    :cond_0
    return-void
.end method

.method public onPreferenceTreeClick(Landroid/preference/PreferenceScreen;Landroid/preference/Preference;)Z
    .locals 1

    .line 536
    iget v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->PREFERENCE_POSITION_SIGNATURE:I

    iput v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->fixedPosition:I

    .line 538
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mNotificationPref:Landroid/preference/Preference;

    if-ne p2, v0, :cond_0

    .line 539
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleNotificationPref()V

    goto :goto_0

    .line 540
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsSignatureEditPref:Landroid/preference/Preference;

    if-ne p2, v0, :cond_1

    .line 541
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleSmsSignatureEditPref()V

    goto :goto_0

    .line 542
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mAutoDeleteMessage:Landroid/preference/Preference;

    if-ne p2, v0, :cond_2

    .line 543
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleAutoDeleteMessage()V

    goto :goto_0

    .line 544
    :cond_2
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mRequestReceiptPref:Landroid/preference/Preference;

    if-ne p2, v0, :cond_3

    .line 545
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleRequestReceiptPref()V

    goto :goto_0

    .line 546
    :cond_3
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitPref:Landroid/preference/Preference;

    if-ne p2, v0, :cond_4

    .line 547
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleSmsLimitPref()V

    goto :goto_0

    .line 548
    :cond_4
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialPref:Landroid/preference/Preference;

    if-ne p2, v0, :cond_5

    .line 550
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleMmsAutoRetrievialPref()V

    goto :goto_0

    .line 551
    :cond_5
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

    if-ne p2, v0, :cond_6

    .line 552
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleMmsAutoRetrievialRoamingPref()V

    goto :goto_0

    .line 553
    :cond_6
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsEncodingPref:Landroid/preference/Preference;

    if-ne p2, v0, :cond_7

    .line 554
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleSmsEncodingPref()V

    goto :goto_0

    .line 555
    :cond_7
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsGroupMmsPref:Landroid/preference/Preference;

    if-ne p2, v0, :cond_8

    .line 556
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleMmsGroupMmsPref()V

    goto :goto_0

    .line 557
    :cond_8
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mWeaPref:Landroid/preference/Preference;

    if-ne p2, v0, :cond_9

    .line 558
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->handleWeaPref()V

    .line 561
    :cond_9
    :goto_0
    invoke-super {p0, p1, p2}, Landroid/preference/PreferenceActivity;->onPreferenceTreeClick(Landroid/preference/PreferenceScreen;Landroid/preference/Preference;)Z

    move-result p0

    return p0
.end method

.method protected onResume()V
    .locals 6

    .line 306
    invoke-super {p0}, Landroid/preference/PreferenceActivity;->onResume()V

    .line 307
    invoke-static {p0}, Lcom/android/mms/MmsConfig;->isSmsEnabled(Landroid/content/Context;)Z

    move-result v0

    .line 308
    iget-boolean v1, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mIsSmsEnabled:Z

    if-eq v0, v1, :cond_0

    .line 309
    iput-boolean v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mIsSmsEnabled:Z

    .line 310
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->invalidateOptionsMenu()V

    .line 313
    :cond_0
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "pref_key_mms_auto_retrieval"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const v1, 0x7f0a0033    # @layout/custom_preference_disabled_layout 'res/layout/custom_preference_disabled_layout.xml'

    const v3, 0x7f0a0034    # @layout/custom_preference_layout 'res/layout/custom_preference_layout.xml'

    const/4 v4, 0x0

    if-nez v0, :cond_1

    .line 314
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setLayoutResource(I)V

    .line 315
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

    invoke-virtual {v0, v4}, Landroid/preference/Preference;->setEnabled(Z)V

    .line 316
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

    invoke-virtual {v0, v2}, Landroid/preference/Preference;->setShouldDisableView(Z)V

    goto :goto_0

    .line 318
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

    invoke-virtual {v0, v3}, Landroid/preference/Preference;->setLayoutResource(I)V

    .line 319
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mMmsAutoRetrievialRoamingPref:Landroid/preference/Preference;

    invoke-virtual {v0, v2}, Landroid/preference/Preference;->setEnabled(Z)V

    .line 322
    :goto_0
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v5, "pref_key_auto_delete"

    invoke-interface {v0, v5, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_2

    .line 323
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitPref:Landroid/preference/Preference;

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setLayoutResource(I)V

    .line 324
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitPref:Landroid/preference/Preference;

    invoke-virtual {v0, v4}, Landroid/preference/Preference;->setEnabled(Z)V

    .line 325
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitPref:Landroid/preference/Preference;

    invoke-virtual {v0, v2}, Landroid/preference/Preference;->setShouldDisableView(Z)V

    goto :goto_1

    .line 327
    :cond_2
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitPref:Landroid/preference/Preference;

    invoke-virtual {v0, v3}, Landroid/preference/Preference;->setLayoutResource(I)V

    .line 328
    iget-object v0, p0, Lcom/android/mms/ui/MessagingPreferenceActivity;->mSmsLimitPref:Landroid/preference/Preference;

    invoke-virtual {v0, v2}, Landroid/preference/Preference;->setEnabled(Z)V

    .line 334
    :goto_1
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->updateSignatureStatus()V

    .line 335
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->registerListeners()V

    .line 336
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->updateSmsEnabledState()V

    .line 337
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->updateSMSCPref()V

    .line 338
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->addMenuBarInBottom()V

    .line 339
    invoke-direct {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->setSignatureSummary()V

    .line 340
    invoke-virtual {p0}, Lcom/android/mms/ui/MessagingPreferenceActivity;->getListView()Landroid/widget/ListView;

    move-result-object v0

    new-instance v1, Lcom/android/mms/ui/MessagingPreferenceActivity$2;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/MessagingPreferenceActivity$2;-><init>(Lcom/android/mms/ui/MessagingPreferenceActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->post(Ljava/lang/Runnable;)Z

    # tzib unified: settings
    invoke-static {p0}, Lcom/android/mms/tzib/TzibSettings;->install(Landroid/preference/PreferenceActivity;)V

    return-void
.end method
