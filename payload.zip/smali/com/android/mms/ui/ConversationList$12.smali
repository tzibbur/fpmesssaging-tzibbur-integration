.class Lcom/android/mms/ui/ConversationList$12;
.super Ljava/lang/Object;
.source "ConversationList.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/mms/ui/ConversationList;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/mms/ui/ConversationList;


# direct methods
.method constructor <init>(Lcom/android/mms/ui/ConversationList;)V
    .locals 0

    .line 1334
    iput-object p1, p0, Lcom/android/mms/ui/ConversationList$12;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 4

    .line 1337
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    if-nez p1, :cond_1

    .line 1339
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList$12;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-virtual {p1}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result p1

    int-to-long v0, p1

    # tzib: live header index, our row may be hidden by the kill switch
    invoke-static {}, Lcom/android/mms/tzib/TzibHook;->mmsNotificationPosition()I

    move-result v2

    int-to-long v2, v2

    cmp-long p1, v0, v2

    if-nez p1, :cond_1

    .line 1340
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList$12;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-static {p1}, Lcom/android/mms/ui/ConversationList;->access$100(Lcom/android/mms/ui/ConversationList;)Z

    move-result p1

    if-eqz p1, :cond_1

    const/16 p1, 0x17

    if-eq p2, p1, :cond_0

    goto :goto_0

    .line 1343
    :cond_0
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList$12;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-static {p0}, Lcom/android/mms/ui/ConversationList;->access$1300(Lcom/android/mms/ui/ConversationList;)V

    const/4 p0, 0x1

    return p0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return p0
.end method
