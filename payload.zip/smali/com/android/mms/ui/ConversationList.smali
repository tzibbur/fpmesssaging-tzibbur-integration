# extended-by: Lcom/android/mms/ui/NotificationConversationList;
.class public Lcom/android/mms/ui/ConversationList;
.super Landroid/app/ListActivity;
.source "ConversationList.java"

# interfaces
.implements Lcom/android/mms/util/DraftCache$OnDraftChangedListener;
.implements Landroid/widget/MenuBar$MenuBarListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;,
        Lcom/android/mms/ui/ConversationList$DeleteThreadListener;
    }
.end annotation


# static fields
.field private static final CHECKED_MESSAGE_LIMITS:Ljava/lang/String; = "checked_message_limits"

.field public static final COLUMN_ID:I = 0x0

.field private static final DEBUG:Z = false

.field private static final DEBUGCLEANUP:Z = true

.field private static final DELAY_TIME:I = 0x1f4

.field public static final DELETE_CONVERSATION_TOKEN:I = 0x709

.field private static final DELETE_OBSOLETE_THREADS_TOKEN:I = 0x70b

.field public static final HAVE_LOCKED_MESSAGES_TOKEN:I = 0x70a

.field public static final HAVE_MESSAGE:I = 0x1

.field private static final LAST_LIST_OFFSET:Ljava/lang/String; = "last_list_offset"

.field private static final LAST_LIST_POS:Ljava/lang/String; = "last_list_pos"

.field public static final MENU_ACTION_DELETE_MESSAGE:I = 0x0

.field public static final MENU_ACTION_MARK_ALL_MESSAGE_AS_READ:I = 0x1

.field public static final MENU_ACTION_SEARCH:I = 0x3

.field public static final MENU_ACTION_SELETE_THREAD:I = 0x4

.field public static final MENU_ACTION_SETTINGS:I = 0x2

.field public static final MENU_ADD_TO_CONTACTS:I = 0x3

.field private static final MENU_ADD_TO_EXISTING:I = 0x3eb

.field private static final MENU_CREATE_NEW_CONTACT:I = 0x3ea

.field public static final MENU_DELETE:I = 0x0

.field public static final MENU_VIEW:I = 0x1

.field public static final MENU_VIEW_CONTACT:I = 0x2

.field private static final MMS_NOTIFICATION_QUERY_TOKEN:I = 0x6a9

.field private static final NOTIFICATION_THREAD_QUERY_TOKEN:I = 0x6a7

.field public static final NOT_OBSOLETE:Ljava/lang/String; = "_id IN (SELECT DISTINCT thread_id FROM sms where thread_id NOT NULL UNION SELECT DISTINCT thread_id FROM pdu where thread_id NOT NULL)"

.field public static final NO_MESSAGE:I = 0x0

.field private static final TAG:Ljava/lang/String; = "Mms"

.field public static final THREAD_LIST_QUERY_TOKEN:I = 0x6a5

.field private static final TYPE_EMAIL:I = 0xa

.field private static final TYPE_PHONE_NUMBER:I = 0xb

.field private static final UNREAD_NOTIFICATION_THREAD_QUERY_TOKEN:I = 0x6a8

.field public static final UNREAD_THREADS_QUERY_TOKEN:I = 0x6a6

.field private static mLastDeletedThread:J = -0x1L

.field private static mMarkReadMode:Z

.field private static mMarkUnreadMode:Z

.field private static mSelectMode:Z

.field private static mSelectedThreadIds:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field contactUpdateListener:Lcom/android/mms/ui/ConversationListItem$ContactUpdateListener;

.field private headerView:Lcom/android/mms/ui/ConversationListItem;

.field mAudioManager:Landroid/media/AudioManager;

.field private mComposeDisabledToast:Landroid/widget/Toast;

.field private mComposeMessageButton:Landroid/widget/ImageButton;

.field private final mContentChangedListener:Lcom/android/mms/ui/ConversationListAdapter$OnContentChangedListener;

.field mConversation:Lcom/android/mms/data/Conversation;

.field private mCurrentMode:I

.field private mDeleteConvcount:I

.field private mDeleteCount:I

.field private final mDeleteObsoleteThreadsRunnable:Ljava/lang/Runnable;

.field private mDeletingRunnable:Ljava/lang/Runnable;

.field private mDoOnceAfterFirstQuery:Z

.field private mEmptyTextview:Landroid/widget/TextView;

.field private mEmptyView:Landroid/widget/LinearLayout;

.field private mHandler:Landroid/os/Handler;

.field private mHasNormalThreads:Z

.field private mHasNotificationThreads:Z

.field private mHasSelectAll:Z

.field private mHeadLayout:Landroid/widget/LinearLayout;

.field private mInboxLable:Landroid/widget/TextView;

.field private mIsNotiShows:Z

.field private mIsRemoveDialogShow:Z

.field private mIsSmsEnabled:Z

.field private mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

.field private mListViewHeader:Landroid/view/ViewGroup;

.field private mMenuBar:Landroid/widget/MenuBar;

.field private mMultiChoiceMode:Z

.field private mNotificationContent:Landroid/view/ViewGroup;

.field private mNotificationDate:Landroid/widget/TextView;

.field private mNotificationFrom:Landroid/widget/TextView;

.field private mNotificationIcon:Landroid/widget/ImageView;

.field private mNotificationLabel:Landroid/widget/TextView;

.field private mNotificationSubject:Landroid/widget/TextView;

.field private mNotificationTime:Landroid/widget/TextView;

.field private mNotificationView:Landroid/view/ViewGroup;

.field private mPrefs:Landroid/content/SharedPreferences;

.field private mProgressDialog:Landroid/app/ProgressDialog;

.field public mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

.field private mRemoveDialog:Landroid/app/AlertDialog;

.field private mRemoveDialogMenuBar:Landroid/widget/MenuBar;

.field private mSavedFirstItemOffset:I

.field private mSavedFirstVisiblePosition:I

.field private mSelectAllView:Landroid/widget/TextView;

.field private mSelectNum:Landroid/widget/TextView;

.field private mShowProgressDialogRunnable:Ljava/lang/Runnable;

.field private mSmsPromoBannerView:Landroid/view/View;

.field private final mThreadListKeyListener:Landroid/view/View$OnKeyListener;

.field private mTid:J

.field private mUnreadConvCount:Landroid/widget/TextView;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 118
    invoke-direct {p0}, Landroid/app/ListActivity;-><init>()V

    const/4 v0, 0x0

    .line 143
    iput v0, p0, Lcom/android/mms/ui/ConversationList;->mDeleteConvcount:I

    const/4 v1, -0x1

    .line 152
    iput v1, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    .line 171
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mMultiChoiceMode:Z

    .line 172
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasNormalThreads:Z

    .line 173
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasNotificationThreads:Z

    .line 213
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    .line 219
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mIsNotiShows:Z

    .line 558
    new-instance v0, Lcom/android/mms/ui/ConversationList$5;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ConversationList$5;-><init>(Lcom/android/mms/ui/ConversationList;)V

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->mContentChangedListener:Lcom/android/mms/ui/ConversationListAdapter$OnContentChangedListener;

    .line 1334
    new-instance v0, Lcom/android/mms/ui/ConversationList$12;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ConversationList$12;-><init>(Lcom/android/mms/ui/ConversationList;)V

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->mThreadListKeyListener:Landroid/view/View$OnKeyListener;

    .line 1405
    new-instance v0, Lcom/android/mms/ui/ConversationList$13;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ConversationList$13;-><init>(Lcom/android/mms/ui/ConversationList;)V

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->mDeleteObsoleteThreadsRunnable:Ljava/lang/Runnable;

    .line 1827
    new-instance v0, Lcom/android/mms/ui/ConversationList$15;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ConversationList$15;-><init>(Lcom/android/mms/ui/ConversationList;)V

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->mDeletingRunnable:Ljava/lang/Runnable;

    .line 1834
    new-instance v0, Lcom/android/mms/ui/ConversationList$16;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ConversationList$16;-><init>(Lcom/android/mms/ui/ConversationList;)V

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->mShowProgressDialogRunnable:Ljava/lang/Runnable;

    .line 2348
    new-instance v0, Lcom/android/mms/ui/ConversationList$17;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ConversationList$17;-><init>(Lcom/android/mms/ui/ConversationList;)V

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->contactUpdateListener:Lcom/android/mms/ui/ConversationListItem$ContactUpdateListener;

    return-void
.end method

.method static synthetic access$000(Lcom/android/mms/ui/ConversationList;)Z
    .locals 0

    .line 118
    iget-boolean p0, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    return p0
.end method

.method static synthetic access$100(Lcom/android/mms/ui/ConversationList;)Z
    .locals 0

    .line 118
    iget-boolean p0, p0, Lcom/android/mms/ui/ConversationList;->mIsNotiShows:Z

    return p0
.end method

.method static synthetic access$1002(Lcom/android/mms/ui/ConversationList;Z)Z
    .locals 0

    .line 118
    iput-boolean p1, p0, Lcom/android/mms/ui/ConversationList;->mIsRemoveDialogShow:Z

    return p1
.end method

.method static synthetic access$102(Lcom/android/mms/ui/ConversationList;Z)Z
    .locals 0

    .line 118
    iput-boolean p1, p0, Lcom/android/mms/ui/ConversationList;->mIsNotiShows:Z

    return p1
.end method

.method static synthetic access$1100(Lcom/android/mms/ui/ConversationList;Ljava/util/Collection;)V
    .locals 0

    .line 118
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ConversationList;->unbindListeners(Ljava/util/Collection;)V

    return-void
.end method

.method static synthetic access$1200()J
    .locals 2

    .line 118
    sget-wide v0, Lcom/android/mms/ui/ConversationList;->mLastDeletedThread:J

    return-wide v0
.end method

.method static synthetic access$1202(J)J
    .locals 0

    .line 118
    sput-wide p0, Lcom/android/mms/ui/ConversationList;->mLastDeletedThread:J

    return-wide p0
.end method

.method static synthetic access$1300(Lcom/android/mms/ui/ConversationList;)V
    .locals 0

    .line 118
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->openMmsNotificationList()V

    return-void
.end method

.method static synthetic access$1900(Lcom/android/mms/ui/ConversationList;)Ljava/lang/Runnable;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mDeleteObsoleteThreadsRunnable:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic access$200(Lcom/android/mms/ui/ConversationList;)V
    .locals 0

    .line 118
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateMenuBar()V

    return-void
.end method

.method static synthetic access$2002(Lcom/android/mms/ui/ConversationList;Z)Z
    .locals 0

    .line 118
    iput-boolean p1, p0, Lcom/android/mms/ui/ConversationList;->mHasNormalThreads:Z

    return p1
.end method

.method static synthetic access$2100(Lcom/android/mms/ui/ConversationList;)V
    .locals 0

    .line 118
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateEmptyView()V

    return-void
.end method

.method static synthetic access$2200(Lcom/android/mms/ui/ConversationList;)Z
    .locals 0

    .line 118
    iget-boolean p0, p0, Lcom/android/mms/ui/ConversationList;->mDoOnceAfterFirstQuery:Z

    return p0
.end method

.method static synthetic access$2202(Lcom/android/mms/ui/ConversationList;Z)Z
    .locals 0

    .line 118
    iput-boolean p1, p0, Lcom/android/mms/ui/ConversationList;->mDoOnceAfterFirstQuery:Z

    return p1
.end method

.method static synthetic access$2300(Lcom/android/mms/ui/ConversationList;)I
    .locals 0

    .line 118
    iget p0, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    return p0
.end method

.method static synthetic access$2302(Lcom/android/mms/ui/ConversationList;I)I
    .locals 0

    .line 118
    iput p1, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    return p1
.end method

.method static synthetic access$2402(Lcom/android/mms/ui/ConversationList;Z)Z
    .locals 0

    .line 118
    iput-boolean p1, p0, Lcom/android/mms/ui/ConversationList;->mHasNotificationThreads:Z

    return p1
.end method

.method static synthetic access$2500(Lcom/android/mms/ui/ConversationList;Landroid/database/Cursor;)V
    .locals 0

    .line 118
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ConversationList;->updateNotificationView(Landroid/database/Cursor;)V

    return-void
.end method

.method static synthetic access$2600(Lcom/android/mms/ui/ConversationList;Z)V
    .locals 0

    .line 118
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ConversationList;->toggleNotificationGroup(Z)V

    return-void
.end method

.method static synthetic access$2700(Lcom/android/mms/ui/ConversationList;)Landroid/widget/TextView;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationLabel:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$2800(Lcom/android/mms/ui/ConversationList;)Ljava/lang/Runnable;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mDeletingRunnable:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic access$2900(Lcom/android/mms/ui/ConversationList;Lcom/android/mms/ui/ConversationList$DeleteThreadListener;Ljava/util/Collection;Ljava/lang/Runnable;ZLcom/android/mms/data/Conversation$ConversationQueryHandler;Landroid/content/Context;)V
    .locals 0

    .line 118
    invoke-direct/range {p0 .. p6}, Lcom/android/mms/ui/ConversationList;->remove(Lcom/android/mms/ui/ConversationList$DeleteThreadListener;Ljava/util/Collection;Ljava/lang/Runnable;ZLcom/android/mms/data/Conversation$ConversationQueryHandler;Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$3000(Lcom/android/mms/ui/ConversationList;Landroid/database/Cursor;Z)V
    .locals 0

    .line 118
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ConversationList;->showMmsNotification(Landroid/database/Cursor;Z)V

    return-void
.end method

.method static synthetic access$302(Lcom/android/mms/ui/ConversationList;J)J
    .locals 0

    .line 118
    iput-wide p1, p0, Lcom/android/mms/ui/ConversationList;->mTid:J

    return-wide p1
.end method

.method static synthetic access$3100(Lcom/android/mms/ui/ConversationList;)Landroid/widget/TextView;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationTime:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$3200(Lcom/android/mms/ui/ConversationList;)Landroid/widget/TextView;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationFrom:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$3300(Lcom/android/mms/ui/ConversationList;)V
    .locals 0

    .line 118
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->hideMmsNotification()V

    return-void
.end method

.method static synthetic access$3400(Lcom/android/mms/ui/ConversationList;)V
    .locals 0

    .line 118
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->exitSelectMode()V

    return-void
.end method

.method static synthetic access$3500(Lcom/android/mms/ui/ConversationList;)Ljava/lang/Runnable;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mShowProgressDialogRunnable:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic access$3600(Lcom/android/mms/ui/ConversationList;)Landroid/app/ProgressDialog;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mProgressDialog:Landroid/app/ProgressDialog;

    return-object p0
.end method

.method static synthetic access$3700(Lcom/android/mms/ui/ConversationList;)I
    .locals 0

    .line 118
    iget p0, p0, Lcom/android/mms/ui/ConversationList;->mDeleteConvcount:I

    return p0
.end method

.method static synthetic access$3702(Lcom/android/mms/ui/ConversationList;I)I
    .locals 0

    .line 118
    iput p1, p0, Lcom/android/mms/ui/ConversationList;->mDeleteConvcount:I

    return p1
.end method

.method static synthetic access$3708(Lcom/android/mms/ui/ConversationList;)I
    .locals 2

    .line 118
    iget v0, p0, Lcom/android/mms/ui/ConversationList;->mDeleteConvcount:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcom/android/mms/ui/ConversationList;->mDeleteConvcount:I

    return v0
.end method

.method static synthetic access$3800(Lcom/android/mms/ui/ConversationList;)Landroid/widget/Toast;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mComposeDisabledToast:Landroid/widget/Toast;

    return-object p0
.end method

.method static synthetic access$3802(Lcom/android/mms/ui/ConversationList;Landroid/widget/Toast;)Landroid/widget/Toast;
    .locals 0

    .line 118
    iput-object p1, p0, Lcom/android/mms/ui/ConversationList;->mComposeDisabledToast:Landroid/widget/Toast;

    return-object p1
.end method

.method static synthetic access$3900(Lcom/android/mms/ui/ConversationList;)I
    .locals 0

    .line 118
    iget p0, p0, Lcom/android/mms/ui/ConversationList;->mDeleteCount:I

    return p0
.end method

.method static synthetic access$400(Lcom/android/mms/ui/ConversationList;)Landroid/os/Handler;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$4000(Lcom/android/mms/ui/ConversationList;Ljava/lang/String;)Ljava/lang/CharSequence;
    .locals 0

    .line 118
    invoke-direct {p0, p1}, Lcom/android/mms/ui/ConversationList;->formatTextToBold(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$4100(Lcom/android/mms/ui/ConversationList;)Landroid/widget/TextView;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationDate:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$4200(Lcom/android/mms/ui/ConversationList;)Landroid/widget/TextView;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationSubject:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$4300(Lcom/android/mms/ui/ConversationList;)Landroid/view/ViewGroup;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    return-object p0
.end method

.method static synthetic access$500(Lcom/android/mms/ui/ConversationList;)Landroid/content/SharedPreferences;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mPrefs:Landroid/content/SharedPreferences;

    return-object p0
.end method

.method static synthetic access$600(Lcom/android/mms/ui/ConversationList;)V
    .locals 0

    .line 118
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->markCheckedMessageLimit()V

    return-void
.end method

.method static synthetic access$700(Lcom/android/mms/ui/ConversationList;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 0

    .line 118
    invoke-direct {p0, p1, p2}, Lcom/android/mms/ui/ConversationList;->log(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method

.method static synthetic access$800(Lcom/android/mms/ui/ConversationList;)Lcom/android/mms/ui/ConversationListAdapter;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    return-object p0
.end method

.method static synthetic access$900(Lcom/android/mms/ui/ConversationList;)Landroid/widget/MenuBar;
    .locals 0

    .line 118
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    return-object p0
.end method

.method public static confirmDeleteThread(JLandroid/content/AsyncQueryHandler;)V
    .locals 2

    const-wide/16 v0, -0x1

    cmp-long v0, p0, v0

    if-eqz v0, :cond_0

    .line 1160
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1161
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 1163
    :goto_0
    invoke-static {v0, p2}, Lcom/android/mms/ui/ConversationList;->confirmDeleteThreads(Ljava/util/Collection;Landroid/content/AsyncQueryHandler;)V

    return-void
.end method

.method public static confirmDeleteThreadDialog(Lcom/android/mms/ui/ConversationList$DeleteThreadListener;Ljava/util/Collection;ZLandroid/content/Context;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/mms/ui/ConversationList$DeleteThreadListener;",
            "Ljava/util/Collection<",
            "Ljava/lang/Long;",
            ">;Z",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    const v0, 0x7f0a0035    # @layout/delete_thread_dialog_view 'res/layout/delete_thread_dialog_view.xml'

    const/4 v1, 0x0

    .line 1191
    invoke-static {p3, v0, v1}, Landroid/view/View;->inflate(Landroid/content/Context;ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    const v2, 0x7f0800ec    # @id/message

    .line 1192
    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const p1, 0x7f0e0081    # @string/confirm_delete_all_conversations 'All threads will be deleted.'

    .line 1195
    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(I)V

    goto :goto_0

    .line 1198
    :cond_0
    invoke-interface {p1}, Ljava/util/Collection;->size()I

    move-result p1

    .line 1199
    invoke-virtual {p3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const/high16 v5, 0x7f0d0000    # @plurals/confirm_delete_conversation

    new-array v6, v3, [Ljava/lang/Object;

    const/4 v7, 0x0

    .line 1200
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    .line 1199
    invoke-virtual {v4, v5, p1, v6}, Landroid/content/res/Resources;->getQuantityString(II[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_0
    const p1, 0x7f080083    # @id/delete_locked

    .line 1203
    invoke-virtual {v0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/CheckBox;

    if-nez p2, :cond_1

    const/16 p2, 0x8

    .line 1205
    invoke-virtual {p1, p2}, Landroid/widget/CheckBox;->setVisibility(I)V

    goto :goto_1

    .line 1207
    :cond_1
    invoke-virtual {p1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result p2

    invoke-virtual {p0, p2}, Lcom/android/mms/ui/ConversationList$DeleteThreadListener;->setDeleteLockedMessage(Z)V

    .line 1208
    new-instance p2, Lcom/android/mms/ui/ConversationList$10;

    invoke-direct {p2, p0, p1}, Lcom/android/mms/ui/ConversationList$10;-><init>(Lcom/android/mms/ui/ConversationList$DeleteThreadListener;Landroid/widget/CheckBox;)V

    invoke-virtual {p1, p2}, Landroid/widget/CheckBox;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1216
    :goto_1
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p3}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const p2, 0x7f0e0087    # @string/confirm_dialog_title 'Delete?'

    .line 1217
    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const p2, 0x1010355    # @android:attr/alertDialogIcon

    .line 1218
    invoke-virtual {p1, p2}, Landroid/app/AlertDialog$Builder;->setIconAttribute(I)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    .line 1219
    invoke-virtual {p1, v3}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const p2, 0x7f0e00a8    # @string/delete 'Delete'

    .line 1220
    invoke-virtual {p1, p2, p0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    const p1, 0x7f0e0196    # @string/no 'Cancel'

    .line 1221
    invoke-virtual {p0, p1, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 1222
    invoke-virtual {p0, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    .line 1223
    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method public static confirmDeleteThreads(Ljava/util/Collection;Landroid/content/AsyncQueryHandler;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Ljava/lang/Long;",
            ">;",
            "Landroid/content/AsyncQueryHandler;",
            ")V"
        }
    .end annotation

    const/16 v0, 0x70a

    .line 1174
    invoke-static {p1, p0, v0}, Lcom/android/mms/data/Conversation;->startQueryHaveLockedMessages(Landroid/content/AsyncQueryHandler;Ljava/util/Collection;I)V

    return-void
.end method

.method public static createAddContactIntent(Ljava/lang/String;)Landroid/content/Intent;
    .locals 2

    .line 1041
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.INSERT_OR_EDIT"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "vnd.android.cursor.item/contact"

    .line 1042
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 1043
    invoke-static {p0}, Lcom/android/mms/util/ContactRecipientEntryUtils;->isEmailAddress(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "email"

    .line 1044
    invoke-virtual {v0, v1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_0

    :cond_0
    const-string v1, "phone"

    .line 1046
    invoke-virtual {v0, v1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 p0, 0x2

    const-string v1, "phone_type"

    .line 1047
    invoke-virtual {v0, v1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    :goto_0
    const/high16 p0, 0x80000

    .line 1050
    invoke-virtual {v0, p0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    return-object v0
.end method

.method private createProgressDialog()Landroid/app/ProgressDialog;
    .locals 2

    .line 1818
    new-instance v0, Landroid/app/ProgressDialog;

    invoke-direct {v0, p0}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 1819
    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setIndeterminate(Z)V

    const/4 v1, 0x0

    .line 1820
    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setProgressStyle(I)V

    .line 1821
    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setCanceledOnTouchOutside(Z)V

    .line 1822
    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setCancelable(Z)V

    const v1, 0x7f0e00af    # @string/deleting_threads 'Deleting threads...'

    .line 1823
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ConversationList;->getText(I)Ljava/lang/CharSequence;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V

    return-object v0
.end method

.method private disableNotificationGroup()V
    .locals 2

    .line 426
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    if-eqz v0, :cond_1

    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationIcon:Landroid/widget/ImageView;

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    .line 429
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setEnabled(Z)V

    .line 430
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    const/high16 v1, 0x3e800000

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setAlpha(F)V

    .line 431
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationIcon:Landroid/widget/ImageView;

    const v0, 0x7f07013e    # @drawable/notification_disable 'res/drawable/notification_disable.xml'

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_1
    :goto_0
    return-void
.end method

.method private enableNotificationGroup()V
    .locals 2

    .line 414
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    if-eqz v0, :cond_1

    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationIcon:Landroid/widget/ImageView;

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    .line 417
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setEnabled(Z)V

    .line 418
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    const/high16 v1, 0x3f800000

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setAlpha(F)V

    .line 419
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationIcon:Landroid/widget/ImageView;

    const v0, 0x7f070144    # @drawable/notification_main 'res/drawable/notification_main.xml'

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_1
    :goto_0
    return-void
.end method

.method private exitEditMode()V
    .locals 2

    const/4 v0, 0x0

    .line 2272
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    .line 2273
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mInboxLable:Landroid/widget/TextView;

    const v1, 0x7f0e02e4    # @string/type_inbox 'Inbox'

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 2274
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mSelectAllView:Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 2275
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mSelectNum:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    const/4 v0, 0x0

    .line 2276
    sput-object v0, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    .line 2277
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateMenuBar()V

    .line 2278
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationListAdapter;->exitEditMode()V

    return-void
.end method

.method private exitSelectMode()V
    .locals 1

    const/4 v0, 0x0

    .line 2288
    sput-boolean v0, Lcom/android/mms/ui/ConversationList;->mSelectMode:Z

    .line 2290
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->exitEditMode()V

    return-void
.end method

.method private formatTextToBold(Ljava/lang/String;)Ljava/lang/CharSequence;
    .locals 3

    if-eqz p1, :cond_0

    .line 1781
    new-instance p0, Landroid/text/SpannableStringBuilder;

    invoke-direct {p0, p1}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 1782
    sget-object p1, Lcom/android/mms/ui/ConversationListItem;->STYLE_BOLD:Landroid/text/style/StyleSpan;

    const/4 v0, 0x0

    invoke-virtual {p0}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v1

    const/16 v2, 0x11

    invoke-virtual {p0, p1, v0, v1, v2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method

.method private hideMmsNotification()V
    .locals 2

    .line 2336
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    if-eqz v0, :cond_0

    .line 2337
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v0

    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->removeHeaderView(Landroid/view/View;)Z

    const/4 v0, 0x0

    .line 2338
    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    :cond_0
    return-void
.end method

.method private inEditMode()V
    .locals 3

    const/4 v0, 0x0

    .line 2261
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    .line 2262
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mInboxLable:Landroid/widget/TextView;

    const v2, 0x7f0e0151    # @string/menu_title_selected 'Selected'

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    .line 2263
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mSelectAllView:Landroid/widget/TextView;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 2264
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mSelectAllView:Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/widget/TextView;->requestFocus()Z

    .line 2265
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mSelectNum:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 2266
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    .line 2267
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateMenuBar()V

    .line 2268
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationListAdapter;->inEditMode()V

    return-void
.end method

.method private inSelectMode()V
    .locals 1

    const/4 v0, 0x1

    .line 2283
    sput-boolean v0, Lcom/android/mms/ui/ConversationList;->mSelectMode:Z

    .line 2284
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->inEditMode()V

    return-void
.end method

.method private initListAdapter()V
    .locals 2

    # tzib: install pinned fake-conversation header before the adapter is set
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibHook;->install(Landroid/app/Activity;Landroid/widget/ListView;)V

    .line 567
    new-instance v0, Lcom/android/mms/tzib/TzibInboxAdapter;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/android/mms/tzib/TzibInboxAdapter;-><init>(Landroid/content/Context;Landroid/database/Cursor;)V

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    .line 568
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mContentChangedListener:Lcom/android/mms/ui/ConversationListAdapter$OnContentChangedListener;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/ConversationListAdapter;->setOnContentChangedListener(Lcom/android/mms/ui/ConversationListAdapter$OnContentChangedListener;)V

    .line 569
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ConversationList;->setListAdapter(Landroid/widget/ListAdapter;)V

    .line 570
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v0

    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    invoke-virtual {v0, p0}, Landroid/widget/ListView;->setRecyclerListener(Landroid/widget/AbsListView$RecyclerListener;)V

    return-void
.end method

.method private initSmsPromoBanner()V
    .locals 8

    .line 574
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    .line 575
    invoke-static {p0}, Landroid/provider/Telephony$Sms;->getDefaultSmsPackage(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    .line 584
    :try_start_0
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    .line 585
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    :try_start_1

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_0
    move-object v4, v3

    .line 588
    :catch_1
    :goto_0
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    if-eqz v4, :cond_0

    if-eqz v3, :cond_0

    if-eqz v1, :cond_0

    .line 592
    iget-object v5, p0, Lcom/android/mms/ui/ConversationList;->mSmsPromoBannerView:Landroid/view/View;

    const v6, 0x7f080050    # @id/banner_sms_default_app_icon

    .line 593
    invoke-virtual {v5, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/ImageView;

    .line 594
    invoke-virtual {v5, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 595
    iget-object v4, p0, Lcom/android/mms/ui/ConversationList;->mSmsPromoBannerView:Landroid/view/View;

    const v5, 0x7f080052    # @id/banner_sms_promo_title

    .line 596
    invoke-virtual {v4, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    .line 597
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e004e    # @string/banner_sms_promo_title_application '%s is your SMS app'

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    .line 598
    invoke-virtual {v3, v0}, Landroid/content/pm/ApplicationInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v0

    aput-object v0, v7, v2

    .line 597
    invoke-virtual {v5, v6, v7}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 599
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 601
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mSmsPromoBannerView:Landroid/view/View;

    new-instance v2, Lcom/android/mms/ui/ConversationList$6;

    invoke-direct {v2, p0, v1}, Lcom/android/mms/ui/ConversationList$6;-><init>(Lcom/android/mms/ui/ConversationList;Landroid/content/Intent;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_1

    .line 609
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mSmsPromoBannerView:Landroid/view/View;

    new-instance v1, Lcom/android/mms/ui/ConversationList$7;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ConversationList$7;-><init>(Lcom/android/mms/ui/ConversationList;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :goto_1
    return-void
.end method

.method private invisibleNotificationGroup()V
    .locals 2

    .line 438
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationContent:Landroid/view/ViewGroup;

    const/16 v1, 0x8

    if-eqz v0, :cond_0

    .line 439
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 441
    :cond_0
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationIcon:Landroid/widget/ImageView;

    if-eqz p0, :cond_1

    .line 442
    invoke-virtual {p0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_1
    return-void
.end method

.method private isMmsNotification()Z
    .locals 4

    .line 2034
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v0

    int-to-long v0, v0

    # tzib: live header index, our row may be hidden by the kill switch
    invoke-static {}, Lcom/android/mms/tzib/TzibHook;->mmsNotificationPosition()I

    move-result v2

    int-to-long v2, v2

    cmp-long v0, v0, v2

    if-nez v0, :cond_0

    .line 2035
    iget-boolean p0, p0, Lcom/android/mms/ui/ConversationList;->mIsNotiShows:Z

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private varargs log(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 2

    .line 2028
    invoke-static {p1, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    .line 2029
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "["

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Thread;->getId()J

    move-result-wide v0

    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p2, "] "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "Mms"

    invoke-static {p1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private markCheckedMessageLimit()V
    .locals 2

    .line 680
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mPrefs:Landroid/content/SharedPreferences;

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "checked_message_limits"

    const/4 v1, 0x1

    .line 681
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 682
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private openMmsNotificationList()V
    .locals 2

    .line 2343
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/MmsNotificationMessageManagementActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 2344
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ConversationList;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private remove(Lcom/android/mms/ui/ConversationList$DeleteThreadListener;Ljava/util/Collection;Ljava/lang/Runnable;ZLcom/android/mms/data/Conversation$ConversationQueryHandler;Landroid/content/Context;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/mms/ui/ConversationList$DeleteThreadListener;",
            "Ljava/util/Collection<",
            "Ljava/lang/Long;",
            ">;",
            "Ljava/lang/Runnable;",
            "Z",
            "Lcom/android/mms/data/Conversation$ConversationQueryHandler;",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    move-object/from16 v6, p0

    .line 1230
    new-instance v7, Landroid/app/AlertDialog$Builder;

    invoke-direct {v7, v6}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 1232
    invoke-static/range {p0 .. p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const v1, 0x7f0a007a    # @layout/remove_dialog 'res/layout/remove_dialog.xml'

    const/4 v8, 0x0

    .line 1233
    invoke-virtual {v0, v1, v8}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v9

    const v0, 0x7f08008a    # @id/dialog_text

    .line 1234
    invoke-virtual {v9, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TctDialogMessage;

    const v1, 0x7f0e0082    # @string/confirm_delete_conversation 'The entire thread will be deleted.'

    .line 1235
    invoke-virtual {v0, v1}, Landroid/widget/TctDialogMessage;->setText(I)V

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-nez p2, :cond_0

    const v1, 0x7f0e0081    # @string/confirm_delete_all_conversations 'All threads will be deleted.'

    .line 1238
    invoke-virtual {v0, v1}, Landroid/widget/TctDialogMessage;->setText(I)V

    goto :goto_0

    .line 1241
    :cond_0
    invoke-interface/range {p2 .. p2}, Ljava/util/Collection;->size()I

    move-result v1

    .line 1242
    iput v1, v6, Lcom/android/mms/ui/ConversationList;->mDeleteCount:I

    .line 1243
    invoke-virtual/range {p6 .. p6}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f0d0003    # @plurals/new_confirm_delete_conversation

    new-array v4, v10, [Ljava/lang/Object;

    .line 1244
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v11

    .line 1243
    invoke-virtual {v2, v3, v1, v4}, Landroid/content/res/Resources;->getQuantityString(II[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TctDialogMessage;->setText(Ljava/lang/CharSequence;)V

    .line 1247
    :goto_0
    new-instance v12, Landroid/view/ViewGroup$LayoutParams;

    const/4 v13, -0x1

    const/4 v14, -0x2

    invoke-direct {v12, v13, v14}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 1250
    new-instance v15, Lcom/android/mms/ui/ConversationList$11;

    move-object v0, v15

    move-object/from16 v1, p0

    move-object/from16 v2, p6

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p5

    invoke-direct/range {v0 .. v5}, Lcom/android/mms/ui/ConversationList$11;-><init>(Lcom/android/mms/ui/ConversationList;Landroid/content/Context;Ljava/util/Collection;Ljava/lang/Runnable;Lcom/android/mms/data/Conversation$ConversationQueryHandler;)V

    invoke-virtual {v7, v15}, Landroid/app/AlertDialog$Builder;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/app/AlertDialog$Builder;

    .line 1305
    invoke-virtual {v7}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    iput-object v0, v6, Lcom/android/mms/ui/ConversationList;->mRemoveDialog:Landroid/app/AlertDialog;

    const/16 v1, 0xe

    .line 1307
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog;->requestWindowFeature(I)Z

    .line 1308
    iget-object v0, v6, Lcom/android/mms/ui/ConversationList;->mRemoveDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

    .line 1309
    iget-object v0, v6, Lcom/android/mms/ui/ConversationList;->mRemoveDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0, v9, v12}, Landroid/app/AlertDialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1312
    iget-object v0, v6, Lcom/android/mms/ui/ConversationList;->mRemoveDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object v0

    iput-object v0, v6, Lcom/android/mms/ui/ConversationList;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    .line 1315
    invoke-static/range {p0 .. p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 1316
    iget-object v0, v6, Lcom/android/mms/ui/ConversationList;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    const v1, 0x7f0e02c4    # @string/str_no 'No'

    const v2, 0x7f0e02c5    # @string/str_yes 'Yes'

    invoke-virtual {v0, v1, v11, v2, v8}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    goto :goto_1

    .line 1318
    :cond_1
    iget-object v0, v6, Lcom/android/mms/ui/ConversationList;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    const v1, 0x7f0e0196    # @string/no 'Cancel'

    const v2, 0x7f0e00aa    # @string/delete_message 'Delete'

    invoke-virtual {v0, v1, v11, v2, v8}, Landroid/widget/MenuBar;->updateMenuBar(IIILjava/util/List;)V

    .line 1322
    :goto_1
    iget-object v0, v6, Lcom/android/mms/ui/ConversationList;->mRemoveDialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    .line 1324
    invoke-virtual {v0, v13, v14}, Landroid/view/Window;->setLayout(II)V

    const/16 v1, 0x50

    .line 1327
    invoke-virtual {v0, v1}, Landroid/view/Window;->setGravity(I)V

    const v1, 0x106000d    # @android:color/transparent

    .line 1328
    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    const/high16 v1, 0x3f000000

    .line 1329
    invoke-virtual {v0, v1}, Landroid/view/Window;->setDimAmount(F)V

    .line 1330
    iput-boolean v10, v6, Lcom/android/mms/ui/ConversationList;->mIsRemoveDialogShow:Z

    return-void
.end method

.method private setupActionBar()V
    .locals 5

    .line 544
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getActionBar()Landroid/app/ActionBar;

    move-result-object v0

    .line 546
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v2, 0x7f0a002c    # @layout/conversation_list_actionbar 'res/layout/conversation_list_actionbar.xml'

    const/4 v3, 0x0

    .line 547
    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    const/16 v2, 0x10

    .line 548
    invoke-virtual {v0, v2, v2}, Landroid/app/ActionBar;->setDisplayOptions(II)V

    .line 550
    new-instance v2, Landroid/app/ActionBar$LayoutParams;

    const/4 v3, -0x2

    const v4, 0x800015

    invoke-direct {v2, v3, v3, v4}, Landroid/app/ActionBar$LayoutParams;-><init>(III)V

    invoke-virtual {v0, v1, v2}, Landroid/app/ActionBar;->setCustomView(Landroid/view/View;Landroid/app/ActionBar$LayoutParams;)V

    const v0, 0x7f0801d9    # @id/unread_conv_count

    .line 555
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->mUnreadConvCount:Landroid/widget/TextView;

    return-void
.end method

.method private showMmsNotification(Landroid/database/Cursor;Z)V
    .locals 5

    if-eqz p2, :cond_2

    .line 2297
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p2

    const v0, 0x7f0a002e    # @layout/conversation_list_item 'res/layout/conversation_list_item.xml'

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p2, v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 2298
    check-cast p2, Lcom/android/mms/ui/ConversationListItem;

    iput-object p2, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    const/4 v0, 0x0

    .line 2299
    invoke-virtual {p2, v0}, Lcom/android/mms/ui/ConversationListItem;->setVisibility(I)V

    .line 2300
    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    invoke-virtual {p2, v2}, Lcom/android/mms/ui/ConversationListItem;->setFocusable(Z)V

    .line 2301
    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    invoke-virtual {p2, v2}, Lcom/android/mms/ui/ConversationListItem;->setEnabled(Z)V

    .line 2302
    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    invoke-virtual {p2, v2}, Lcom/android/mms/ui/ConversationListItem;->setClickable(Z)V

    .line 2304
    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    const v1, 0x7f0800b5    # @id/from

    invoke-virtual {p2, v1}, Lcom/android/mms/ui/ConversationListItem;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    iput-object p2, p0, Lcom/android/mms/ui/ConversationList;->mNotificationFrom:Landroid/widget/TextView;

    .line 2305
    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    const v1, 0x7f0801ab    # @id/subject

    invoke-virtual {p2, v1}, Lcom/android/mms/ui/ConversationListItem;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    .line 2306
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    const v2, 0x7f0801ca    # @id/time

    invoke-virtual {v1, v2}, Lcom/android/mms/ui/ConversationListItem;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationTime:Landroid/widget/TextView;

    .line 2307
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationFrom:Landroid/widget/TextView;

    const v2, 0x7f0e00ce    # @string/download_mms 'Download MMS'

    invoke-virtual {p0, v2}, Lcom/android/mms/ui/ConversationList;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2308
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f07006f    # @drawable/conversation_item_background_read 'res/drawable/conversation_item_background_read.xml'

    .line 2309
    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 2308
    invoke-virtual {v1, v2}, Lcom/android/mms/ui/ConversationListItem;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2311
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    const-string v1, "date"

    .line 2312
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v1

    invoke-interface {p1, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v1

    const-wide/16 v3, 0x3e8

    mul-long/2addr v1, v3

    const/16 p1, 0x10

    .line 2313
    invoke-static {p0, v1, v2, p1}, Landroid/text/format/DateUtils;->formatDateTime(Landroid/content/Context;JI)Ljava/lang/String;

    move-result-object p1

    .line 2314
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationTime:Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0e00cf    # @string/download_mms_prompt 'You received a multimedia message, press download to retrieve its content before %s'

    .line 2315
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ConversationList;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2316
    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 2317
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 2318
    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->mNotificationTime:Landroid/widget/TextView;

    invoke-virtual {p2}, Landroid/widget/TextView;->getTextSize()F

    move-result p2

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 2319
    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->mNotificationTime:Landroid/widget/TextView;

    invoke-virtual {p2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p2

    invoke-interface {p2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result p1

    float-to-int p1, p1

    rsub-int p1, p1, 0xbe

    const/16 p2, 0xb4

    if-gt p1, p2, :cond_0

    .line 2322
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationTime:Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/widget/TextView;->getVisibility()I

    move-result v1

    const/16 v2, 0x8

    if-ne v1, v2, :cond_1

    :cond_0
    move p1, p2

    .line 2325
    :cond_1
    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->mNotificationFrom:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setMaxWidth(I)V

    .line 2327
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object p1

    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->headerView:Lcom/android/mms/ui/ConversationListItem;

    invoke-virtual {p1, p2}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;)V

    .line 2329
    iput v0, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    .line 2330
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object p1

    iget p2, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    invoke-virtual {p1, p2}, Landroid/widget/ListView;->setSelection(I)V

    const/4 p1, -0x1

    .line 2331
    iput p1, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    :cond_2
    return-void
.end method

.method private stopAsyncQuery()V
    .locals 2

    .line 822
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    if-eqz v0, :cond_0

    const/16 v1, 0x6a5

    .line 823
    invoke-virtual {v0, v1}, Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;->cancelOperation(I)V

    .line 824
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    const/16 v0, 0x6a6

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;->cancelOperation(I)V

    :cond_0
    return-void
.end method

.method private toggleNotificationGroup(Z)V
    .locals 3

    .line 464
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getIntent()Landroid/content/Intent;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 466
    invoke-virtual {v0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 468
    :goto_0
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    if-eqz p1, :cond_3

    const/4 p1, 0x0

    const-string v2, "pref_key_seperate_notification_msg"

    .line 469
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_3

    const-class p1, Lcom/android/mms/ui/ConversationList;

    .line 470
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    .line 471
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    if-nez p1, :cond_2

    .line 472
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mListViewHeader:Landroid/view/ViewGroup;

    const v0, 0x7f0801f0    # @id/view_stub_notification

    .line 473
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/view/ViewStub;

    if-eqz p1, :cond_1

    .line 475
    invoke-virtual {p1}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    .line 477
    :cond_1
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mListViewHeader:Landroid/view/ViewGroup;

    const v0, 0x7f080121    # @id/notification_header

    .line 478
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    iput-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    .line 479
    new-instance v0, Lcom/android/mms/ui/ConversationList$4;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ConversationList$4;-><init>(Lcom/android/mms/ui/ConversationList;)V

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 487
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    const v0, 0x7f080120    # @id/notification_content

    .line 488
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    iput-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationContent:Landroid/view/ViewGroup;

    .line 489
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    const v0, 0x7f080122    # @id/notification_icon

    .line 490
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationIcon:Landroid/widget/ImageView;

    .line 491
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    const v0, 0x7f080123    # @id/notification_label

    .line 492
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationLabel:Landroid/widget/TextView;

    .line 493
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    const v0, 0x7f08007e    # @id/date

    .line 494
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationDate:Landroid/widget/TextView;

    .line 495
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationView:Landroid/view/ViewGroup;

    const v0, 0x7f0801ab    # @id/subject

    .line 496
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/android/mms/ui/ConversationList;->mNotificationSubject:Landroid/widget/TextView;

    .line 498
    :cond_2
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->visibleNotificationGroup()V

    goto :goto_1

    .line 500
    :cond_3
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->invisibleNotificationGroup()V

    :goto_1
    return-void
.end method

.method private unbindListeners(Ljava/util/Collection;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    .line 755
    :goto_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/ListView;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_2

    .line 756
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 757
    instance-of v2, v1, Lcom/android/mms/ui/ConversationListItem;

    if-eqz v2, :cond_1

    .line 758
    check-cast v1, Lcom/android/mms/ui/ConversationListItem;

    if-nez p1, :cond_0

    .line 760
    invoke-virtual {v1}, Lcom/android/mms/ui/ConversationListItem;->unbind()V

    goto :goto_1

    .line 761
    :cond_0
    invoke-virtual {v1}, Lcom/android/mms/ui/ConversationListItem;->getConversation()Lcom/android/mms/data/Conversation;

    move-result-object v2

    if-eqz v2, :cond_1

    .line 762
    invoke-virtual {v1}, Lcom/android/mms/ui/ConversationListItem;->getConversation()Lcom/android/mms/data/Conversation;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-interface {p1, v2}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 763
    invoke-virtual {v1}, Lcom/android/mms/ui/ConversationListItem;->unbind()V

    :cond_1
    :goto_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method private updateEmptyView()V
    .locals 4

    .line 1790
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "pref_key_seperate_notification_msg"

    const/4 v2, 0x0

    .line 1791
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/16 v1, 0x8

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    .line 1792
    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasNotificationThreads:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasNormalThreads:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 1798
    :cond_0
    iput v2, p0, Lcom/android/mms/ui/ConversationList;->mCurrentMode:I

    .line 1799
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mEmptyView:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1800
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mEmptyTextview:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->requestFocus()Z

    goto :goto_1

    .line 1794
    :cond_1
    :goto_0
    iput v3, p0, Lcom/android/mms/ui/ConversationList;->mCurrentMode:I

    .line 1795
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mEmptyView:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    goto :goto_1

    .line 1803
    :cond_2
    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasNormalThreads:Z

    if-eqz v0, :cond_3

    .line 1804
    iput v3, p0, Lcom/android/mms/ui/ConversationList;->mCurrentMode:I

    .line 1805
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mEmptyView:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    goto :goto_1

    .line 1807
    :cond_3
    iput v2, p0, Lcom/android/mms/ui/ConversationList;->mCurrentMode:I

    .line 1808
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mEmptyView:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1809
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mEmptyTextview:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->requestFocus()Z

    .line 1813
    :goto_1
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateMenuBar()V

    return-void
.end method

.method private updateMenuBar()V
    .locals 14

    # tzib unified: menu
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->menu(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :tzib_continue_menu

    return-void

    :tzib_continue_menu


    .line 2045
    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mIsRemoveDialogShow:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mRemoveDialog:Landroid/app/AlertDialog;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mRemoveDialogMenuBar:Landroid/widget/MenuBar;

    if-eqz v0, :cond_0

    .line 2046
    invoke-virtual {v0}, Landroid/widget/MenuBar;->refreshMenuBar()V

    return-void

    .line 2051
    :cond_0
    iget v0, p0, Lcom/android/mms/ui/ConversationList;->mCurrentMode:I

    const v1, 0x7f0e0125    # @string/menu_action_new 'New'

    const v2, 0x7f0e012d    # @string/menu_action_settings 'Settings'

    const/4 v3, 0x0

    if-nez v0, :cond_1

    .line 2053
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, v1, v3, p0, v3}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    goto/16 :goto_1

    :cond_1
    const/4 v4, 0x1

    if-ne v0, v4, :cond_a

    .line 2056
    sget-boolean v0, Lcom/android/mms/ui/ConversationList;->mSelectMode:Z

    const v5, 0x7f0e0128    # @string/menu_action_select 'Select'

    if-eqz v0, :cond_5

    .line 2057
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mSelectNum:Landroid/widget/TextView;

    sget-object v1, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-virtual {v1}, Ljava/util/HashSet;->size()I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2059
    sget-object v0, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result v0

    const v1, 0x7f0e0122    # @string/menu_action_deselect 'Deselect'

    const v2, 0x7f0e00aa    # @string/delete_message 'Delete'

    const v4, 0x7f0e0274    # @string/selected_all 'Select all'

    if-lez v0, :cond_3

    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    if-nez v0, :cond_3

    .line 2061
    sget-object v0, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    iget-wide v6, p0, Lcom/android/mms/ui/ConversationList;->mTid:J

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 2062
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, v4, v1, p0, v3}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    goto/16 :goto_1

    .line 2064
    :cond_2
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, v1, v4, p0, v3}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    goto/16 :goto_1

    .line 2066
    :cond_3
    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    if-eqz v0, :cond_4

    .line 2067
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f0e00b7    # @string/deselected_all 'Deselect all'

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, v4, v1, p0, v3}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    goto/16 :goto_1

    .line 2070
    :cond_4
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, v1, p0, v3, v3}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    goto/16 :goto_1

    .line 2074
    :cond_5
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->requestFocus()Z

    .line 2075
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2078
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->isMmsNotification()Z

    move-result v3

    const v6, 0x7f0e014f    # @string/menu_search 'Search'

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eqz v3, :cond_6

    .line 2079
    new-instance v3, Landroid/util/Pair;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v7, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2080
    new-instance v3, Landroid/util/Pair;

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-direct {v3, v6, v2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 2081
    :cond_6
    iget-object v3, p0, Lcom/android/mms/ui/ConversationList;->mConversation:Lcom/android/mms/data/Conversation;

    const v9, 0x7f0e012b    # @string/menu_action_selete_thread 'Select thread'

    const/4 v10, 0x4

    const v11, 0x7f0e0124    # @string/menu_action_mark_all_message_as_read 'Mark all messages as read'

    const v12, 0x7f0e0121    # @string/menu_action_delete_thread 'Delete thread'

    const/4 v13, 0x0

    if-eqz v3, :cond_8

    invoke-virtual {v3}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/mms/data/ContactList;->size()I

    move-result v3

    if-lez v3, :cond_8

    iget-object v3, p0, Lcom/android/mms/ui/ConversationList;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {v3}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v3

    invoke-virtual {v3, v13}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/mms/data/Contact;

    invoke-virtual {v3}, Lcom/android/mms/data/Contact;->isHasName()Z

    move-result v3

    if-eqz v3, :cond_8

    .line 2083
    new-instance v3, Landroid/util/Pair;

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-direct {v3, v13, v12}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2084
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v3

    if-nez v3, :cond_7

    .line 2085
    new-instance v3, Landroid/util/Pair;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-direct {v3, v10, v9}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2087
    :cond_7
    new-instance v3, Landroid/util/Pair;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v7, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2088
    new-instance v3, Landroid/util/Pair;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2090
    new-instance v3, Landroid/util/Pair;

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-direct {v3, v6, v2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 2092
    :cond_8
    new-instance v3, Landroid/util/Pair;

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-direct {v3, v13, v12}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2093
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v3

    if-nez v3, :cond_9

    .line 2094
    new-instance v3, Landroid/util/Pair;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-direct {v3, v10, v9}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2096
    :cond_9
    new-instance v3, Landroid/util/Pair;

    const/16 v9, 0x3ea

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    const v10, 0x7f0e009f    # @string/create_new 'Create new contact'

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-direct {v3, v9, v10}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2097
    new-instance v3, Landroid/util/Pair;

    const/16 v9, 0x3eb

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    const v10, 0x7f0e0032    # @string/add_to_existing 'Add to existing contact'

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-direct {v3, v9, v10}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2098
    new-instance v3, Landroid/util/Pair;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-direct {v3, v7, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2099
    new-instance v3, Landroid/util/Pair;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v3, v6, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2101
    new-instance v3, Landroid/util/Pair;

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-direct {v3, v6, v2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2105
    :goto_0
    iget-object v2, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0e0127    # @string/menu_action_options 'Options'

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    # tzib inbox options: pause
    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibThreadOptions;->add(Landroid/app/Activity;Ljava/util/List;)V
    invoke-virtual {v2, v1, v3, v5, v0}, Landroid/widget/MenuBar;->updateMenuBar(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 2106
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 2107
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0e0126    # @string/menu_action_ok 'OK'

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v4, v1}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    .line 2108
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const v1, 0x7f0700f8    # @drawable/ic_options 'res/drawable/ic_options.png'

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    invoke-virtual {v0, v8, p0}, Landroid/widget/MenuBar;->setSoftKeyImage(ILandroid/graphics/drawable/Drawable;)V

    :cond_a
    :goto_1
    return-void
.end method

.method private updateNotificationView(Landroid/database/Cursor;)V
    .locals 2

    .line 1691
    new-instance v0, Lcom/android/mms/ui/ConversationList$14;

    invoke-direct {v0, p0}, Lcom/android/mms/ui/ConversationList$14;-><init>(Lcom/android/mms/ui/ConversationList;)V

    const/4 p0, 0x1

    new-array p0, p0, [Landroid/database/Cursor;

    const/4 v1, 0x0

    aput-object p1, p0, v1

    .line 1775
    invoke-virtual {v0, p0}, Lcom/android/mms/ui/ConversationList$14;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method private visibleNotificationGroup()V
    .locals 2

    .line 450
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationContent:Landroid/view/ViewGroup;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    .line 451
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 453
    :cond_0
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mNotificationIcon:Landroid/widget/ImageView;

    if-eqz p0, :cond_1

    const/16 v0, 0x8

    .line 454
    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_1
    return-void
.end method


# virtual methods
.method public checkAll()V
    .locals 8
    # tzib unified: select actual SMS identities only
    new-instance v0, Ljava/util/HashSet;
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V
    sput-object v0, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;
    invoke-virtual {v1}, Lcom/android/mms/ui/ConversationListAdapter;->getCursor()Landroid/database/Cursor;
    move-result-object v2
    if-eqz v2, :tzib_checked
    invoke-interface {v2}, Landroid/database/Cursor;->getPosition()I
    move-result v3
    const-string v4, "_id"
    invoke-interface {v2, v4}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I
    move-result v4
    const/4 v5, -0x1
    invoke-interface {v2, v5}, Landroid/database/Cursor;->moveToPosition(I)Z
    :tzib_check_next
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z
    move-result v5
    if-eqz v5, :tzib_check_restore
    invoke-interface {v2, v4}, Landroid/database/Cursor;->getLong(I)J
    move-result-wide v6
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v5
    invoke-virtual {v0, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    goto :tzib_check_next
    :tzib_check_restore
    invoke-interface {v2, v3}, Landroid/database/Cursor;->moveToPosition(I)Z
    :tzib_checked
    const/4 v2, 0x1
    iput-boolean v2, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z
    invoke-virtual {v1, v0}, Lcom/android/mms/ui/ConversationListAdapter;->UpdateSelectedThreadIds(Ljava/util/HashSet;)V
    invoke-virtual {v1}, Lcom/android/mms/ui/ConversationListAdapter;->notifyDataSetChanged()V
    return-void
.end method

# implemented-by: Lcom/android/mms/ui/NotificationConversationList;
.method public createNewMessage()V
    .locals 2

    # tzib unified: newMessage
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->newMessage(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :tzib_continue_newMessage

    return-void

    :tzib_continue_newMessage


    const-wide/16 v0, 0x0

    .line 1032
    invoke-static {p0, v0, v1}, Lcom/android/mms/ui/ComposeMessageActivity;->createIntent(Landroid/content/Context;J)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ConversationList;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

# implemented-by: Lcom/android/mms/ui/NotificationConversationList;
.method protected initCreateNewMessageButton()V
    .locals 0

    return-void
.end method

.method public onClickCSK()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public onClickLSK()Z
    .locals 5

    .line 2117
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mAudioManager:Landroid/media/AudioManager;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->playSoundEffect(I)V

    .line 2119
    sget-boolean v0, Lcom/android/mms/ui/ConversationList;->mSelectMode:Z

    if-eqz v0, :cond_1

    .line 2122
    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    .line 2123
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->unCheckAll()V

    .line 2125
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e0274    # @string/selected_all 'Select all'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    .line 2126
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e0122    # @string/menu_action_deselect 'Deselect'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    goto :goto_0

    .line 2128
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->checkAll()V

    .line 2129
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e00b7    # @string/deselected_all 'Deselect all'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    .line 2130
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0e0128    # @string/menu_action_select 'Select'

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Landroid/widget/MenuBar;->setSoftKeyName(ILjava/lang/String;)V

    .line 2133
    :goto_0
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateMenuBar()V

    goto :goto_1

    .line 2137
    :cond_1
    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mIsSmsEnabled:Z

    if-eqz v0, :cond_2

    .line 2138
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->createNewMessage()V

    goto :goto_1

    .line 2141
    :cond_2
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mComposeDisabledToast:Landroid/widget/Toast;

    if-nez v0, :cond_3

    const v0, 0x7f0e0076    # @string/compose_disabled_toast 'Can't compose. Not default SMS app.'

    .line 2142
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->mComposeDisabledToast:Landroid/widget/Toast;

    .line 2145
    :cond_3
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mComposeDisabledToast:Landroid/widget/Toast;

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :goto_1
    return v1
.end method

.method public onClickRSK()Z
    .locals 2

    .line 2161
    sget-boolean v0, Lcom/android/mms/ui/ConversationList;->mSelectMode:Z

    if-eqz v0, :cond_0

    .line 2163
    sget-object v0, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result v0

    if-lez v0, :cond_1

    .line 2164
    sget-object v0, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    invoke-static {v0, p0}, Lcom/android/mms/ui/ConversationList;->confirmDeleteThreads(Ljava/util/Collection;Landroid/content/AsyncQueryHandler;)V

    goto :goto_0

    .line 2168
    :cond_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/MessagingPreferenceActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v1, -0x1

    .line 2169
    invoke-virtual {p0, v0, v1}, Lcom/android/mms/ui/ConversationList;->startActivityIfNeeded(Landroid/content/Intent;I)Z

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return p0
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    .line 1133
    invoke-super {p0, p1}, Landroid/app/ListActivity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    return-void
.end method

.method public onContextItemSelected(Landroid/view/MenuItem;)Z
    .locals 5

    # tzib unified: contextMenu
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibHook;->contextMenu(Landroid/app/Activity;Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :tzib_continue_contextMenu

    return v0

    :tzib_continue_contextMenu


    .line 1091
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    invoke-virtual {v0}, Lcom/android/mms/ui/ConversationListAdapter;->getCursor()Landroid/database/Cursor;

    move-result-object v0

    if-eqz v0, :cond_4

    .line 1092
    invoke-interface {v0}, Landroid/database/Cursor;->getPosition()I

    move-result v1

    if-ltz v1, :cond_4

    .line 1093
    invoke-static {p0, v0}, Lcom/android/mms/data/Conversation;->from(Landroid/content/Context;Landroid/database/Cursor;)Lcom/android/mms/data/Conversation;

    move-result-object v0

    .line 1094
    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v1

    .line 1095
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v3

    if-eqz v3, :cond_3

    const/4 v4, 0x1

    if-eq v3, v4, :cond_2

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eq v3, v1, :cond_1

    const/4 v1, 0x3

    if-eq v3, v1, :cond_0

    goto :goto_0

    .line 1112
    :cond_0
    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/mms/data/Contact;

    invoke-virtual {v0}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object v0

    .line 1113
    invoke-static {v0}, Lcom/android/mms/ui/ConversationList;->createAddContactIntent(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ConversationList;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 1105
    :cond_1
    invoke-virtual {v0}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/mms/data/Contact;

    .line 1106
    new-instance v1, Landroid/content/Intent;

    invoke-virtual {v0}, Lcom/android/mms/data/Contact;->getUri()Landroid/net/Uri;

    move-result-object v0

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v0, 0x80000

    .line 1107
    invoke-virtual {v1, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 1108
    invoke-virtual {p0, v1}, Lcom/android/mms/ui/ConversationList;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 1101
    :cond_2
    invoke-virtual {p0, v1, v2}, Lcom/android/mms/ui/ConversationList;->openThread(J)V

    goto :goto_0

    .line 1097
    :cond_3
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    invoke-static {v1, v2, v0}, Lcom/android/mms/ui/ConversationList;->confirmDeleteThread(JLandroid/content/AsyncQueryHandler;)V

    .line 1120
    :cond_4
    :goto_0
    invoke-super {p0, p1}, Landroid/app/ListActivity;->onContextItemSelected(Landroid/view/MenuItem;)Z

    move-result p0

    return p0
.end method

# implemented-by: Lcom/android/mms/ui/NotificationConversationList;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    # tzib inbox options: restore
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibHook;->restored(Landroid/app/Activity;Landroid/os/Bundle;)V

    .line 235
    invoke-super {p0, p1}, Landroid/app/ListActivity;->onCreate(Landroid/os/Bundle;)V

    .line 236
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->checkPermissionsIfNeeded(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 240
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getApplication()Landroid/app/Application;

    move-result-object v0

    invoke-static {v0}, Lcom/android/mms/data/RecipientIdCache;->init(Landroid/content/Context;)V

    .line 243
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0xe

    .line 248
    invoke-virtual {v0, v1}, Landroid/view/Window;->requestFeature(I)Z

    const v0, 0x7f0a0032    # @layout/conversation_list_screen 'res/layout/conversation_list_screen.xml'

    .line 249
    invoke-virtual {p0, v0}, Lcom/android/mms/ui/ConversationList;->setContentView(I)V

    .line 251
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMailboxMode()Z

    move-result v0

    const/4 v1, -0x1

    if-eqz v0, :cond_1

    .line 252
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/android/mms/ui/MailBoxMessageList;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 253
    invoke-virtual {p0, p1, v1}, Lcom/android/mms/ui/ConversationList;->startActivityIfNeeded(Landroid/content/Intent;I)Z

    .line 254
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->finish()V

    return-void

    :cond_1
    const/4 v0, 0x0

    .line 258
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mIsNotiShows:Z

    const v2, 0x7f080051    # @id/banner_sms_promo

    .line 259
    invoke-virtual {p0, v2}, Lcom/android/mms/ui/ConversationList;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, p0, Lcom/android/mms/ui/ConversationList;->mSmsPromoBannerView:Landroid/view/View;

    const/16 v3, 0x8

    .line 261
    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 262
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->initCreateNewMessageButton()V

    const v2, 0x7f0800cf    # @id/inbox_lable

    .line 263
    invoke-virtual {p0, v2}, Lcom/android/mms/ui/ConversationList;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lcom/android/mms/ui/ConversationList;->mInboxLable:Landroid/widget/TextView;

    const v2, 0x7f0800bc    # @id/head_layout

    .line 265
    invoke-virtual {p0, v2}, Lcom/android/mms/ui/ConversationList;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    iput-object v2, p0, Lcom/android/mms/ui/ConversationList;->mHeadLayout:Landroid/widget/LinearLayout;

    const v2, 0x7f080183    # @id/select_num

    .line 266
    invoke-virtual {p0, v2}, Lcom/android/mms/ui/ConversationList;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lcom/android/mms/ui/ConversationList;->mSelectNum:Landroid/widget/TextView;

    .line 268
    new-instance v2, Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    invoke-direct {v2, p0, v3}, Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;-><init>(Lcom/android/mms/ui/ConversationList;Landroid/content/ContentResolver;)V

    iput-object v2, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    .line 270
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v2

    const v3, 0x7f08009c    # @id/empty

    .line 271
    invoke-virtual {p0, v3}, Lcom/android/mms/ui/ConversationList;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    iput-object v3, p0, Lcom/android/mms/ui/ConversationList;->mEmptyView:Landroid/widget/LinearLayout;

    const v3, 0x7f08017d    # @id/second_text_counter

    .line 273
    invoke-virtual {p0, v3}, Lcom/android/mms/ui/ConversationList;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    iput-object v3, p0, Lcom/android/mms/ui/ConversationList;->mEmptyTextview:Landroid/widget/TextView;

    const/4 v4, 0x1

    .line 274
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setFocusable(Z)V

    const v3, 0x7f08017e    # @id/select_all

    .line 276
    invoke-virtual {p0, v3}, Lcom/android/mms/ui/ConversationList;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    iput-object v3, p0, Lcom/android/mms/ui/ConversationList;->mSelectAllView:Landroid/widget/TextView;

    .line 277
    new-instance v4, Lcom/android/mms/ui/ConversationList$1;

    invoke-direct {v4, p0}, Lcom/android/mms/ui/ConversationList$1;-><init>(Lcom/android/mms/ui/ConversationList;)V

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 288
    iget-object v3, p0, Lcom/android/mms/ui/ConversationList;->mSelectAllView:Landroid/widget/TextView;

    new-instance v4, Lcom/android/mms/ui/ConversationList$2;

    invoke-direct {v4, p0, v2}, Lcom/android/mms/ui/ConversationList$2;-><init>(Lcom/android/mms/ui/ConversationList;Landroid/widget/ListView;)V

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 302
    iget-object v3, p0, Lcom/android/mms/ui/ConversationList;->mThreadListKeyListener:Landroid/view/View$OnKeyListener;

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    const/4 v3, 0x0

    .line 305
    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setMultiChoiceModeListener(Landroid/widget/AbsListView$MultiChoiceModeListener;)V

    .line 307
    new-instance v3, Lcom/android/mms/ui/ConversationList$3;

    invoke-direct {v3, p0}, Lcom/android/mms/ui/ConversationList$3;-><init>(Lcom/android/mms/ui/ConversationList;)V

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 334
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->initListAdapter()V

    .line 338
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->createProgressDialog()Landroid/app/ProgressDialog;

    move-result-object v2

    iput-object v2, p0, Lcom/android/mms/ui/ConversationList;->mProgressDialog:Landroid/app/ProgressDialog;

    const v2, 0x7f0e003b    # @string/app_label 'Messages'

    .line 340
    invoke-virtual {p0, v2}, Lcom/android/mms/ui/ConversationList;->setTitle(I)V

    .line 342
    new-instance v2, Landroid/os/Handler;

    invoke-direct {v2}, Landroid/os/Handler;-><init>()V

    iput-object v2, p0, Lcom/android/mms/ui/ConversationList;->mHandler:Landroid/os/Handler;

    .line 343
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    iput-object v2, p0, Lcom/android/mms/ui/ConversationList;->mPrefs:Landroid/content/SharedPreferences;

    const-string v3, "checked_message_limits"

    .line 344
    invoke-interface {v2, v3, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_2

    .line 347
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->runOneTimeStorageLimitCheckForLegacyMessages()V

    :cond_2
    if-eqz p1, :cond_3

    const-string v2, "last_list_pos"

    .line 351
    invoke-virtual {p1, v2, v1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    iput v1, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    const-string v1, "last_list_offset"

    .line 353
    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result p1

    iput p1, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstItemOffset:I

    goto :goto_0

    .line 355
    :cond_3
    iput v1, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    .line 356
    iput v0, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstItemOffset:I

    .line 359
    :goto_0
    :try_start_0
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->isWfcUnavailable(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_4

    .line 360
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->pupConnectWifiNotification(Landroid/content/Context;)V

    :try_end_0
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    const-string p1, "Mms"

    const-string v0, "SettingNotFoundException wfc"

    .line 363
    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 366
    :cond_4
    :goto_1
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getMenuBar()Landroid/widget/MenuBar;

    move-result-object p1

    iput-object p1, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    .line 367
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_5

    .line 368
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    const v0, 0x7f07014f    # @drawable/option_menu_item_selector_dish 'res/drawable/option_menu_item_selector_dish.xml'

    invoke-virtual {p1, v0}, Landroid/widget/MenuBar;->setOptionMenuItemBackground(I)V

    goto :goto_2

    .line 370
    :cond_5
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    const v0, 0x7f07014e    # @drawable/option_menu_item_selector 'res/drawable/option_menu_item_selector.xml'

    invoke-virtual {p1, v0}, Landroid/widget/MenuBar;->setOptionMenuItemBackground(I)V

    .line 372
    :goto_2
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p1, p0}, Landroid/widget/MenuBar;->setMenuBarListener(Landroid/widget/MenuBar$MenuBarListener;)V

    const-string p1, "audio"

    .line 374
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ConversationList;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/media/AudioManager;

    iput-object p1, p0, Lcom/android/mms/ui/ConversationList;->mAudioManager:Landroid/media/AudioManager;

    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 2

    .line 832
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMailboxMode()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 835
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object p0

    const v0, 0x7f0b0001    # @menu/conversation_list_menu 'res/menu/conversation_list_menu.xml'

    invoke-virtual {p0, v0, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const p0, 0x7f080011    # @id/action_change_to_conversation_mode

    .line 837
    invoke-interface {p1, p0}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p0

    if-eqz p0, :cond_1

    const/4 p1, 0x0

    .line 839
    invoke-interface {p0, p1}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    :cond_1
    return v1
.end method

.method protected onDestroy()V
    .locals 2

    # tzib unified: destroy
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->destroy(Landroid/app/Activity;)V


    .line 739
    invoke-super {p0}, Landroid/app/ListActivity;->onDestroy()V

    .line 740
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    .line 741
    invoke-virtual {v0, v1}, Lcom/android/mms/ui/ConversationListAdapter;->changeCursor(Landroid/database/Cursor;)V

    .line 743
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mHandler:Landroid/os/Handler;

    if-eqz v0, :cond_1

    .line 744
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mShowProgressDialogRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 746
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mProgressDialog:Landroid/app/ProgressDialog;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "dismiss progress dialog"

    .line 747
    invoke-static {v0}, Lcom/android/mms/LogTag;->debugD(Ljava/lang/String;)V

    .line 748
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mProgressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {p0}, Landroid/app/ProgressDialog;->dismiss()V

    .line 750
    :cond_2
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->removeDialogs()V

    .line 751
    invoke-static {}, Lcom/android/mms/data/Contact;->clearListener()V

    return-void
.end method

# overrides: Lcom/android/mms/util/DraftCache$OnDraftChangedListener;
.method public onDraftChanged(JZ)V
    .locals 2

    .line 772
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    new-instance v1, Lcom/android/mms/ui/ConversationList$9;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/android/mms/ui/ConversationList$9;-><init>(Lcom/android/mms/ui/ConversationList;JZ)V

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 1

    # tzib unified: keyDown
    invoke-static {p0, p1, p2}, Lcom/android/mms/tzib/TzibHook;->keyDown(Landroid/app/Activity;ILandroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :tzib_continue_keyDown

    return v0

    :tzib_continue_keyDown


    const/16 v0, 0x54

    if-ne p1, v0, :cond_1

    .line 1139
    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mMultiChoiceMode:Z

    if-nez v0, :cond_1

    .line 1140
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const p2, 0x7f040006    # @bool/config_classify_search 'false'

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 1141
    new-instance p1, Landroid/content/Intent;

    const-class p2, Lcom/android/mms/ui/SearchActivityExtend;

    invoke-direct {p1, p0, p2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 p2, -0x1

    .line 1142
    invoke-virtual {p0, p1, p2}, Lcom/android/mms/ui/ConversationList;->startActivityIfNeeded(Landroid/content/Intent;I)Z

    :cond_0
    const/4 p0, 0x1

    return p0

    .line 1147
    :cond_1
    invoke-super {p0, p1, p2}, Landroid/app/ListActivity;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p0

    return p0
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .locals 2

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    .line 2233
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->onClickLSK()Z

    move-result p0

    return p0

    :cond_0
    const/4 v1, 0x2

    if-ne p1, v1, :cond_1

    .line 2238
    sget-object v1, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/util/HashSet;->size()I

    move-result v1

    if-lez v1, :cond_1

    .line 2239
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mAudioManager:Landroid/media/AudioManager;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/media/AudioManager;->playSoundEffect(I)V

    .line 2240
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->onClickRSK()Z

    move-result p0

    return p0

    :cond_1
    const/4 v1, 0x4

    if-ne p1, v1, :cond_3

    .line 2247
    sget-boolean v1, Lcom/android/mms/ui/ConversationList;->mSelectMode:Z

    if-eqz v1, :cond_2

    .line 2248
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->exitSelectMode()V

    return v0

    .line 2252
    :cond_2
    invoke-super {p0, p1, p2}, Landroid/app/ListActivity;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result p0

    return p0

    .line 2255
    :cond_3
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    invoke-virtual {p0, p1, p2}, Landroid/widget/MenuBar;->onKeyUp(ILandroid/view/KeyEvent;)Z

    return v0
.end method

.method protected onListItemClick(Landroid/widget/ListView;Landroid/view/View;IJ)V
    .locals 2

    # tzib: position 0 is the pinned row -> open the menu instead of a thread
    invoke-static {p0, p3}, Lcom/android/mms/tzib/TzibHook;->handleClick(Landroid/app/Activity;I)Z

    move-result v0

    if-eqz v0, :tzib_not_handled

    return-void

    :tzib_not_handled
    .line 959
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p4, "start conversation onListItemClick time is "

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p4

    invoke-virtual {p1, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p4, "mmstime"

    invoke-static {p4, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 960
    iget-boolean p1, p0, Lcom/android/mms/ui/ConversationList;->mIsNotiShows:Z

    if-eqz p1, :cond_0

    # tzib: our row may be hidden by the kill switch, so ask for the live index
    invoke-static {}, Lcom/android/mms/tzib/TzibHook;->mmsNotificationPosition()I

    move-result v0

    if-ne p3, v0, :cond_0

    .line 961
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->openMmsNotificationList()V

    return-void

    .line 966
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1, p3}, Landroid/widget/ListView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/database/Cursor;

    if-eqz p1, :cond_6

    .line 967
    invoke-interface {p1}, Landroid/database/Cursor;->getPosition()I

    move-result p4

    if-gez p4, :cond_1

    goto/16 :goto_3

    .line 970
    :cond_1
    invoke-static {p0, p1}, Lcom/android/mms/data/Conversation;->from(Landroid/content/Context;Landroid/database/Cursor;)Lcom/android/mms/data/Conversation;

    move-result-object p4

    .line 971
    invoke-virtual {p4}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide p4

    .line 976
    sget-boolean v0, Lcom/android/mms/ui/ConversationList;->mSelectMode:Z

    if-nez v0, :cond_3

    sget-boolean v0, Lcom/android/mms/ui/ConversationList;->mMarkReadMode:Z

    if-nez v0, :cond_3

    sget-boolean v0, Lcom/android/mms/ui/ConversationList;->mMarkUnreadMode:Z

    if-eqz v0, :cond_2

    goto :goto_0

    .line 1003
    :cond_2
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "onListItemClick: pos="

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p3, ", view="

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, ", tid="

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "Mms"

    invoke-static {p2, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1005
    invoke-virtual {p0, p4, p5}, Lcom/android/mms/ui/ConversationList;->openThread(J)V

    return-void

    .line 978
    :cond_3
    :goto_0
    sget-object p3, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result p3

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p3, :cond_4

    .line 979
    sget-object p3, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p4

    invoke-virtual {p3, p4}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 980
    check-cast p2, Lcom/android/mms/ui/ConversationListItem;

    invoke-virtual {p2, v0}, Lcom/android/mms/ui/ConversationListItem;->updateView(Z)V

    goto :goto_1

    .line 983
    :cond_4
    sget-object p3, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p4

    invoke-virtual {p3, p4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 984
    check-cast p2, Lcom/android/mms/ui/ConversationListItem;

    invoke-virtual {p2, v1}, Lcom/android/mms/ui/ConversationListItem;->updateView(Z)V

    .line 987
    :goto_1
    iget-object p2, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    sget-object p3, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-virtual {p2, p3}, Lcom/android/mms/ui/ConversationListAdapter;->UpdateSelectedThreadIds(Ljava/util/HashSet;)V

    .line 990
    sget-object p2, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-virtual {p2}, Ljava/util/HashSet;->size()I

    move-result p2

    invoke-interface {p1}, Landroid/database/Cursor;->getCount()I

    move-result p1

    if-ne p2, p1, :cond_5

    .line 991
    iput-boolean v1, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    goto :goto_2

    .line 994
    :cond_5
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    .line 997
    :goto_2
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateMenuBar()V

    :cond_6
    :goto_3
    return-void
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .locals 0

    # tzib unified: notification intent
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ConversationList;->setIntent(Landroid/content/Intent;)V


    .line 688
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->startAsyncQuery()V

    return-void
.end method

.method public onOptionMenuClick(I)V
    .locals 2

    # tzib unified: option
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibHook;->option(Landroid/app/Activity;I)Z

    move-result v0

    if-eqz v0, :tzib_continue_option

    return-void

    :tzib_continue_option


    const/4 v0, 0x4

    if-ne p1, v0, :cond_0

    .line 2186
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->inSelectMode()V

    goto/16 :goto_1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    .line 2188
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->checkAll()V

    .line 2189
    invoke-static {p0}, Lcom/android/mms/data/Conversation;->createNew(Landroid/content/Context;)Lcom/android/mms/data/Conversation;

    move-result-object p0

    .line 2190
    sget-object p1, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-virtual {p0, p1}, Lcom/android/mms/data/Conversation;->startMarkRead(Ljava/util/Collection;)V

    const/4 p0, 0x0

    .line 2191
    sput-object p0, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    goto/16 :goto_1

    :cond_1
    const/4 v0, 0x2

    if-ne p1, v0, :cond_2

    .line 2194
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/android/mms/ui/MessagingPreferenceActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v0, -0x1

    .line 2195
    invoke-virtual {p0, p1, v0}, Lcom/android/mms/ui/ConversationList;->startActivityIfNeeded(Landroid/content/Intent;I)Z

    goto/16 :goto_1

    :cond_2
    if-nez p1, :cond_5

    .line 2198
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/database/Cursor;

    if-eqz p1, :cond_4

    .line 2199
    invoke-interface {p1}, Landroid/database/Cursor;->getPosition()I

    move-result v0

    if-gez v0, :cond_3

    goto :goto_0

    .line 2202
    :cond_3
    invoke-static {p0, p1}, Lcom/android/mms/data/Conversation;->from(Landroid/content/Context;Landroid/database/Cursor;)Lcom/android/mms/data/Conversation;

    move-result-object p1

    .line 2203
    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide v0

    .line 2204
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    invoke-static {v0, v1, p0}, Lcom/android/mms/ui/ConversationList;->confirmDeleteThread(JLandroid/content/AsyncQueryHandler;)V

    goto/16 :goto_1

    :cond_4
    :goto_0
    return-void

    :cond_5
    const/4 v0, 0x3

    if-ne p1, v0, :cond_6

    .line 2207
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/android/mms/ui/SearchConversationActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 2208
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ConversationList;->startActivity(Landroid/content/Intent;)V

    goto :goto_1

    :cond_6
    const/16 v0, 0x3ea

    const/4 v1, 0x0

    if-ne p1, v0, :cond_8

    .line 2211
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p1

    invoke-virtual {p1, v1}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/mms/data/Contact;

    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object p1

    const-string v0, "@"

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_7

    .line 2212
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p1

    invoke-virtual {p1, v1}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/mms/data/Contact;

    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xa

    invoke-static {p0, p1, v0}, Lcom/android/mms/ui/MessageUtils;->createNewContact(Landroid/content/Context;Ljava/lang/String;I)V

    goto :goto_1

    .line 2214
    :cond_7
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p1

    invoke-virtual {p1, v1}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/mms/data/Contact;

    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xb

    invoke-static {p0, p1, v0}, Lcom/android/mms/ui/MessageUtils;->createNewContact(Landroid/content/Context;Ljava/lang/String;I)V

    goto :goto_1

    :cond_8
    const/16 v0, 0x3eb

    if-ne p1, v0, :cond_9

    .line 2217
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p1}, Lcom/android/mms/data/Conversation;->getRecipients()Lcom/android/mms/data/ContactList;

    move-result-object p1

    invoke-virtual {p1, v1}, Lcom/android/mms/data/ContactList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/mms/data/Contact;

    invoke-virtual {p1}, Lcom/android/mms/data/Contact;->getNumber()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/android/mms/ui/ConversationList;->createAddContactIntent(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ConversationList;->startActivity(Landroid/content/Intent;)V

    :cond_9
    :goto_1
    return-void
.end method

.method public onOptionMenuDismiss()V
    .locals 0

    # tzib inbox options: dismiss
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->dismissed(Landroid/app/Activity;)V

    return-void
.end method

.method public onOptionMenuShow()V
    .locals 0

    # tzib inbox options: snapshot
    invoke-static {p0}, Lcom/android/mms/tzib/TzibThreadOptions;->opened(Landroid/app/Activity;)V

    return-void
.end method

# implemented-by: Lcom/android/mms/ui/NotificationConversationList;
.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 3

    # tzib unified: optionsMenu
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibHook;->optionsMenu(Landroid/app/Activity;Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :tzib_continue_optionsMenu

    return v0

    :tzib_continue_optionsMenu


    .line 911
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    const/4 v0, -0x1

    const/4 v1, 0x1

    sparse-switch p1, :sswitch_data_0

    return v1

    .line 913
    :sswitch_0    # 0x7f080163
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/android/mms/ui/SearchConversationActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 914
    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ConversationList;->startActivity(Landroid/content/Intent;)V

    return v1

    .line 921
    :sswitch_1    # 0x7f080023
    new-instance p1, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/MessagingPreferenceActivity;

    invoke-direct {p1, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 922
    invoke-virtual {p0, p1, v0}, Lcom/android/mms/ui/ConversationList;->startActivityIfNeeded(Landroid/content/Intent;I)Z

    goto :goto_0

    .line 934
    :sswitch_2    # 0x7f08001c
    invoke-static {p0}, Lcom/android/mms/ui/MessageUtils;->showMemoryStatusDialog(Landroid/content/Context;)V

    goto :goto_0

    :sswitch_3    # 0x7f080017
    const-wide/16 v0, -0x1

    .line 918
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    invoke-static {v0, v1, p0}, Lcom/android/mms/ui/ConversationList;->confirmDeleteThread(JLandroid/content/AsyncQueryHandler;)V

    goto :goto_0

    .line 931
    :sswitch_4    # 0x7f080016
    invoke-static {p0}, Lcom/android/mms/LogTag;->dumpInternalTables(Landroid/content/Context;)V

    goto :goto_0

    .line 925
    :sswitch_5    # 0x7f080012
    new-instance p1, Landroid/content/Intent;

    const-class v2, Lcom/android/mms/ui/MailBoxMessageList;

    invoke-direct {p1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 926
    invoke-virtual {p0, p1, v0}, Lcom/android/mms/ui/ConversationList;->startActivityIfNeeded(Landroid/content/Intent;I)Z

    .line 927
    invoke-static {v1}, Lcom/android/mms/ui/MessageUtils;->setMailboxMode(Z)V

    .line 928
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->finish()V

    :goto_0
    const/4 p0, 0x0

    return p0

    :sswitch_data_0
    .sparse-switch
        0x7f080012 -> :sswitch_5    # @id/action_change_to_folder_mode @id/action_change_to_folder_mode
        0x7f080016 -> :sswitch_4    # @id/action_debug_dump @id/action_debug_dump
        0x7f080017 -> :sswitch_3    # @id/action_delete_all @id/action_delete_all
        0x7f08001c -> :sswitch_2    # @id/action_memory_status @id/action_memory_status
        0x7f080023 -> :sswitch_1    # @id/action_settings @id/action_settings
        0x7f080163 -> :sswitch_0    # @id/search @id/search

    .end sparse-switch
.end method

.method public onPause()V
    .locals 2

    # tzib unified: pause
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->pause(Landroid/app/Activity;)V


    .line 387
    invoke-super {p0}, Landroid/app/ListActivity;->onPause()V

    .line 390
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    .line 391
    invoke-virtual {v0, v1}, Lcom/android/mms/ui/ConversationListAdapter;->setOnContentChangedListener(Lcom/android/mms/ui/ConversationListAdapter$OnContentChangedListener;)V

    .line 397
    :cond_0
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 399
    invoke-virtual {v0}, Landroid/widget/ListView;->getFirstVisiblePosition()I

    move-result v1

    iput v1, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    const/4 v1, 0x0

    .line 400
    invoke-virtual {v0, v1}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 401
    :cond_1
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v1

    :goto_0
    iput v1, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstItemOffset:I

    .line 404
    :cond_2
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    if-eqz p0, :cond_3

    .line 405
    invoke-virtual {p0}, Landroid/widget/MenuBar;->dismissOptionMenu()V

    :cond_3
    return-void
.end method

# implemented-by: Lcom/android/mms/ui/NotificationConversationList;
.method public onPrepareOptionsMenu(Landroid/view/Menu;)Z
    .locals 3

    # tzib inbox options: framework
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibThreadOptions;->prepare(Landroid/app/Activity;Landroid/view/Menu;)V

    .line 871
    invoke-static {}, Lcom/android/mms/ui/MessageUtils;->isMailboxMode()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    const v0, 0x7f080017    # @id/action_delete_all

    .line 874
    invoke-interface {p1, v0}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    .line 876
    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 879
    :cond_1
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const v0, 0x7f04000a    # @bool/config_mailbox_enable 'false'

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p0

    if-nez p0, :cond_3

    const p0, 0x7f080012    # @id/action_change_to_folder_mode

    .line 880
    invoke-interface {p1, p0}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p0

    if-eqz p0, :cond_2

    .line 882
    invoke-interface {p0, v2}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    :cond_2
    const p0, 0x7f08001c    # @id/action_memory_status

    .line 884
    invoke-interface {p1, p0}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p0

    if-eqz p0, :cond_3

    .line 886
    invoke-interface {p0, v2}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    :cond_3
    const p0, 0x7f080016    # @id/action_debug_dump

    .line 891
    invoke-interface {p1, p0}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p0

    if-eqz p0, :cond_4

    .line 893
    invoke-interface {p0, v2}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    :cond_4
    return v1
.end method

.method protected onResume()V
    .locals 2

    .line 506
    invoke-super {p0}, Landroid/app/ListActivity;->onResume()V

    # tzib: add or remove the pinned row to match Settings.Global "not_tag"
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibHook;->refresh(Landroid/app/Activity;Landroid/widget/ListView;)V

    .line 508
    invoke-static {p0}, Lcom/android/mms/MmsConfig;->isSmsEnabled(Landroid/content/Context;)Z

    move-result v0

    .line 509
    iget-boolean v1, p0, Lcom/android/mms/ui/ConversationList;->mIsSmsEnabled:Z

    if-eq v0, v1, :cond_0

    .line 510
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mIsSmsEnabled:Z

    .line 511
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->invalidateOptionsMenu()V

    .line 513
    :cond_0
    invoke-static {p0}, Lcom/android/mms/util/UiUtil;->isDishSimpleMode(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 514
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    const v1, 0x7f07014f    # @drawable/option_menu_item_selector_dish 'res/drawable/option_menu_item_selector_dish.xml'

    invoke-virtual {v0, v1}, Landroid/widget/MenuBar;->setOptionMenuItemBackground(I)V

    goto :goto_0

    .line 516
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;

    const v1, 0x7f07014e    # @drawable/option_menu_item_selector 'res/drawable/option_menu_item_selector.xml'

    invoke-virtual {v0, v1}, Landroid/widget/MenuBar;->setOptionMenuItemBackground(I)V

    :goto_0
    const/4 v0, 0x1

    .line 518
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mIsSmsEnabled:Z

    if-nez v0, :cond_3

    .line 530
    invoke-static {p0}, Lcom/android/mms/MmsConfig;->isSmsPromoDismissed(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_2

    goto :goto_1

    .line 533
    :cond_2
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->initSmsPromoBanner()V

    .line 534
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mSmsPromoBannerView:Landroid/view/View;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    goto :goto_2

    .line 531
    :cond_3
    :goto_1
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mSmsPromoBannerView:Landroid/view/View;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 536
    :goto_2
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mContentChangedListener:Lcom/android/mms/ui/ConversationListAdapter$OnContentChangedListener;

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/ConversationListAdapter;->setOnContentChangedListener(Lcom/android/mms/ui/ConversationListAdapter$OnContentChangedListener;)V

    .line 537
    iget-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mDoOnceAfterFirstQuery:Z

    if-nez v0, :cond_4

    .line 538
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->startAsyncQuery()V

    .line 540
    :cond_4
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateMenuBar()V

    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 379
    invoke-super {p0, p1}, Landroid/app/ListActivity;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 381
    iget v0, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstVisiblePosition:I

    const-string v1, "last_list_pos"

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 382
    iget p0, p0, Lcom/android/mms/ui/ConversationList;->mSavedFirstItemOffset:I

    const-string v0, "last_list_offset"

    invoke-virtual {p1, v0, p0}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    return-void
.end method

.method public onSearchRequested()Z
    .locals 1

    .line 902
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const v0, 0x7f040006    # @bool/config_classify_search 'false'

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    const/4 p0, 0x1

    return p0
.end method

.method protected onStart()V
    .locals 2

    .line 693
    invoke-super {p0}, Landroid/app/ListActivity;->onStart()V

    .line 695
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/16 v1, 0xef

    invoke-static {v0, v1}, Lcom/android/mms/transaction/MessagingNotification;->cancelNotification(Landroid/content/Context;I)V

    .line 698
    invoke-static {}, Lcom/android/mms/util/DraftCache;->getInstance()Lcom/android/mms/util/DraftCache;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/android/mms/util/DraftCache;->addOnDraftChangedListener(Lcom/android/mms/util/DraftCache$OnDraftChangedListener;)V

    const/4 v0, 0x1

    .line 700
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mDoOnceAfterFirstQuery:Z

    .line 702
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->startAsyncQuery()V

    .line 717
    invoke-static {}, Lcom/android/mms/data/Conversation;->loadingThreads()Z

    move-result p0

    if-nez p0, :cond_0

    .line 718
    invoke-static {}, Lcom/android/mms/data/Contact;->invalidateCache()V

    :cond_0
    return-void
.end method

.method protected onStop()V
    .locals 1

    .line 724
    invoke-super {p0}, Landroid/app/ListActivity;->onStop()V

    .line 726
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->stopAsyncQuery()V

    .line 728
    invoke-static {}, Lcom/android/mms/util/DraftCache;->getInstance()Lcom/android/mms/util/DraftCache;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/android/mms/util/DraftCache;->removeOnDraftChangedListener(Lcom/android/mms/util/DraftCache$OnDraftChangedListener;)V

    const/4 v0, 0x0

    .line 730
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ConversationList;->unbindListeners(Ljava/util/Collection;)V

    return-void
.end method

# implemented-by: Lcom/android/mms/ui/NotificationConversationList;
.method public openThread(J)V
    .locals 0

    .line 1036
    invoke-static {p0, p1, p2}, Lcom/android/mms/ui/ComposeMessageActivity;->createIntent(Landroid/content/Context;J)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/android/mms/ui/ConversationList;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public declared-synchronized runOneTimeStorageLimitCheckForLegacyMessages()V
    .locals 3

    monitor-enter p0

    .line 628
    :try_start_0
    invoke-static {p0}, Lcom/android/mms/util/Recycler;->isAutoDeleteEnabled(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 632
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->markCheckedMessageLimit()V

    .line 633
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    .line 635
    :cond_0
    :try_start_1
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/android/mms/ui/ConversationList$8;

    invoke-direct {v1, p0}, Lcom/android/mms/ui/ConversationList$8;-><init>(Lcom/android/mms/ui/ConversationList;)V

    const-string v2, "ConversationList.runOneTimeStorageLimitCheckForLegacyMessages"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 671
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 672
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

# implemented-by: Lcom/android/mms/ui/NotificationConversationList;
.method public startAsyncQuery()V
    .locals 12

    .line 785
    :try_start_0
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    if-nez v0, :cond_0

    const-string v0, "Mms"

    const-string v1, "startAsyncQuery null adapter"

    .line 786
    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 787
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->finish()V

    return-void

    .line 793
    :cond_0
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    if-nez v0, :cond_1

    .line 794
    new-instance v0, Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;-><init>(Lcom/android/mms/ui/ConversationList;Landroid/content/ContentResolver;)V

    iput-object v0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    .line 805
    :cond_1
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    const/16 v1, 0x6a5

    const-string v2, "_id IN (SELECT DISTINCT thread_id FROM sms where thread_id NOT NULL UNION SELECT DISTINCT thread_id FROM pdu where thread_id NOT NULL)"

    invoke-static {v0, v1, v2}, Lcom/android/mms/data/Conversation;->startQuery(Landroid/content/AsyncQueryHandler;ILjava/lang/String;)V

    const/4 v0, 0x0

    .line 806
    invoke-direct {p0, v0}, Lcom/android/mms/ui/ConversationList;->toggleNotificationGroup(Z)V

    .line 808
    iget-object v1, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    const/16 v2, 0x6a6

    const-string v3, "read=0 and _id IN (SELECT DISTINCT thread_id FROM sms where thread_id NOT NULL UNION SELECT DISTINCT thread_id FROM pdu where thread_id NOT NULL)"

    invoke-static {v1, v2, v3}, Lcom/android/mms/data/Conversation;->startQuery(Landroid/content/AsyncQueryHandler;ILjava/lang/String;)V

    .line 811
    iget-object v4, p0, Lcom/android/mms/ui/ConversationList;->mQueryHandler:Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;

    const/16 v5, 0x6a9

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    sget-object v7, Landroid/provider/Telephony$Mms$Inbox;->CONTENT_URI:Landroid/net/Uri;

    const-string v0, "_id"

    const-string v1, "read"

    const-string v2, "date"

    const-string v3, "m_type"

    filled-new-array {v0, v1, v2, v3}, [Ljava/lang/String;

    move-result-object v8

    const-string v9, "m_type = ?"

    const-string v0, "130"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v10

    const-string v11, "date DESC"

    invoke-virtual/range {v4 .. v11}, Lcom/android/mms/ui/ConversationList$ThreadListQueryHandler;->startQuery(ILjava/lang/Object;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 817
    invoke-static {p0, v0}, Landroid/database/sqlite/SqliteWrapper;->checkSQLiteException(Landroid/content/Context;Landroid/database/sqlite/SQLiteException;)V

    :goto_0
    return-void
.end method

.method public unCheckAll()V
    .locals 2

    const/4 v0, 0x0

    .line 1870
    iput-boolean v0, p0, Lcom/android/mms/ui/ConversationList;->mHasSelectAll:Z

    .line 1871
    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationList;->getListAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    invoke-interface {v0}, Landroid/widget/ListAdapter;->getCount()I

    .line 1876
    sget-object v0, Lcom/android/mms/ui/ConversationList;->mSelectedThreadIds:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    .line 1877
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateMenuBar()V

    .line 1878
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/mms/ui/ConversationListAdapter;->UpdateSelectedThreadIds(Ljava/util/HashSet;)V

    .line 1879
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;

    invoke-virtual {p0}, Lcom/android/mms/ui/ConversationListAdapter;->notifyDataSetChanged()V

    return-void
.end method

# tzib unified: async Tzibbur changes also drive the stock empty state and softkeys
.method public tzibInboxChanged()V
    .locals 2
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mEmptyView:Landroid/widget/LinearLayout;
    if-eqz v0, :tzib_state_done
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mMenuBar:Landroid/widget/MenuBar;
    if-eqz v0, :tzib_state_done
    iget-object v0, p0, Lcom/android/mms/ui/ConversationList;->mListAdapter:Lcom/android/mms/ui/ConversationListAdapter;
    if-eqz v0, :tzib_state_done
    invoke-virtual {v0}, Lcom/android/mms/ui/ConversationListAdapter;->getCount()I
    move-result v0
    const/4 v1, 0x0
    if-eqz v0, :tzib_state_count
    const/4 v1, 0x1
    :tzib_state_count
    iput-boolean v1, p0, Lcom/android/mms/ui/ConversationList;->mHasNormalThreads:Z
    invoke-direct {p0}, Lcom/android/mms/ui/ConversationList;->updateEmptyView()V
    :tzib_state_done
    return-void
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I
    move-result v0
    if-nez v0, :tzib_dispatch
    invoke-static {p0}, Lcom/android/mms/tzib/TzibHook;->interacted(Landroid/app/Activity;)V
    :tzib_dispatch
    invoke-super {p0, p1}, Landroid/app/ListActivity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    move-result v0
    return v0
.end method
