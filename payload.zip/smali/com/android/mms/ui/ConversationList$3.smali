.class Lcom/android/mms/ui/ConversationList$3;
.super Ljava/lang/Object;
.source "ConversationList.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/mms/ui/ConversationList;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/mms/ui/ConversationList;


# direct methods
.method constructor <init>(Lcom/android/mms/ui/ConversationList;)V
    .locals 0

    .line 307
    iput-object p1, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    # tzib unified: selected
    iget-object p4, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;
    invoke-static {p4, p3}, Lcom/android/mms/tzib/TzibHook;->handleSelected(Landroid/app/Activity;I)Z
    move-result p4
    if-eqz p4, :tzib_stock_selected
    return-void
    :tzib_stock_selected

    .line 310
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-virtual {p1}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1, p3}, Landroid/widget/ListView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/database/Cursor;

    .line 312
    iget-object p3, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-virtual {p3}, Lcom/android/mms/ui/ConversationList;->getListView()Landroid/widget/ListView;

    move-result-object p3

    invoke-virtual {p3}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result p3

    # tzib: live header index, our row may be hidden by the kill switch.
    # Scratch in p4: the long "id" param is never read, and p1 holds the cursor
    # which is still needed below.
    invoke-static {}, Lcom/android/mms/tzib/TzibHook;->mmsNotificationPosition()I

    move-result p4

    if-ne p3, p4, :cond_0

    iget-object p3, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-static {p3}, Lcom/android/mms/ui/ConversationList;->access$100(Lcom/android/mms/ui/ConversationList;)Z

    move-result p3

    if-eqz p3, :cond_0

    .line 313
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-static {p0}, Lcom/android/mms/ui/ConversationList;->access$200(Lcom/android/mms/ui/ConversationList;)V

    return-void

    :cond_0
    if-eqz p1, :cond_2

    .line 317
    invoke-interface {p1}, Landroid/database/Cursor;->getPosition()I

    move-result p3

    if-gez p3, :cond_1

    goto :goto_0

    .line 321
    :cond_1
    iget-object p3, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-static {p3, p1}, Lcom/android/mms/data/Conversation;->from(Landroid/content/Context;Landroid/database/Cursor;)Lcom/android/mms/data/Conversation;

    move-result-object p1

    iput-object p1, p3, Lcom/android/mms/ui/ConversationList;->mConversation:Lcom/android/mms/data/Conversation;

    .line 322
    iget-object p1, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;

    iget-object p3, p1, Lcom/android/mms/ui/ConversationList;->mConversation:Lcom/android/mms/data/Conversation;

    invoke-virtual {p3}, Lcom/android/mms/data/Conversation;->getThreadId()J

    move-result-wide p3

    invoke-static {p1, p3, p4}, Lcom/android/mms/ui/ConversationList;->access$302(Lcom/android/mms/ui/ConversationList;J)J

    .line 323
    check-cast p2, Lcom/android/mms/ui/ConversationListItem;

    iget-object p1, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;

    iget-object p1, p1, Lcom/android/mms/ui/ConversationList;->contactUpdateListener:Lcom/android/mms/ui/ConversationListItem$ContactUpdateListener;

    invoke-virtual {p2, p1}, Lcom/android/mms/ui/ConversationListItem;->setContactUpdateListener(Lcom/android/mms/ui/ConversationListItem$ContactUpdateListener;)V

    .line 326
    iget-object p0, p0, Lcom/android/mms/ui/ConversationList$3;->this$0:Lcom/android/mms/ui/ConversationList;

    invoke-static {p0}, Lcom/android/mms/ui/ConversationList;->access$200(Lcom/android/mms/ui/ConversationList;)V

    :cond_2
    :goto_0
    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    return-void
.end method
