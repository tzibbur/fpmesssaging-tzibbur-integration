.class public final Lcom/tzibbur/basic/store/TzbSessionPrefs;
.super Ljava/lang/Object;
.source "TzbSessionPrefs.java"

# interfaces
.implements Lcom/tzibbur/basic/store/TzbSession;


# static fields
.field private static final DEFAULT_MIN_MEMBERS:I = 0x3

.field private static final KEY_BLOCKED:Ljava/lang/String; = "tzb_device_blocked"

.field private static final KEY_CAP_ADD_PHONES_MAX:Ljava/lang/String; = "tzb_cap_add_phones_max"

.field private static final KEY_CAP_CONTACTS_MAX:Ljava/lang/String; = "tzb_cap_contacts_max"

.field private static final KEY_CAP_CONTACT_DISCOVERY:Ljava/lang/String; = "tzb_cap_contact_discovery"

.field private static final KEY_CAP_DISPLAY_NAME_MAX:Ljava/lang/String; = "tzb_cap_display_name_max"

.field private static final KEY_CAP_GROUP_NAME_MAX:Ljava/lang/String; = "tzb_cap_group_name_max"

.field private static final KEY_DEVICE_ID:Ljava/lang/String; = "tzb_device_id"

.field private static final KEY_DISPLAY_NAME:Ljava/lang/String; = "tzb_display_name"

.field private static final KEY_MIN_MEMBERS:Ljava/lang/String; = "tzb_min_members"

.field private static final KEY_PHONE:Ljava/lang/String; = "tzb_phone_e164"

.field private static final KEY_TOKEN:Ljava/lang/String; = "tzb_token"

.field private static final KEY_USER_ID:Ljava/lang/String; = "tzb_user_id"

.field private static final PREFS_NAME:Ljava/lang/String; = "tzb_session"


# instance fields
.field private volatile cachedToken:Ljava/lang/String;

.field private final prefs:Landroid/content/SharedPreferences;

.field private volatile tokenLoaded:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;

    .line 45
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 47
    const-string v1, "tzb_session"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    .line 48
    return-void
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public clear()V
    .locals 4

    .line 227
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbSessionPrefs;->deviceBlocked()Z

    move-result v0

    .line 228
    .local v0, "blocked":Z
    monitor-enter p0

    .line 229
    const/4 v1, 0x0

    :try_start_0
    iput-object v1, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->cachedToken:Ljava/lang/String;

    .line 230
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->tokenLoaded:Z

    .line 231
    monitor-exit p0

    .line 232
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v2, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 233
    .local v2, "e":Landroid/content/SharedPreferences$Editor;
    if-eqz v0, :cond_0

    const-string v3, "tzb_device_blocked"

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 234
    :cond_0
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 235
    return-void

    .line 231
    .end local v2
    :catchall_0
    move-exception v1

    :try_start_1
    monitor-exit p0

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public contactDiscovery()Z
    .locals 3

    .line 214
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_cap_contact_discovery"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    return v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public contactsCheckMaxPhones(I)I
    .locals 2
    .param p1, "fallback"    # I

    .line 198
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_cap_contacts_max"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public deviceBlocked()Z
    .locals 3

    .line 160
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_device_blocked"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    return v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public deviceId()Ljava/lang/String;
    .locals 3

    .line 106
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_device_id"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public displayName()Ljava/lang/String;
    .locals 3

    .line 111
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_display_name"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public displayNameMaxLength(I)I
    .locals 2
    .param p1, "fallback"    # I

    .line 188
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_cap_display_name_max"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public enrolled()Z
    .locals 1

    .line 60
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbSessionPrefs;->token()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public groupAddMaxPhones(I)I
    .locals 2
    .param p1, "fallback"    # I

    .line 209
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_cap_add_phones_max"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public groupNameMaxLength(I)I
    .locals 2
    .param p1, "fallback"    # I

    .line 193
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_cap_group_name_max"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public minMembers()I
    .locals 3

    .line 149
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_min_members"

    const/4 v2, 0x3

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public phoneE164()Ljava/lang/String;
    .locals 3

    .line 116
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_phone_e164"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public saveCapabilities(Lcom/tzibbur/basic/model/TzbCapabilities;)V
    .locals 3
    .param p1, "c"    # Lcom/tzibbur/basic/model/TzbCapabilities;

    .line 171
    if-nez p1, :cond_0

    return-void

    .line 175
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 176
    .local v0, "e":Landroid/content/SharedPreferences$Editor;
    iget v1, p1, Lcom/tzibbur/basic/model/TzbCapabilities;->displayNameMaxLength:I

    if-lez v1, :cond_1

    .line 177
    const-string v1, "tzb_cap_display_name_max"

    iget v2, p1, Lcom/tzibbur/basic/model/TzbCapabilities;->displayNameMaxLength:I

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 179
    :cond_1
    iget v1, p1, Lcom/tzibbur/basic/model/TzbCapabilities;->groupNameMaxLength:I

    if-lez v1, :cond_2

    const-string v1, "tzb_cap_group_name_max"

    iget v2, p1, Lcom/tzibbur/basic/model/TzbCapabilities;->groupNameMaxLength:I

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 180
    :cond_2
    iget v1, p1, Lcom/tzibbur/basic/model/TzbCapabilities;->contactsCheckMaxPhones:I

    if-lez v1, :cond_3

    const-string v1, "tzb_cap_contacts_max"

    iget v2, p1, Lcom/tzibbur/basic/model/TzbCapabilities;->contactsCheckMaxPhones:I

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 181
    :cond_3
    iget v1, p1, Lcom/tzibbur/basic/model/TzbCapabilities;->groupAddMaxPhones:I

    if-lez v1, :cond_4

    const-string v1, "tzb_cap_add_phones_max"

    iget v2, p1, Lcom/tzibbur/basic/model/TzbCapabilities;->groupAddMaxPhones:I

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 182
    :cond_4
    const-string v1, "tzb_cap_contact_discovery"

    iget-boolean v2, p1, Lcom/tzibbur/basic/model/TzbCapabilities;->contactDiscovery:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 183
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 184
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public saveEnrollment(Lcom/tzibbur/basic/model/TzbEnrollment;)V
    .locals 5
    .param p1, "enrollment"    # Lcom/tzibbur/basic/model/TzbEnrollment;

    .line 125
    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->token:Ljava/lang/String;

    invoke-static {v0}, Lcom/tzibbur/basic/store/TzbTokenCipher;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 126
    .local v0, "sealed":Ljava/lang/String;
    monitor-enter p0

    .line 127
    :try_start_0
    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->token:Ljava/lang/String;

    iput-object v1, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->cachedToken:Ljava/lang/String;

    .line 128
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->tokenLoaded:Z

    .line 129
    monitor-exit p0

    .line 131
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v1, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "tzb_token"

    .line 132
    if-eqz v0, :cond_0

    move-object v3, v0

    goto :goto_0

    :cond_0
    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->token:Ljava/lang/String;

    :goto_0
    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "tzb_user_id"

    .line 133
    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->user:Lcom/tzibbur/basic/model/TzbUser;

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->user:Lcom/tzibbur/basic/model/TzbUser;

    iget-object v3, v3, Lcom/tzibbur/basic/model/TzbUser;->id:Ljava/lang/String;

    goto :goto_1

    :cond_1
    move-object v3, v4

    :goto_1
    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "tzb_device_id"

    .line 134
    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->device:Lcom/tzibbur/basic/model/TzbDevice;

    if-eqz v3, :cond_2

    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->device:Lcom/tzibbur/basic/model/TzbDevice;

    iget-object v3, v3, Lcom/tzibbur/basic/model/TzbDevice;->id:Ljava/lang/String;

    goto :goto_2

    :cond_2
    move-object v3, v4

    :goto_2
    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "tzb_display_name"

    .line 136
    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->user:Lcom/tzibbur/basic/model/TzbUser;

    if-eqz v3, :cond_3

    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->user:Lcom/tzibbur/basic/model/TzbUser;

    iget-object v3, v3, Lcom/tzibbur/basic/model/TzbUser;->displayName:Ljava/lang/String;

    goto :goto_3

    :cond_3
    move-object v3, v4

    .line 135
    :goto_3
    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "tzb_phone_e164"

    .line 137
    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->user:Lcom/tzibbur/basic/model/TzbUser;

    if-eqz v3, :cond_4

    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbEnrollment;->user:Lcom/tzibbur/basic/model/TzbUser;

    iget-object v4, v3, Lcom/tzibbur/basic/model/TzbUser;->phoneE164:Ljava/lang/String;

    :cond_4
    invoke-interface {v1, v2, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 138
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 139
    return-void

    .line 129
    :catchall_0
    move-exception v1

    :try_start_1
    monitor-exit p0

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public setContactDiscovery(Z)V
    .locals 2
    .param p1, "available"    # Z

    .line 219
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "tzb_cap_contact_discovery"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 220
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public setContactsCheckMaxPhones(I)V
    .locals 2
    .param p1, "maxPhones"    # I

    .line 203
    if-gtz p1, :cond_0

    return-void

    .line 204
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "tzb_cap_contacts_max"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 205
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public setDeviceBlocked()V
    .locals 3

    .line 166
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "tzb_device_blocked"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 167
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public setDisplayName(Ljava/lang/String;)V
    .locals 2
    .param p1, "displayName"    # Ljava/lang/String;

    .line 144
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "tzb_display_name"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 145
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public setMinMembers(I)V
    .locals 2
    .param p1, "minMembers"    # I

    .line 154
    if-gtz p1, :cond_0

    return-void

    .line 155
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "tzb_min_members"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 156
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public token()Ljava/lang/String;
    .locals 5

    .line 65
    iget-boolean v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->tokenLoaded:Z

    if-eqz v0, :cond_0

    .line 66
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->cachedToken:Ljava/lang/String;

    return-object v0

    .line 68
    :cond_0
    monitor-enter p0

    .line 69
    :try_start_0
    iget-boolean v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->tokenLoaded:Z

    if-eqz v0, :cond_1

    .line 70
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->cachedToken:Ljava/lang/String;

    monitor-exit p0

    return-object v0

    .line 72
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_token"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 74
    .local v0, "stored":Ljava/lang/String;
    invoke-static {v0}, Lcom/tzibbur/basic/store/TzbTokenCipher;->isEncrypted(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 75
    invoke-static {v0}, Lcom/tzibbur/basic/store/TzbTokenCipher;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 76
    .local v1, "token":Ljava/lang/String;
    if-nez v1, :cond_3

    .line 80
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbSessionPrefs;->clear()V

    .line 81
    monitor-exit p0

    return-object v2

    .line 84
    .end local v1
    :cond_2
    move-object v1, v0

    .line 86
    .restart local v1
    if-eqz v1, :cond_3

    .line 87
    invoke-static {v1}, Lcom/tzibbur/basic/store/TzbTokenCipher;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 88
    .local v2, "sealed":Ljava/lang/String;
    if-eqz v2, :cond_3

    .line 89
    iget-object v3, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "tzb_token"

    invoke-interface {v3, v4, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 93
    .end local v2
    :cond_3
    iput-object v1, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->cachedToken:Ljava/lang/String;

    .line 94
    const/4 v2, 0x1

    iput-boolean v2, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->tokenLoaded:Z

    .line 95
    monitor-exit p0

    return-object v1

    .line 96
    .end local v0
    .end local v1
    :catchall_0
    move-exception v0

    monitor-exit p0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbSession;
.method public userId()Ljava/lang/String;
    .locals 3

    .line 101
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbSessionPrefs;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_user_id"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
