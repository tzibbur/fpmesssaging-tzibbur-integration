.class public final Lcom/tzibbur/basic/store/TzbDatabase;
.super Landroid/database/sqlite/SQLiteOpenHelper;
.source "TzbDatabase.java"

# interfaces
.implements Lcom/tzibbur/basic/store/TzbStore;


# static fields
.field private static final CREATE_MUTE_GAPS:Ljava/lang/String; = "CREATE TABLE IF NOT EXISTS tzb_mute_gaps (group_id TEXT NOT NULL,after_seq INTEGER NOT NULL,PRIMARY KEY(group_id, after_seq))"

.field private static final DB_NAME:Ljava/lang/String; = "tzb_client.db"

.field private static final DB_VERSION:I = 0x6

.field private static final GROUP_COLS:[Ljava/lang/String;

.field private static final ISO_MILLIS:Ljava/lang/String; = "yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'"

.field private static final ISO_SECONDS:Ljava/lang/String; = "yyyy-MM-dd\'T\'HH:mm:ss\'Z\'"

.field private static final MESSAGE_COLS:[Ljava/lang/String;

.field private static final NOT_EXPIRED:Ljava/lang/String; = "(expires_at_ms IS NULL OR expires_at_ms > ?)"

.field private static final OUTBOX_COLS:[Ljava/lang/String;

.field private static final T_GROUPS:Ljava/lang/String; = "tzb_groups"

.field private static final T_MESSAGES:Ljava/lang/String; = "tzb_messages"

.field private static final T_MUTE_GAPS:Ljava/lang/String; = "tzb_mute_gaps"

.field private static final T_OUTBOX:Ljava/lang/String; = "tzb_outbox"

.field private static final T_READ:Ljava/lang/String; = "tzb_read_state"


# direct methods
.method static constructor <clinit>()V
    .locals 17

    .line 40
    const-string v15, "member_cap"

    const-string v16, "min_members_to_post"

    const-string v1, "id"

    const-string v2, "name"

    const-string v3, "category"

    const-string v4, "kind"

    const-string v5, "who_can_post"

    const-string v6, "who_can_add_members"

    const-string v7, "created_by"

    const-string v8, "created_at"

    const-string v9, "role"

    const-string v10, "member_count"

    const-string v11, "muted"

    const-string v12, "read_seq"

    const-string v13, "unread_count"

    const-string v14, "message_max_length"

    filled-new-array/range {v1 .. v16}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/tzibbur/basic/store/TzbDatabase;->GROUP_COLS:[Ljava/lang/String;

    .line 47
    const-string v7, "created_at"

    const-string v8, "expires_at"

    const-string v1, "id"

    const-string v2, "group_id"

    const-string v3, "seq"

    const-string v4, "sender_id"

    const-string v5, "body"

    const-string v6, "client_message_id"

    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/tzibbur/basic/store/TzbDatabase;->MESSAGE_COLS:[Ljava/lang/String;

    .line 63
    const-string v5, "state"

    const-string v6, "last_error"

    const-string v1, "client_message_id"

    const-string v2, "group_id"

    const-string v3, "body"

    const-string v4, "created_at_ms"

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/tzibbur/basic/store/TzbDatabase;->OUTBOX_COLS:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;

    .line 68
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v3, "tzb_client.db"

    invoke-direct {p0, v0, v3, v1, v2}, Landroid/database/sqlite/SQLiteOpenHelper;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)V

    .line 69
    # tzib message actions: init
    invoke-static {p1}, Lcom/android/mms/tzib/TzibDeletedMessages;->init(Landroid/content/Context;)V
    return-void
.end method

.method private static groupValues(Lcom/tzibbur/basic/model/TzbGroup;)Landroid/content/ContentValues;
    .locals 3
    .param p0, "g"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 521
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 522
    .local v0, "cv":Landroid/content/ContentValues;
    const-string v1, "id"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 523
    const-string v1, "name"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 524
    const-string v1, "category"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->category:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 525
    const-string v1, "kind"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->kind:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 526
    const-string v1, "who_can_post"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->whoCanPost:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 527
    const-string v1, "who_can_add_members"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->whoCanAddMembers:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 528
    const-string v1, "created_by"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->createdBy:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 529
    const-string v1, "created_at"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->createdAt:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 530
    const-string v1, "role"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->role:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 531
    iget v1, p0, Lcom/tzibbur/basic/model/TzbGroup;->memberCount:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "member_count"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 532
    iget-boolean v1, p0, Lcom/tzibbur/basic/model/TzbGroup;->muted:Z

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "muted"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 533
    iget-wide v1, p0, Lcom/tzibbur/basic/model/TzbGroup;->readSeq:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "read_seq"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 534
    iget v1, p0, Lcom/tzibbur/basic/model/TzbGroup;->unreadCount:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "unread_count"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 535
    iget v1, p0, Lcom/tzibbur/basic/model/TzbGroup;->messageMaxLength:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "message_max_length"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 536
    iget v1, p0, Lcom/tzibbur/basic/model/TzbGroup;->memberCap:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "member_cap"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 537
    iget v1, p0, Lcom/tzibbur/basic/model/TzbGroup;->minMembersToPost:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "min_members_to_post"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 538
    return-object v0
.end method

.method private static messageValues(Lcom/tzibbur/basic/model/TzbMessage;)Landroid/content/ContentValues;
    .locals 3
    .param p0, "m"    # Lcom/tzibbur/basic/model/TzbMessage;

    .line 551
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 552
    .local v0, "cv":Landroid/content/ContentValues;
    const-string v1, "id"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbMessage;->id:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 553
    const-string v1, "group_id"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbMessage;->groupId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 554
    iget-wide v1, p0, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "seq"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 555
    const-string v1, "sender_id"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbMessage;->senderId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 556
    const-string v1, "body"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 557
    const-string v1, "client_message_id"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbMessage;->clientMessageId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 558
    const-string v1, "created_at"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbMessage;->createdAt:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 559
    const-string v1, "expires_at"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbMessage;->expiresAt:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 560
    iget-object v1, p0, Lcom/tzibbur/basic/model/TzbMessage;->expiresAt:Ljava/lang/String;

    invoke-static {v1}, Lcom/tzibbur/basic/store/TzbDatabase;->parseIsoMillis(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "expires_at_ms"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 561
    # tzib message actions: scrub
    invoke-static {p0, v0}, Lcom/android/mms/tzib/TzibDeletedMessages;->scrub(Lcom/tzibbur/basic/model/TzbMessage;Landroid/content/ContentValues;)V
    return-object v0
.end method

.method private static nowArg()Ljava/lang/String;
    .locals 2

    .line 571
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static parseIsoMillis(Ljava/lang/String;)Ljava/lang/Long;
    .locals 9
    .param p0, "iso"    # Ljava/lang/String;

    .line 580
    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    .line 581
    :cond_0
    const-string v1, "yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'"

    const-string v2, "yyyy-MM-dd\'T\'HH:mm:ss\'Z\'"

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    .line 582
    .local v1, "patterns":[Ljava/lang/String;
    array-length v2, v1

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_1

    aget-object v5, v1, v4

    .line 583
    .local v5, "pattern":Ljava/lang/String;
    new-instance v6, Ljava/text/SimpleDateFormat;

    sget-object v7, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v6, v5, v7}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 584
    .local v6, "f":Ljava/text/SimpleDateFormat;
    const-string v7, "UTC"

    invoke-static {v7}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/text/SimpleDateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 585
    invoke-virtual {v6, v3}, Ljava/text/SimpleDateFormat;->setLenient(Z)V

    .line 587
    :try_start_0
    invoke-virtual {v6, p0}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/Date;->getTime()J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    :try_end_0
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 588
    :catch_0
    move-exception v7

    .line 582
    .end local v5
    .end local v6
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 592
    :cond_1
    return-object v0
.end method

.method private queryMessages(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;
    .locals 3
    .param p1, "sql"    # Ljava/lang/String;
    .param p2, "args"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation

    .line 596
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 597
    .local v0, "out":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    invoke-virtual {v1, p1, p2}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 599
    .local v1, "c":Landroid/database/Cursor;
    :goto_0
    :try_start_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 600
    invoke-static {v1}, Lcom/tzibbur/basic/store/TzbDatabase;->readMessage(Landroid/database/Cursor;)Lcom/tzibbur/basic/model/TzbMessage;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 603
    :cond_0
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 604
    nop

    .line 605
    return-object v0

    .line 603
    :catchall_0
    move-exception v2

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 604
    throw v2
.end method

.method private queryOutbox(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;
    .locals 11
    .param p1, "where"    # Ljava/lang/String;
    .param p2, "args"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/store/TzbOutboxItem;",
            ">;"
        }
    .end annotation

    .line 609
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v1, v0

    .line 610
    .local v1, "out":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/store/TzbOutboxItem;>;"
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    sget-object v4, Lcom/tzibbur/basic/store/TzbDatabase;->OUTBOX_COLS:[Ljava/lang/String;

    const/4 v8, 0x0

    const-string v9, "created_at_ms ASC, rowid ASC"

    const-string v3, "tzb_outbox"

    const/4 v7, 0x0

    move-object v5, p1

    move-object v6, p2

    invoke-virtual/range {v2 .. v9}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .line 613
    .local v2, "c":Landroid/database/Cursor;
    :goto_0
    :try_start_0
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 614
    new-instance v3, Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 615
    const/4 v0, 0x0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v0, 0x1

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v0, 0x2

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    .line 616
    const/4 v0, 0x3

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v7

    const/4 v0, 0x4

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v9

    const/4 v0, 0x5

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v10

    invoke-direct/range {v3 .. v10}, Lcom/tzibbur/basic/store/TzbOutboxItem;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JILjava/lang/String;)V

    .line 614
    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 619
    :cond_0
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 620
    nop

    .line 621
    return-object v1

    .line 619
    :catchall_0
    move-exception v0

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 620
    throw v0
.end method

.method private static readGroup(Landroid/database/Cursor;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 21
    .param p0, "c"    # Landroid/database/Cursor;

    .line 542
    move-object/from16 v0, p0

    new-instance v1, Lcom/tzibbur/basic/model/TzbGroup;

    .line 543
    const/4 v2, 0x0

    move v3, v2

    invoke-interface {v0, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    move v5, v3

    invoke-interface {v0, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    invoke-interface {v0, v6}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x3

    invoke-interface {v0, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v7

    .line 544
    const/4 v8, 0x4

    invoke-interface {v0, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x5

    invoke-interface {v0, v9}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x6

    invoke-interface {v0, v10}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v10

    const/4 v11, 0x7

    invoke-interface {v0, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v11

    .line 545
    const/16 v12, 0x8

    invoke-interface {v0, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v12

    const/16 v13, 0x9

    invoke-interface {v0, v13}, Landroid/database/Cursor;->getInt(I)I

    move-result v13

    const/16 v14, 0xa

    invoke-interface {v0, v14}, Landroid/database/Cursor;->getInt(I)I

    move-result v14

    if-eqz v14, :cond_0

    goto :goto_0

    :cond_0
    move v4, v5

    .line 546
    :goto_0
    const/16 v5, 0xb

    invoke-interface {v0, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v14

    const/16 v5, 0xc

    invoke-interface {v0, v5}, Landroid/database/Cursor;->getInt(I)I

    move-result v5

    .line 547
    move-object/from16 v16, v1

    const/16 v1, 0xd

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    move/from16 v17, v1

    const/16 v1, 0xe

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    move/from16 v18, v1

    const/16 v1, 0xf

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    move/from16 v19, v18

    move/from16 v18, v1

    move-object/from16 v1, v16

    move/from16 v16, v17

    move/from16 v17, v19

    move-object/from16 v19, v12

    move v12, v4

    move-object v4, v6

    move-object v6, v8

    move-object v8, v10

    move-object/from16 v10, v19

    move-wide/from16 v19, v14

    move v15, v5

    move-object v5, v7

    move-object v7, v9

    move-object v9, v11

    move v11, v13

    move-wide/from16 v13, v19

    invoke-direct/range {v1 .. v18}, Lcom/tzibbur/basic/model/TzbGroup;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZJIIII)V

    .line 542
    move-object/from16 v16, v1

    return-object v16
.end method

.method private static readMessage(Landroid/database/Cursor;)Lcom/tzibbur/basic/model/TzbMessage;
    .locals 10
    .param p0, "c"    # Landroid/database/Cursor;

    .line 565
    new-instance v0, Lcom/tzibbur/basic/model/TzbMessage;

    .line 566
    const/4 v1, 0x0

    invoke-interface {p0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-interface {p0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x2

    invoke-interface {p0, v3}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v3

    const/4 v5, 0x3

    invoke-interface {p0, v5}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v5

    .line 567
    const/4 v6, 0x4

    invoke-interface {p0, v6}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x5

    invoke-interface {p0, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x6

    invoke-interface {p0, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x7

    invoke-interface {p0, v9}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-direct/range {v0 .. v9}, Lcom/tzibbur/basic/model/TzbMessage;-><init>(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 565
    return-object v0
.end method

.method private static readSeqInternal(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)J
    .locals 3
    .param p0, "db"    # Landroid/database/sqlite/SQLiteDatabase;
    .param p1, "groupId"    # Ljava/lang/String;

    .line 647
    const-string v0, "SELECT read_seq FROM tzb_read_state WHERE group_id=?"

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    .line 651
    .local v0, "c":Landroid/database/Cursor;
    :try_start_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v1

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :cond_0
    const-wide/16 v1, 0x0

    .line 653
    :goto_0
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 651
    return-wide v1

    .line 653
    :catchall_0
    move-exception v1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 654
    throw v1
.end method

.method private static seedReadSeq(Landroid/database/sqlite/SQLiteDatabase;Lcom/tzibbur/basic/model/TzbGroup;)V
    .locals 4
    .param p0, "db"    # Landroid/database/sqlite/SQLiteDatabase;
    .param p1, "g"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 631
    iget-wide v0, p1, Lcom/tzibbur/basic/model/TzbGroup;->readSeq:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-lez v0, :cond_0

    .line 632
    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    iget-wide v1, p1, Lcom/tzibbur/basic/model/TzbGroup;->readSeq:J

    invoke-static {p0, v0, v1, v2}, Lcom/tzibbur/basic/store/TzbDatabase;->setReadSeqInternal(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;J)V

    .line 634
    :cond_0
    return-void
.end method

.method private static setReadSeqInternal(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;J)V
    .locals 6
    .param p0, "db"    # Landroid/database/sqlite/SQLiteDatabase;
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "seq"    # J

    .line 637
    invoke-static {p0, p1}, Lcom/tzibbur/basic/store/TzbDatabase;->readSeqInternal(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)J

    move-result-wide v0

    .line 638
    .local v0, "current":J
    cmp-long v2, p2, v0

    if-lez v2, :cond_0

    .line 639
    new-instance v2, Landroid/content/ContentValues;

    invoke-direct {v2}, Landroid/content/ContentValues;-><init>()V

    .line 640
    .local v2, "cv":Landroid/content/ContentValues;
    const-string v3, "group_id"

    invoke-virtual {v2, v3, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 641
    const-string v3, "read_seq"

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 642
    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v5, "tzb_read_state"

    invoke-virtual {p0, v5, v3, v2, v4}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    .line 644
    .end local v2
    :cond_0
    return-void
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public clearAll()V
    .locals 3

    .line 504
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 505
    .local v0, "db":Landroid/database/sqlite/SQLiteDatabase;
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 507
    :try_start_0
    const-string v1, "tzb_messages"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 508
    const-string v1, "tzb_groups"

    invoke-virtual {v0, v1, v2, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 509
    const-string v1, "tzb_outbox"

    invoke-virtual {v0, v1, v2, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 510
    const-string v1, "tzb_read_state"

    invoke-virtual {v0, v1, v2, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 511
    const-string v1, "tzb_mute_gaps"

    invoke-virtual {v0, v1, v2, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 512
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    .line 514
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 515
    nop

    .line 516
    return-void

    .line 514
    :catchall_0
    move-exception v1

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 515
    throw v1
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public enqueueOutbox(Lcom/tzibbur/basic/store/TzbOutboxItem;)V
    .locals 5
    .param p1, "item"    # Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 461
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 462
    .local v0, "cv":Landroid/content/ContentValues;
    const-string v1, "client_message_id"

    iget-object v2, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 463
    const-string v1, "group_id"

    iget-object v2, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 464
    const-string v1, "body"

    iget-object v2, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->body:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 465
    iget-wide v1, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->createdAtMillis:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "created_at_ms"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 466
    iget v1, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->state:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "state"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 467
    const-string v1, "last_error"

    iget-object v2, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->lastError:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 468
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v4, "tzb_outbox"

    invoke-virtual {v1, v4, v2, v0, v3}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    .line 470
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public group(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 9
    .param p1, "groupId"    # Ljava/lang/String;

    .line 276
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    sget-object v2, Lcom/tzibbur/basic/store/TzbDatabase;->GROUP_COLS:[Ljava/lang/String;

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const-string v8, "1"

    const-string v1, "tzb_groups"

    const-string v3, "id=?"

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v0 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 279
    .local v1, "c":Landroid/database/Cursor;
    :try_start_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {v1}, Lcom/tzibbur/basic/store/TzbDatabase;->readGroup(Landroid/database/Cursor;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 281
    :goto_0
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 279
    return-object v0

    .line 281
    :catchall_0
    move-exception v0

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 282
    throw v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public groupIds()Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 205
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 206
    .local v0, "out":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const-string v2, "SELECT id FROM tzb_groups"

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 209
    .local v1, "c":Landroid/database/Cursor;
    :goto_0
    :try_start_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 210
    const/4 v2, 0x0

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 213
    :cond_0
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 214
    nop

    .line 215
    return-object v0

    .line 213
    :catchall_0
    move-exception v2

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 214
    throw v2
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public groups()Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbGroup;",
            ">;"
        }
    .end annotation

    .line 253
    const-string v0, "SELECT g.id, g.name, g.category, g.kind, g.who_can_post, g.who_can_add_members, g.created_by, g.created_at, g.role, g.member_count, g.muted, g.read_seq, g.unread_count, g.message_max_length, g.member_cap, g.min_members_to_post FROM tzb_groups g LEFT JOIN (SELECT group_id, MAX(rowid) AS act FROM tzb_messages GROUP BY group_id) m ON m.group_id = g.id ORDER BY CASE WHEN g.kind=\'system\' THEN 0 ELSE 1 END ASC, IFNULL(m.act, -1) DESC, g.name ASC"

    .line 262
    .local v0, "sql":Ljava/lang/String;
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 263
    .local v1, "out":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbGroup;>;"
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v0, v3}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .line 265
    .local v2, "c":Landroid/database/Cursor;
    :goto_0
    :try_start_0
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v3

    if-eqz v3, :cond_0

    .line 266
    invoke-static {v2}, Lcom/tzibbur/basic/store/TzbDatabase;->readGroup(Landroid/database/Cursor;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 269
    :cond_0
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 270
    nop

    .line 271
    return-object v1

    .line 269
    :catchall_0
    move-exception v3

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 270
    throw v3
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public hasMessage(Ljava/lang/String;)Z
    .locals 3
    .param p1, "messageId"    # Ljava/lang/String;

    .line 387
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const-string v1, "SELECT 1 FROM tzb_messages WHERE id=? LIMIT 1"

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    .line 391
    .local v0, "c":Landroid/database/Cursor;
    :try_start_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    .line 393
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 391
    return v1

    .line 393
    :catchall_0
    move-exception v1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 394
    throw v1
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public insertMessages(Ljava/util/List;)I
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;)I"
        }
    .end annotation

    .line 289
    .local p1, "messages":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 290
    .local v0, "db":Landroid/database/sqlite/SQLiteDatabase;
    const/4 v1, 0x0

    .line 291
    .local v1, "inserted":I
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 293
    :try_start_0
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/tzibbur/basic/model/TzbMessage;

    .line 296
    .local v3, "m":Lcom/tzibbur/basic/model/TzbMessage;
    const-string v4, "tzb_messages"

    invoke-static {v3}, Lcom/tzibbur/basic/store/TzbDatabase;->messageValues(Lcom/tzibbur/basic/model/TzbMessage;)Landroid/content/ContentValues;

    move-result-object v5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v4, v7, v5, v6}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide v4

    .line 298
    .local v4, "rowId":J
    const-wide/16 v6, -0x1

    cmp-long v6, v4, v6

    if-eqz v6, :cond_0

    .line 299
    add-int/lit8 v1, v1, 0x1

    .line 301
    .end local v3
    .end local v4
    :cond_0
    goto :goto_0

    .line 302
    :cond_1
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    .line 304
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 305
    nop

    .line 306
    return v1

    .line 304
    :catchall_0
    move-exception v2

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 305
    throw v2
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public lastMessage(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMessage;
    .locals 9
    .param p1, "groupId"    # Ljava/lang/String;

    .line 331
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    sget-object v2, Lcom/tzibbur/basic/store/TzbDatabase;->MESSAGE_COLS:[Ljava/lang/String;

    .line 333
    invoke-static {}, Lcom/tzibbur/basic/store/TzbDatabase;->nowArg()Ljava/lang/String;

    move-result-object v1

    filled-new-array {p1, v1}, [Ljava/lang/String;

    move-result-object v4

    .line 331
    const-string v1, "tzb_messages"

    const-string v3, "group_id=? AND (expires_at_ms IS NULL OR expires_at_ms > ?)"

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v7, "seq DESC"

    const-string v8, "1"

    invoke-virtual/range {v0 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 335
    .local v1, "c":Landroid/database/Cursor;
    :try_start_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {v1}, Lcom/tzibbur/basic/store/TzbDatabase;->readMessage(Landroid/database/Cursor;)Lcom/tzibbur/basic/model/TzbMessage;

    move-result-object v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 337
    :goto_0
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 335
    return-object v0

    .line 337
    :catchall_0
    move-exception v0

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 338
    throw v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public latestMessages(Ljava/lang/String;I)Ljava/util/List;
    .locals 3
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "limit"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation

    .line 311
    const-string v0, "SELECT id, group_id, seq, sender_id, body, client_message_id, created_at, expires_at FROM (SELECT * FROM tzb_messages WHERE group_id=? AND (expires_at_ms IS NULL OR expires_at_ms > ?) ORDER BY seq DESC LIMIT ?) ORDER BY seq ASC"

    .line 315
    .local v0, "sql":Ljava/lang/String;
    invoke-static {}, Lcom/tzibbur/basic/store/TzbDatabase;->nowArg()Ljava/lang/String;

    move-result-object v1

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {p1, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lcom/tzibbur/basic/store/TzbDatabase;->queryMessages(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    return-object v1
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public maxSeq(Ljava/lang/String;)J
    .locals 3
    .param p1, "groupId"    # Ljava/lang/String;

    .line 345
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const-string v1, "SELECT IFNULL(MAX(seq), 0) FROM tzb_messages WHERE group_id=?"

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    .line 349
    .local v0, "c":Landroid/database/Cursor;
    :try_start_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v1

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :cond_0
    const-wide/16 v1, 0x0

    .line 351
    :goto_0
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 349
    return-wide v1

    .line 351
    :catchall_0
    move-exception v1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 352
    throw v1
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public messagesBefore(Ljava/lang/String;JI)Ljava/util/List;
    .locals 4
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "beforeSeq"    # J
    .param p4, "limit"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "JI)",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation

    .line 320
    const-string v0, "SELECT id, group_id, seq, sender_id, body, client_message_id, created_at, expires_at FROM (SELECT * FROM tzb_messages WHERE group_id=? AND seq<? AND (expires_at_ms IS NULL OR expires_at_ms > ?) ORDER BY seq DESC LIMIT ?) ORDER BY seq ASC"

    .line 324
    .local v0, "sql":Ljava/lang/String;
    nop

    .line 325
    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lcom/tzibbur/basic/store/TzbDatabase;->nowArg()Ljava/lang/String;

    move-result-object v2

    invoke-static {p4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    filled-new-array {p1, v1, v2, v3}, [Ljava/lang/String;

    move-result-object v1

    .line 324
    invoke-direct {p0, v0, v1}, Lcom/tzibbur/basic/store/TzbDatabase;->queryMessages(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    return-object v1
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public muteGaps(Ljava/lang/String;)Ljava/util/List;
    .locals 4
    .param p1, "groupId"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .line 370
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 371
    .local v0, "out":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Long;>;"
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const-string v2, "SELECT after_seq FROM tzb_mute_gaps WHERE group_id=? ORDER BY after_seq ASC"

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 376
    .local v1, "c":Landroid/database/Cursor;
    :goto_0
    :try_start_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 377
    const/4 v2, 0x0

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 380
    :cond_0
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 381
    nop

    .line 382
    return-object v0

    .line 380
    :catchall_0
    move-exception v2

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 381
    throw v2
.end method

.method public onCreate(Landroid/database/sqlite/SQLiteDatabase;)V
    .locals 1
    .param p1, "db"    # Landroid/database/sqlite/SQLiteDatabase;

    .line 73
    const-string v0, "CREATE TABLE tzb_groups (id TEXT PRIMARY KEY,name TEXT NOT NULL,category TEXT,kind TEXT,who_can_post TEXT,who_can_add_members TEXT,created_by TEXT,created_at TEXT,role TEXT,member_count INTEGER NOT NULL DEFAULT 0,muted INTEGER NOT NULL DEFAULT 0,read_seq INTEGER NOT NULL DEFAULT 0,unread_count INTEGER NOT NULL DEFAULT 0,message_max_length INTEGER NOT NULL DEFAULT 1000,member_cap INTEGER NOT NULL DEFAULT 100,min_members_to_post INTEGER NOT NULL DEFAULT -1)"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 100
    const-string v0, "CREATE TABLE tzb_messages (id TEXT PRIMARY KEY,group_id TEXT NOT NULL,seq INTEGER NOT NULL,sender_id TEXT,body TEXT,client_message_id TEXT,created_at TEXT,expires_at TEXT,expires_at_ms INTEGER,UNIQUE(group_id, seq))"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 112
    const-string v0, "CREATE TABLE tzb_outbox (client_message_id TEXT PRIMARY KEY,group_id TEXT NOT NULL,body TEXT NOT NULL,created_at_ms INTEGER NOT NULL,state INTEGER NOT NULL DEFAULT 0,last_error TEXT)"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 120
    const-string v0, "CREATE TABLE tzb_read_state (group_id TEXT PRIMARY KEY,read_seq INTEGER NOT NULL DEFAULT 0)"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 124
    const-string v0, "CREATE TABLE IF NOT EXISTS tzb_mute_gaps (group_id TEXT NOT NULL,after_seq INTEGER NOT NULL,PRIMARY KEY(group_id, after_seq))"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 125
    return-void
.end method

.method public onUpgrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .locals 1
    .param p1, "db"    # Landroid/database/sqlite/SQLiteDatabase;
    .param p2, "oldVersion"    # I
    .param p3, "newVersion"    # I

    .line 143
    const/4 v0, 0x2

    if-ge p2, v0, :cond_0

    .line 144
    const-string v0, "ALTER TABLE tzb_groups ADD COLUMN read_seq INTEGER NOT NULL DEFAULT 0"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 146
    const-string v0, "ALTER TABLE tzb_groups ADD COLUMN unread_count INTEGER NOT NULL DEFAULT 0"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 149
    :cond_0
    const/4 v0, 0x3

    if-ge p2, v0, :cond_1

    .line 152
    const-string v0, "ALTER TABLE tzb_groups ADD COLUMN message_max_length INTEGER NOT NULL DEFAULT 1000"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 154
    const-string v0, "ALTER TABLE tzb_groups ADD COLUMN member_cap INTEGER NOT NULL DEFAULT 100"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 157
    :cond_1
    const/4 v0, 0x4

    if-ge p2, v0, :cond_2

    .line 160
    const-string v0, "ALTER TABLE tzb_messages ADD COLUMN expires_at TEXT"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 161
    const-string v0, "ALTER TABLE tzb_messages ADD COLUMN expires_at_ms INTEGER"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 163
    :cond_2
    const/4 v0, 0x6

    if-ge p2, v0, :cond_3

    .line 164
    const-string v0, "CREATE TABLE IF NOT EXISTS tzb_mute_gaps (group_id TEXT NOT NULL,after_seq INTEGER NOT NULL,PRIMARY KEY(group_id, after_seq))"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 166
    :cond_3
    const/4 v0, 0x5

    if-ge p2, v0, :cond_4

    .line 169
    const-string v0, "ALTER TABLE tzb_groups ADD COLUMN min_members_to_post INTEGER NOT NULL DEFAULT -1"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 172
    :cond_4
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public outbox(Ljava/lang/String;)Ljava/util/List;
    .locals 2
    .param p1, "groupId"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/store/TzbOutboxItem;",
            ">;"
        }
    .end annotation

    .line 482
    const-string v0, "group_id=?"

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lcom/tzibbur/basic/store/TzbDatabase;->queryOutbox(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public outboxDone(Ljava/lang/String;)V
    .locals 4
    .param p1, "clientMessageId"    # Ljava/lang/String;

    .line 487
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const-string v1, "client_message_id=?"

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v2

    const-string v3, "tzb_outbox"

    invoke-virtual {v0, v3, v1, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 489
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public outboxSetState(Ljava/lang/String;ILjava/lang/String;)V
    .locals 5
    .param p1, "clientMessageId"    # Ljava/lang/String;
    .param p2, "state"    # I
    .param p3, "lastError"    # Ljava/lang/String;

    .line 493
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 494
    .local v0, "cv":Landroid/content/ContentValues;
    const-string v1, "state"

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 495
    const-string v1, "last_error"

    invoke-virtual {v0, v1, p3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 496
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const-string v2, "client_message_id=?"

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v3

    const-string v4, "tzb_outbox"

    invoke-virtual {v1, v4, v0, v2, v3}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    .line 498
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public pendingOutbox()Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/store/TzbOutboxItem;",
            ">;"
        }
    .end annotation

    .line 476
    const-string v0, "state<>2"

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/tzibbur/basic/store/TzbDatabase;->queryOutbox(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public readSeq(Ljava/lang/String;)J
    .locals 2
    .param p1, "groupId"    # Ljava/lang/String;

    .line 413
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    invoke-static {v0, p1}, Lcom/tzibbur/basic/store/TzbDatabase;->readSeqInternal(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)J

    move-result-wide v0

    return-wide v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public recordMuteGap(Ljava/lang/String;J)V
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "afterSeq"    # J

    .line 357
    if-eqz p1, :cond_1

    const-wide/16 v0, 0x0

    cmp-long v0, p2, v0

    if-gtz v0, :cond_0

    goto :goto_0

    .line 360
    :cond_0
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 361
    .local v0, "cv":Landroid/content/ContentValues;
    const-string v1, "group_id"

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 362
    const-string v1, "after_seq"

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 364
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v4, "tzb_mute_gaps"

    invoke-virtual {v1, v4, v2, v0, v3}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    .line 366
    return-void

    .line 358
    .end local v0
    :cond_1
    :goto_0
    return-void
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public removeGroup(Ljava/lang/String;)V
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;

    .line 234
    const-string v0, "group_id=?"

    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 235
    .local v1, "db":Landroid/database/sqlite/SQLiteDatabase;
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 237
    :try_start_0
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v2

    .line 238
    .local v2, "args":[Ljava/lang/String;
    const-string v3, "tzb_groups"

    const-string v4, "id=?"

    invoke-virtual {v1, v3, v4, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 239
    const-string v3, "tzb_messages"

    invoke-virtual {v1, v3, v0, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 240
    const-string v3, "tzb_read_state"

    invoke-virtual {v1, v3, v0, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 241
    const-string v3, "tzb_outbox"

    invoke-virtual {v1, v3, v0, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 242
    const-string v3, "tzb_mute_gaps"

    invoke-virtual {v1, v3, v0, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 243
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    .line 245
    .end local v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 246
    nop

    .line 247
    return-void

    .line 245
    :catchall_0
    move-exception v0

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 246
    throw v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public replaceGroups(Ljava/util/List;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbGroup;",
            ">;)V"
        }
    .end annotation

    .line 178
    .local p1, "groups":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbGroup;>;"
    const-string v0, "tzb_groups"

    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 179
    .local v1, "db":Landroid/database/sqlite/SQLiteDatabase;
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 181
    const/4 v2, 0x0

    :try_start_0
    invoke-virtual {v1, v0, v2, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 182
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/tzibbur/basic/model/TzbGroup;

    .line 183
    .local v4, "g":Lcom/tzibbur/basic/model/TzbGroup;
    invoke-static {v4}, Lcom/tzibbur/basic/store/TzbDatabase;->groupValues(Lcom/tzibbur/basic/model/TzbGroup;)Landroid/content/ContentValues;

    move-result-object v5

    const/4 v6, 0x5

    invoke-virtual {v1, v0, v2, v5, v6}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    .line 185
    invoke-static {v1, v4}, Lcom/tzibbur/basic/store/TzbDatabase;->seedReadSeq(Landroid/database/sqlite/SQLiteDatabase;Lcom/tzibbur/basic/model/TzbGroup;)V

    .line 186
    .end local v4
    goto :goto_0

    .line 189
    :cond_0
    const-string v0, "DELETE FROM tzb_messages WHERE group_id NOT IN (SELECT id FROM tzb_groups)"

    invoke-virtual {v1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 191
    const-string v0, "DELETE FROM tzb_read_state WHERE group_id NOT IN (SELECT id FROM tzb_groups)"

    invoke-virtual {v1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 193
    const-string v0, "DELETE FROM tzb_outbox WHERE group_id NOT IN (SELECT id FROM tzb_groups)"

    invoke-virtual {v1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 195
    const-string v0, "DELETE FROM tzb_mute_gaps WHERE group_id NOT IN (SELECT id FROM tzb_groups)"

    invoke-virtual {v1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 197
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    .line 199
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 200
    nop

    .line 201
    return-void

    .line 199
    :catchall_0
    move-exception v0

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 200
    throw v0
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public setReadSeq(Ljava/lang/String;J)V
    .locals 2
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "seq"    # J

    .line 401
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 402
    .local v0, "db":Landroid/database/sqlite/SQLiteDatabase;
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 404
    :try_start_0
    invoke-static {v0, p1, p2, p3}, Lcom/tzibbur/basic/store/TzbDatabase;->setReadSeqInternal(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;J)V

    .line 405
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    .line 407
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 408
    nop

    .line 409
    return-void

    .line 407
    :catchall_0
    move-exception v1

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 408
    throw v1
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public unreadCount(Ljava/lang/String;)I
    .locals 8
    .param p1, "groupId"    # Ljava/lang/String;

    .line 431
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 440
    invoke-static {}, Lcom/tzibbur/basic/store/TzbDatabase;->nowArg()Ljava/lang/String;

    move-result-object v1

    filled-new-array {v1, p1}, [Ljava/lang/String;

    move-result-object v1

    .line 431
    const-string v2, "SELECT g.read_seq, g.unread_count, IFNULL(r.read_seq, 0), (SELECT COUNT(*) FROM tzb_messages m  WHERE m.group_id=g.id  AND m.seq > MAX(g.read_seq, IFNULL(r.read_seq, 0))  AND (expires_at_ms IS NULL OR expires_at_ms > ?)) FROM tzb_groups g LEFT JOIN tzb_read_state r ON r.group_id=g.id WHERE g.id=?"

    invoke-virtual {v0, v2, v1}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    .line 442
    .local v0, "c":Landroid/database/Cursor;
    :try_start_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    if-nez v1, :cond_0

    .line 443
    nop

    .line 453
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 443
    return v2

    .line 445
    :cond_0
    :try_start_1
    invoke-interface {v0, v2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v1

    .line 446
    .local v1, "serverReadSeq":J
    const/4 v3, 0x1

    invoke-interface {v0, v3}, Landroid/database/Cursor;->getInt(I)I

    move-result v3

    .line 447
    .local v3, "serverUnread":I
    const/4 v4, 0x2

    invoke-interface {v0, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v4

    .line 448
    .local v4, "localReadSeq":J
    const/4 v6, 0x3

    invoke-interface {v0, v6}, Landroid/database/Cursor;->getInt(I)I

    move-result v6

    .line 449
    .local v6, "aboveBothWatermarks":I
    cmp-long v7, v4, v1

    if-lez v7, :cond_1

    .line 450
    move v7, v6

    goto :goto_0

    .line 451
    :cond_1
    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    move-result v7

    .line 453
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0
    :goto_0

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 449
    return v7

    .line 453
    .end local v1
    .end local v3
    .end local v4
    .end local v6
    :catchall_0
    move-exception v1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 454
    throw v1
.end method

# overrides: Lcom/tzibbur/basic/store/TzbStore;
.method public upsertGroup(Lcom/tzibbur/basic/model/TzbGroup;)V
    .locals 5
    .param p1, "group"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 220
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbDatabase;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 221
    .local v0, "db":Landroid/database/sqlite/SQLiteDatabase;
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 223
    :try_start_0
    const-string v1, "tzb_groups"

    invoke-static {p1}, Lcom/tzibbur/basic/store/TzbDatabase;->groupValues(Lcom/tzibbur/basic/model/TzbGroup;)Landroid/content/ContentValues;

    move-result-object v2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v4, v2, v3}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    .line 225
    invoke-static {v0, p1}, Lcom/tzibbur/basic/store/TzbDatabase;->seedReadSeq(Landroid/database/sqlite/SQLiteDatabase;Lcom/tzibbur/basic/model/TzbGroup;)V

    .line 226
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    .line 228
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 229
    nop

    .line 230
    return-void

    .line 228
    :catchall_0
    move-exception v1

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 229
    throw v1
.end method
