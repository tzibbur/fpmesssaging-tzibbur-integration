.class public final Lcom/tzibbur/basic/store/TzbApplyStore;
.super Ljava/lang/Object;
.source "TzbApplyStore.java"


# static fields
.field private static final KEY_APPROVED_PHONE:Ljava/lang/String; = "tzb_apply_approved_phone"

.field private static final KEY_LAST_CHECK_MS:Ljava/lang/String; = "tzb_apply_last_check_ms"

.field private static final KEY_LAST_STATUS:Ljava/lang/String; = "tzb_apply_last_status"

.field private static final KEY_NEXT_ALLOWED_MS:Ljava/lang/String; = "tzb_apply_next_allowed_ms"

.field private static final KEY_PENDING_PHONE:Ljava/lang/String; = "tzb_apply_pending_phone"

.field private static final PREFS_NAME:Ljava/lang/String; = "tzb_apply"


# instance fields
.field private final prefs:Landroid/content/SharedPreferences;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;

    .line 45
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 47
    const-string v1, "tzb_apply"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    .line 48
    return-void
.end method


# virtual methods
.method public approvedFor(Ljava/lang/String;)Z
    .locals 1
    .param p1, "phoneE164"    # Ljava/lang/String;

    .line 62
    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 65
    :cond_0
    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbApplyStore;->approvedPhone()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0

    .line 63
    :cond_1
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method public approvedPhone()Ljava/lang/String;
    .locals 3

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_apply_approved_phone"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public clearApproval(Ljava/lang/String;)V
    .locals 4
    .param p1, "status"    # Ljava/lang/String;

    .line 89
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 90
    const-string v1, "tzb_apply_approved_phone"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 91
    const-string v1, "tzb_apply_last_status"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 92
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-string v3, "tzb_apply_last_check_ms"

    invoke-interface {v0, v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 93
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 94
    return-void
.end method

.method public holdStatusCalls(I)V
    .locals 6
    .param p1, "seconds"    # I

    .line 148
    if-gtz p1, :cond_0

    .line 149
    return-void

    .line 151
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    int-to-long v2, p1

    const-wide/16 v4, 0x3e8

    mul-long/2addr v2, v4

    add-long/2addr v0, v2

    .line 152
    .local v0, "until":J
    iget-object v2, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    const-wide/16 v3, 0x0

    const-string v5, "tzb_apply_next_allowed_ms"

    invoke-interface {v2, v5, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v2

    cmp-long v2, v0, v2

    if-lez v2, :cond_1

    .line 153
    iget-object v2, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2, v5, v0, v1}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 155
    :cond_1
    return-void
.end method

.method public lastCheckMs()J
    .locals 4

    .line 128
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_apply_last_check_ms"

    const-wide/16 v2, 0x0

    invoke-interface {v0, v1, v2, v3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    return-wide v0
.end method

.method public lastStatus()Ljava/lang/String;
    .locals 3

    .line 117
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_apply_last_status"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public nextAllowedMs()J
    .locals 4

    .line 137
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_apply_next_allowed_ms"

    const-wide/16 v2, 0x0

    invoke-interface {v0, v1, v2, v3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    return-wide v0
.end method

.method public pendingPhone()Ljava/lang/String;
    .locals 3

    .line 159
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_apply_pending_phone"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public rekeyApproval(Ljava/lang/String;)V
    .locals 2
    .param p1, "phoneE164"    # Ljava/lang/String;

    .line 110
    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lcom/tzibbur/basic/store/TzbApplyStore;->approvedPhone()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 113
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "tzb_apply_approved_phone"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 114
    return-void

    .line 111
    :cond_1
    :goto_0
    return-void
.end method

.method public secondsUntilAllowed()I
    .locals 6

    .line 142
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "tzb_apply_next_allowed_ms"

    const-wide/16 v2, 0x0

    invoke-interface {v0, v1, v2, v3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sub-long/2addr v0, v4

    .line 143
    .local v0, "left":J
    cmp-long v2, v0, v2

    if-gtz v2, :cond_0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const-wide/16 v2, 0x3e7

    add-long/2addr v2, v0

    const-wide/16 v4, 0x3e8

    div-long/2addr v2, v4

    long-to-int v2, v2

    :goto_0
    return v2
.end method

.method public setApproved(Ljava/lang/String;)V
    .locals 4
    .param p1, "phoneE164"    # Ljava/lang/String;

    .line 72
    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 75
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 76
    const-string v1, "tzb_apply_approved_phone"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 77
    const-string v1, "tzb_apply_last_status"

    const-string v2, "approved"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 78
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-string v3, "tzb_apply_last_check_ms"

    invoke-interface {v0, v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 79
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 80
    return-void

    .line 73
    :cond_1
    :goto_0
    return-void
.end method

.method public setLastStatus(Ljava/lang/String;)V
    .locals 4
    .param p1, "status"    # Ljava/lang/String;

    .line 121
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 122
    const-string v1, "tzb_apply_last_status"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 123
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-string v3, "tzb_apply_last_check_ms"

    invoke-interface {v0, v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 124
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 125
    return-void
.end method

.method public setPendingPhone(Ljava/lang/String;)V
    .locals 2
    .param p1, "phoneE164"    # Ljava/lang/String;

    .line 163
    iget-object v0, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "tzb_apply_pending_phone"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 164
    return-void
.end method

.method public statusCallAllowed()Z
    .locals 6

    .line 133
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-object v2, p0, Lcom/tzibbur/basic/store/TzbApplyStore;->prefs:Landroid/content/SharedPreferences;

    const-string v3, "tzb_apply_next_allowed_ms"

    const-wide/16 v4, 0x0

    invoke-interface {v2, v3, v4, v5}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v2

    cmp-long v0, v0, v2

    if-ltz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method
