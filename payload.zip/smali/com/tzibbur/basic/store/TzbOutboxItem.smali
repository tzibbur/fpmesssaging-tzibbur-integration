.class public final Lcom/tzibbur/basic/store/TzbOutboxItem;
.super Ljava/lang/Object;
.source "TzbOutboxItem.java"


# static fields
.field public static final STATE_FAILED:I = 0x2

.field public static final STATE_PENDING:I = 0x0

.field public static final STATE_SENDING:I = 0x1


# instance fields
.field public final body:Ljava/lang/String;

.field public final clientMessageId:Ljava/lang/String;

.field public final createdAtMillis:J

.field public final groupId:Ljava/lang/String;

.field public final lastError:Ljava/lang/String;

.field public final state:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JILjava/lang/String;)V
    .locals 0
    .param p1, "clientMessageId"    # Ljava/lang/String;
    .param p2, "groupId"    # Ljava/lang/String;
    .param p3, "body"    # Ljava/lang/String;
    .param p4, "createdAtMillis"    # J
    .param p6, "state"    # I
    .param p7, "lastError"    # Ljava/lang/String;

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object p1, p0, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    .line 19
    iput-object p2, p0, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    .line 20
    iput-object p3, p0, Lcom/tzibbur/basic/store/TzbOutboxItem;->body:Ljava/lang/String;

    .line 21
    iput-wide p4, p0, Lcom/tzibbur/basic/store/TzbOutboxItem;->createdAtMillis:J

    .line 22
    iput p6, p0, Lcom/tzibbur/basic/store/TzbOutboxItem;->state:I

    .line 23
    iput-object p7, p0, Lcom/tzibbur/basic/store/TzbOutboxItem;->lastError:Ljava/lang/String;

    .line 24
    return-void
.end method
