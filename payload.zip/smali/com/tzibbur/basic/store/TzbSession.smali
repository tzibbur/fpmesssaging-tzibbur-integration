.class public interface abstract Lcom/tzibbur/basic/store/TzbSession;
.super Ljava/lang/Object;
.source "TzbSession.java"


# virtual methods
# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract clear()V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract contactDiscovery()Z
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract contactsCheckMaxPhones(I)I
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract deviceBlocked()Z
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract deviceId()Ljava/lang/String;
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract displayName()Ljava/lang/String;
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract displayNameMaxLength(I)I
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract enrolled()Z
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract groupAddMaxPhones(I)I
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract groupNameMaxLength(I)I
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract minMembers()I
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract phoneE164()Ljava/lang/String;
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract saveCapabilities(Lcom/tzibbur/basic/model/TzbCapabilities;)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract saveEnrollment(Lcom/tzibbur/basic/model/TzbEnrollment;)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract setContactDiscovery(Z)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract setContactsCheckMaxPhones(I)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract setDeviceBlocked()V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract setDisplayName(Ljava/lang/String;)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract setMinMembers(I)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract token()Ljava/lang/String;
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbSessionPrefs;
.method public abstract userId()Ljava/lang/String;
.end method
