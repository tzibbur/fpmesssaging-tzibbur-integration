.class public interface abstract Lcom/tzibbur/basic/store/TzbStore;
.super Ljava/lang/Object;
.source "TzbStore.java"


# virtual methods
# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract clearAll()V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract enqueueOutbox(Lcom/tzibbur/basic/store/TzbOutboxItem;)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract group(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract groupIds()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract groups()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbGroup;",
            ">;"
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract hasMessage(Ljava/lang/String;)Z
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract insertMessages(Ljava/util/List;)I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;)I"
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract lastMessage(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMessage;
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract latestMessages(Ljava/lang/String;I)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract maxSeq(Ljava/lang/String;)J
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract messagesBefore(Ljava/lang/String;JI)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "JI)",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract muteGaps(Ljava/lang/String;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract outbox(Ljava/lang/String;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/store/TzbOutboxItem;",
            ">;"
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract outboxDone(Ljava/lang/String;)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract outboxSetState(Ljava/lang/String;ILjava/lang/String;)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract pendingOutbox()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/store/TzbOutboxItem;",
            ">;"
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract readSeq(Ljava/lang/String;)J
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract recordMuteGap(Ljava/lang/String;J)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract removeGroup(Ljava/lang/String;)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract replaceGroups(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbGroup;",
            ">;)V"
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract setReadSeq(Ljava/lang/String;J)V
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract unreadCount(Ljava/lang/String;)I
.end method

# implemented-by: Lcom/tzibbur/basic/store/TzbDatabase;
.method public abstract upsertGroup(Lcom/tzibbur/basic/model/TzbGroup;)V
.end method
