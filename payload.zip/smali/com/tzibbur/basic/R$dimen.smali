.class public final Lcom/tzibbur/basic/R$dimen;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static tzb_bubble_max_width_margin:I = 0x7f0600ac    # @dimen/tzb_bubble_max_width_margin '48.0dp'

.field public static tzb_bubble_radius:I = 0x7f0600ad    # @dimen/tzb_bubble_radius '6.0dp'

.field public static tzb_compose_edit_radius:I = 0x7f0600ae    # @dimen/tzb_compose_edit_radius '2.0dp'

.field public static tzb_compose_edit_radius_focus:I = 0x7f0600af    # @dimen/tzb_compose_edit_radius_focus '3.0dp'

.field public static tzb_compose_hairline:I = 0x7f0600b0    # @dimen/tzb_compose_hairline '1.0dp'

.field public static tzb_compose_label_height:I = 0x7f0600b1    # @dimen/tzb_compose_label_height '22.0dp'

.field public static tzb_compose_margin_bottom:I = 0x7f0600b2    # @dimen/tzb_compose_margin_bottom '5.0dp'

.field public static tzb_compose_margin_end:I = 0x7f0600b3    # @dimen/tzb_compose_margin_end '10.0dp'

.field public static tzb_compose_margin_start:I = 0x7f0600b4    # @dimen/tzb_compose_margin_start '11.0dp'

.field public static tzb_compose_min_height:I = 0x7f0600b5    # @dimen/tzb_compose_min_height '28.0dp'

.field public static tzb_list_item_min_height:I = 0x7f0600b6    # @dimen/tzb_list_item_min_height '40.0dp'

.field public static tzb_pad:I = 0x7f0600b7    # @dimen/tzb_pad '8.0dp'

.field public static tzb_pad_double:I = 0x7f0600b8    # @dimen/tzb_pad_double '16.0dp'

.field public static tzb_pad_half:I = 0x7f0600b9    # @dimen/tzb_pad_half '4.0dp'

.field public static tzb_text_body:I = 0x7f0600ba    # @dimen/tzb_text_body '18.0sp'

.field public static tzb_text_label:I = 0x7f0600bb    # @dimen/tzb_text_label '14.0sp'

.field public static tzb_text_small:I = 0x7f0600bc    # @dimen/tzb_text_small '13.0sp'

.field public static tzb_text_title:I = 0x7f0600bd    # @dimen/tzb_text_title '20.0sp'


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
