.class public final Lcom/tzibbur/basic/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static tzb_about_third_party:I = 0x7f0e0307    # @string/tzb_about_third_party 'Group messaging in this app is provided by Tzibbur, an independent third-party service. It is not op ...'

.field public static tzb_about_title:I = 0x7f0e0308    # @string/tzb_about_title 'About Tzibbur'

.field public static tzb_action_add_admins:I = 0x7f0e0309    # @string/tzb_action_add_admins 'Restrict adding members to admins'

.field public static tzb_action_add_everyone:I = 0x7f0e030a    # @string/tzb_action_add_everyone 'Allow everyone to add members'

.field public static tzb_action_delete:I = 0x7f0e030b    # @string/tzb_action_delete 'Delete group'

.field public static tzb_action_leave:I = 0x7f0e030c    # @string/tzb_action_leave 'Leave group'

.field public static tzb_action_post_admins:I = 0x7f0e030d    # @string/tzb_action_post_admins 'Restrict posting to admins'

.field public static tzb_action_post_everyone:I = 0x7f0e030e    # @string/tzb_action_post_everyone 'Allow everyone to post'

.field public static tzb_action_rename:I = 0x7f0e030f    # @string/tzb_action_rename 'Rename group'

.field public static tzb_add:I = 0x7f0e0310    # @string/tzb_add 'Add'

.field public static tzb_add_member_title:I = 0x7f0e0311    # @string/tzb_add_member_title 'Add member'

.field public static tzb_added_member:I = 0x7f0e0312    # @string/tzb_added_member 'Added %s'

.field public static tzb_already_member:I = 0x7f0e0313    # @string/tzb_already_member '%s is already a member'

.field public static tzb_app_name:I = 0x7f0e0314    # @string/tzb_app_name 'Tzibbur'

.field public static tzb_apply_approved_body:I = 0x7f0e0315    # @string/tzb_apply_approved_body 'You're approved. Taking you in…'

.field public static tzb_apply_approved_head:I = 0x7f0e0316    # @string/tzb_apply_approved_head 'Approved'

.field public static tzb_apply_banned_body:I = 0x7f0e0317    # @string/tzb_apply_banned_body 'Tzibbur is not available for this number. Please contact support if you think this is a mistake.'

.field public static tzb_apply_banned_head:I = 0x7f0e0318    # @string/tzb_apply_banned_head 'Access not available'

.field public static tzb_apply_checking_head:I = 0x7f0e0319    # @string/tzb_apply_checking_head 'Checking your access…'

.field public static tzb_apply_denied_body:I = 0x7f0e031a    # @string/tzb_apply_denied_body 'Your last request was not approved. You can send another one.'

.field public static tzb_apply_err_bad_characters:I = 0x7f0e031b    # @string/tzb_apply_err_bad_characters 'Please remove any unusual characters and try again.'

.field public static tzb_apply_err_cannot_apply:I = 0x7f0e031c    # @string/tzb_apply_err_cannot_apply 'You can't send a request right now.'

.field public static tzb_apply_err_check_number:I = 0x7f0e031d    # @string/tzb_apply_err_check_number 'Please check the phone number and try again.'

.field public static tzb_apply_err_offline:I = 0x7f0e031e    # @string/tzb_apply_err_offline 'Couldn't reach the service. Check your connection and try again.'

.field public static tzb_apply_err_rate_limited:I = 0x7f0e031f    # @string/tzb_apply_err_rate_limited 'Too many attempts. Please wait %1$d seconds.'

.field public static tzb_apply_err_too_long:I = 0x7f0e0320    # @string/tzb_apply_err_too_long 'That's too long — please keep it under %1$d characters.'

.field public static tzb_apply_form_body:I = 0x7f0e0321    # @string/tzb_apply_form_body 'Tzibbur now requires approval before it can be used on this phone.\n\nThe more you tell the reviewer a ...'

.field public static tzb_apply_form_head:I = 0x7f0e0322    # @string/tzb_apply_form_head 'Request access to Tzibbur'

.field public static tzb_apply_name_hint:I = 0x7f0e0323    # @string/tzb_apply_name_hint 'Your name'

.field public static tzb_apply_name_label:I = 0x7f0e0324    # @string/tzb_apply_name_label 'Your name'

.field public static tzb_apply_notes_hint:I = 0x7f0e0325    # @string/tzb_apply_notes_hint 'Anything the reviewer should know'

.field public static tzb_apply_notes_label:I = 0x7f0e0326    # @string/tzb_apply_notes_label 'Anything else'

.field public static tzb_apply_org_hint:I = 0x7f0e0327    # @string/tzb_apply_org_hint 'Yeshiva, shul or company'

.field public static tzb_apply_org_label:I = 0x7f0e0328    # @string/tzb_apply_org_label 'Organization'

.field public static tzb_apply_pending_body:I = 0x7f0e0329    # @string/tzb_apply_pending_body 'Your request for %1$s has been sent. This screen updates by itself as soon as it is approved.'

.field public static tzb_apply_pending_head:I = 0x7f0e032a    # @string/tzb_apply_pending_head 'Waiting for approval'

.field public static tzb_apply_phone_hint:I = 0x7f0e032b    # @string/tzb_apply_phone_hint 'e.g. 212 555 0142'

.field public static tzb_apply_phone_label:I = 0x7f0e032c    # @string/tzb_apply_phone_label 'Your phone number'

.field public static tzb_apply_reason_hint:I = 0x7f0e032d    # @string/tzb_apply_reason_hint 'e.g. my shul uses it'

.field public static tzb_apply_reason_label:I = 0x7f0e032e    # @string/tzb_apply_reason_label 'Why you need it'

.field public static tzb_apply_refresh_btn:I = 0x7f0e032f    # @string/tzb_apply_refresh_btn 'Check again'

.field public static tzb_apply_refresh_btn_wait:I = 0x7f0e0330    # @string/tzb_apply_refresh_btn_wait 'Check again (%1$d)'

.field public static tzb_apply_required_note:I = 0x7f0e0331    # @string/tzb_apply_required_note 'Only your phone number is required.'

.field public static tzb_apply_signed_in_hint:I = 0x7f0e0332    # @string/tzb_apply_signed_in_hint 'This phone is signed in as %1$s. Use that number unless you are switching to a different one.'

.field public static tzb_apply_status_checking:I = 0x7f0e0333    # @string/tzb_apply_status_checking 'Checking…'

.field public static tzb_apply_status_sending:I = 0x7f0e0334    # @string/tzb_apply_status_sending 'Sending your request…'

.field public static tzb_apply_status_still_pending:I = 0x7f0e0335    # @string/tzb_apply_status_still_pending 'Still waiting for a decision.'

.field public static tzb_apply_submit_btn:I = 0x7f0e0336    # @string/tzb_apply_submit_btn 'Send request'

.field public static tzb_apply_title:I = 0x7f0e0337    # @string/tzb_apply_title 'Request access'

.field public static tzb_cancel:I = 0x7f0e0338    # @string/tzb_cancel 'Cancel'

.field public static tzb_cat_family:I = 0x7f0e0339    # @string/tzb_cat_family 'Family'

.field public static tzb_cat_neighborhood:I = 0x7f0e033a    # @string/tzb_cat_neighborhood 'Neighborhood'

.field public static tzb_cat_other:I = 0x7f0e033b    # @string/tzb_cat_other 'Other'

.field public static tzb_cat_school:I = 0x7f0e033c    # @string/tzb_cat_school 'School'

.field public static tzb_cat_shul:I = 0x7f0e033d    # @string/tzb_cat_shul 'Shul'

.field public static tzb_category_label:I = 0x7f0e033e    # @string/tzb_category_label 'Category'

.field public static tzb_char_counter:I = 0x7f0e033f    # @string/tzb_char_counter '%1$d/%2$d'

.field public static tzb_check_off:I = 0x7f0e0340    # @string/tzb_check_off '[ ]'

.field public static tzb_check_on:I = 0x7f0e0341    # @string/tzb_check_on '[✓]'

.field public static tzb_close:I = 0x7f0e0342    # @string/tzb_close 'Close'

.field public static tzb_compose_hint:I = 0x7f0e0343    # @string/tzb_compose_hint 'Message'

.field public static tzb_compose_label:I = 0x7f0e0344    # @string/tzb_compose_label 'Message'

.field public static tzb_contact_pick_failed:I = 0x7f0e0345    # @string/tzb_contact_pick_failed 'Couldn't read the contact — type the number instead'

.field public static tzb_contacts_add_selected:I = 0x7f0e0346    # @string/tzb_contacts_add_selected 'Add selected (%d)'

.field public static tzb_contacts_browse:I = 0x7f0e0347    # @string/tzb_contacts_browse 'Browse contacts'

.field public static tzb_contacts_check_rest:I = 0x7f0e0348    # @string/tzb_contacts_check_rest 'Check the rest'

.field public static tzb_contacts_choose:I = 0x7f0e0349    # @string/tzb_contacts_choose 'Choose from contacts'

.field public static tzb_contacts_empty_device:I = 0x7f0e034a    # @string/tzb_contacts_empty_device 'No contacts on this device.'

.field public static tzb_contacts_empty_matches:I = 0x7f0e034b    # @string/tzb_contacts_empty_matches 'None of your contacts use Tzibbur yet.'

.field public static tzb_contacts_found:I = 0x7f0e034c    # @string/tzb_contacts_found '%d contacts on Tzibbur'

.field public static tzb_contacts_open_settings:I = 0x7f0e034d    # @string/tzb_contacts_open_settings 'Open settings'

.field public static tzb_contacts_paused:I = 0x7f0e034e    # @string/tzb_contacts_paused 'Paused — too many checks. %d contacts left.'

.field public static tzb_contacts_permission_denied:I = 0x7f0e034f    # @string/tzb_contacts_permission_denied 'Contacts permission is off, so we can't match your phonebook. You can type a number instead.'

.field public static tzb_contacts_progress:I = 0x7f0e0350    # @string/tzb_contacts_progress 'Checked %1$d of %2$d contacts'

.field public static tzb_contacts_reading:I = 0x7f0e0351    # @string/tzb_contacts_reading 'Reading contacts…'

.field public static tzb_contacts_search_hint:I = 0x7f0e0352    # @string/tzb_contacts_search_hint 'Search name or number'

.field public static tzb_contacts_title:I = 0x7f0e0353    # @string/tzb_contacts_title 'Choose from contacts'

.field public static tzb_contacts_type_instead:I = 0x7f0e0354    # @string/tzb_contacts_type_instead 'Type a number instead'

.field public static tzb_contacts_unavailable:I = 0x7f0e0355    # @string/tzb_contacts_unavailable 'Contact matching isn't available right now.'

.field public static tzb_create:I = 0x7f0e0356    # @string/tzb_create 'Create'

.field public static tzb_create_group_title:I = 0x7f0e0357    # @string/tzb_create_group_title 'New group'

.field public static tzb_delete:I = 0x7f0e0358    # @string/tzb_delete 'Delete'

.field public static tzb_delete_confirm_1:I = 0x7f0e0359    # @string/tzb_delete_confirm_1 'Delete this group for all members?'

.field public static tzb_delete_confirm_2:I = 0x7f0e035a    # @string/tzb_delete_confirm_2 'This cannot be undone. Delete permanently?'

.field public static tzb_device_blocked_body:I = 0x7f0e035b    # @string/tzb_device_blocked_body 'Tzibbur is not available on this handset. Please contact support if you think this is a mistake.'

.field public static tzb_device_blocked_title:I = 0x7f0e035c    # @string/tzb_device_blocked_title 'This device has been blocked'

.field public static tzb_device_never_seen:I = 0x7f0e035d    # @string/tzb_device_never_seen 'Never'

.field public static tzb_devices_empty:I = 0x7f0e035e    # @string/tzb_devices_empty 'No devices'

.field public static tzb_devices_line:I = 0x7f0e035f    # @string/tzb_devices_line '%1$s · %2$s'

.field public static tzb_devices_revoke_msg:I = 0x7f0e0360    # @string/tzb_devices_revoke_msg '%1$s will be signed out and must enroll again to use Tzibbur.'

.field public static tzb_devices_revoke_title:I = 0x7f0e0361    # @string/tzb_devices_revoke_title 'Sign out this device?'

.field public static tzb_devices_revoked:I = 0x7f0e0362    # @string/tzb_devices_revoked 'Device signed out'

.field public static tzb_devices_this_phone:I = 0x7f0e0363    # @string/tzb_devices_this_phone '%1$s (this phone)'

.field public static tzb_devices_use_signout:I = 0x7f0e0364    # @string/tzb_devices_use_signout 'To sign out this phone, use Sign out'

.field public static tzb_enroll_code_hint:I = 0x7f0e0365    # @string/tzb_enroll_code_hint '6-digit code'

.field public static tzb_enroll_code_sent_to:I = 0x7f0e0366    # @string/tzb_enroll_code_sent_to 'Code sent by SMS to %1$s'

.field public static tzb_enroll_code_title:I = 0x7f0e0367    # @string/tzb_enroll_code_title 'Enter the code'

.field public static tzb_enroll_err_check_number:I = 0x7f0e0368    # @string/tzb_enroll_err_check_number 'Please check the phone number and try again.'

.field public static tzb_enroll_err_code_stale:I = 0x7f0e0369    # @string/tzb_enroll_err_code_stale 'Code expired or too many tries. Press Back to request a new code.'

.field public static tzb_enroll_err_enter_code:I = 0x7f0e036a    # @string/tzb_enroll_err_enter_code 'Enter the 6-digit code from the SMS.'

.field public static tzb_enroll_err_name_long:I = 0x7f0e036b    # @string/tzb_enroll_err_name_long 'That name is too long (64 characters max).'

.field public static tzb_enroll_err_name_reserved:I = 0x7f0e036c    # @string/tzb_enroll_err_name_reserved 'That name isn't available — please choose another.'

.field public static tzb_enroll_err_rate_limited:I = 0x7f0e036d    # @string/tzb_enroll_err_rate_limited 'Too many attempts. Please wait %1$d seconds.'

.field public static tzb_enroll_err_sms_failed:I = 0x7f0e036e    # @string/tzb_enroll_err_sms_failed 'Couldn't send the SMS. Please try again.'

.field public static tzb_enroll_err_unavailable:I = 0x7f0e036f    # @string/tzb_enroll_err_unavailable 'Service temporarily unavailable. Please try again later.'

.field public static tzb_enroll_err_wrong_code:I = 0x7f0e0370    # @string/tzb_enroll_err_wrong_code 'Wrong or expired code. Try again.'

.field public static tzb_enroll_name_continue_btn:I = 0x7f0e0371    # @string/tzb_enroll_name_continue_btn 'Continue'

.field public static tzb_enroll_name_counter:I = 0x7f0e0372    # @string/tzb_enroll_name_counter '%1$d/%2$d'

.field public static tzb_enroll_name_empty:I = 0x7f0e0373    # @string/tzb_enroll_name_empty 'Please enter a name.'

.field public static tzb_enroll_name_explain:I = 0x7f0e0374    # @string/tzb_enroll_name_explain 'This is how people in your groups will see your messages. You can change it later in Settings.'

.field public static tzb_enroll_name_input_hint:I = 0x7f0e0375    # @string/tzb_enroll_name_input_hint 'Your name'

.field public static tzb_enroll_name_invalid:I = 0x7f0e0376    # @string/tzb_enroll_name_invalid 'That name isn't allowed — please choose another.'

.field public static tzb_enroll_name_needed:I = 0x7f0e0377    # @string/tzb_enroll_name_needed 'A name is needed to finish signing in. Press Verify to choose one.'

.field public static tzb_enroll_name_title:I = 0x7f0e0378    # @string/tzb_enroll_name_title 'Choose your name'

.field public static tzb_enroll_phone_hint:I = 0x7f0e0379    # @string/tzb_enroll_phone_hint 'e.g. 212 555 0142'

.field public static tzb_enroll_phone_label:I = 0x7f0e037a    # @string/tzb_enroll_phone_label 'Your phone number'

.field public static tzb_enroll_phone_rationale:I = 0x7f0e037b    # @string/tzb_enroll_phone_rationale 'Phone permission is used only to fill in your number automatically.'

.field public static tzb_enroll_phone_title:I = 0x7f0e037c    # @string/tzb_enroll_phone_title 'Sign in to Tzibbur'

.field public static tzb_enroll_resend_btn:I = 0x7f0e037d    # @string/tzb_enroll_resend_btn 'Resend code'

.field public static tzb_enroll_resend_btn_wait:I = 0x7f0e037e    # @string/tzb_enroll_resend_btn_wait 'Resend code (%1$d)'

.field public static tzb_enroll_send_btn:I = 0x7f0e037f    # @string/tzb_enroll_send_btn 'Get code by SMS'

.field public static tzb_enroll_sms_hint:I = 0x7f0e0380    # @string/tzb_enroll_sms_hint 'Waiting for the SMS — the code will be filled in automatically.'

.field public static tzb_enroll_status_code_received:I = 0x7f0e0381    # @string/tzb_enroll_status_code_received 'Code read from SMS.'

.field public static tzb_enroll_status_code_resent:I = 0x7f0e0382    # @string/tzb_enroll_status_code_resent 'A new code was sent.'

.field public static tzb_enroll_status_sending:I = 0x7f0e0383    # @string/tzb_enroll_status_sending 'Sending code…'

.field public static tzb_enroll_status_verifying:I = 0x7f0e0384    # @string/tzb_enroll_status_verifying 'Verifying…'

.field public static tzb_enroll_third_party:I = 0x7f0e0385    # @string/tzb_enroll_third_party 'Group messaging in this app is provided by Tzibbur, an independent third-party service. It is not op ...'

.field public static tzb_enroll_verify_btn:I = 0x7f0e0386    # @string/tzb_enroll_verify_btn 'Verify'

.field public static tzb_err_adding_not_allowed:I = 0x7f0e0387    # @string/tzb_err_adding_not_allowed 'Only admins can add members to this group.'

.field public static tzb_err_admin_required:I = 0x7f0e0388    # @string/tzb_err_admin_required 'Only an admin can do that. Ask an admin of this group.'

.field public static tzb_err_contacts_unavailable:I = 0x7f0e0389    # @string/tzb_err_contacts_unavailable 'Choosing from contacts is not available on this phone.'

.field public static tzb_err_group_full:I = 0x7f0e038a    # @string/tzb_err_group_full 'The group is full'

.field public static tzb_err_group_full_n:I = 0x7f0e038b    # @string/tzb_err_group_full_n 'The group is full (max %1$d members)'

.field public static tzb_err_group_too_small:I = 0x7f0e038c    # @string/tzb_err_group_too_small 'The group needs more members before anyone can post'

.field public static tzb_err_invalid_category:I = 0x7f0e038d    # @string/tzb_err_invalid_category 'Category not accepted — please pick again'

.field public static tzb_err_invalid_display_name:I = 0x7f0e038e    # @string/tzb_err_invalid_display_name 'Name is empty or too long'

.field public static tzb_err_invalid_group_name:I = 0x7f0e038f    # @string/tzb_err_invalid_group_name 'Group name is empty or too long'

.field public static tzb_err_invalid_message:I = 0x7f0e0390    # @string/tzb_err_invalid_message 'Message is empty or too long'

.field public static tzb_err_last_admin:I = 0x7f0e0391    # @string/tzb_err_last_admin 'Make someone else an admin first'

.field public static tzb_err_leave_not_allowed:I = 0x7f0e0392    # @string/tzb_err_leave_not_allowed 'You cannot leave this thread.'

.field public static tzb_err_message_too_long_n:I = 0x7f0e0393    # @string/tzb_err_message_too_long_n 'Message too long — max %1$d characters'

.field public static tzb_err_not_found:I = 0x7f0e0394    # @string/tzb_err_not_found 'Not found — it may have been removed'

.field public static tzb_err_phone_batch_too_large_n:I = 0x7f0e0395    # @string/tzb_err_phone_batch_too_large_n 'Too many numbers at once (max %1$d). Try fewer.'

.field public static tzb_err_posting_not_allowed:I = 0x7f0e0396    # @string/tzb_err_posting_not_allowed 'Only admins can post in this group.'

.field public static tzb_err_rate_limited:I = 0x7f0e0397    # @string/tzb_err_rate_limited 'Too many requests — please wait a moment'

.field public static tzb_err_reason_system_thread:I = 0x7f0e0398    # @string/tzb_err_reason_system_thread 'This thread is managed by Tzibbur.'

.field public static tzb_err_reserved_display_name:I = 0x7f0e0399    # @string/tzb_err_reserved_display_name 'That name isn't available — please pick another name'

.field public static tzb_error_generic:I = 0x7f0e039a    # @string/tzb_error_generic 'Something went wrong. Please try again.'

.field public static tzb_error_network:I = 0x7f0e039b    # @string/tzb_error_network 'No connection. Will retry automatically.'

.field public static tzb_error_not_allowed:I = 0x7f0e039c    # @string/tzb_error_not_allowed 'Not allowed in this group.'

.field public static tzb_group_info_title:I = 0x7f0e039d    # @string/tzb_group_info_title 'Group info'

.field public static tzb_group_list_empty_button:I = 0x7f0e039e    # @string/tzb_group_list_empty_button 'Create your first group'

.field public static tzb_group_list_empty_text:I = 0x7f0e039f    # @string/tzb_group_list_empty_text 'You are not in any groups yet.\nCreate a group and add members by their phone numbers.'

.field public static tzb_group_name_hint:I = 0x7f0e03a0    # @string/tzb_group_name_hint 'Group name'

.field public static tzb_info_category:I = 0x7f0e03a1    # @string/tzb_info_category 'Category'

.field public static tzb_info_members:I = 0x7f0e03a2    # @string/tzb_info_members 'Members'

.field public static tzb_info_muted:I = 0x7f0e03a3    # @string/tzb_info_muted 'Muted'

.field public static tzb_info_name:I = 0x7f0e03a4    # @string/tzb_info_name 'Name'

.field public static tzb_info_who_can_add:I = 0x7f0e03a5    # @string/tzb_info_who_can_add 'Who can add members'

.field public static tzb_info_who_can_post:I = 0x7f0e03a6    # @string/tzb_info_who_can_post 'Who can post'

.field public static tzb_info_your_role:I = 0x7f0e03a7    # @string/tzb_info_your_role 'Your role'

.field public static tzb_leave:I = 0x7f0e03a8    # @string/tzb_leave 'Leave'

.field public static tzb_leave_confirm:I = 0x7f0e03a9    # @string/tzb_leave_confirm 'Leave this group?'

.field public static tzb_legal_load_failed:I = 0x7f0e03aa    # @string/tzb_legal_load_failed 'Couldn't load — try again.'

.field public static tzb_legal_loading:I = 0x7f0e03ab    # @string/tzb_legal_loading 'Loading…'

.field public static tzb_legal_title_privacy:I = 0x7f0e03ac    # @string/tzb_legal_title_privacy 'Privacy Policy'

.field public static tzb_legal_title_terms:I = 0x7f0e03ad    # @string/tzb_legal_title_terms 'Terms of Service'

.field public static tzb_legal_updated_suffix:I = 0x7f0e03ae    # @string/tzb_legal_updated_suffix '(updated)'

.field public static tzb_load_earlier:I = 0x7f0e03af    # @string/tzb_load_earlier 'Load earlier messages'

.field public static tzb_load_more:I = 0x7f0e03b0    # @string/tzb_load_more 'Load more'

.field public static tzb_loading:I = 0x7f0e03b1    # @string/tzb_loading 'Loading…'

.field public static tzb_member_count:I = 0x7f0e03b2    # @string/tzb_member_count '%d members'

.field public static tzb_member_kind_organization:I = 0x7f0e03b3    # @string/tzb_member_kind_organization ' (organization)'

.field public static tzb_member_kind_service:I = 0x7f0e03b4    # @string/tzb_member_kind_service ' (Tzibbur)'

.field public static tzb_members_count_of_cap:I = 0x7f0e03b5    # @string/tzb_members_count_of_cap '%1$d / %2$d members'

.field public static tzb_members_title:I = 0x7f0e03b6    # @string/tzb_members_title 'Members'

.field public static tzb_menu_add_member:I = 0x7f0e03b7    # @string/tzb_menu_add_member 'Add member'

.field public static tzb_menu_cd:I = 0x7f0e03b8    # @string/tzb_menu_cd 'Menu'

.field public static tzb_menu_group_info:I = 0x7f0e03b9    # @string/tzb_menu_group_info 'Group info'

.field public static tzb_menu_make_admin:I = 0x7f0e03ba    # @string/tzb_menu_make_admin 'Make admin'

.field public static tzb_menu_members:I = 0x7f0e03bb    # @string/tzb_menu_members 'Members'

.field public static tzb_menu_mute:I = 0x7f0e03bc    # @string/tzb_menu_mute 'Mute'

.field public static tzb_menu_new_group:I = 0x7f0e03bd    # @string/tzb_menu_new_group 'New group'

.field public static tzb_menu_refresh:I = 0x7f0e03be    # @string/tzb_menu_refresh 'Refresh'

.field public static tzb_menu_remove_admin:I = 0x7f0e03bf    # @string/tzb_menu_remove_admin 'Remove admin'

.field public static tzb_menu_remove_member:I = 0x7f0e03c0    # @string/tzb_menu_remove_member 'Remove from group'

.field public static tzb_menu_settings:I = 0x7f0e03c1    # @string/tzb_menu_settings 'Settings'

.field public static tzb_menu_unmute:I = 0x7f0e03c2    # @string/tzb_menu_unmute 'Unmute'

.field public static tzb_msg_copied:I = 0x7f0e03c3    # @string/tzb_msg_copied 'Message copied'

.field public static tzb_msg_copy:I = 0x7f0e03c4    # @string/tzb_msg_copy 'Copy'

.field public static tzb_muted_divider:I = 0x7f0e03c5    # @string/tzb_muted_divider 'Messages while muted are not shown'

.field public static tzb_muted_indicator:I = 0x7f0e03c6    # @string/tzb_muted_indicator '🔇'

.field public static tzb_no_longer_member:I = 0x7f0e03c7    # @string/tzb_no_longer_member 'You are no longer a member of this group'

.field public static tzb_no_messages_yet:I = 0x7f0e03c8    # @string/tzb_no_messages_yet 'No messages yet'

.field public static tzb_not_available_on_device:I = 0x7f0e03c9    # @string/tzb_not_available_on_device 'Not available on this device'

.field public static tzb_not_on_tzibbur:I = 0x7f0e03ca    # @string/tzb_not_on_tzibbur '%s isn't on Tzibbur yet'

.field public static tzb_notice_admins_only:I = 0x7f0e03cb    # @string/tzb_notice_admins_only 'Only admins can post here'

.field public static tzb_notice_system_thread:I = 0x7f0e03cc    # @string/tzb_notice_system_thread 'Announcements from Tzibbur'

.field public static tzb_ok:I = 0x7f0e03cd    # @string/tzb_ok 'OK'

.field public static tzb_phone_hint:I = 0x7f0e03ce    # @string/tzb_phone_hint 'Phone number'

.field public static tzb_pick_category:I = 0x7f0e03cf    # @string/tzb_pick_category 'Pick a category'

.field public static tzb_remove:I = 0x7f0e03d0    # @string/tzb_remove 'Remove'

.field public static tzb_remove_member_confirm:I = 0x7f0e03d1    # @string/tzb_remove_member_confirm 'Remove %s from the group?'

.field public static tzb_resend:I = 0x7f0e03d2    # @string/tzb_resend 'Resend'

.field public static tzb_resend_confirm:I = 0x7f0e03d3    # @string/tzb_resend_confirm 'Send this message again?'

.field public static tzb_resend_title:I = 0x7f0e03d4    # @string/tzb_resend_title 'Message failed'

.field public static tzb_retry:I = 0x7f0e03d5    # @string/tzb_retry 'Retry'

.field public static tzb_role_admin:I = 0x7f0e03d6    # @string/tzb_role_admin 'Admin'

.field public static tzb_role_member:I = 0x7f0e03d7    # @string/tzb_role_member 'Member'

.field public static tzb_send:I = 0x7f0e03d8    # @string/tzb_send 'Send'

.field public static tzb_send_failed_retry:I = 0x7f0e03d9    # @string/tzb_send_failed_retry 'Failed — press to retry'

.field public static tzb_sending:I = 0x7f0e03da    # @string/tzb_sending 'Sending…'

.field public static tzb_settings_about:I = 0x7f0e03db    # @string/tzb_settings_about 'About Tzibbur'

.field public static tzb_settings_connection:I = 0x7f0e03dc    # @string/tzb_settings_connection 'Connection'

.field public static tzb_settings_devices:I = 0x7f0e03dd    # @string/tzb_settings_devices 'My devices'

.field public static tzb_settings_name:I = 0x7f0e03de    # @string/tzb_settings_name 'Your name'

.field public static tzb_settings_notification:I = 0x7f0e03df    # @string/tzb_settings_notification 'Background notification'

.field public static tzb_settings_notification_desc:I = 0x7f0e03e0    # @string/tzb_settings_notification_desc 'Keeps messages arriving. Open to hide its notification.'

.field public static tzb_settings_notification_hidden:I = 0x7f0e03e1    # @string/tzb_settings_notification_hidden 'Hidden'

.field public static tzb_settings_notification_shown:I = 0x7f0e03e2    # @string/tzb_settings_notification_shown 'Shown'

.field public static tzb_settings_phone:I = 0x7f0e03e3    # @string/tzb_settings_phone 'Phone number'

.field public static tzb_settings_sign_out:I = 0x7f0e03e4    # @string/tzb_settings_sign_out 'Sign out'

.field public static tzb_settings_title:I = 0x7f0e03e5    # @string/tzb_settings_title 'Settings'

.field public static tzb_settings_version:I = 0x7f0e03e6    # @string/tzb_settings_version 'App version'

.field public static tzb_sign_out_confirm_1:I = 0x7f0e03e7    # @string/tzb_sign_out_confirm_1 'Sign out of Tzibbur on this device?'

.field public static tzb_sign_out_confirm_2:I = 0x7f0e03e8    # @string/tzb_sign_out_confirm_2 'This device will need a new SMS code to sign in again. Continue?'

.field public static tzb_signout_offline_msg:I = 0x7f0e03e9    # @string/tzb_signout_offline_msg 'Sign out from this phone anyway? Its session stays active on the server — you can revoke it later fr ...'

.field public static tzb_signout_offline_title:I = 0x7f0e03ea    # @string/tzb_signout_offline_title 'Couldn't reach the server'

.field public static tzb_state_connecting:I = 0x7f0e03eb    # @string/tzb_state_connecting 'Connecting…'

.field public static tzb_state_live:I = 0x7f0e03ec    # @string/tzb_state_live 'Connected'

.field public static tzb_state_offline:I = 0x7f0e03ed    # @string/tzb_state_offline 'Offline'

.field public static tzb_state_polling:I = 0x7f0e03ee    # @string/tzb_state_polling 'Polling'

.field public static tzb_sync_channel_messages:I = 0x7f0e03ef    # @string/tzb_sync_channel_messages 'Messages'

.field public static tzb_sync_channel_service:I = 0x7f0e03f0    # @string/tzb_sync_channel_service 'Background connection'

.field public static tzb_sync_fallback_title:I = 0x7f0e03f1    # @string/tzb_sync_fallback_title 'Tzibbur'

.field public static tzb_sync_service_text:I = 0x7f0e03f2    # @string/tzb_sync_service_text 'Connected to Tzibbur'

.field public static tzb_sync_unread_fmt:I = 0x7f0e03f3    # @string/tzb_sync_unread_fmt '%1$d new messages'

.field public static tzb_system_sender_name:I = 0x7f0e03f4    # @string/tzb_system_sender_name 'Tzibbur System'

.field public static tzb_title_with_state:I = 0x7f0e03f5    # @string/tzb_title_with_state '%1$s — %2$s'

.field public static tzb_unread_divider:I = 0x7f0e03f6    # @string/tzb_unread_divider 'Unread messages'

.field public static tzb_unread_overflow:I = 0x7f0e03f7    # @string/tzb_unread_overflow '999+'

.field public static tzb_value_admins:I = 0x7f0e03f8    # @string/tzb_value_admins 'Admins only'

.field public static tzb_value_everyone:I = 0x7f0e03f9    # @string/tzb_value_everyone 'Everyone'

.field public static tzb_value_no:I = 0x7f0e03fa    # @string/tzb_value_no 'No'

.field public static tzb_value_yes:I = 0x7f0e03fb    # @string/tzb_value_yes 'Yes'

.field public static tzb_you_marker:I = 0x7f0e03fc    # @string/tzb_you_marker '(You)'


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
