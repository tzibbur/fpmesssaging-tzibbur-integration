.class public final Lcom/tzibbur/basic/model/TzbMemberAddResult;
.super Ljava/lang/Object;
.source "TzbMemberAddResult.java"


# instance fields
.field public final added:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;"
        }
    .end annotation
.end field

.field public final alreadyMembers:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final notFound:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 11
    .local p1, "added":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMember;>;"
    .local p2, "alreadyMembers":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .local p3, "notFound":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbMemberAddResult;->added:Ljava/util/List;

    .line 13
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbMemberAddResult;->alreadyMembers:Ljava/util/List;

    .line 14
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbMemberAddResult;->notFound:Ljava/util/List;

    .line 15
    return-void
.end method
