.class public final Lcom/tzibbur/basic/model/TzbGroup;
.super Ljava/lang/Object;
.source "TzbGroup.java"


# instance fields
.field public final category:Ljava/lang/String;

.field public final createdAt:Ljava/lang/String;

.field public final createdBy:Ljava/lang/String;

.field public final id:Ljava/lang/String;

.field public final kind:Ljava/lang/String;

.field public final memberCap:I

.field public final memberCount:I

.field public final messageMaxLength:I

.field public final minMembersToPost:I

.field public final muted:Z

.field public final name:Ljava/lang/String;

.field public final readSeq:J

.field public final role:Ljava/lang/String;

.field public final unreadCount:I

.field public final whoCanAddMembers:Ljava/lang/String;

.field public final whoCanPost:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZJIIII)V
    .locals 16
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "category"    # Ljava/lang/String;
    .param p4, "kind"    # Ljava/lang/String;
    .param p5, "whoCanPost"    # Ljava/lang/String;
    .param p6, "whoCanAddMembers"    # Ljava/lang/String;
    .param p7, "createdBy"    # Ljava/lang/String;
    .param p8, "createdAt"    # Ljava/lang/String;
    .param p9, "role"    # Ljava/lang/String;
    .param p10, "memberCount"    # I
    .param p11, "muted"    # Z
    .param p12, "readSeq"    # J
    .param p14, "unreadCount"    # I
    .param p15, "messageMaxLength"    # I
    .param p16, "memberCap"    # I
    .param p17, "minMembersToPost"    # I

    .line 39
    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 40
    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    .line 41
    move-object/from16 v2, p2

    iput-object v2, v0, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    .line 42
    move-object/from16 v3, p3

    iput-object v3, v0, Lcom/tzibbur/basic/model/TzbGroup;->category:Ljava/lang/String;

    .line 43
    move-object/from16 v4, p4

    iput-object v4, v0, Lcom/tzibbur/basic/model/TzbGroup;->kind:Ljava/lang/String;

    .line 44
    move-object/from16 v5, p5

    iput-object v5, v0, Lcom/tzibbur/basic/model/TzbGroup;->whoCanPost:Ljava/lang/String;

    .line 45
    move-object/from16 v6, p6

    iput-object v6, v0, Lcom/tzibbur/basic/model/TzbGroup;->whoCanAddMembers:Ljava/lang/String;

    .line 46
    move-object/from16 v7, p7

    iput-object v7, v0, Lcom/tzibbur/basic/model/TzbGroup;->createdBy:Ljava/lang/String;

    .line 47
    move-object/from16 v8, p8

    iput-object v8, v0, Lcom/tzibbur/basic/model/TzbGroup;->createdAt:Ljava/lang/String;

    .line 48
    move-object/from16 v9, p9

    iput-object v9, v0, Lcom/tzibbur/basic/model/TzbGroup;->role:Ljava/lang/String;

    .line 49
    move/from16 v10, p10

    iput v10, v0, Lcom/tzibbur/basic/model/TzbGroup;->memberCount:I

    .line 50
    move/from16 v11, p11

    iput-boolean v11, v0, Lcom/tzibbur/basic/model/TzbGroup;->muted:Z

    .line 51
    move-wide/from16 v12, p12

    iput-wide v12, v0, Lcom/tzibbur/basic/model/TzbGroup;->readSeq:J

    .line 52
    move/from16 v14, p14

    iput v14, v0, Lcom/tzibbur/basic/model/TzbGroup;->unreadCount:I

    .line 53
    move/from16 v15, p15

    iput v15, v0, Lcom/tzibbur/basic/model/TzbGroup;->messageMaxLength:I

    .line 54
    move/from16 v1, p16

    iput v1, v0, Lcom/tzibbur/basic/model/TzbGroup;->memberCap:I

    .line 55
    move/from16 v1, p17

    iput v1, v0, Lcom/tzibbur/basic/model/TzbGroup;->minMembersToPost:I

    .line 56
    return-void
.end method


# virtual methods
.method public callerIsAdmin()Z
    .locals 2

    .line 63
    const-string v0, "admin"

    iget-object v1, p0, Lcom/tzibbur/basic/model/TzbGroup;->role:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public callerMayAddMembers()Z
    .locals 3

    .line 73
    invoke-virtual {p0}, Lcom/tzibbur/basic/model/TzbGroup;->isSystem()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    .line 74
    :cond_0
    const-string v0, "everyone"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->whoCanAddMembers:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lcom/tzibbur/basic/model/TzbGroup;->callerIsAdmin()Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    const/4 v1, 0x1

    :cond_2
    return v1
.end method

.method public callerMayPost()Z
    .locals 3

    .line 68
    invoke-virtual {p0}, Lcom/tzibbur/basic/model/TzbGroup;->isSystem()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    .line 69
    :cond_0
    const-string v0, "everyone"

    iget-object v2, p0, Lcom/tzibbur/basic/model/TzbGroup;->whoCanPost:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lcom/tzibbur/basic/model/TzbGroup;->callerIsAdmin()Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    const/4 v1, 0x1

    :cond_2
    return v1
.end method

.method public isSystem()Z
    .locals 2

    .line 59
    const-string v0, "system"

    iget-object v1, p0, Lcom/tzibbur/basic/model/TzbGroup;->kind:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method
