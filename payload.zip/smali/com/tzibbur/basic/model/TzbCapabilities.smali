.class public final Lcom/tzibbur/basic/model/TzbCapabilities;
.super Ljava/lang/Object;
.source "TzbCapabilities.java"


# static fields
.field public static final DEVICE_BLOCKED:Ljava/lang/String; = "blocked"


# instance fields
.field public final contactDiscovery:Z

.field public final contactsCheckMaxPhones:I

.field public final deviceEnabled:Z

.field public final deviceModelMaxLength:I

.field public final deviceReason:Ljava/lang/String;

.field public final displayNameMaxLength:I

.field public final groupAddMaxPhones:I

.field public final groupNameMaxLength:I

.field public final smsOnlyFactors:Z

.field public final unreadCountMax:I


# direct methods
.method public constructor <init>(IIIIIIZZLjava/lang/String;Z)V
    .locals 0
    .param p1, "displayNameMaxLength"    # I
    .param p2, "groupNameMaxLength"    # I
    .param p3, "contactsCheckMaxPhones"    # I
    .param p4, "groupAddMaxPhones"    # I
    .param p5, "unreadCountMax"    # I
    .param p6, "deviceModelMaxLength"    # I
    .param p7, "smsOnlyFactors"    # Z
    .param p8, "contactDiscovery"    # Z
    .param p9, "deviceReason"    # Ljava/lang/String;
    .param p10, "deviceEnabled"    # Z

    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 37
    iput p1, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->displayNameMaxLength:I

    .line 38
    iput p2, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->groupNameMaxLength:I

    .line 39
    iput p3, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->contactsCheckMaxPhones:I

    .line 40
    iput p4, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->groupAddMaxPhones:I

    .line 41
    iput p5, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->unreadCountMax:I

    .line 42
    iput p6, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->deviceModelMaxLength:I

    .line 43
    iput-boolean p7, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->smsOnlyFactors:Z

    .line 44
    iput-boolean p8, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->contactDiscovery:Z

    .line 45
    iput-object p9, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->deviceReason:Ljava/lang/String;

    .line 46
    iput-boolean p10, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->deviceEnabled:Z

    .line 47
    return-void
.end method


# virtual methods
.method public deviceBlocked()Z
    .locals 2

    .line 51
    const-string v0, "blocked"

    iget-object v1, p0, Lcom/tzibbur/basic/model/TzbCapabilities;->deviceReason:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method
