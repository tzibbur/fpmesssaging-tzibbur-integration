.class public final Lcom/tzibbur/basic/model/TzbAuthStart;
.super Ljava/lang/Object;
.source "TzbAuthStart.java"


# instance fields
.field public final challengeId:Ljava/lang/String;

.field public final expiresAt:Ljava/lang/String;

.field public final resendAfterSeconds:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;I)V
    .locals 0
    .param p1, "challengeId"    # Ljava/lang/String;
    .param p2, "expiresAt"    # Ljava/lang/String;
    .param p3, "resendAfterSeconds"    # I

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbAuthStart;->challengeId:Ljava/lang/String;

    .line 10
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbAuthStart;->expiresAt:Ljava/lang/String;

    .line 11
    iput p3, p0, Lcom/tzibbur/basic/model/TzbAuthStart;->resendAfterSeconds:I

    .line 12
    return-void
.end method
