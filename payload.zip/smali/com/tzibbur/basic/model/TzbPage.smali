.class public final Lcom/tzibbur/basic/model/TzbPage;
.super Ljava/lang/Object;
.source "TzbPage.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "TT;>;"
        }
    .end annotation
.end field

.field public final nextCursor:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/lang/String;)V
    .locals 0
    .param p2, "nextCursor"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "TT;>;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 10
    .local p0, "this":Lcom/tzibbur/basic/model/TzbPage;, "Lcom/tzibbur/basic/model/TzbPage<TT;>;"
    .local p1, "items":Ljava/util/List;, "Ljava/util/List<TT;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbPage;->items:Ljava/util/List;

    .line 12
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbPage;->nextCursor:Ljava/lang/String;

    .line 13
    return-void
.end method
