.class public final Lcom/tzibbur/basic/model/TzbEnrollment;
.super Ljava/lang/Object;
.source "TzbEnrollment.java"


# instance fields
.field public final device:Lcom/tzibbur/basic/model/TzbDevice;

.field public final token:Ljava/lang/String;

.field public final user:Lcom/tzibbur/basic/model/TzbUser;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbUser;Lcom/tzibbur/basic/model/TzbDevice;)V
    .locals 0
    .param p1, "token"    # Ljava/lang/String;
    .param p2, "user"    # Lcom/tzibbur/basic/model/TzbUser;
    .param p3, "device"    # Lcom/tzibbur/basic/model/TzbDevice;

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbEnrollment;->token:Ljava/lang/String;

    .line 11
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbEnrollment;->user:Lcom/tzibbur/basic/model/TzbUser;

    .line 12
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbEnrollment;->device:Lcom/tzibbur/basic/model/TzbDevice;

    .line 13
    return-void
.end method
