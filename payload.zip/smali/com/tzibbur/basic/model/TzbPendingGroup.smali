.class public final Lcom/tzibbur/basic/model/TzbPendingGroup;
.super Ljava/lang/Object;
.source "TzbPendingGroup.java"


# instance fields
.field public final deliveredSeq:J

.field public final groupId:Ljava/lang/String;

.field public final hasMore:Z

.field public final messages:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;JLjava/util/List;Z)V
    .locals 0
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "deliveredSeq"    # J
    .param p5, "hasMore"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "J",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;Z)V"
        }
    .end annotation

    .line 13
    .local p4, "messages":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbPendingGroup;->groupId:Ljava/lang/String;

    .line 15
    iput-wide p2, p0, Lcom/tzibbur/basic/model/TzbPendingGroup;->deliveredSeq:J

    .line 16
    iput-object p4, p0, Lcom/tzibbur/basic/model/TzbPendingGroup;->messages:Ljava/util/List;

    .line 17
    iput-boolean p5, p0, Lcom/tzibbur/basic/model/TzbPendingGroup;->hasMore:Z

    .line 18
    return-void
.end method
