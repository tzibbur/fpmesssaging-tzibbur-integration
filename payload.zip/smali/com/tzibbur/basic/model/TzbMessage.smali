.class public final Lcom/tzibbur/basic/model/TzbMessage;
.super Ljava/lang/Object;
.source "TzbMessage.java"


# instance fields
.field public final body:Ljava/lang/String;

.field public final clientMessageId:Ljava/lang/String;

.field public final createdAt:Ljava/lang/String;

.field public final expiresAt:Ljava/lang/String;

.field public final groupId:Ljava/lang/String;

.field public final id:Ljava/lang/String;

.field public final senderId:Ljava/lang/String;

.field public final seq:J


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "groupId"    # Ljava/lang/String;
    .param p3, "seq"    # J
    .param p5, "senderId"    # Ljava/lang/String;
    .param p6, "body"    # Ljava/lang/String;
    .param p7, "clientMessageId"    # Ljava/lang/String;
    .param p8, "createdAt"    # Ljava/lang/String;
    .param p9, "expiresAt"    # Ljava/lang/String;

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbMessage;->id:Ljava/lang/String;

    .line 19
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbMessage;->groupId:Ljava/lang/String;

    .line 20
    iput-wide p3, p0, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    .line 21
    iput-object p5, p0, Lcom/tzibbur/basic/model/TzbMessage;->senderId:Ljava/lang/String;

    .line 22
    iput-object p6, p0, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    .line 23
    iput-object p7, p0, Lcom/tzibbur/basic/model/TzbMessage;->clientMessageId:Ljava/lang/String;

    .line 24
    iput-object p8, p0, Lcom/tzibbur/basic/model/TzbMessage;->createdAt:Ljava/lang/String;

    .line 25
    iput-object p9, p0, Lcom/tzibbur/basic/model/TzbMessage;->expiresAt:Ljava/lang/String;

    .line 26
    return-void
.end method
