.class public final Lcom/tzibbur/basic/model/TzbLegalDocument;
.super Ljava/lang/Object;
.source "TzbLegalDocument.java"


# static fields
.field public static final KEY_PRIVACY:Ljava/lang/String; = "privacy"

.field public static final KEY_TERMS:Ljava/lang/String; = "terms"


# instance fields
.field public final checksum:Ljava/lang/String;

.field public final key:Ljava/lang/String;

.field public final text:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "checksum"    # Ljava/lang/String;

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbLegalDocument;->key:Ljava/lang/String;

    .line 17
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbLegalDocument;->text:Ljava/lang/String;

    .line 18
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbLegalDocument;->checksum:Ljava/lang/String;

    .line 19
    return-void
.end method
