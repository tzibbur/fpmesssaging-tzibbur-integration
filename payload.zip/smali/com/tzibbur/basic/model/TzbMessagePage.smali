.class public final Lcom/tzibbur/basic/model/TzbMessagePage;
.super Ljava/lang/Object;
.source "TzbMessagePage.java"


# instance fields
.field public final items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation
.end field

.field public final nextAfterSeq:Ljava/lang/Long;

.field public final nextBeforeSeq:Ljava/lang/Long;


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/lang/Long;Ljava/lang/Long;)V
    .locals 0
    .param p2, "nextAfterSeq"    # Ljava/lang/Long;
    .param p3, "nextBeforeSeq"    # Ljava/lang/Long;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ")V"
        }
    .end annotation

    .line 11
    .local p1, "items":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbMessagePage;->items:Ljava/util/List;

    .line 13
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbMessagePage;->nextAfterSeq:Ljava/lang/Long;

    .line 14
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbMessagePage;->nextBeforeSeq:Ljava/lang/Long;

    .line 15
    return-void
.end method
