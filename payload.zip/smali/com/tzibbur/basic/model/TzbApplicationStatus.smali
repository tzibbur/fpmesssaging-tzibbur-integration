.class public final Lcom/tzibbur/basic/model/TzbApplicationStatus;
.super Ljava/lang/Object;
.source "TzbApplicationStatus.java"


# static fields
.field public static final STATUS_APPROVED:Ljava/lang/String; = "approved"

.field public static final STATUS_BANNED:Ljava/lang/String; = "banned"

.field public static final STATUS_DENIED:Ljava/lang/String; = "denied"

.field public static final STATUS_NONE:Ljava/lang/String; = "none"

.field public static final STATUS_PENDING:Ljava/lang/String; = "pending"


# instance fields
.field public final canApply:Z

.field public final decidedAt:Ljava/lang/String;

.field public final status:Ljava/lang/String;

.field public final submissionCount:I


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLjava/lang/String;I)V
    .locals 0
    .param p1, "status"    # Ljava/lang/String;
    .param p2, "canApply"    # Z
    .param p3, "decidedAt"    # Ljava/lang/String;
    .param p4, "submissionCount"    # I

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->status:Ljava/lang/String;

    .line 36
    iput-boolean p2, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->canApply:Z

    .line 37
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->decidedAt:Ljava/lang/String;

    .line 38
    iput p4, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->submissionCount:I

    .line 39
    return-void
.end method


# virtual methods
.method public isApproved()Z
    .locals 2

    .line 42
    const-string v0, "approved"

    iget-object v1, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->status:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public isBanned()Z
    .locals 2

    .line 50
    const-string v0, "banned"

    iget-object v1, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->status:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public isPending()Z
    .locals 2

    .line 46
    const-string v0, "pending"

    iget-object v1, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->status:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public revokesApproval()Z
    .locals 2

    .line 61
    const-string v0, "denied"

    iget-object v1, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->status:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->status:Ljava/lang/String;

    .line 62
    const-string v1, "banned"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/model/TzbApplicationStatus;->status:Ljava/lang/String;

    .line 63
    const-string v1, "pending"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 61
    :goto_1
    return v0
.end method
