.class public final Lcom/tzibbur/basic/model/TzbGroupEvent;
.super Ljava/lang/Object;
.source "TzbGroupEvent.java"


# static fields
.field public static final GROUP_DELETED:Ljava/lang/String; = "group-deleted"

.field public static final GROUP_UPDATED:Ljava/lang/String; = "group-updated"

.field public static final MEMBER_ADDED:Ljava/lang/String; = "member-added"

.field public static final MEMBER_REMOVED:Ljava/lang/String; = "member-removed"

.field public static final ROLE_CHANGED:Ljava/lang/String; = "role-changed"


# instance fields
.field public final actorId:Ljava/lang/String;

.field public final event:Ljava/lang/String;

.field public final groupId:Ljava/lang/String;

.field public final joinedSeq:J

.field public final name:Ljava/lang/String;

.field public final reason:Ljava/lang/String;

.field public final role:Ljava/lang/String;

.field public final userId:Ljava/lang/String;

.field public final whoCanAddMembers:Ljava/lang/String;

.field public final whoCanPost:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "event"    # Ljava/lang/String;
    .param p2, "groupId"    # Ljava/lang/String;
    .param p3, "userId"    # Ljava/lang/String;
    .param p4, "role"    # Ljava/lang/String;
    .param p5, "actorId"    # Ljava/lang/String;
    .param p6, "reason"    # Ljava/lang/String;
    .param p7, "joinedSeq"    # J
    .param p9, "name"    # Ljava/lang/String;
    .param p10, "whoCanPost"    # Ljava/lang/String;
    .param p11, "whoCanAddMembers"    # Ljava/lang/String;

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->event:Ljava/lang/String;

    .line 26
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->groupId:Ljava/lang/String;

    .line 27
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->userId:Ljava/lang/String;

    .line 28
    iput-object p4, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->role:Ljava/lang/String;

    .line 29
    iput-object p5, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->actorId:Ljava/lang/String;

    .line 30
    iput-object p6, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->reason:Ljava/lang/String;

    .line 31
    iput-wide p7, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->joinedSeq:J

    .line 32
    iput-object p9, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->name:Ljava/lang/String;

    .line 33
    iput-object p10, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->whoCanPost:Ljava/lang/String;

    .line 34
    iput-object p11, p0, Lcom/tzibbur/basic/model/TzbGroupEvent;->whoCanAddMembers:Ljava/lang/String;

    .line 35
    return-void
.end method
