.class public final Lcom/tzibbur/basic/model/TzbApplication;
.super Ljava/lang/Object;
.source "TzbApplication.java"


# instance fields
.field public final id:Ljava/lang/String;

.field public final status:Ljava/lang/String;

.field public final submittedAt:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "status"    # Ljava/lang/String;
    .param p3, "submittedAt"    # Ljava/lang/String;

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbApplication;->id:Ljava/lang/String;

    .line 15
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbApplication;->status:Ljava/lang/String;

    .line 16
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbApplication;->submittedAt:Ljava/lang/String;

    .line 17
    return-void
.end method
