.class public final Lcom/tzibbur/basic/model/TzbSendResult;
.super Ljava/lang/Object;
.source "TzbSendResult.java"


# instance fields
.field public final command:Lcom/tzibbur/basic/model/TzbCommandResult;

.field public final duplicate:Z

.field public final message:Lcom/tzibbur/basic/model/TzbMessage;


# direct methods
.method public constructor <init>(Lcom/tzibbur/basic/model/TzbMessage;ZLcom/tzibbur/basic/model/TzbCommandResult;)V
    .locals 0
    .param p1, "message"    # Lcom/tzibbur/basic/model/TzbMessage;
    .param p2, "duplicate"    # Z
    .param p3, "command"    # Lcom/tzibbur/basic/model/TzbCommandResult;

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbSendResult;->message:Lcom/tzibbur/basic/model/TzbMessage;

    .line 11
    iput-boolean p2, p0, Lcom/tzibbur/basic/model/TzbSendResult;->duplicate:Z

    .line 12
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbSendResult;->command:Lcom/tzibbur/basic/model/TzbCommandResult;

    .line 13
    return-void
.end method


# virtual methods
.method public isCommand()Z
    .locals 1

    .line 16
    iget-object v0, p0, Lcom/tzibbur/basic/model/TzbSendResult;->command:Lcom/tzibbur/basic/model/TzbCommandResult;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method
