.class public final Lcom/tzibbur/basic/model/TzbMember;
.super Ljava/lang/Object;
.source "TzbMember.java"


# instance fields
.field public final displayName:Ljava/lang/String;

.field public final joinedAt:Ljava/lang/String;

.field public final kind:Ljava/lang/String;

.field public final phoneE164:Ljava/lang/String;

.field public final role:Ljava/lang/String;

.field public final userId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "userId"    # Ljava/lang/String;
    .param p2, "displayName"    # Ljava/lang/String;
    .param p3, "phoneE164"    # Ljava/lang/String;
    .param p4, "kind"    # Ljava/lang/String;
    .param p5, "role"    # Ljava/lang/String;
    .param p6, "joinedAt"    # Ljava/lang/String;

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 19
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbMember;->userId:Ljava/lang/String;

    .line 20
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbMember;->displayName:Ljava/lang/String;

    .line 21
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbMember;->phoneE164:Ljava/lang/String;

    .line 22
    iput-object p4, p0, Lcom/tzibbur/basic/model/TzbMember;->kind:Ljava/lang/String;

    .line 23
    iput-object p5, p0, Lcom/tzibbur/basic/model/TzbMember;->role:Ljava/lang/String;

    .line 24
    iput-object p6, p0, Lcom/tzibbur/basic/model/TzbMember;->joinedAt:Ljava/lang/String;

    .line 25
    return-void
.end method
