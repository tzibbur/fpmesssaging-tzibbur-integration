.class public final Lcom/tzibbur/basic/model/TzbCommandResult;
.super Ljava/lang/Object;
.source "TzbCommandResult.java"


# instance fields
.field public final code:Ljava/lang/String;

.field public final name:Ljava/lang/String;

.field public final ok:Z

.field public final params:Lorg/json/JSONObject;

.field public final text:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLjava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "ok"    # Z
    .param p3, "code"    # Ljava/lang/String;
    .param p4, "params"    # Lorg/json/JSONObject;
    .param p5, "text"    # Ljava/lang/String;

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbCommandResult;->name:Ljava/lang/String;

    .line 15
    iput-boolean p2, p0, Lcom/tzibbur/basic/model/TzbCommandResult;->ok:Z

    .line 16
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    .line 17
    if-eqz p4, :cond_0

    move-object v0, p4

    goto :goto_0

    :cond_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :goto_0
    iput-object v0, p0, Lcom/tzibbur/basic/model/TzbCommandResult;->params:Lorg/json/JSONObject;

    .line 18
    iput-object p5, p0, Lcom/tzibbur/basic/model/TzbCommandResult;->text:Ljava/lang/String;

    .line 19
    return-void
.end method
