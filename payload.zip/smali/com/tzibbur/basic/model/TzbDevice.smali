.class public final Lcom/tzibbur/basic/model/TzbDevice;
.super Ljava/lang/Object;
.source "TzbDevice.java"


# instance fields
.field public final deviceModel:Ljava/lang/String;

.field public final id:Ljava/lang/String;

.field public final imei:Ljava/lang/String;

.field public final lastSeenAt:Ljava/lang/String;

.field public final platform:Ljava/lang/String;

.field public final registeredAt:Ljava/lang/String;

.field public final serialNumber:Ljava/lang/String;

.field public final userId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "userId"    # Ljava/lang/String;
    .param p3, "platform"    # Ljava/lang/String;
    .param p4, "deviceModel"    # Ljava/lang/String;
    .param p5, "registeredAt"    # Ljava/lang/String;
    .param p6, "lastSeenAt"    # Ljava/lang/String;
    .param p7, "serialNumber"    # Ljava/lang/String;
    .param p8, "imei"    # Ljava/lang/String;

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbDevice;->id:Ljava/lang/String;

    .line 18
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbDevice;->userId:Ljava/lang/String;

    .line 19
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbDevice;->platform:Ljava/lang/String;

    .line 20
    iput-object p4, p0, Lcom/tzibbur/basic/model/TzbDevice;->deviceModel:Ljava/lang/String;

    .line 21
    iput-object p5, p0, Lcom/tzibbur/basic/model/TzbDevice;->registeredAt:Ljava/lang/String;

    .line 22
    iput-object p6, p0, Lcom/tzibbur/basic/model/TzbDevice;->lastSeenAt:Ljava/lang/String;

    .line 23
    iput-object p7, p0, Lcom/tzibbur/basic/model/TzbDevice;->serialNumber:Ljava/lang/String;

    .line 24
    iput-object p8, p0, Lcom/tzibbur/basic/model/TzbDevice;->imei:Ljava/lang/String;

    .line 25
    return-void
.end method
