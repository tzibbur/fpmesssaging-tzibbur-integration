.class public final Lcom/tzibbur/basic/model/TzbUser;
.super Ljava/lang/Object;
.source "TzbUser.java"


# instance fields
.field public final createdAt:Ljava/lang/String;

.field public final displayName:Ljava/lang/String;

.field public final id:Ljava/lang/String;

.field public final kind:Ljava/lang/String;

.field public final phoneE164:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "phoneE164"    # Ljava/lang/String;
    .param p3, "kind"    # Ljava/lang/String;
    .param p4, "displayName"    # Ljava/lang/String;
    .param p5, "createdAt"    # Ljava/lang/String;

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    iput-object p1, p0, Lcom/tzibbur/basic/model/TzbUser;->id:Ljava/lang/String;

    .line 15
    iput-object p2, p0, Lcom/tzibbur/basic/model/TzbUser;->phoneE164:Ljava/lang/String;

    .line 16
    iput-object p3, p0, Lcom/tzibbur/basic/model/TzbUser;->kind:Ljava/lang/String;

    .line 17
    iput-object p4, p0, Lcom/tzibbur/basic/model/TzbUser;->displayName:Ljava/lang/String;

    .line 18
    iput-object p5, p0, Lcom/tzibbur/basic/model/TzbUser;->createdAt:Ljava/lang/String;

    .line 19
    return-void
.end method
