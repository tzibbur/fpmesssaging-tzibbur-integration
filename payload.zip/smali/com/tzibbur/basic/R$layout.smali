.class public final Lcom/tzibbur/basic/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static tzb_about_activity:I = 0x7f0a0098    # @layout/tzb_about_activity 'res/layout/tzb_about_activity.xml'

.field public static tzb_add_member_dialog:I = 0x7f0a0099    # @layout/tzb_add_member_dialog 'res/layout/tzb_add_member_dialog.xml'

.field public static tzb_apply_activity:I = 0x7f0a009a    # @layout/tzb_apply_activity 'res/layout/tzb_apply_activity.xml'

.field public static tzb_category_item:I = 0x7f0a009b    # @layout/tzb_category_item 'res/layout/tzb_category_item.xml'

.field public static tzb_contact_picker_activity:I = 0x7f0a009c    # @layout/tzb_contact_picker_activity 'res/layout/tzb_contact_picker_activity.xml'

.field public static tzb_contact_picker_item:I = 0x7f0a009d    # @layout/tzb_contact_picker_item 'res/layout/tzb_contact_picker_item.xml'

.field public static tzb_conversation_activity:I = 0x7f0a009e    # @layout/tzb_conversation_activity 'res/layout/tzb_conversation_activity.xml'

.field public static tzb_device_blocked_activity:I = 0x7f0a009f    # @layout/tzb_device_blocked_activity 'res/layout/tzb_device_blocked_activity.xml'

.field public static tzb_dialog_edit:I = 0x7f0a00a0    # @layout/tzb_dialog_edit 'res/layout/tzb_dialog_edit.xml'

.field public static tzb_enroll_code_activity:I = 0x7f0a00a1    # @layout/tzb_enroll_code_activity 'res/layout/tzb_enroll_code_activity.xml'

.field public static tzb_enroll_name_activity:I = 0x7f0a00a2    # @layout/tzb_enroll_name_activity 'res/layout/tzb_enroll_name_activity.xml'

.field public static tzb_enroll_phone_activity:I = 0x7f0a00a3    # @layout/tzb_enroll_phone_activity 'res/layout/tzb_enroll_phone_activity.xml'

.field public static tzb_group_create_activity:I = 0x7f0a00a4    # @layout/tzb_group_create_activity 'res/layout/tzb_group_create_activity.xml'

.field public static tzb_group_info_activity:I = 0x7f0a00a5    # @layout/tzb_group_info_activity 'res/layout/tzb_group_info_activity.xml'

.field public static tzb_group_list_activity:I = 0x7f0a00a6    # @layout/tzb_group_list_activity 'res/layout/tzb_group_list_activity.xml'

.field public static tzb_group_list_item:I = 0x7f0a00a7    # @layout/tzb_group_list_item 'res/layout/tzb_group_list_item.xml'

.field public static tzb_legal_activity:I = 0x7f0a00a8    # @layout/tzb_legal_activity 'res/layout/tzb_legal_activity.xml'

.field public static tzb_load_earlier_header:I = 0x7f0a00a9    # @layout/tzb_load_earlier_header 'res/layout/tzb_load_earlier_header.xml'

.field public static tzb_member_list_activity:I = 0x7f0a00aa    # @layout/tzb_member_list_activity 'res/layout/tzb_member_list_activity.xml'

.field public static tzb_member_list_footer:I = 0x7f0a00ab    # @layout/tzb_member_list_footer 'res/layout/tzb_member_list_footer.xml'

.field public static tzb_member_list_item:I = 0x7f0a00ac    # @layout/tzb_member_list_item 'res/layout/tzb_member_list_item.xml'

.field public static tzb_message_item_in:I = 0x7f0a00ad    # @layout/tzb_message_item_in 'res/layout/tzb_message_item_in.xml'

.field public static tzb_message_item_out:I = 0x7f0a00ae    # @layout/tzb_message_item_out 'res/layout/tzb_message_item_out.xml'

.field public static tzb_message_item_sponsored:I = 0x7f0a00af    # @layout/tzb_message_item_sponsored 'res/layout/tzb_message_item_sponsored.xml'

.field public static tzb_message_item_system:I = 0x7f0a00b0    # @layout/tzb_message_item_system 'res/layout/tzb_message_item_system.xml'

.field public static tzb_muted_divider:I = 0x7f0a00b1    # @layout/tzb_muted_divider 'res/layout/tzb_muted_divider.xml'

.field public static tzb_settings_activity:I = 0x7f0a00b2    # @layout/tzb_settings_activity 'res/layout/tzb_settings_activity.xml'

.field public static tzb_title_bar:I = 0x7f0a00b3    # @layout/tzb_title_bar 'res/layout/tzb_title_bar.xml'

.field public static tzb_unread_divider:I = 0x7f0a00b4    # @layout/tzb_unread_divider 'res/layout/tzb_unread_divider.xml'


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
