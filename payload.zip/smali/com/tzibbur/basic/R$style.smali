.class public final Lcom/tzibbur/basic/R$style;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static TzbTheme:I = 0x7f0f018c    # @style/TzbTheme

.field public static TzbTheme_NoDisplay:I = 0x7f0f018d    # @style/TzbTheme.NoDisplay


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
