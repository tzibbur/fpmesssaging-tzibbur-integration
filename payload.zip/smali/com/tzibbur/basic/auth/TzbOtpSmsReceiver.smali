.class public final Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;
.super Landroid/content/BroadcastReceiver;
.source "TzbOtpSmsReceiver.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;
    }
.end annotation


# static fields
.field private static final SIX_DIGITS:Ljava/util/regex/Pattern;


# instance fields
.field private listener:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 30
    const-string v0, "\\b\\d{6}\\b"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;->SIX_DIGITS:Ljava/util/regex/Pattern;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 23
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 11
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .line 40
    iget-object v0, p0, Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;->listener:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;

    .line 41
    .local v0, "l":Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;
    if-eqz v0, :cond_b

    if-nez p2, :cond_0

    goto/16 :goto_5

    .line 42
    :cond_0
    const-string v1, "android.provider.Telephony.SMS_RECEIVED"

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    return-void

    .line 46
    :cond_1
    :try_start_0
    invoke-static {p2}, Landroid/provider/Telephony$Sms$Intents;->getMessagesFromIntent(Landroid/content/Intent;)[Landroid/telephony/SmsMessage;

    move-result-object v1

    .line 49
    .local v1, "parts":[Landroid/telephony/SmsMessage;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    nop

    .line 50
    if-eqz v1, :cond_a

    array-length v2, v1

    if-nez v2, :cond_2

    goto :goto_4

    .line 54
    :cond_2
    new-instance v2, Ljava/util/LinkedHashMap;

    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 55
    .local v2, "bodies":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/StringBuilder;>;"
    array-length v3, v1

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v3, :cond_7

    aget-object v5, v1, v4

    .line 56
    .local v5, "part":Landroid/telephony/SmsMessage;
    if-nez v5, :cond_3

    goto :goto_2

    .line 60
    :cond_3
    :try_start_1
    invoke-virtual {v5}, Landroid/telephony/SmsMessage;->getMessageBody()Ljava/lang/String;

    move-result-object v6

    .line 61
    .local v6, "body":Ljava/lang/String;
    invoke-virtual {v5}, Landroid/telephony/SmsMessage;->getOriginatingAddress()Ljava/lang/String;

    move-result-object v7

    .line 64
    .local v7, "from":Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    nop

    .line 65
    if-nez v6, :cond_4

    goto :goto_2

    .line 66
    :cond_4
    if-nez v7, :cond_5

    const-string v8, ""

    goto :goto_1

    :cond_5
    move-object v8, v7

    .line 67
    .local v8, "key":Ljava/lang/String;
    :goto_1
    invoke-interface {v2, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/StringBuilder;

    .line 68
    .local v9, "sb":Ljava/lang/StringBuilder;
    if-nez v9, :cond_6

    .line 69
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    move-object v9, v10

    .line 70
    invoke-interface {v2, v8, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    :cond_6
    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_2

    .line 62
    .end local v6
    .end local v7
    .end local v8
    .end local v9
    :catchall_0
    move-exception v6

    .line 63
    .local v6, "t":Ljava/lang/Throwable;
    nop

    .line 55
    .end local v5
    .end local v6
    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 75
    :cond_7
    invoke-interface {v2}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_9

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/StringBuilder;

    .line 76
    .local v4, "sb":Ljava/lang/StringBuilder;
    sget-object v5, Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;->SIX_DIGITS:Ljava/util/regex/Pattern;

    invoke-virtual {v5, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v5

    .line 77
    .local v5, "m":Ljava/util/regex/Matcher;
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->find()Z

    move-result v6

    if-eqz v6, :cond_8

    .line 78
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;->onOtpCode(Ljava/lang/String;)V

    .line 79
    return-void

    .line 81
    .end local v4
    .end local v5
    :cond_8
    goto :goto_3

    .line 82
    :cond_9
    return-void

    .line 50
    .end local v2
    :cond_a
    :goto_4
    return-void

    .line 47
    .end local v1
    :catchall_1
    move-exception v1

    .line 48
    .local v1, "t":Ljava/lang/Throwable;
    return-void

    .line 41
    .end local v1
    :cond_b
    :goto_5
    return-void
.end method

.method public setListener(Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;)V
    .locals 0
    .param p1, "listener"    # Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;

    .line 35
    iput-object p1, p0, Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;->listener:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;

    .line 36
    return-void
.end method
