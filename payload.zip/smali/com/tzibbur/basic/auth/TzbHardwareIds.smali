.class public final Lcom/tzibbur/basic/auth/TzbHardwareIds;
.super Ljava/lang/Object;
.source "TzbHardwareIds.java"


# static fields
.field private static final UNKNOWN:Ljava/lang/String; = "unknown"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static clean(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "value"    # Ljava/lang/String;

    .line 71
    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    .line 72
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 73
    .local v1, "trimmed":Ljava/lang/String;
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2

    const-string v2, "unknown"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_0

    .line 74
    :cond_1
    return-object v1

    .line 73
    :cond_2
    :goto_0
    return-object v0
.end method

.method private static hasPhoneStatePermission(Landroid/content/Context;)Z
    .locals 1
    .param p0, "context"    # Landroid/content/Context;

    .line 66
    const-string v0, "android.permission.READ_PHONE_STATE"

    invoke-virtual {p0, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static imei(Landroid/content/Context;)Ljava/lang/String;
    .locals 4
    .param p0, "context"    # Landroid/content/Context;

    .line 49
    invoke-static {p0}, Lcom/tzibbur/basic/auth/TzbHardwareIds;->hasPhoneStatePermission(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 50
    const/4 v0, 0x0

    return-object v0

    .line 52
    :cond_0
    const/4 v0, 0x0

    .line 54
    .local v0, "imei":Ljava/lang/String;
    :try_start_0
    const-string v1, "phone"

    .line 55
    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/TelephonyManager;

    .line 56
    .local v1, "tm":Landroid/telephony/TelephonyManager;
    if-eqz v1, :cond_2

    .line 57
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_1

    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getImei()Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getDeviceId()Ljava/lang/String;

    move-result-object v2

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    :goto_0

    move-object v0, v2

    .line 61
    .end local v1
    :cond_2
    goto :goto_1

    .line 59
    :catchall_0
    move-exception v1

    .line 62
    :goto_1
    invoke-static {v0}, Lcom/tzibbur/basic/auth/TzbHardwareIds;->clean(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public static serialNumber(Landroid/content/Context;)Ljava/lang/String;
    .locals 3
    .param p0, "context"    # Landroid/content/Context;

    .line 32
    const/4 v0, 0x0

    .line 34
    .local v0, "serial":Ljava/lang/String;
    :try_start_0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_0

    invoke-static {p0}, Lcom/tzibbur/basic/auth/TzbHardwareIds;->hasPhoneStatePermission(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 35
    invoke-static {}, Landroid/os/Build;->getSerial()Ljava/lang/String;

    move-result-object v1

    move-object v0, v1

    .end local v0
    .local v1, "serial":Ljava/lang/String;
    goto :goto_0

    .line 36
    .end local v1
    .restart local v0
    :cond_0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-ge v1, v2, :cond_1

    .line 37
    sget-object v1, Landroid/os/Build;->SERIAL:Ljava/lang/String;

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v0, v1

    .line 42
    :cond_1
    :goto_0
    goto :goto_1

    .line 39
    :catchall_0
    move-exception v1

    .line 43
    :goto_1
    invoke-static {v0}, Lcom/tzibbur/basic/auth/TzbHardwareIds;->clean(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method
