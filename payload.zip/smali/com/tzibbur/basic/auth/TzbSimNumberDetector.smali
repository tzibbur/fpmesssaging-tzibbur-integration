.class public final Lcom/tzibbur/basic/auth/TzbSimNumberDetector;
.super Ljava/lang/Object;
.source "TzbSimNumberDetector.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static detect(Landroid/content/Context;)Ljava/lang/String;
    .locals 2
    .param p0, "context"    # Landroid/content/Context;

    .line 32
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    if-lt v0, v1, :cond_0

    .line 33
    invoke-static {p0}, Lcom/tzibbur/basic/auth/TzbSimNumberDetector;->viaGetPhoneNumber(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 34
    .local v0, "number":Ljava/lang/String;
    invoke-static {v0}, Lcom/tzibbur/basic/auth/TzbSimNumberDetector;->isEmpty(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 38
    .end local v0
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/auth/TzbSimNumberDetector;->viaSubscriptionInfo(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 39
    .restart local v0
    invoke-static {v0}, Lcom/tzibbur/basic/auth/TzbSimNumberDetector;->isEmpty(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 42
    :cond_1
    invoke-static {p0}, Lcom/tzibbur/basic/auth/TzbSimNumberDetector;->viaLine1Number(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 43
    invoke-static {v0}, Lcom/tzibbur/basic/auth/TzbSimNumberDetector;->isEmpty(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 45
    :cond_2
    const/4 v1, 0x0

    return-object v1
.end method

.method private static isEmpty(Ljava/lang/String;)Z
    .locals 1
    .param p0, "s"    # Ljava/lang/String;

    .line 92
    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method private static viaGetPhoneNumber(Landroid/content/Context;)Ljava/lang/String;
    .locals 9
    .param p0, "context"    # Landroid/content/Context;

    .line 50
    const/4 v0, 0x0

    :try_start_0
    const-string v1, "telephony_subscription_service"

    .line 51
    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/SubscriptionManager;

    .line 52
    .local v1, "sm":Landroid/telephony/SubscriptionManager;
    if-nez v1, :cond_0

    return-object v0

    .line 53
    :cond_0
    invoke-static {}, Landroid/telephony/SubscriptionManager;->getDefaultSubscriptionId()I

    move-result v2

    .line 54
    .local v2, "subId":I
    const-class v3, Landroid/telephony/SubscriptionManager;

    const-string v4, "getPhoneNumber"

    const/4 v5, 0x1

    new-array v6, v5, [Ljava/lang/Class;

    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v8, 0x0

    aput-object v7, v6, v8

    invoke-virtual {v3, v4, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    .line 55
    .local v3, "m":Ljava/lang/reflect/Method;
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v5, v5, [Ljava/lang/Object;

    aput-object v4, v5, v8

    invoke-virtual {v3, v1, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 56
    .local v4, "result":Ljava/lang/Object;
    instance-of v5, v4, Ljava/lang/String;

    if-eqz v5, :cond_1

    move-object v5, v4

    check-cast v5, Ljava/lang/String;

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v0, v5

    :cond_1
    return-object v0

    .line 57
    .end local v1
    .end local v2
    .end local v3
    .end local v4
    :catchall_0
    move-exception v1

    .line 58
    .local v1, "t":Ljava/lang/Throwable;
    return-object v0
.end method

.method private static viaLine1Number(Landroid/content/Context;)Ljava/lang/String;
    .locals 2
    .param p0, "context"    # Landroid/content/Context;

    .line 82
    const/4 v0, 0x0

    :try_start_0
    const-string v1, "phone"

    .line 83
    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/TelephonyManager;

    .line 84
    .local v1, "tm":Landroid/telephony/TelephonyManager;
    if-nez v1, :cond_0

    return-object v0

    .line 85
    :cond_0
    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getLine1Number()Ljava/lang/String;

    move-result-object v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    .line 86
    .end local v1
    :catchall_0
    move-exception v1

    .line 87
    .local v1, "t":Ljava/lang/Throwable;
    return-object v0
.end method

.method private static viaSubscriptionInfo(Landroid/content/Context;)Ljava/lang/String;
    .locals 7
    .param p0, "context"    # Landroid/content/Context;

    .line 64
    const/4 v0, 0x0

    :try_start_0
    const-string v1, "telephony_subscription_service"

    .line 65
    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/SubscriptionManager;

    .line 66
    .local v1, "sm":Landroid/telephony/SubscriptionManager;
    if-nez v1, :cond_0

    return-object v0

    .line 67
    :cond_0
    invoke-virtual {v1}, Landroid/telephony/SubscriptionManager;->getActiveSubscriptionInfoList()Ljava/util/List;

    move-result-object v2

    .line 68
    .local v2, "subs":Ljava/util/List;, "Ljava/util/List<Landroid/telephony/SubscriptionInfo;>;"
    if-nez v2, :cond_1

    return-object v0

    .line 69
    :cond_1
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/telephony/SubscriptionInfo;

    .line 70
    .local v4, "info":Landroid/telephony/SubscriptionInfo;
    if-nez v4, :cond_2

    goto :goto_0

    .line 71
    :cond_2
    invoke-virtual {v4}, Landroid/telephony/SubscriptionInfo;->getNumber()Ljava/lang/String;

    move-result-object v5

    .line 72
    .local v5, "n":Ljava/lang/String;
    invoke-static {v5}, Lcom/tzibbur/basic/auth/TzbSimNumberDetector;->isEmpty(Ljava/lang/String;)Z

    move-result v6

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v6, :cond_3

    return-object v5

    .line 73
    .end local v4
    .end local v5
    :cond_3
    goto :goto_0

    .line 74
    :cond_4
    return-object v0

    .line 75
    .end local v1
    .end local v2
    :catchall_0
    move-exception v1

    .line 76
    .local v1, "t":Ljava/lang/Throwable;
    return-object v0
.end method
