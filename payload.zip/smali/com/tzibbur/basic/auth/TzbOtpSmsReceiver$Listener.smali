.class public interface abstract Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;
.super Ljava/lang/Object;
.source "TzbOtpSmsReceiver.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Listener"
.end annotation


# virtual methods
.method public abstract onOtpCode(Ljava/lang/String;)V
.end method
