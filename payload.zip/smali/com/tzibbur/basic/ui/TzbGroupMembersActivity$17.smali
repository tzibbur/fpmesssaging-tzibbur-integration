.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->removeMember(Lcom/tzibbur/basic/model/TzbMember;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

.field final synthetic val$gid:Ljava/lang/String;

.field final synthetic val$member:Lcom/tzibbur/basic/model/TzbMember;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/lang/String;Lcom/tzibbur/basic/model/TzbMember;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 477
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;->val$gid:Ljava/lang/String;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;->val$member:Lcom/tzibbur/basic/model/TzbMember;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 477
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;->call()Ljava/lang/Void;

    move-result-object v0

    return-object v0
.end method

.method public call()Ljava/lang/Void;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 480
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;->val$gid:Ljava/lang/String;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;->val$member:Lcom/tzibbur/basic/model/TzbMember;

    iget-object v2, v2, Lcom/tzibbur/basic/model/TzbMember;->userId:Ljava/lang/String;

    invoke-interface {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApi;->removeMember(Ljava/lang/String;Ljava/lang/String;)V

    .line 481
    const/4 v0, 0x0

    return-object v0
.end method
