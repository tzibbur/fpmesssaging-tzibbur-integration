.class public Lcom/tzibbur/basic/ui/TzbComposeEditText;
.super Lcom/tzibbur/basic/ui/TzbKeypadEditText;
.source "TzbComposeEditText.java"


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;

    .line 53
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;-><init>(Landroid/content/Context;)V

    .line 54
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .line 57
    invoke-direct {p0, p1, p2}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 58
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyleAttr"    # I

    .line 61
    invoke-direct {p0, p1, p2, p3}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 62
    return-void
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/ui/TzbKeypadEditText;
.method protected onImeEditorAction(I)Z
    .locals 1
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibConversationStyle;->imeAction(Landroid/view/View;I)Z
    move-result v0
    return v0
.end method
