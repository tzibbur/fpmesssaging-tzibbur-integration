.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$2;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 104
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$2;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 3
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 107
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    invoke-virtual {p1, p3}, Landroid/widget/AdapterView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v0

    .line 108
    .local v0, "item":Ljava/lang/Object;
    if-nez v0, :cond_0

    .line 110
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$2;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$100(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$2;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$200(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)V

    goto :goto_0

    .line 111
    :cond_0
    instance-of v1, v0, Lcom/tzibbur/basic/model/TzbMember;

    if-eqz v1, :cond_1

    .line 112
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$2;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    move-object v2, v0

    check-cast v2, Lcom/tzibbur/basic/model/TzbMember;

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$302(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)Lcom/tzibbur/basic/model/TzbMember;

    .line 113
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$2;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$2;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$300(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/model/TzbMember;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$400(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)V

    .line 115
    :cond_1
    :goto_0
    return-void
.end method
