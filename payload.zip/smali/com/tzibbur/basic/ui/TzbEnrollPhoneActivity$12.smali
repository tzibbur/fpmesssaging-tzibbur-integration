.class Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$12;
.super Ljava/lang/Object;
.source "TzbEnrollPhoneActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->fetchCapabilities()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbCapabilities;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

.field final synthetic val$core:Lcom/tzibbur/basic/core/TzbCore;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Lcom/tzibbur/basic/core/TzbCore;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 464
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$12;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$12;->val$core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 0
    .param p1, "error"    # Ljava/lang/Exception;

    .line 477
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbCapabilities;)V
    .locals 1
    .param p1, "capabilities"    # Lcom/tzibbur/basic/model/TzbCapabilities;

    .line 467
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$12;->val$core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/tzibbur/basic/store/TzbSession;->saveCapabilities(Lcom/tzibbur/basic/model/TzbCapabilities;)V

    .line 468
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lcom/tzibbur/basic/model/TzbCapabilities;->deviceBlocked()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 470
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$12;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V

    .line 472
    :cond_0
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 464
    check-cast p1, Lcom/tzibbur/basic/model/TzbCapabilities;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$12;->onResult(Lcom/tzibbur/basic/model/TzbCapabilities;)V

    return-void
.end method
