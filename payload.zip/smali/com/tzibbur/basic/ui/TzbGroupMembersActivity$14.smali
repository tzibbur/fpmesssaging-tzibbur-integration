.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->submitAdd(Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbMemberAddResult;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 373
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 3
    .param p1, "error"    # Ljava/lang/Exception;

    .line 399
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_1

    .line 400
    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    .line 405
    .local v0, "p":Lcom/tzibbur/basic/net/TzbProblem;
    const-string v1, "adding_members_not_allowed"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    .line 406
    const-string v2, "forbidden"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 407
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1602(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)Z

    .line 408
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$600(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    .line 411
    .end local v0
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 412
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbMemberAddResult;)V
    .locals 8
    .param p1, "result"    # Lcom/tzibbur/basic/model/TzbMemberAddResult;

    .line 376
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 377
    .local v0, "report":Ljava/lang/StringBuilder;
    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbMemberAddResult;->added:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/tzibbur/basic/model/TzbMember;

    .line 378
    .local v2, "member":Lcom/tzibbur/basic/model/TzbMember;
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    sget v6, Lcom/tzibbur/basic/R$string;->tzb_added_member:I

    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 379
    invoke-static {v7}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$900(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

    move-result-object v7

    invoke-virtual {v7, v2}, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->labelFor(Lcom/tzibbur/basic/model/TzbMember;)Ljava/lang/String;

    move-result-object v7

    new-array v4, v4, [Ljava/lang/Object;

    aput-object v7, v4, v3

    .line 378
    invoke-virtual {v5, v6, v4}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1500(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    .line 380
    .end local v2
    goto :goto_0

    .line 381
    :cond_0
    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbMemberAddResult;->alreadyMembers:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 382
    .local v2, "p":Ljava/lang/String;
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    sget v6, Lcom/tzibbur/basic/R$string;->tzb_already_member:I

    new-array v7, v4, [Ljava/lang/Object;

    aput-object v2, v7, v3

    invoke-virtual {v5, v6, v7}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v5}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1500(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    .line 383
    .end local v2
    goto :goto_1

    .line 384
    :cond_1
    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbMemberAddResult;->notFound:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 385
    .restart local v2
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    sget v6, Lcom/tzibbur/basic/R$string;->tzb_not_on_tzibbur:I

    new-array v7, v4, [Ljava/lang/Object;

    aput-object v2, v7, v3

    invoke-virtual {v5, v6, v7}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v5}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1500(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    .line 386
    .end local v2
    goto :goto_2

    .line 387
    :cond_2
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    if-lez v1, :cond_3

    .line 388
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 389
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 388
    invoke-static {v1, v2, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    .line 389
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 391
    :cond_3
    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbMemberAddResult;->added:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_4

    .line 392
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v1, v4}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$200(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)V

    .line 393
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    .line 395
    :cond_4
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 373
    check-cast p1, Lcom/tzibbur/basic/model/TzbMemberAddResult;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;->onResult(Lcom/tzibbur/basic/model/TzbMemberAddResult;)V

    return-void
.end method
