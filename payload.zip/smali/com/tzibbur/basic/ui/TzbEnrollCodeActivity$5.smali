.class Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;
.super Ljava/lang/Object;
.source "TzbEnrollCodeActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verify()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbEnrollment;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 312
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "error"    # Ljava/lang/Exception;

    .line 321
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$402(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Z)Z

    .line 322
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$600(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Z)V

    .line 323
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$700(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/Exception;)V

    .line 324
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbEnrollment;)V
    .locals 2
    .param p1, "enrollment"    # Lcom/tzibbur/basic/model/TzbEnrollment;

    .line 315
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$402(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Z)Z

    .line 316
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$500(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Lcom/tzibbur/basic/model/TzbEnrollment;)V

    .line 317
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 312
    check-cast p1, Lcom/tzibbur/basic/model/TzbEnrollment;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;->onResult(Lcom/tzibbur/basic/model/TzbEnrollment;)V

    return-void
.end method
