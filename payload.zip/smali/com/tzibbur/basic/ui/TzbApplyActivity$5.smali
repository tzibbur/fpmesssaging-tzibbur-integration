.class Lcom/tzibbur/basic/ui/TzbApplyActivity$5;
.super Ljava/lang/Object;
.source "TzbApplyActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 239
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 242
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const-string v2, "privacy"

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbLegalActivity;->intent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->startActivity(Landroid/content/Intent;)V

    .line 244
    return-void
.end method
