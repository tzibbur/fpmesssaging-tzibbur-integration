.class public Lcom/tzibbur/basic/ui/TzbGroupListActivity;
.super Lcom/tzibbur/basic/ui/TzbBaseActivity;
.source "TzbGroupListActivity.java"


# static fields
.field private static final PREF_ASKED_CONTACTS:Ljava/lang/String; = "tzb_asked_contacts"

.field private static final RC_READ_CONTACTS:I = 0x15

.field private static final UI_PREFS:Ljava/lang/String; = "tzb_ui_prefs"


# instance fields
.field private adapter:Lcom/tzibbur/basic/ui/TzbGroupListAdapter;

.field private firstSyncKicked:Z

.field private list:Landroid/widget/ListView;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 29
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbGroupListActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupListActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 29
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->openConversation(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)Lcom/tzibbur/basic/ui/TzbGroupListAdapter;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    .line 29
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->adapter:Lcom/tzibbur/basic/ui/TzbGroupListAdapter;

    return-object v0
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    .line 29
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->firstSyncKicked:Z

    return v0
.end method

.method static synthetic access$202(Lcom/tzibbur/basic/ui/TzbGroupListActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupListActivity;
    .param p1, "x1"    # Z

    .line 29
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->firstSyncKicked:Z

    return p1
.end method

.method private maybeRequestContactsPermission()V
    .locals 5

    .line 90
    const-string v0, "android.permission.READ_CONTACTS"

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_0

    .line 92
    return-void

    .line 94
    :cond_0
    const-string v1, "tzb_ui_prefs"

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    .line 95
    .local v1, "prefs":Landroid/content/SharedPreferences;
    const-string v3, "tzb_asked_contacts"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_1

    return-void

    .line 96
    :cond_1
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/4 v4, 0x1

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 97
    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x15

    invoke-virtual {p0, v0, v2}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->requestPermissions([Ljava/lang/String;I)V

    .line 98
    return-void
.end method

.method private openConversation(Ljava/lang/String;)V
    .locals 2
    .param p1, "groupId"    # Ljava/lang/String;

    .line 120
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 121
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "tzb_group_id"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 122
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->startActivity(Landroid/content/Intent;)V

    .line 123
    return-void
.end method

.method private requery()V
    .locals 2

    .line 126
    new-instance v0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$3;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)V

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)V

    invoke-static {v0, v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 158
    return-void
.end method

.method private updateTitle(I)V
    .locals 5
    .param p1, "state"    # I

    .line 161
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_app_name:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 162
    .local v0, "app":Ljava/lang/String;
    const/4 v1, 0x2

    if-ne p1, v1, :cond_0

    .line 163
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->setTitleBarText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 165
    :cond_0
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_title_with_state:I

    .line 166
    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->connectionStateText(I)Ljava/lang/String;

    move-result-object v3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v0, v1, v4

    const/4 v4, 0x1

    aput-object v3, v1, v4

    .line 165
    invoke-virtual {p0, v2, v1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->setTitleBarText(Ljava/lang/CharSequence;)V

    .line 168
    :goto_0
    return-void
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onConnectionChanged(I)V
    .locals 0
    .param p1, "state"    # I

    .line 184
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->updateTitle(I)V

    .line 185
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 41
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onCreate(Landroid/os/Bundle;)V

    .line 43
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 44
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->finish()V

    .line 45
    return-void

    .line 49
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 50
    return-void

    .line 52
    :cond_1
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_group_list_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->setContentView(I)V

    .line 56
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 57
    new-instance v0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->adapter:Lcom/tzibbur/basic/ui/TzbGroupListAdapter;

    .line 58
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_group_list:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->list:Landroid/widget/ListView;

    .line 59
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->list:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->adapter:Lcom/tzibbur/basic/ui/TzbGroupListAdapter;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 60
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->list:Landroid/widget/ListView;

    sget v1, Lcom/tzibbur/basic/R$id;->tzb_group_list_empty:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setEmptyView(Landroid/view/View;)V

    .line 61
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->list:Landroid/widget/ListView;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupListActivity$1;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 71
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_app_name:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->setupTitleBar(Ljava/lang/CharSequence;Z)V

    .line 73
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_create_first_group_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    .line 74
    .local v0, "createFirst":Landroid/widget/Button;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupListActivity$2;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 81
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->maybeRequestContactsPermission()V

    .line 82
    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 2
    .param p1, "menu"    # Landroid/view/Menu;

    .line 191
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$menu;->tzb_group_list_menu:I

    invoke-virtual {v0, v1, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    .line 192
    const/4 v0, 0x1

    return v0
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onGroupMessagesChanged(Ljava/lang/String;)V
    .locals 0
    .param p1, "groupId"    # Ljava/lang/String;

    .line 179
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->requery()V

    .line 180
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onGroupsChanged()V
    .locals 0

    .line 174
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->requery()V

    .line 175
    return-void
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 4
    .param p1, "item"    # Landroid/view/MenuItem;

    .line 197
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    .line 198
    .local v0, "id":I
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_menu_new_group:I

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    .line 199
    new-instance v1, Landroid/content/Intent;

    const-class v3, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-direct {v1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->startActivity(Landroid/content/Intent;)V

    .line 200
    return v2

    .line 202
    :cond_0
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_menu_refresh:I

    if-ne v0, v1, :cond_1

    .line 203
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/sync/TzbSync;->nudge()V

    .line 204
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    .line 205
    return v2

    .line 207
    :cond_1
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_menu_settings:I

    if-ne v0, v1, :cond_2

    .line 208
    new-instance v1, Landroid/content/Intent;

    const-class v3, Lcom/android/mms/ui/MessagingPreferenceActivity;

    invoke-direct {v1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->startActivity(Landroid/content/Intent;)V

    .line 209
    return v2

    .line 211
    :cond_2
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result v1

    return v1
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 1
    .param p1, "requestCode"    # I
    .param p2, "permissions"    # [Ljava/lang/String;
    .param p3, "grantResults"    # [I

    .line 103
    invoke-super {p0, p1, p2, p3}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 104
    const/16 v0, 0x15

    if-ne p1, v0, :cond_0

    array-length v0, p3

    if-lez v0, :cond_0

    const/4 v0, 0x0

    aget v0, p3, v0

    if-nez v0, :cond_0

    .line 107
    invoke-static {}, Lcom/tzibbur/basic/ui/TzbContactNames;->clearCache()V

    .line 109
    :cond_0
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onStart()V
    .locals 1

    .line 113
    invoke-super {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onStart()V

    .line 114
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->connectionState()I

    move-result v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->updateTitle(I)V

    .line 115
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->nudge()V

    .line 116
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->requery()V

    .line 117
    return-void
.end method
