.class Lcom/tzibbur/basic/ui/TzbConversationActivity$7;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 271
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 4
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 274
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    invoke-virtual {p1, p3}, Landroid/widget/AdapterView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v0

    .line 275
    .local v0, "item":Ljava/lang/Object;
    if-nez v0, :cond_0

    .line 277
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    goto :goto_0

    .line 278
    :cond_0
    instance-of v1, v0, Lcom/tzibbur/basic/store/TzbOutboxItem;

    if-eqz v1, :cond_2

    .line 279
    move-object v1, v0

    check-cast v1, Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 280
    .local v1, "outboxItem":Lcom/tzibbur/basic/store/TzbOutboxItem;
    iget v2, v1, Lcom/tzibbur/basic/store/TzbOutboxItem;->state:I

    const/4 v3, 0x2

    if-ne v2, v3, :cond_1

    .line 281
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v2, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/store/TzbOutboxItem;)V

    .line 284
    .end local v1
    :cond_1
    goto :goto_0

    :cond_2
    instance-of v1, v0, Lcom/tzibbur/basic/model/TzbMessage;

    if-eqz v1, :cond_3

    .line 285
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    move-object v2, v0

    check-cast v2, Lcom/tzibbur/basic/model/TzbMessage;

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1200(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/model/TzbMessage;)V

    goto :goto_0

    .line 286
    :cond_3
    instance-of v1, v0, Lcom/tzibbur/basic/model/TzbCommandResult;

    if-eqz v1, :cond_4

    .line 287
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    move-object v2, v0

    check-cast v2, Lcom/tzibbur/basic/model/TzbCommandResult;

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1300(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/model/TzbCommandResult;)V

    .line 289
    :cond_4
    :goto_0
    return-void
.end method
