.class Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$10;
.super Ljava/lang/Object;
.source "TzbGroupInfoActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->update(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbGroup;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 222
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 1
    .param p1, "error"    # Ljava/lang/Exception;

    .line 231
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 232
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbGroup;)V
    .locals 1
    .param p1, "updated"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 225
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->access$502(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Lcom/tzibbur/basic/model/TzbGroup;)Lcom/tzibbur/basic/model/TzbGroup;

    .line 226
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->access$600(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    .line 227
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 222
    check-cast p1, Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$10;->onResult(Lcom/tzibbur/basic/model/TzbGroup;)V

    return-void
.end method
