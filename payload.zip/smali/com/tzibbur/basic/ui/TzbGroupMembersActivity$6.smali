.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadGroup()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbGroup;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 158
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 0
    .param p1, "error"    # Ljava/lang/Exception;

    .line 181
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbGroup;)V
    .locals 3
    .param p1, "result"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 161
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$502(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbGroup;)Lcom/tzibbur/basic/model/TzbGroup;

    .line 162
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$500(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    if-nez v0, :cond_0

    .line 166
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_no_longer_member:I

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    .line 167
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 168
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->finish()V

    .line 169
    return-void

    .line 171
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$500(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/model/TzbGroup;->isSystem()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 173
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->finish()V

    .line 174
    return-void

    .line 176
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$600(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    .line 177
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$700(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    .line 178
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 158
    check-cast p1, Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;->onResult(Lcom/tzibbur/basic/model/TzbGroup;)V

    return-void
.end method
