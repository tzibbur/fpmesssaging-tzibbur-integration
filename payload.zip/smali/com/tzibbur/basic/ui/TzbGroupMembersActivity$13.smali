.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->submitAdd(Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbMemberAddResult;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

.field final synthetic val$chunk:I

.field final synthetic val$gid:Ljava/lang/String;

.field final synthetic val$phones:Ljava/util/List;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/util/List;ILjava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 357
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->val$phones:Ljava/util/List;

    iput p3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->val$chunk:I

    iput-object p4, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbMemberAddResult;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 360
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 361
    .local v0, "added":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMember;>;"
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 362
    .local v1, "already":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 363
    .local v2, "notFound":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const/4 v3, 0x0

    .local v3, "from":I
    :goto_0
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->val$phones:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_0

    .line 364
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->val$phones:Ljava/util/List;

    iget v5, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->val$chunk:I

    add-int/2addr v5, v3

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->val$phones:Ljava/util/List;

    .line 365
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v5

    invoke-interface {v4, v3, v5}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v4

    .line 366
    .local v4, "batch":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v5, v5, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v5}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v5

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->val$gid:Ljava/lang/String;

    const/4 v7, 0x0

    invoke-interface {v5, v6, v4, v7}, Lcom/tzibbur/basic/net/TzbApi;->addMembers(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMemberAddResult;

    move-result-object v5

    .line 367
    .local v5, "part":Lcom/tzibbur/basic/model/TzbMemberAddResult;
    iget-object v6, v5, Lcom/tzibbur/basic/model/TzbMemberAddResult;->added:Ljava/util/List;

    invoke-interface {v0, v6}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 368
    iget-object v6, v5, Lcom/tzibbur/basic/model/TzbMemberAddResult;->alreadyMembers:Ljava/util/List;

    invoke-interface {v1, v6}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 369
    iget-object v6, v5, Lcom/tzibbur/basic/model/TzbMemberAddResult;->notFound:Ljava/util/List;

    invoke-interface {v2, v6}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 363
    .end local v4
    .end local v5
    iget v4, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->val$chunk:I

    add-int/2addr v3, v4

    goto :goto_0

    .line 371
    .end local v3
    :cond_0
    new-instance v3, Lcom/tzibbur/basic/model/TzbMemberAddResult;

    invoke-direct {v3, v0, v1, v2}, Lcom/tzibbur/basic/model/TzbMemberAddResult;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    return-object v3
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 357
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;->call()Lcom/tzibbur/basic/model/TzbMemberAddResult;

    move-result-object v0

    return-object v0
.end method
