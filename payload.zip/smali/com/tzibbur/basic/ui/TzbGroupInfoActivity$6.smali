.class Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$6;
.super Ljava/lang/Object;
.source "TzbGroupInfoActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->loadGroup()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbGroup;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 120
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$6;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbGroup;
    .locals 2

    .line 123
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$6;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbStore;->group(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 120
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$6;->call()Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    return-object v0
.end method
