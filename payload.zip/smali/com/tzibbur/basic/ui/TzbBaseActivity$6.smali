.class Lcom/tzibbur/basic/ui/TzbBaseActivity$6;
.super Ljava/lang/Object;
.source "TzbBaseActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbBaseActivity;->handleUnauthorized()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbBaseActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbBaseActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbBaseActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 495
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbBaseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 498
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbBaseActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->signOutLocally()V

    .line 499
    return-void
.end method
