.class Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$1;
.super Ljava/lang/Object;
.source "TzbGroupCreateActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 66
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 69
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$000(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    .line 70
    return-void
.end method
