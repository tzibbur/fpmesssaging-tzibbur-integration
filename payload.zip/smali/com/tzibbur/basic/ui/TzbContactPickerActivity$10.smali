.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->sweepNext()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

.field final synthetic val$chunk:Ljava/util/List;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/util/List;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 352
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->val$chunk:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    .line 356
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->val$chunk:Ljava/util/List;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/net/TzbApi;->contactsCheck(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    .line 357
    .local v0, "registered":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->val$chunk:Ljava/util/List;

    invoke-static {v1, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1500(Ljava/util/List;Ljava/util/List;)Ljava/util/Set;

    move-result-object v1

    .line 358
    .local v1, "matched":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->val$chunk:Ljava/util/List;

    invoke-static {v2, v3, v1}, Lcom/tzibbur/basic/ui/TzbContactsSource;->putCache(Landroid/content/Context;Ljava/util/Collection;Ljava/util/Set;)V

    .line 359
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 360
    .local v2, "matchedInOrder":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->val$chunk:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 361
    .local v4, "phone":Ljava/lang/String;
    invoke-interface {v1, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 362
    .end local v4
    :cond_0
    goto :goto_0

    .line 363
    :cond_1
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    new-instance v4, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;

    invoke-direct {v4, p0, v2}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;Ljava/util/List;)V

    invoke-static {v3, v4}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$800(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/lang/Runnable;)V

    .line 382
    .end local v0
    .end local v1
    .end local v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    .line 374
    :catch_0
    move-exception v0

    .line 375
    .local v0, "error":Ljava/lang/Exception;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$2;

    invoke-direct {v2, p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$2;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;Ljava/lang/Exception;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$800(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/lang/Runnable;)V

    .line 383
    .end local v0
    :goto_1
    return-void
.end method
