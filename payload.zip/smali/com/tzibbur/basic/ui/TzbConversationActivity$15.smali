.class Lcom/tzibbur/basic/ui/TzbConversationActivity$15;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->dropGroupAndFinish()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 538
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$15;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 541
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$15;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbStore;->removeGroup(Ljava/lang/String;)V

    .line 542
    return-void
.end method
