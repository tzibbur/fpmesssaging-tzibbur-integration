.class Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;
.super Ljava/lang/Object;
.source "TzbGroupInfoActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->update(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbGroup;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

.field final synthetic val$gid:Ljava/lang/String;

.field final synthetic val$name:Ljava/lang/String;

.field final synthetic val$whoCanAddMembers:Ljava/lang/String;

.field final synthetic val$whoCanPost:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 215
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->val$gid:Ljava/lang/String;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->val$name:Ljava/lang/String;

    iput-object p4, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->val$whoCanPost:Ljava/lang/String;

    iput-object p5, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->val$whoCanAddMembers:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbGroup;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 218
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->val$gid:Ljava/lang/String;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->val$name:Ljava/lang/String;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->val$whoCanPost:Ljava/lang/String;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->val$whoCanAddMembers:Ljava/lang/String;

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tzibbur/basic/net/TzbApi;->updateGroup(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    .line 219
    .local v0, "updated":Lcom/tzibbur/basic/model/TzbGroup;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v1

    invoke-interface {v1, v0}, Lcom/tzibbur/basic/store/TzbStore;->upsertGroup(Lcom/tzibbur/basic/model/TzbGroup;)V

    .line 220
    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 215
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;->call()Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    return-object v0
.end method
