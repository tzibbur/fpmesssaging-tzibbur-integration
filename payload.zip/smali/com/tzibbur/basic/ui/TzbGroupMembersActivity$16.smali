.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$16;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->confirmRemove(Lcom/tzibbur/basic/model/TzbMember;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

.field final synthetic val$member:Lcom/tzibbur/basic/model/TzbMember;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 465
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$16;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$16;->val$member:Lcom/tzibbur/basic/model/TzbMember;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 2
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 468
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$16;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$16;->val$member:Lcom/tzibbur/basic/model/TzbMember;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1900(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)V

    .line 469
    return-void
.end method
