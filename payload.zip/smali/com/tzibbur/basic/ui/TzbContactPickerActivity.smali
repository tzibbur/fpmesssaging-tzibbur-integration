.class public Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
.super Lcom/tzibbur/basic/ui/TzbBaseActivity;
.source "TzbContactPickerActivity.java"


# static fields
.field private static final CHUNK:I = 0x64

.field public static final EXTRA_PHONES:Ljava/lang/String; = "tzb_phones"

.field private static final RC_READ_CONTACTS:I = 0x1f

.field private static final REQ_SYSTEM_PICK:I = 0x20

.field public static final RESULT_TYPE_INSTEAD:I = 0x1


# instance fields
.field private adapter:Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

.field private addBtn:Landroid/widget/Button;

.field private browseBtn:Landroid/widget/Button;

.field private cancelBtn:Landroid/widget/Button;

.field private checkedCount:I

.field private destroyed:Z

.field private earliestResumeAt:J

.field private list:Landroid/widget/ListView;

.field private manualBtn:Landroid/widget/Button;

.field private final namesByPhone:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final pending:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private resumeBtn:Landroid/widget/Button;

.field private searchEdit:Landroid/widget/EditText;

.field private settingsBtn:Landroid/widget/Button;

.field private statusView:Landroid/widget/TextView;

.field private sweeping:Z

.field private totalToCheck:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;-><init>()V

    .line 75
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->namesByPhone:Ljava/util/Map;

    .line 77
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->adapter:Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    return-object v0
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->updateAddButton()V

    return-void
.end method

.method static synthetic access$1000(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/util/List;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .param p1, "x1"    # Ljava/util/List;

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->buildRows(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$1100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    return-object v0
.end method

.method static synthetic access$1202(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;I)I
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .param p1, "x1"    # I

    .line 52
    iput p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->checkedCount:I

    return p1
.end method

.method static synthetic access$1212(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;I)I
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .param p1, "x1"    # I

    .line 52
    iget v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->checkedCount:I

    add-int/2addr v0, p1

    iput v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->checkedCount:I

    return v0
.end method

.method static synthetic access$1302(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;I)I
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .param p1, "x1"    # I

    .line 52
    iput p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->totalToCheck:I

    return p1
.end method

.method static synthetic access$1400(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->sweepNext()V

    return-void
.end method

.method static synthetic access$1500(Ljava/util/List;Ljava/util/List;)Ljava/util/Set;
    .locals 1
    .param p0, "x0"    # Ljava/util/List;
    .param p1, "x1"    # Ljava/util/List;

    .line 52
    invoke-static {p0, p1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->matchBack(Ljava/util/List;Ljava/util/List;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$1602(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .param p1, "x1"    # Z

    .line 52
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->sweeping:Z

    return p1
.end method

.method static synthetic access$1700(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->updateProgress()V

    return-void
.end method

.method static synthetic access$1800(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/lang/Exception;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .param p1, "x1"    # Ljava/lang/Exception;

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->onSweepError(Ljava/lang/Exception;)V

    return-void
.end method

.method static synthetic access$1900(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->destroyed:Z

    return v0
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->browseSystemPicker()V

    return-void
.end method

.method static synthetic access$2000(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusBelowSearch()V

    return-void
.end method

.method static synthetic access$2100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Landroid/widget/ListView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->list:Landroid/widget/ListView;

    return-object v0
.end method

.method static synthetic access$2200(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusAboveList()V

    return-void
.end method

.method static synthetic access$2300(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusBelowList()V

    return-void
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->openAppSettings()V

    return-void
.end method

.method static synthetic access$400(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeSweep()V

    return-void
.end method

.method static synthetic access$500(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->manualBtn:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusFirstAvailable()V

    return-void
.end method

.method static synthetic access$800(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/lang/Runnable;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .param p1, "x1"    # Ljava/lang/Runnable;

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->post(Ljava/lang/Runnable;)V

    return-void
.end method

.method static synthetic access$900(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Ljava/util/Map;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->namesByPhone:Ljava/util/Map;

    return-object v0
.end method

.method private browseSystemPicker()V
    .locals 4

    .line 233
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.PICK"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 234
    const-string v1, "vnd.android.cursor.dir/phone_v2"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 236
    .local v0, "pick":Landroid/content/Intent;
    const/16 v1, 0x20

    :try_start_0
    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 239
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 237
    :catch_0
    move-exception v1

    .line 238
    .local v1, "e":Landroid/content/ActivityNotFoundException;
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_contact_pick_failed:I

    const/4 v3, 0x1

    invoke-static {p0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 240
    .end local v1
    :goto_0
    return-void
.end method

.method private buildRows(Ljava/util/List;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;",
            ">;"
        }
    .end annotation

    .line 464
    .local p1, "phones":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    new-instance v0, Ljava/util/ArrayList;

    .line 465
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 466
    .local v0, "rows":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;>;"
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 467
    .local v2, "phone":Ljava/lang/String;
    new-instance v3, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->namesByPhone:Ljava/util/Map;

    invoke-interface {v4, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-direct {v3, v2, v4}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 468
    .end local v2
    goto :goto_0

    .line 469
    :cond_0
    return-object v0
.end method

.method private finishSweep()V
    .locals 6

    .line 443
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeBtn:Landroid/widget/Button;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 444
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->adapter:Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->totalMatches()I

    move-result v0

    .line 445
    .local v0, "matches":I
    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 446
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_contacts_empty_matches:I

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(I)V

    .line 447
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->manualBtn:Landroid/widget/Button;

    invoke-virtual {v2, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 448
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusFirstAvailable()V

    goto :goto_0

    .line 450
    :cond_0
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_contacts_found:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    aput-object v4, v5, v1

    invoke-virtual {p0, v3, v5}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 452
    :goto_0
    return-void
.end method

.method private focusAboveList()V
    .locals 1

    .line 591
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->settingsBtn:Landroid/widget/Button;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->manualBtn:Landroid/widget/Button;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->browseBtn:Landroid/widget/Button;

    .line 592
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeBtn:Landroid/widget/Button;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 595
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->searchEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 596
    return-void

    .line 593
    :cond_1
    :goto_0
    return-void
.end method

.method private focusBelowList()V
    .locals 1

    .line 518
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->addBtn:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->addBtn:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 519
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->addBtn:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    goto :goto_0

    .line 521
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->cancelBtn:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    .line 523
    :goto_0
    return-void
.end method

.method private focusBelowSearch()V
    .locals 1

    .line 578
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeBtn:Landroid/widget/Button;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->browseBtn:Landroid/widget/Button;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->manualBtn:Landroid/widget/Button;

    .line 579
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->settingsBtn:Landroid/widget/Button;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    .line 582
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getCount()I

    move-result v0

    if-lez v0, :cond_1

    .line 583
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->requestFocus()Z

    goto :goto_0

    .line 585
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->addBtn:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    .line 587
    :goto_0
    return-void

    .line 580
    :cond_2
    :goto_1
    return-void
.end method

.method private focusFirstAvailable()V
    .locals 1

    .line 600
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->browseBtn:Landroid/widget/Button;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->manualBtn:Landroid/widget/Button;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->settingsBtn:Landroid/widget/Button;

    .line 601
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusIfVisible(Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 604
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->searchEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 605
    return-void

    .line 602
    :cond_1
    :goto_0
    return-void
.end method

.method private focusIfVisible(Landroid/view/View;)Z
    .locals 1
    .param p1, "view"    # Landroid/view/View;

    .line 608
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private hasContactsPermission()Z
    .locals 1

    .line 202
    const-string v0, "android.permission.READ_CONTACTS"

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private static matchBack(Ljava/util/List;Ljava/util/List;)Ljava/util/Set;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 477
    .local p0, "submitted":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .local p1, "registered":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 478
    .local v0, "byTail":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 479
    .local v2, "phone":Ljava/lang/String;
    invoke-static {v2}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->tail(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 480
    .end local v2
    goto :goto_0

    .line 481
    :cond_0
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 482
    .local v1, "matched":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 483
    .local v3, "e164":Ljava/lang/String;
    invoke-static {v3}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->tail(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 484
    .local v4, "original":Ljava/lang/String;
    if-eqz v4, :cond_1

    invoke-interface {v1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 485
    .end local v3
    .end local v4
    :cond_1
    goto :goto_1

    .line 486
    :cond_2
    return-object v1
.end method

.method private onSweepError(Ljava/lang/Exception;)V
    .locals 10
    .param p1, "error"    # Ljava/lang/Exception;

    .line 388
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_5

    .line 389
    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    .line 390
    .local v0, "problem":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isUnauthorized()Z

    move-result v3

    if-eqz v3, :cond_0

    .line 391
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 392
    return-void

    .line 394
    :cond_0
    const-string v3, "contact_discovery_unavailable"

    iget-object v4, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    iget-object v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    .line 395
    const-string v4, "forbidden"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_1

    .line 406
    :cond_1
    const-string v3, "contacts_batch_too_large"

    iget-object v4, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    .line 409
    iget-object v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    const-string v4, "maxPhones"

    invoke-virtual {v3, v4, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    .line 410
    .local v3, "maxPhones":I
    if-lez v3, :cond_2

    .line 411
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1, v3}, Lcom/tzibbur/basic/store/TzbSession;->setContactsCheckMaxPhones(I)V

    .line 412
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->sweepNext()V

    .line 413
    return-void

    .line 416
    .end local v3
    :cond_2
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isRateLimited()Z

    move-result v3

    if-eqz v3, :cond_5

    .line 418
    iget v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    if-lez v3, :cond_3

    iget v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    goto :goto_0

    :cond_3
    const/16 v3, 0x3c

    .line 419
    .local v3, "wait":I
    :goto_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    int-to-long v6, v3

    const-wide/16 v8, 0x3e8

    mul-long/2addr v6, v8

    add-long/2addr v4, v6

    iput-wide v4, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->earliestResumeAt:J

    .line 420
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_contacts_paused:I

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    new-array v1, v1, [Ljava/lang/Object;

    aput-object v6, v1, v2

    invoke-virtual {p0, v5, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 421
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeBtn:Landroid/widget/Button;

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 422
    return-void

    .line 399
    .end local v3
    :cond_4
    :goto_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1, v2}, Lcom/tzibbur/basic/store/TzbSession;->setContactDiscovery(Z)V

    .line 400
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 401
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_contacts_unavailable:I

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(I)V

    .line 402
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeBtn:Landroid/widget/Button;

    const/16 v3, 0x8

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 403
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->manualBtn:Landroid/widget/Button;

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 404
    return-void

    .line 426
    .end local v0
    :cond_5
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_contacts_paused:I

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v1, v1, [Ljava/lang/Object;

    aput-object v4, v1, v2

    invoke-virtual {p0, v3, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 427
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeBtn:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 428
    return-void
.end method

.method private openAppSettings()V
    .locals 4

    .line 272
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.APPLICATION_DETAILS_SETTINGS"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "package"

    .line 273
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    move-result-object v0

    .line 272
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->startActivity(Landroid/content/Intent;)V

    .line 277
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 274
    :catch_0
    move-exception v0

    .line 276
    .local v0, "e":Ljava/lang/RuntimeException;
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_not_available_on_device:I

    const/4 v2, 0x1

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 278
    .end local v0
    :goto_0
    return-void
.end method

.method private post(Ljava/lang/Runnable;)V
    .locals 1
    .param p1, "task"    # Ljava/lang/Runnable;

    .line 496
    new-instance v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$11;

    invoke-direct {v0, p0, p1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$11;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/lang/Runnable;)V

    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbBg;->onMain(Ljava/lang/Runnable;)V

    .line 502
    return-void
.end method

.method private resumeSweep()V
    .locals 4

    .line 431
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 432
    .local v0, "now":J
    iget-wide v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->earliestResumeAt:J

    cmp-long v2, v0, v2

    if-gez v2, :cond_0

    .line 434
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_err_rate_limited:I

    const/4 v3, 0x1

    invoke-static {p0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 435
    return-void

    .line 437
    :cond_0
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeBtn:Landroid/widget/Button;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 438
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->updateProgress()V

    .line 439
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->sweepNext()V

    .line 440
    return-void
.end method

.method private startDiscovery()V
    .locals 2

    .line 283
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_contacts_reading:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 284
    new-instance v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/lang/Runnable;)V

    .line 337
    return-void
.end method

.method private sweepNext()V
    .locals 4

    .line 344
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->destroyed:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->sweeping:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 345
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 346
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->finishSweep()V

    .line 347
    return-void

    .line 349
    :cond_1
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->sweeping:Z

    .line 350
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    .line 351
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/16 v3, 0x64

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v3, 0x0

    invoke-interface {v1, v3, v2}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 352
    .local v0, "chunk":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/util/List;)V

    invoke-static {v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/lang/Runnable;)V

    .line 385
    return-void

    .line 344
    .end local v0
    :cond_2
    :goto_0
    return-void
.end method

.method private static tail(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "phone"    # Ljava/lang/String;

    .line 491
    const-string v0, ""

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const-string v1, "[^0-9]"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 492
    .local v0, "digits":Ljava/lang/String;
    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x9

    if-le v1, v2, :cond_1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    :cond_1
    move-object v1, v0

    :goto_1
    return-object v1
.end method

.method private updateAddButton()V
    .locals 7

    .line 505
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->adapter:Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->selectedCount()I

    move-result v0

    .line 506
    .local v0, "count":I
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->addBtn:Landroid/widget/Button;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_contacts_add_selected:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x1

    new-array v5, v4, [Ljava/lang/Object;

    const/4 v6, 0x0

    aput-object v3, v5, v6

    invoke-virtual {p0, v2, v5}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 507
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->addBtn:Landroid/widget/Button;

    if-lez v0, :cond_0

    goto :goto_0

    :cond_0
    move v4, v6

    :goto_0
    invoke-virtual {v1, v4}, Landroid/widget/Button;->setEnabled(Z)V

    .line 508
    return-void
.end method

.method private updateProgress()V
    .locals 7

    .line 455
    iget v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->totalToCheck:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 456
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_contacts_progress:I

    iget v4, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->checkedCount:I

    .line 457
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    iget v5, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->totalToCheck:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v6, 0x2

    new-array v6, v6, [Ljava/lang/Object;

    aput-object v4, v6, v1

    aput-object v5, v6, v2

    .line 456
    invoke-virtual {p0, v3, v6}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 458
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->pending:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 459
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_contacts_found:I

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->adapter:Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    invoke-virtual {v4}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->totalMatches()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v4, v2, v1

    invoke-virtual {p0, v3, v2}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 461
    :cond_1
    :goto_0
    return-void
.end method

.method private wireKeyChain()V
    .locals 2

    .line 526
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->searchEdit:Landroid/widget/EditText;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$12;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$12;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 537
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->list:Landroid/widget/ListView;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$13;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$13;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 554
    new-instance v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$14;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$14;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    .line 569
    .local v0, "upToList":Landroid/view/View$OnKeyListener;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->addBtn:Landroid/widget/Button;

    invoke-virtual {v1, v0}, Landroid/widget/Button;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 570
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->cancelBtn:Landroid/widget/Button;

    invoke-virtual {v1, v0}, Landroid/widget/Button;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 571
    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 10
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 244
    invoke-super {p0, p1, p2, p3}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onActivityResult(IILandroid/content/Intent;)V

    .line 245
    const/16 v0, 0x20

    if-ne p1, v0, :cond_6

    const/4 v1, -0x1

    if-ne p2, v1, :cond_6

    if-nez p3, :cond_0

    goto :goto_3

    .line 246
    :cond_0
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    .line 247
    .local v3, "uri":Landroid/net/Uri;
    if-nez v3, :cond_1

    return-void

    .line 248
    :cond_1
    const/4 v8, 0x0

    .line 249
    .local v8, "number":Ljava/lang/String;
    const/4 v9, 0x0

    .line 251
    .local v9, "cursor":Landroid/database/Cursor;
    :try_start_0
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v0, "data1"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v2 .. v7}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    move-object v9, v0

    .line 254
    if-eqz v9, :cond_2

    invoke-interface {v9}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 255
    const/4 v0, 0x0

    invoke-interface {v9, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v8, v0

    .line 261
    :cond_2
    if-eqz v9, :cond_3

    :goto_0
    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_2

    .line 257
    :catch_0
    move-exception v0

    .line 259
    .local v0, "e":Ljava/lang/SecurityException;
    :try_start_1
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_contact_pick_failed:I

    const/4 v4, 0x1

    invoke-static {p0, v2, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 261
    .end local v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v9, :cond_3

    goto :goto_0

    .line 263
    :cond_3
    :goto_1
    if-nez v8, :cond_4

    return-void

    .line 264
    :cond_4
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 265
    .local v0, "phones":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    invoke-static {v8}, Lcom/tzibbur/basic/ui/TzbContactsSource;->normalize(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 266
    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    const-string v4, "tzb_phones"

    invoke-virtual {v2, v4, v0}, Landroid/content/Intent;->putStringArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->setResult(ILandroid/content/Intent;)V

    .line 267
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->finish()V

    .line 268
    return-void

    .line 261
    .end local v0
    :goto_2
    if-eqz v9, :cond_5

    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    .line 262
    :cond_5
    throw v0

    .line 245
    .end local v3
    .end local v8
    .end local v9
    :cond_6
    :goto_3
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 86
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onCreate(Landroid/os/Bundle;)V

    .line 88
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 89
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->finish()V

    .line 90
    return-void

    .line 94
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 95
    return-void

    .line 97
    :cond_1
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_contact_picker_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->setContentView(I)V

    .line 100
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 102
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_contacts_title:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->setupTitleBar(Ljava/lang/CharSequence;Z)V

    .line 104
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_contacts_list:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->list:Landroid/widget/ListView;

    .line 105
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_contacts_search:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->searchEdit:Landroid/widget/EditText;

    .line 106
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_contacts_status:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    .line 107
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_contacts_resume_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeBtn:Landroid/widget/Button;

    .line 108
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_contacts_browse_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->browseBtn:Landroid/widget/Button;

    .line 109
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_contacts_settings_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->settingsBtn:Landroid/widget/Button;

    .line 110
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_contacts_manual_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->manualBtn:Landroid/widget/Button;

    .line 111
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_contacts_add_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->addBtn:Landroid/widget/Button;

    .line 112
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_contacts_cancel_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->cancelBtn:Landroid/widget/Button;

    .line 113
    const/4 v0, 0x1

    new-array v0, v0, [Landroid/widget/EditText;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->searchEdit:Landroid/widget/EditText;

    aput-object v2, v0, v1

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->attachAutoIme([Landroid/widget/EditText;)V

    .line 117
    new-instance v0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->adapter:Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    .line 118
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setItemsCanFocus(Z)V

    .line 119
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->list:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->adapter:Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 120
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->list:Landroid/widget/ListView;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$1;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 127
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->searchEdit:Landroid/widget/EditText;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$2;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 140
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->addBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$3;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 150
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->cancelBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$4;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 156
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->manualBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$5;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$5;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 163
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->browseBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$6;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 169
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->settingsBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$7;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$7;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 175
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->resumeBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$8;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$8;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 182
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->wireKeyChain()V

    .line 183
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->updateAddButton()V

    .line 187
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->hasContactsPermission()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 188
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->startDiscovery()V

    goto :goto_0

    .line 189
    :cond_2
    if-nez p1, :cond_3

    .line 190
    const-string v0, "android.permission.READ_CONTACTS"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x1f

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->requestPermissions([Ljava/lang/String;I)V

    .line 193
    :cond_3
    :goto_0
    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 197
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->destroyed:Z

    .line 198
    invoke-super {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onDestroy()V

    .line 199
    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 3
    .param p1, "requestCode"    # I
    .param p2, "permissions"    # [Ljava/lang/String;
    .param p3, "grantResults"    # [I

    .line 209
    invoke-super {p0, p1, p2, p3}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 210
    const/16 v0, 0x1f

    if-eq p1, v0, :cond_0

    return-void

    .line 211
    :cond_0
    array-length v0, p3

    const/4 v1, 0x0

    if-lez v0, :cond_1

    aget v0, p3, v1

    if-nez v0, :cond_1

    .line 212
    invoke-static {}, Lcom/tzibbur/basic/ui/TzbContactNames;->clearCache()V

    .line 213
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->startDiscovery()V

    .line 214
    return-void

    .line 218
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->statusView:Landroid/widget/TextView;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_contacts_permission_denied:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(I)V

    .line 219
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->browseBtn:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 220
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->manualBtn:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 221
    const-string v0, "android.permission.READ_CONTACTS"

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->shouldShowRequestPermissionRationale(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 222
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->settingsBtn:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 224
    :cond_2
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->focusFirstAvailable()V

    .line 225
    return-void
.end method
