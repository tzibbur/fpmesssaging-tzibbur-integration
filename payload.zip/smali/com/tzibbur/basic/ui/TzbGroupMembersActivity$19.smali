.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->changeRole(Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbMember;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

.field final synthetic val$gid:Ljava/lang/String;

.field final synthetic val$member:Lcom/tzibbur/basic/model/TzbMember;

.field final synthetic val$role:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/lang/String;Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 499
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;->val$gid:Ljava/lang/String;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;->val$member:Lcom/tzibbur/basic/model/TzbMember;

    iput-object p4, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;->val$role:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbMember;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 502
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;->val$gid:Ljava/lang/String;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;->val$member:Lcom/tzibbur/basic/model/TzbMember;

    iget-object v2, v2, Lcom/tzibbur/basic/model/TzbMember;->userId:Ljava/lang/String;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;->val$role:Ljava/lang/String;

    invoke-interface {v0, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbApi;->setRole(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMember;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 499
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;->call()Lcom/tzibbur/basic/model/TzbMember;

    move-result-object v0

    return-object v0
.end method
