.class public Lcom/tzibbur/basic/ui/TzbAboutActivity;
.super Lcom/android/mms/tzib/TzibAboutScreen;
.source "TzbAboutActivity.java"

.method public constructor <init>()V
    .locals 0
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibAboutScreen;-><init>()V
    return-void
.end method
