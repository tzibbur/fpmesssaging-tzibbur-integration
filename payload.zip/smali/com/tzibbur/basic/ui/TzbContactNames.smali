.class public final Lcom/tzibbur/basic/ui/TzbContactNames;
.super Ljava/lang/Object;
.source "TzbContactNames.java"


# static fields
.field private static final CACHE:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 22
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/tzibbur/basic/ui/TzbContactNames;->CACHE:Ljava/util/Map;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 65
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static clearCache()V
    .locals 2

    .line 60
    sget-object v0, Lcom/tzibbur/basic/ui/TzbContactNames;->CACHE:Ljava/util/Map;

    monitor-enter v0

    .line 61
    :try_start_0
    sget-object v1, Lcom/tzibbur/basic/ui/TzbContactNames;->CACHE:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    .line 62
    monitor-exit v0

    .line 63
    return-void

    .line 62
    :catchall_0
    move-exception v1

    monitor-exit v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method public static lookup(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 9
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "phoneE164"    # Ljava/lang/String;

    .line 30
    if-nez p1, :cond_0

    const/4 v0, 0x0

    return-object v0

    .line 31
    :cond_0
    sget-object v1, Lcom/tzibbur/basic/ui/TzbContactNames;->CACHE:Ljava/util/Map;

    monitor-enter v1

    .line 32
    :try_start_0
    sget-object v0, Lcom/tzibbur/basic/ui/TzbContactNames;->CACHE:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lcom/tzibbur/basic/ui/TzbContactNames;->CACHE:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    monitor-exit v1

    return-object v0

    .line 33
    :cond_1
    monitor-exit v1

    .line 34
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const/4 v1, 0x0

    .line 35
    .local v1, "name":Ljava/lang/String;
    const/4 v2, 0x0

    .line 37
    .local v2, "cursor":Landroid/database/Cursor;
    :try_start_1
    sget-object v0, Landroid/provider/ContactsContract$PhoneLookup;->CONTENT_FILTER_URI:Landroid/net/Uri;

    .line 38
    invoke-static {p1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 37
    invoke-static {v0, v3}, Landroid/net/Uri;->withAppendedPath(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    move-object v4, v0

    .line 39
    .local v4, "uri":Landroid/net/Uri;
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const-string v0, "display_name"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v3 .. v8}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    move-object v2, v0

    .line 42
    if-eqz v2, :cond_2

    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 43
    const/4 v0, 0x0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v1, v0

    .line 50
    .end local v4
    :cond_2
    if-eqz v2, :cond_4

    goto :goto_0

    :catchall_0
    move-exception v0

    if-eqz v2, :cond_3

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 51
    :cond_3
    throw v0

    .line 47
    :catch_0
    move-exception v0

    .line 50
    if-eqz v2, :cond_4

    goto :goto_0

    .line 45
    :catch_1
    move-exception v0

    .line 50
    if-eqz v2, :cond_4

    :goto_0
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 52
    :cond_4
    move-object v3, v2

    move-object v2, v1

    .end local v1
    .local v2, "name":Ljava/lang/String;
    .local v3, "cursor":Landroid/database/Cursor;
    sget-object v4, Lcom/tzibbur/basic/ui/TzbContactNames;->CACHE:Ljava/util/Map;

    monitor-enter v4

    .line 53
    :try_start_2
    sget-object v0, Lcom/tzibbur/basic/ui/TzbContactNames;->CACHE:Ljava/util/Map;

    invoke-interface {v0, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    monitor-exit v4

    .line 55
    return-object v2

    .line 54
    :catchall_1
    move-exception v0

    monitor-exit v4

    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw v0

    .line 33
    .end local v2
    .end local v3
    :catchall_2
    move-exception v0

    :try_start_3
    monitor-exit v1

    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    throw v0
.end method
