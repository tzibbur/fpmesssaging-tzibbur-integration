.class Lcom/tzibbur/basic/ui/TzbConversationActivity$13;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadGroup()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbGroup;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 504
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbGroup;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 507
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbStore;->group(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    .line 508
    .local v0, "cached":Lcom/tzibbur/basic/model/TzbGroup;
    if-eqz v0, :cond_0

    return-object v0

    .line 511
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;->val$gid:Ljava/lang/String;

    invoke-interface {v1, v2}, Lcom/tzibbur/basic/net/TzbApi;->getGroup(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v1

    .line 512
    .local v1, "fetched":Lcom/tzibbur/basic/model/TzbGroup;
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v2, v2, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v2}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v2

    invoke-interface {v2, v1}, Lcom/tzibbur/basic/store/TzbStore;->upsertGroup(Lcom/tzibbur/basic/model/TzbGroup;)V

    .line 513
    return-object v1
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 504
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;->call()Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    return-object v0
.end method
