.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$12;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->showAddDialog()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 308
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$12;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 312
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$12;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 313
    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1300(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 312
    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->stripPhoneFormatting(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 314
    .local v0, "typed":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    .line 315
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$12;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1400(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/util/List;)V

    .line 317
    :cond_0
    return-void
.end method
