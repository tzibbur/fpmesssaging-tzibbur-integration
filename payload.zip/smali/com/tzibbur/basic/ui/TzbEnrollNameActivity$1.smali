.class Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$1;
.super Ljava/lang/Object;
.source "TzbEnrollNameActivity.java"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 83
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 2
    .param p1, "s"    # Landroid/text/Editable;

    .line 94
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->access$000(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V

    .line 96
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->access$100(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)Landroid/widget/TextView;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 97
    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0
    .param p1, "s"    # Ljava/lang/CharSequence;
    .param p2, "start"    # I
    .param p3, "count"    # I
    .param p4, "after"    # I

    .line 86
    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0
    .param p1, "s"    # Ljava/lang/CharSequence;
    .param p2, "start"    # I
    .param p3, "before"    # I
    .param p4, "count"    # I

    .line 90
    return-void
.end method
