.class Lcom/tzibbur/basic/ui/TzbApplyActivity$9;
.super Ljava/lang/Object;
.source "TzbApplyActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;->submit()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbApplication;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

.field final synthetic val$displayName:Ljava/lang/String;

.field final synthetic val$notes:Ljava/lang/String;

.field final synthetic val$number:Ljava/lang/String;

.field final synthetic val$organization:Ljava/lang/String;

.field final synthetic val$reason:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 445
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$number:Ljava/lang/String;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$displayName:Ljava/lang/String;

    iput-object p4, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$reason:Ljava/lang/String;

    iput-object p5, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$organization:Ljava/lang/String;

    iput-object p6, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$notes:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbApplication;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 448
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$number:Ljava/lang/String;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$displayName:Ljava/lang/String;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$reason:Ljava/lang/String;

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$organization:Ljava/lang/String;

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->val$notes:Ljava/lang/String;

    sget-object v7, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-interface/range {v1 .. v7}, Lcom/tzibbur/basic/net/TzbApi;->submitApplication(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbApplication;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 445
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;->call()Lcom/tzibbur/basic/model/TzbApplication;

    move-result-object v0

    return-object v0
.end method
