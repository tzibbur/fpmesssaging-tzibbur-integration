.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$7;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->refreshLegalDocuments()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbLegalDocument;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

.field final synthetic val$cache:Lcom/tzibbur/basic/store/TzbLegalCache;

.field final synthetic val$key:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Lcom/tzibbur/basic/store/TzbLegalCache;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 130
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$7;->val$cache:Lcom/tzibbur/basic/store/TzbLegalCache;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$7;->val$key:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 0
    .param p1, "error"    # Ljava/lang/Exception;

    .line 139
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbLegalDocument;)V
    .locals 5
    .param p1, "doc"    # Lcom/tzibbur/basic/model/TzbLegalDocument;

    .line 133
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$7;->val$cache:Lcom/tzibbur/basic/store/TzbLegalCache;

    new-instance v1, Lcom/tzibbur/basic/model/TzbLegalDocument;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$7;->val$key:Ljava/lang/String;

    iget-object v3, p1, Lcom/tzibbur/basic/model/TzbLegalDocument;->text:Ljava/lang/String;

    iget-object v4, p1, Lcom/tzibbur/basic/model/TzbLegalDocument;->checksum:Ljava/lang/String;

    invoke-direct {v1, v2, v3, v4}, Lcom/tzibbur/basic/model/TzbLegalDocument;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/store/TzbLegalCache;->put(Lcom/tzibbur/basic/model/TzbLegalDocument;)V

    .line 134
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 130
    check-cast p1, Lcom/tzibbur/basic/model/TzbLegalDocument;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$7;->onResult(Lcom/tzibbur/basic/model/TzbLegalDocument;)V

    return-void
.end method
