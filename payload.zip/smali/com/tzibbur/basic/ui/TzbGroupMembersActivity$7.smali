.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadMembers(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbPage<",
        "Lcom/tzibbur/basic/model/TzbMember;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

.field final synthetic val$cursor:Ljava/lang/String;

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 210
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;->val$gid:Ljava/lang/String;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;->val$cursor:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbPage;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tzibbur/basic/model/TzbPage<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 213
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;->val$gid:Ljava/lang/String;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;->val$cursor:Ljava/lang/String;

    const/16 v3, 0x32

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbApi;->listMembers(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)Lcom/tzibbur/basic/model/TzbPage;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 210
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;->call()Lcom/tzibbur/basic/model/TzbPage;

    move-result-object v0

    return-object v0
.end method
