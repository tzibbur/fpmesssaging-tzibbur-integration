.class public final Lcom/tzibbur/basic/ui/TzbTctMenuBar;
.super Ljava/lang/Object;
.source "TzbTctMenuBar.java"


# static fields
.field private static final MENU_BAR_CLASS:Ljava/lang/String; = "android.widget.MenuBar"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static find(Landroid/app/Activity;)Landroid/widget/FrameLayout;
    .locals 4
    .param p0, "activity"    # Landroid/app/Activity;

    .line 90
    :try_start_0
    const-class v0, Landroid/app/Activity;

    const-string v1, "getMenuBar"

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    .line 91
    .local v0, "m":Ljava/lang/reflect/Method;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 92
    new-array v1, v2, [Ljava/lang/Object;

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 93
    .local v1, "bar":Ljava/lang/Object;
    instance-of v2, v1, Landroid/widget/FrameLayout;

    if-eqz v2, :cond_0

    .line 94
    move-object v2, v1

    check-cast v2, Landroid/widget/FrameLayout;

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v2

    .line 99
    .end local v0
    .end local v1
    :cond_0
    goto :goto_0

    .line 96
    :catchall_0
    move-exception v0

    .line 100
    :goto_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->findByClassName(Landroid/view/View;)Landroid/widget/FrameLayout;

    move-result-object v0

    return-object v0
.end method

.method private static findByClassName(Landroid/view/View;)Landroid/widget/FrameLayout;
    .locals 4
    .param p0, "v"    # Landroid/view/View;

    .line 104
    const/4 v0, 0x0

    if-nez p0, :cond_0

    .line 105
    return-object v0

    .line 107
    :cond_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "android.widget.MenuBar"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    instance-of v1, p0, Landroid/widget/FrameLayout;

    if-eqz v1, :cond_1

    .line 108
    move-object v0, p0

    check-cast v0, Landroid/widget/FrameLayout;

    return-object v0

    .line 110
    :cond_1
    instance-of v1, p0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_3

    .line 111
    move-object v1, p0

    check-cast v1, Landroid/view/ViewGroup;

    .line 112
    .local v1, "g":Landroid/view/ViewGroup;
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    if-ge v2, v3, :cond_3

    .line 113
    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v3}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->findByClassName(Landroid/view/View;)Landroid/widget/FrameLayout;

    move-result-object v3

    .line 114
    .local v3, "hit":Landroid/widget/FrameLayout;
    if-eqz v3, :cond_2

    return-object v3

    .line 112
    .end local v3
    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 117
    .end local v1
    .end local v2
    :cond_3
    return-object v0
.end method

.method private static goEdgeToEdge(Landroid/app/Activity;)V
    .locals 3
    .param p0, "activity"    # Landroid/app/Activity;

    .line 64
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    .line 65
    .local v0, "decor":Landroid/view/View;
    invoke-virtual {v0}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v1

    or-int/lit16 v1, v1, 0x200

    or-int/lit8 v1, v1, 0x2

    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 68
    const v1, 0x1020002    # @android:id/content

    invoke-virtual {p0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    .line 69
    .local v1, "content":Landroid/view/View;
    if-nez v1, :cond_0

    .line 70
    return-void

    .line 72
    :cond_0
    new-instance v2, Lcom/tzibbur/basic/ui/TzbTctMenuBar$1;

    invoke-direct {v2}, Lcom/tzibbur/basic/ui/TzbTctMenuBar$1;-><init>()V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnApplyWindowInsetsListener(Landroid/view/View$OnApplyWindowInsetsListener;)V

    .line 82
    invoke-virtual {v1}, Landroid/view/View;->requestApplyInsets()V

    .line 85
    .end local v0
    .end local v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 83
    :catchall_0
    move-exception v0

    .line 86
    :goto_0
    return-void
.end method

.method public static hide(Landroid/app/Activity;)V
    .locals 5
    .param p0, "activity"    # Landroid/app/Activity;

    .line 36
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->find(Landroid/app/Activity;)Landroid/widget/FrameLayout;

    move-result-object v0

    .line 37
    .local v0, "bar":Landroid/widget/FrameLayout;
    if-nez v0, :cond_0

    .line 38
    return-void

    .line 41
    :cond_0
    :try_start_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-string v2, "hideMenuBar"

    const/4 v3, 0x0

    new-array v4, v3, [Ljava/lang/Class;

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    new-array v2, v3, [Ljava/lang/Object;

    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 42
    :catchall_0
    move-exception v1

    .line 46
    :goto_0
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->goEdgeToEdge(Landroid/app/Activity;)V

    .line 47
    return-void
.end method
