# extended-by: Lcom/tzibbur/basic/ui/TzbAboutActivity;
# extended-by: Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
# extended-by: Lcom/tzibbur/basic/ui/TzbConversationActivity;
# extended-by: Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
# extended-by: Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
# extended-by: Lcom/tzibbur/basic/ui/TzbGroupListActivity;
# extended-by: Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
# extended-by: Lcom/tzibbur/basic/ui/TzbSettingsActivity;
.class public abstract Lcom/tzibbur/basic/ui/TzbBaseActivity;
.super Landroid/app/Activity;
.source "TzbBaseActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/sync/TzbSyncListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;
    }
.end annotation


# static fields
.field private static startedActivities:I


# instance fields
.field protected core:Lcom/tzibbur/basic/core/TzbCore;

.field private counted:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 40
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method public static varargs attachAutoIme([Landroid/widget/EditText;)V
    .locals 4
    .param p0, "fields"    # [Landroid/widget/EditText;

    .line 277
    array-length v0, p0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    aget-object v2, p0, v1

    .line 278
    .local v2, "field":Landroid/widget/EditText;
    if-nez v2, :cond_0

    goto :goto_1

    .line 279
    :cond_0
    new-instance v3, Lcom/tzibbur/basic/ui/TzbBaseActivity$4;

    invoke-direct {v3}, Lcom/tzibbur/basic/ui/TzbBaseActivity$4;-><init>()V

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 277
    .end local v2
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 286
    :cond_1
    return-void
.end method

.method public static attachDialogIme(Landroid/app/AlertDialog;Landroid/widget/EditText;)V
    .locals 2
    .param p0, "dialog"    # Landroid/app/AlertDialog;
    .param p1, "field"    # Landroid/widget/EditText;

    .line 333
    invoke-virtual {p0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 334
    invoke-virtual {p0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Landroid/view/Window;->setSoftInputMode(I)V

    .line 337
    :cond_0
    const/4 v0, 0x1

    new-array v0, v0, [Landroid/widget/EditText;

    const/4 v1, 0x0

    aput-object p1, v0, v1

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->attachAutoIme([Landroid/widget/EditText;)V

    .line 338
    invoke-virtual {p1}, Landroid/widget/EditText;->requestFocus()Z

    .line 339
    return-void
.end method

.method private handleUnauthorized()V
    .locals 1

    .line 495
    new-instance v0, Lcom/tzibbur/basic/ui/TzbBaseActivity$6;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbBaseActivity;)V

    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/lang/Runnable;)V

    .line 501
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->routeToEnrollment()V

    .line 502
    return-void
.end method

.method private notAllowedText(Lorg/json/JSONObject;I)Ljava/lang/String;
    .locals 2
    .param p1, "errors"    # Lorg/json/JSONObject;
    .param p2, "stateText"    # I

    .line 454
    const-string v0, "reason"

    const-string v1, ""

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 455
    .local v0, "reason":Ljava/lang/String;
    const-string v1, "system_thread"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 456
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_err_reason_system_thread:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 458
    :cond_0
    const-string v1, "admins_only"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    const-string v1, "not_admin"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    .line 461
    :cond_1
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_error_not_allowed:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 459
    :cond_2
    :goto_0
    invoke-virtual {p0, p2}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public static stripPhoneFormatting(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p0, "input"    # Ljava/lang/String;

    .line 321
    const-string v0, ""

    if-nez p0, :cond_0

    return-object v0

    .line 322
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    const-string v2, "+"

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    .line 323
    .local v1, "plus":Z
    const-string v3, "[^0-9]"

    invoke-virtual {p0, v3, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 324
    .local v0, "digits":Ljava/lang/String;
    if-eqz v1, :cond_1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :cond_1
    move-object v2, v0

    :goto_0
    return-object v2
.end method

.method public static syncImeToFocus(Landroid/view/View;Z)V
    .locals 1
    .param p0, "v"    # Landroid/view/View;
    .param p1, "hasFocus"    # Z

    .line 295
    new-instance v0, Lcom/tzibbur/basic/ui/TzbBaseActivity$5;

    invoke-direct {v0, p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity$5;-><init>(Landroid/view/View;Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 313
    return-void
.end method


# virtual methods
.method protected connectionStateText(I)Ljava/lang/String;
    .locals 1
    .param p1, "state"    # I

    .line 506
    packed-switch p1, :pswitch_data_0

    .line 514
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_state_offline:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 512
    :pswitch_0    # 0x3
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_state_polling:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 508
    :pswitch_1    # 0x2
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_state_live:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 510
    :pswitch_2    # 0x1
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_state_connecting:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2    # 0x1
        :pswitch_1    # 0x2
        :pswitch_0    # 0x3
    .end packed-switch
.end method

.method protected handleDeviceBlocked()V
    .locals 1

    .line 489
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->setDeviceBlocked()V

    .line 490
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;->show(Landroid/content/Context;)V

    .line 491
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->finish()V

    .line 492
    return-void
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbConversationActivity;
.method public onCommandResult(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbCommandResult;)V
    .locals 0
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "result"    # Lcom/tzibbur/basic/model/TzbCommandResult;

    .line 122
    return-void
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupListActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbSettingsActivity;
.method public onConnectionChanged(I)V
    .locals 0
    .param p1, "state"    # I

    .line 128
    return-void
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbAboutActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbConversationActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupListActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbSettingsActivity;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 46
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 47
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    .line 48
    return-void
.end method

.method public onCreatePanelMenu(ILandroid/view/Menu;)Z
    .locals 1
    .param p1, "featureId"    # I
    .param p2, "menu"    # Landroid/view/Menu;

    .line 162
    const/4 v0, 0x0

    return v0
.end method

.method public onDeviceBlocked()V
    .locals 1

    .line 132
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_0

    .line 133
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;->show(Landroid/content/Context;)V

    .line 134
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->finish()V

    .line 136
    :cond_0
    return-void
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbConversationActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupListActivity;
.method public onGroupMessagesChanged(Ljava/lang/String;)V
    .locals 0
    .param p1, "groupId"    # Ljava/lang/String;

    .line 116
    return-void
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbConversationActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupListActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
.method public onGroupsChanged()V
    .locals 0

    .line 119
    return-void
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbConversationActivity;
.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 1
    .param p1, "keyCode"    # I
    .param p2, "event"    # Landroid/view/KeyEvent;

    .line 167
    const/16 v0, 0x52

    if-ne p1, v0, :cond_0

    .line 169
    invoke-virtual {p2}, Landroid/view/KeyEvent;->startTracking()V

    .line 170
    const/4 v0, 0x1

    return v0

    .line 172
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result v0

    return v0
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .locals 1
    .param p1, "keyCode"    # I
    .param p2, "event"    # Landroid/view/KeyEvent;

    .line 177
    const/16 v0, 0x52

    if-ne p1, v0, :cond_1

    .line 178
    invoke-virtual {p2}, Landroid/view/KeyEvent;->isTracking()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p2}, Landroid/view/KeyEvent;->isCanceled()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->showAppMenu()V

    .line 179
    :cond_0
    const/4 v0, 0x1

    return v0

    .line 181
    :cond_1
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result v0

    return v0
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbConversationActivity;
.method public onSendFailed(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
    .locals 0
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "problemCode"    # Ljava/lang/String;
    .param p3, "errors"    # Lorg/json/JSONObject;

    .line 125
    return-void
.end method

.method public onSessionExpired()V
    .locals 0

    .line 141
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->routeToEnrollment()V

    .line 142
    return-void
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbConversationActivity;
# implemented-by: Lcom/tzibbur/basic/ui/TzbGroupListActivity;
.method protected onStart()V
    .locals 2

    .line 69
    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    .line 76
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->deviceBlocked()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 78
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;->show(Landroid/content/Context;)V

    .line 79
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->finish()V

    .line 80
    return-void

    .line 82
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v0

    if-nez v0, :cond_1

    .line 83
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->routeToEnrollment()V

    .line 84
    return-void

    .line 89
    :cond_1
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 90
    return-void

    .line 95
    :cond_2
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->recheckIfStale(Landroid/content/Context;)V

    .line 96
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0, p0}, Lcom/tzibbur/basic/sync/TzbSync;->addListener(Lcom/tzibbur/basic/sync/TzbSyncListener;)V

    .line 97
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->counted:Z

    .line 98
    sget v0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->startedActivities:I

    add-int/lit8 v1, v0, 0x1

    sput v1, Lcom/tzibbur/basic/ui/TzbBaseActivity;->startedActivities:I

    if-nez v0, :cond_3

    .line 99
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->nudge()V

    .line 101
    :cond_3
    return-void
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbConversationActivity;
.method protected onStop()V
    .locals 1

    .line 105
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->counted:Z

    if-eqz v0, :cond_0

    .line 106
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->counted:Z

    .line 107
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0, p0}, Lcom/tzibbur/basic/sync/TzbSync;->removeListener(Lcom/tzibbur/basic/sync/TzbSyncListener;)V

    .line 108
    sget v0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->startedActivities:I

    if-lez v0, :cond_0

    sget v0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->startedActivities:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lcom/tzibbur/basic/ui/TzbBaseActivity;->startedActivities:I

    .line 110
    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    .line 111
    return-void
.end method

.method public openOptionsMenu()V
    .locals 0

    .line 157
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->showAppMenu()V

    .line 158
    return-void
.end method

.method protected problemText(Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p1, "code"    # Ljava/lang/String;

    .line 356
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {p0, p1, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->problemText(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method protected problemText(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 1
    .param p1, "code"    # Ljava/lang/String;
    .param p2, "errors"    # Lorg/json/JSONObject;

    .line 366
    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->problemText(Ljava/lang/String;Lorg/json/JSONObject;I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method protected problemText(Ljava/lang/String;Lorg/json/JSONObject;I)Ljava/lang/String;
    .locals 8
    .param p1, "code"    # Ljava/lang/String;
    .param p2, "errors"    # Lorg/json/JSONObject;
    .param p3, "status"    # I

    .line 377
    const/16 v0, 0x193

    if-nez p1, :cond_1

    .line 378
    if-ne p3, v0, :cond_0

    .line 379
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_error_not_allowed:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 380
    :cond_0
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_error_generic:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 378
    :goto_0
    return-object v0

    .line 382
    :cond_1
    if-nez p2, :cond_2

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    move-object p2, v1

    .line 383
    :cond_2
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, -0x1

    sparse-switch v1, :sswitch_data_0

    :cond_3
    goto/16 :goto_1

    :sswitch_0    # 0x75d0b1bf
    const-string v1, "invalid_message"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0xc

    goto/16 :goto_2

    :sswitch_1    # 0x74b2f103
    const-string v1, "device_blocked"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x5

    goto/16 :goto_2

    :sswitch_2    # 0x7199d1df
    const-string v1, "contacts_batch_too_large"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x7

    goto/16 :goto_2

    :sswitch_3    # 0x6607839f
    const-string v1, "reserved_display_name"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0x9

    goto/16 :goto_2

    :sswitch_4    # 0x62d34246
    const-string v1, "invalid_category"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0xb

    goto/16 :goto_2

    :sswitch_5    # 0x604afb16
    const-string v1, "not_found"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0x11

    goto/16 :goto_2

    :sswitch_6    # 0x599e9bf9
    const-string v1, "forbidden"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0x10

    goto/16 :goto_2

    :sswitch_7    # 0x4df7dc78
    const-string v1, "adding_members_not_allowed"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    move v1, v2

    goto/16 :goto_2

    :sswitch_8    # 0x4c6b1c4f
    const-string v1, "group_full"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0xd

    goto/16 :goto_2

    :sswitch_9    # 0x4877889c
    const-string v1, "group_too_small"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0xe

    goto/16 :goto_2

    :sswitch_a    # -0x1d25d71
    const-string v1, "admin_required"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x2

    goto :goto_2

    :sswitch_b    # -0x5cd386d
    const-string v1, "invalid_group_name"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0xa

    goto :goto_2

    :sswitch_c    # -0x3280e941
    const-string v1, "posting_not_allowed"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    move v1, v3

    goto :goto_2

    :sswitch_d    # -0x39a7e706
    const-string v1, "phone_batch_too_large"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x6

    goto :goto_2

    :sswitch_e    # -0x4faabe9e
    const-string v1, "contact_discovery_unavailable"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x4

    goto :goto_2

    :sswitch_f    # -0x51bf1ad0
    const-string v1, "invalid_display_name"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0x8

    goto :goto_2

    :sswitch_10    # -0x60e696c5
    const-string v1, "rate_limited"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0x12

    goto :goto_2

    :sswitch_11    # -0x7170dd4c
    const-string v1, "leave_not_allowed"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x3

    goto :goto_2

    :sswitch_12    # -0x78f9cf9a
    const-string v1, "last_admin"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0xf

    goto :goto_2

    :goto_1
    move v1, v4

    :goto_2
    packed-switch v1, :pswitch_data_0

    .line 442
    if-ne p3, v0, :cond_8

    .line 443
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_error_not_allowed:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_7

    .line 439
    :pswitch_0    # 0x12
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_rate_limited:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 437
    :pswitch_1    # 0x11
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_not_found:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 435
    :pswitch_2    # 0x10
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_error_not_allowed:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 433
    :pswitch_3    # 0xf
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_last_admin:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 424
    :pswitch_4    # 0xe
    const-string v0, "minMembers"

    invoke-virtual {p2, v0, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    .line 425
    .local v0, "minMembers":I
    const-string v1, "currentMembers"

    invoke-virtual {p2, v1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    .line 426
    .local v1, "currentMembers":I
    sub-int v4, v0, v1

    .line 427
    .local v4, "missing":I
    if-lez v0, :cond_4

    if-ltz v1, :cond_4

    if-lez v4, :cond_4

    .line 428
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    sget v6, Lcom/tzibbur/basic/R$plurals;->tzb_notice_group_too_small:I

    .line 429
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v7, v2, v3

    .line 428
    invoke-virtual {v5, v6, v4, v2}, Landroid/content/res/Resources;->getQuantityString(II[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    goto :goto_3

    .line 430
    :cond_4
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_err_group_too_small:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    .line 427
    :goto_3
    return-object v2

    .line 418
    .end local v0
    .end local v1
    .end local v4
    :pswitch_5    # 0xd
    const-string v0, "maxMembers"

    invoke-virtual {p2, v0, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    .line 419
    .local v0, "maxMembers":I
    if-lez v0, :cond_5

    .line 420
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_err_group_full_n:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v4, v2, v3

    invoke-virtual {p0, v1, v2}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    goto :goto_4

    .line 421
    :cond_5
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_err_group_full:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 419
    :goto_4
    return-object v1

    .line 412
    .end local v0
    :pswitch_6    # 0xc
    const-string v0, "maxLength"

    invoke-virtual {p2, v0, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    .line 413
    .local v0, "maxLength":I
    if-lez v0, :cond_6

    .line 414
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_err_message_too_long_n:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v4, v2, v3

    invoke-virtual {p0, v1, v2}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    goto :goto_5

    .line 415
    :cond_6
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_err_invalid_message:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 413
    :goto_5
    return-object v1

    .line 410
    .end local v0
    :pswitch_7    # 0xb
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_invalid_category:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 408
    :pswitch_8    # 0xa
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_invalid_group_name:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 406
    :pswitch_9    # 0x9
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_reserved_display_name:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 404
    :pswitch_a    # 0x8
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_invalid_display_name:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 398
    :pswitch_b    # 0x7
    const-string v0, "maxPhones"

    invoke-virtual {p2, v0, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    .line 399
    .local v0, "maxPhones":I
    if-lez v0, :cond_7

    .line 400
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_err_phone_batch_too_large_n:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v4, v2, v3

    invoke-virtual {p0, v1, v2}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    goto :goto_6

    .line 401
    :cond_7
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_error_generic:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 399
    :goto_6
    return-object v1

    .line 395
    .end local v0
    :pswitch_c    # 0x5
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_device_blocked_title:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 393
    :pswitch_d    # 0x4
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_contacts_unavailable:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 391
    :pswitch_e    # 0x3
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_leave_not_allowed:I

    invoke-direct {p0, p2, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->notAllowedText(Lorg/json/JSONObject;I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 389
    :pswitch_f    # 0x2
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_admin_required:I

    invoke-direct {p0, p2, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->notAllowedText(Lorg/json/JSONObject;I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 387
    :pswitch_10    # 0x1
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_adding_not_allowed:I

    invoke-direct {p0, p2, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->notAllowedText(Lorg/json/JSONObject;I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 385
    :pswitch_11    # 0x0
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_posting_not_allowed:I

    invoke-direct {p0, p2, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->notAllowedText(Lorg/json/JSONObject;I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 444
    :cond_8
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_error_generic:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 442
    :goto_7
    return-object v0

    :sswitch_data_0
    .sparse-switch
        -0x78f9cf9a -> :sswitch_12
        -0x7170dd4c -> :sswitch_11
        -0x60e696c5 -> :sswitch_10
        -0x51bf1ad0 -> :sswitch_f
        -0x4faabe9e -> :sswitch_e
        -0x39a7e706 -> :sswitch_d
        -0x3280e941 -> :sswitch_c
        -0x5cd386d -> :sswitch_b
        -0x1d25d71 -> :sswitch_a
        0x4877889c -> :sswitch_9
        0x4c6b1c4f -> :sswitch_8
        0x4df7dc78 -> :sswitch_7
        0x599e9bf9 -> :sswitch_6
        0x604afb16 -> :sswitch_5
        0x62d34246 -> :sswitch_4
        0x6607839f -> :sswitch_3
        0x7199d1df -> :sswitch_2
        0x74b2f103 -> :sswitch_1
        0x75d0b1bf -> :sswitch_0

    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11    # 0x0
        :pswitch_10    # 0x1
        :pswitch_f    # 0x2
        :pswitch_e    # 0x3
        :pswitch_d    # 0x4
        :pswitch_c    # 0x5
        :pswitch_b    # 0x6
        :pswitch_b    # 0x7
        :pswitch_a    # 0x8
        :pswitch_9    # 0x9
        :pswitch_8    # 0xa
        :pswitch_7    # 0xb
        :pswitch_6    # 0xc
        :pswitch_5    # 0xd
        :pswitch_4    # 0xe
        :pswitch_3    # 0xf
        :pswitch_2    # 0x10
        :pswitch_1    # 0x11
        :pswitch_0    # 0x12
    .end packed-switch
.end method

.method protected routeToEnrollment()V
    .locals 2

    .line 347
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 348
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "com.tzibbur.basic.ui.TzbEnrollPhoneActivity"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 349
    const v1, 0x24000000    # CLEAR_TOP | SINGLE_TOP; keep Messages below

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 350
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->startActivity(Landroid/content/Intent;)V

    .line 351
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->finish()V

    .line 352
    return-void
.end method

.method protected setTitleBarText(Ljava/lang/CharSequence;)V
    .locals 1
    .param p1, "title"    # Ljava/lang/CharSequence;

    .line 262
    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->setTitle(Ljava/lang/CharSequence;)V

    .line 263
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_title_text:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 264
    .local v0, "titleText":Landroid/widget/TextView;
    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 265
    :cond_0
    return-void
.end method

.method protected setupTitleBar(Ljava/lang/CharSequence;Z)V
    .locals 2
    .param p1, "title"    # Ljava/lang/CharSequence;
    .param p2, "hasMenu"    # Z

    .line 243
    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->setTitleBarText(Ljava/lang/CharSequence;)V

    .line 244
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_menu_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 245
    .local v0, "menuButton":Landroid/view/View;
    if-nez v0, :cond_0

    return-void

    .line 246
    :cond_0
    if-eqz p2, :cond_1

    .line 247
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 248
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setFocusable(Z)V

    .line 249
    new-instance v1, Lcom/tzibbur/basic/ui/TzbBaseActivity$3;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbBaseActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_0

    .line 256
    :cond_1
    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 258
    :goto_0
    return-void
.end method

.method protected showAppMenu()V
    .locals 4

    .line 189
    const v0, 0x1020002    # @android:id/content

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 190
    .local v0, "anchor":Landroid/view/View;
    if-nez v0, :cond_0

    return-void

    .line 193
    :cond_0
    new-instance v1, Landroid/widget/PopupMenu;

    invoke-direct {v1, p0, v0}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    invoke-virtual {v1}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    .line 194
    .local v1, "menu":Landroid/view/Menu;
    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onCreateOptionsMenu(Landroid/view/Menu;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onPrepareOptionsMenu(Landroid/view/Menu;)Z

    move-result v2

    if-nez v2, :cond_1

    goto :goto_0

    .line 195
    :cond_1
    new-instance v2, Lcom/tzibbur/basic/ui/TzbBaseActivity$1;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbBaseActivity;)V

    const/4 v3, 0x0

    invoke-virtual {p0, v3, v1, v2}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->showMenuDialog(Ljava/lang/CharSequence;Landroid/view/Menu;Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;)V

    .line 201
    return-void

    .line 194
    :cond_2
    :goto_0
    return-void
.end method

.method protected showMenuDialog(Ljava/lang/CharSequence;Landroid/view/Menu;Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;)V
    .locals 6
    .param p1, "title"    # Ljava/lang/CharSequence;
    .param p2, "menu"    # Landroid/view/Menu;
    .param p3, "pick"    # Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;

    .line 213
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 214
    .local v0, "items":Ljava/util/List;, "Ljava/util/List<Landroid/view/MenuItem;>;"
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-interface {p2}, Landroid/view/Menu;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 215
    invoke-interface {p2, v1}, Landroid/view/Menu;->getItem(I)Landroid/view/MenuItem;

    move-result-object v2

    .line 216
    .local v2, "item":Landroid/view/MenuItem;
    invoke-interface {v2}, Landroid/view/MenuItem;->isVisible()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Landroid/view/MenuItem;->isEnabled()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 214
    .end local v2
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 218
    .end local v1
    :cond_1
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2

    return-void

    .line 219
    :cond_2
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    new-array v1, v1, [Ljava/lang/CharSequence;

    .line 220
    .local v1, "titles":[Ljava/lang/CharSequence;
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_1
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_3

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/MenuItem;

    invoke-interface {v3}, Landroid/view/MenuItem;->getTitle()Ljava/lang/CharSequence;

    move-result-object v3

    aput-object v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 221
    .end local v2
    :cond_3
    new-instance v2, Landroid/app/AlertDialog$Builder;

    invoke-direct {v2, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 222
    .local v2, "builder":Landroid/app/AlertDialog$Builder;
    if-eqz p1, :cond_4

    invoke-virtual {v2, p1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 223
    :cond_4
    new-instance v3, Lcom/tzibbur/basic/ui/TzbBaseActivity$2;

    invoke-direct {v3, p0, p3, v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbBaseActivity;Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;Ljava/util/List;)V

    invoke-virtual {v2, v1, v3}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 229
    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    .line 230
    invoke-virtual {v3}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 231
    return-void
.end method

.method protected toastProblem(Ljava/lang/Exception;)V
    .locals 5
    .param p1, "error"    # Ljava/lang/Exception;

    .line 466
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " one-shot failed"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "TzbUi"

    invoke-static {v1, v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 467
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    const/4 v1, 0x1

    if-eqz v0, :cond_2

    .line 468
    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    .line 469
    .local v0, "problem":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isDeviceBlocked()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 471
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->handleDeviceBlocked()V

    .line 472
    return-void

    .line 474
    :cond_0
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isUnauthorized()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 477
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->handleUnauthorized()V

    .line 478
    return-void

    .line 480
    :cond_1
    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    iget-object v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    iget v4, v0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    invoke-virtual {p0, v2, v3, v4}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->problemText(Ljava/lang/String;Lorg/json/JSONObject;I)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    .line 481
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 482
    .end local v0
    goto :goto_0

    .line 483
    :cond_2
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_error_network:I

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 485
    :goto_0
    return-void
.end method
