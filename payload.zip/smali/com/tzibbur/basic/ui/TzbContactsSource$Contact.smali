.class public final Lcom/tzibbur/basic/ui/TzbContactsSource$Contact;
.super Ljava/lang/Object;
.source "TzbContactsSource.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/ui/TzbContactsSource;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Contact"
.end annotation


# instance fields
.field public final displayName:Ljava/lang/String;

.field public final phone:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "phone"    # Ljava/lang/String;
    .param p2, "displayName"    # Ljava/lang/String;

    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 38
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactsSource$Contact;->phone:Ljava/lang/String;

    .line 39
    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbContactsSource$Contact;->displayName:Ljava/lang/String;

    .line 40
    return-void
.end method
