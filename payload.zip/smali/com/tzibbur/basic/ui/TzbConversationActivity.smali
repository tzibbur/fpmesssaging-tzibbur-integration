.class public Lcom/tzibbur/basic/ui/TzbConversationActivity;
.super Lcom/tzibbur/basic/ui/TzbBaseActivity;
.source "TzbConversationActivity.java"


# static fields
.field public static final EXTRA_GROUP_ID:Ljava/lang/String; = "tzb_group_id"

.field private static final PAGE:I = 0x32


# instance fields
.field private adapter:Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

.field private bottomMenuBtn:Landroid/view/View;

.field private final commandResults:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbCommandResult;",
            ">;"
        }
    .end annotation
.end field

.field private composeEdit:Landroid/widget/EditText;

.field private composeLabel:Landroid/widget/TextView;

.field private composeOverLimit:Z

.field private composePanel:Landroid/view/View;

.field private counterView:Landroid/widget/TextView;

.field private dividerSeq:J

.field private group:Lcom/tzibbur/basic/model/TzbGroup;

.field private groupId:Ljava/lang/String;

.field private headerShown:Z

.field private initialFocusDone:Z

.field private initialPositionDone:Z

.field private list:Landroid/widget/ListView;

.field private loadEarlierHeader:Landroid/view/View;

.field private loadingEarlier:Z

.field private maxBody:I

.field private muteGaps:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private noMoreEarlier:Z

.field private noticeView:Landroid/widget/TextView;

.field private volatile prevReadSeq:J

.field private final readSeqLock:Ljava/lang/Object;

.field private resumed:Z

.field private scrollToNewestOnStart:Z

.field private sendBtn:Landroid/widget/Button;

.field private final shownMessages:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation
.end field

.field private shownOutbox:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/store/TzbOutboxItem;",
            ">;"
        }
    .end annotation
.end field

.field private started:Z

.field private unreadPositioned:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;-><init>()V

    .line 117
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    .line 118
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->commandResults:Ljava/util/List;

    .line 119
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownOutbox:Ljava/util/List;

    .line 136
    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->prevReadSeq:J

    .line 137
    new-instance v2, Ljava/lang/Object;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->readSeqLock:Ljava/lang/Object;

    .line 144
    iput-wide v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->dividerSeq:J

    .line 629
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->muteGaps:Ljava/util/List;

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Z

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->applyComposeFocusStyle(Z)V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composerVisible()Z

    move-result v0

    return v0
.end method

.method static synthetic access$1000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadEarlier()V

    return-void
.end method

.method static synthetic access$1100(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/store/TzbOutboxItem;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->confirmResend(Lcom/tzibbur/basic/store/TzbOutboxItem;)V

    return-void
.end method

.method static synthetic access$1200(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/model/TzbMessage;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbMessage;

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->showMessageDetails(Lcom/tzibbur/basic/model/TzbMessage;)V

    return-void
.end method

.method static synthetic access$1300(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/model/TzbCommandResult;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbCommandResult;

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->showCommandDetails(Lcom/tzibbur/basic/model/TzbCommandResult;)V

    return-void
.end method

.method static synthetic access$1400(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->send()V

    return-void
.end method

.method static synthetic access$1500(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->isComposeCursorOnFirstLine()Z

    move-result v0

    return v0
.end method

.method static synthetic access$1600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->isComposeCursorOnLastLine()Z

    move-result v0

    return v0
.end method

.method static synthetic access$1700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusGateRow()Z

    move-result v0

    return v0
.end method

.method static synthetic access$1800(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Z

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->pageOversizedSelectedRow(Z)Z

    move-result v0

    return v0
.end method

.method static synthetic access$1900(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->updateCounter()V

    return-void
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/EditText;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    return-object v0
.end method

.method static synthetic access$2000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$2100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    return-object v0
.end method

.method static synthetic access$2102(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/model/TzbGroup;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 52
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    return-object p1
.end method

.method static synthetic access$2200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->applyGroup()V

    return-void
.end method

.method static synthetic access$2300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->dropGroupAndFinish()V

    return-void
.end method

.method static synthetic access$2400(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/store/TzbStore;Ljava/lang/String;)J
    .locals 2
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/store/TzbStore;
    .param p2, "x2"    # Ljava/lang/String;

    .line 52
    invoke-direct {p0, p1, p2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->capturePrevReadSeq(Lcom/tzibbur/basic/store/TzbStore;Ljava/lang/String;)J

    move-result-wide v0

    return-wide v0
.end method

.method static synthetic access$2500(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->isAtBottom()Z

    move-result v0

    return v0
.end method

.method static synthetic access$2600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    return-object v0
.end method

.method static synthetic access$2700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownOutbox:Ljava/util/List;

    return-object v0
.end method

.method static synthetic access$2702(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/util/List;)Ljava/util/List;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Ljava/util/List;

    .line 52
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownOutbox:Ljava/util/List;

    return-object p1
.end method

.method static synthetic access$2800(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->muteGaps:Ljava/util/List;

    return-object v0
.end method

.method static synthetic access$2802(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/util/List;)Ljava/util/List;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Ljava/util/List;

    .line 52
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->muteGaps:Ljava/util/List;

    return-object p1
.end method

.method static synthetic access$2900(Lcom/tzibbur/basic/ui/TzbConversationActivity;)I
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->oldestUnreadIndex()I

    move-result v0

    return v0
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    return-object v0
.end method

.method static synthetic access$3000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)J
    .locals 2
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-wide v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->dividerSeq:J

    return-wide v0
.end method

.method static synthetic access$3002(Lcom/tzibbur/basic/ui/TzbConversationActivity;J)J
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # J

    .line 52
    iput-wide p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->dividerSeq:J

    return-wide p1
.end method

.method static synthetic access$3100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->commandResults:Ljava/util/List;

    return-object v0
.end method

.method static synthetic access$3200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Lcom/tzibbur/basic/ui/TzbMessageListAdapter;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    return-object v0
.end method

.method static synthetic access$3300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->updateLoadEarlierVisibility()V

    return-void
.end method

.method static synthetic access$3402(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Z

    .line 52
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialPositionDone:Z

    return p1
.end method

.method static synthetic access$3502(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Z

    .line 52
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->unreadPositioned:Z

    return p1
.end method

.method static synthetic access$3602(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Z

    .line 52
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialFocusDone:Z

    return p1
.end method

.method static synthetic access$3700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)I
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->measureUnreadDividerHeight()I

    move-result v0

    return v0
.end method

.method static synthetic access$3800(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->scrollToEnd()V

    return-void
.end method

.method static synthetic access$3900(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->applyEntryFocus()V

    return-void
.end method

.method static synthetic access$400(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->sendBtn:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$4000(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)I
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->adapterIndexOfMessage(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method static synthetic access$4100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->resumed:Z

    return v0
.end method

.method static synthetic access$4200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->markRead()V

    return-void
.end method

.method static synthetic access$4302(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Z

    .line 52
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadingEarlier:Z

    return p1
.end method

.method static synthetic access$4402(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Z

    .line 52
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noMoreEarlier:Z

    return p1
.end method

.method static synthetic access$4500(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Z

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V

    return-void
.end method

.method static synthetic access$4600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/lang/Object;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->readSeqLock:Ljava/lang/Object;

    return-object v0
.end method

.method static synthetic access$4700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)J
    .locals 2
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-wide v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->prevReadSeq:J

    return-wide v0
.end method

.method static synthetic access$4702(Lcom/tzibbur/basic/ui/TzbConversationActivity;J)J
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # J

    .line 52
    iput-wide p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->prevReadSeq:J

    return-wide p1
.end method

.method static synthetic access$500(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeActionable()Z

    move-result v0

    return v0
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->openMembers()V

    return-void
.end method

.method static synthetic access$800(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 52
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusBottomMenuButton()Z

    move-result v0

    return v0
.end method

.method static synthetic access$900(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .param p1, "x1"    # Z

    .line 52
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusListAtViewport(Z)V

    return-void
.end method

.method private adapterIndexOfMessage(Ljava/lang/String;)I
    .locals 5
    .param p1, "messageId"    # Ljava/lang/String;

    .line 854
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->indexOfMessage(Ljava/lang/String;)I

    move-result v0

    .line 855
    .local v0, "index":I
    if-gez v0, :cond_0

    const/4 v1, -0x1

    return v1

    .line 856
    :cond_0
    iget-wide v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->dividerSeq:J

    const-wide/16 v3, 0x0

    cmp-long v1, v1, v3

    if-ltz v1, :cond_1

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/tzibbur/basic/model/TzbMessage;

    iget-wide v1, v1, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    iget-wide v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->dividerSeq:J

    cmp-long v1, v1, v3

    if-ltz v1, :cond_1

    add-int/lit8 v0, v0, 0x1

    .line 857
    :cond_1
    return v0
.end method

.method private applyComposeFocusStyle(Z)V
    .locals 1
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeOverLimit:Z
    invoke-static {p0, p1, v0}, Lcom/android/mms/tzib/TzibConversationStyle;->focus(Landroid/app/Activity;ZZ)V
    return-void
.end method

.method private applyEntryFocus()V
    .locals 1

    .line 687
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialFocusDone:Z

    if-eqz v0, :cond_0

    return-void

    .line 688
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialFocusDone:Z

    .line 689
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composerVisible()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->unreadPositioned:Z

    if-nez v0, :cond_1

    .line 690
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    goto :goto_0

    .line 692
    :cond_1
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusListForEntry()V

    .line 694
    :goto_0
    return-void
.end method

.method private applyGroup()V
    .locals 9

    .line 551
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v0, v0, Lcom/tzibbur/basic/model/TzbGroup;->messageMaxLength:I

    iput v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->maxBody:I

    .line 552
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v0}, Lcom/tzibbur/basic/model/TzbGroup;->isSystem()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 553
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_system_sender_name:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v0, v0, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    .line 552
    :goto_0
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->setTitleBarText(Ljava/lang/CharSequence;)V

    .line 554
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_title_extra:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 555
    .local v0, "titleExtra":Landroid/widget/TextView;
    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    .line 556
    sget v3, Lcom/tzibbur/basic/R$string;->tzb_member_count:I

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v4, v4, Lcom/tzibbur/basic/model/TzbGroup;->memberCount:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v5, v1, [Ljava/lang/Object;

    aput-object v4, v5, v2

    invoke-virtual {p0, v3, v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 557
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 559
    :cond_1
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    invoke-virtual {v3}, Landroid/widget/TextView;->hasFocus()Z

    move-result v3

    .line 560
    .local v3, "noticeHadFocus":Z
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v4}, Lcom/tzibbur/basic/model/TzbGroup;->callerMayPost()Z

    move-result v4

    .line 564
    .local v4, "mayPost":Z
    if-eqz v4, :cond_2

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupTooSmall()Z

    move-result v5

    if-eqz v5, :cond_2

    move v5, v1

    goto :goto_1

    :cond_2
    move v5, v2

    .line 565
    .local v5, "tooSmall":Z
    :goto_1
    if-eqz v4, :cond_3

    if-nez v5, :cond_3

    goto :goto_2

    :cond_3
    move v1, v2

    .line 568
    .local v1, "mayCompose":Z
    :goto_2
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composePanel:Landroid/view/View;

    const/16 v7, 0x8

    if-eqz v1, :cond_4

    move v8, v2

    goto :goto_3

    :cond_4
    move v8, v7

    :goto_3
    invoke-virtual {v6, v8}, Landroid/view/View;->setVisibility(I)V

    .line 569
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->sendBtn:Landroid/widget/Button;

    if-eqz v1, :cond_5

    move v8, v2

    goto :goto_4

    :cond_5
    move v8, v7

    :goto_4
    invoke-virtual {v6, v8}, Landroid/widget/Button;->setVisibility(I)V

    .line 570
    if-eqz v1, :cond_6

    .line 571
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setVisibility(I)V

    .line 572
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->updateCounter()V

    goto :goto_7

    .line 574
    :cond_6
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->counterView:Landroid/widget/TextView;

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setVisibility(I)V

    .line 575
    if-eqz v5, :cond_7

    .line 576
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->tooSmallNoticeText()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_6

    .line 578
    :cond_7
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v7}, Lcom/tzibbur/basic/model/TzbGroup;->isSystem()Z

    move-result v7

    if-eqz v7, :cond_8

    .line 579
    sget v7, Lcom/tzibbur/basic/R$string;->tzb_notice_system_thread:I

    goto :goto_5

    .line 580
    :cond_8
    sget v7, Lcom/tzibbur/basic/R$string;->tzb_notice_admins_only:I

    .line 578
    :goto_5
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(I)V

    .line 582
    :goto_6
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 588
    :goto_7
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setFocusable(Z)V

    .line 589
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setClickable(Z)V

    .line 590
    if-eqz v5, :cond_9

    .line 591
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    sget v6, Lcom/tzibbur/basic/R$drawable;->tzb_focusable_item_bg:I

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setBackgroundResource(I)V

    goto :goto_8

    .line 593
    :cond_9
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    sget v6, Lcom/tzibbur/basic/R$color;->tzb_bubble_system:I

    invoke-virtual {p0, v6}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getColor(I)I

    move-result v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setBackgroundColor(I)V

    .line 595
    :goto_8
    if-eqz v3, :cond_b

    if-nez v5, :cond_b

    .line 598
    if-eqz v1, :cond_a

    .line 599
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->requestFocus()Z

    goto :goto_9

    .line 601
    :cond_a
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusBottomMenuButton()Z

    .line 609
    :cond_b
    :goto_9
    iget-boolean v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialFocusDone:Z

    if-nez v2, :cond_c

    iget-boolean v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialPositionDone:Z

    if-eqz v2, :cond_c

    .line 610
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->applyEntryFocus()V

    .line 612
    :cond_c
    # tzib conversation: refresh
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->refresh(Landroid/app/Activity;)V

    return-void
.end method

.method private capturePrevReadSeq(Lcom/tzibbur/basic/store/TzbStore;Ljava/lang/String;)J
    .locals 5
    .param p1, "store"    # Lcom/tzibbur/basic/store/TzbStore;
    .param p2, "gid"    # Ljava/lang/String;

    .line 884
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->readSeqLock:Ljava/lang/Object;

    monitor-enter v0

    .line 885
    :try_start_0
    iget-wide v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->prevReadSeq:J

    const-wide/16 v3, 0x0

    cmp-long v1, v1, v3

    if-gez v1, :cond_0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 886
    invoke-interface {p1, p2}, Lcom/tzibbur/basic/store/TzbStore;->readSeq(Ljava/lang/String;)J

    move-result-wide v1

    iput-wide v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->prevReadSeq:J

    .line 888
    :cond_0
    iget-wide v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->prevReadSeq:J

    monitor-exit v0

    return-wide v1

    .line 889
    :catchall_0
    move-exception v1

    monitor-exit v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method private composerVisible()Z
    .locals 1

    .line 616
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composePanel:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private confirmResend(Lcom/tzibbur/basic/store/TzbOutboxItem;)V
    .locals 4
    .param p1, "item"    # Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 1129
    iget-object v0, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->lastError:Ljava/lang/String;

    if-eqz v0, :cond_0

    .line 1130
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p1, Lcom/tzibbur/basic/store/TzbOutboxItem;->lastError:Ljava/lang/String;

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->problemText(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_resend_confirm:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 1131
    :cond_0
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_resend_confirm:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    :goto_0
    nop

    .line 1132
    .local v0, "message":Ljava/lang/String;
    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_resend_title:I

    .line 1133
    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 1134
    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_resend:I

    new-instance v3, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;

    invoke-direct {v3, p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/store/TzbOutboxItem;)V

    .line 1135
    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 1148
    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 1149
    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 1150
    return-void
.end method

.method private counterThreshold()I
    .locals 5

    .line 1090
    iget v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->maxBody:I

    add-int/lit8 v0, v0, -0x64

    iget v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->maxBody:I

    int-to-double v1, v1

    const-wide v3, 0x3fe999999999999aL    # 0.8

    mul-double/2addr v1, v3

    double-to-int v1, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0
.end method

.method private dropGroupAndFinish()V
    .locals 2

    .line 536
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_no_longer_member:I

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 537
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    .line 538
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$15;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$15;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V

    invoke-static {v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/lang/Runnable;)V

    .line 544
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->finish()V

    .line 545
    return-void
.end method

.method private focusBottomMenuButton()Z
    .locals 1

    .line 668
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->bottomMenuBtn:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->bottomMenuBtn:Landroid/view/View;

    .line 669
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->bottomMenuBtn:Landroid/view/View;

    .line 670
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 668
    :goto_0
    return v0
.end method

.method private focusGateRow()Z
    .locals 1

    .line 662
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeActionable()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->requestFocus()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    .line 663
    :cond_0
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusBottomMenuButton()Z

    move-result v0

    return v0
.end method

.method private focusListAtViewport(Z)V
    .locals 8
    .param p1, "fromBelow"    # Z

    .line 949
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getCount()I

    move-result v0

    if-nez v0, :cond_0

    .line 950
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusGateRow()Z

    .line 951
    return-void

    .line 953
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getFirstVisiblePosition()I

    move-result v0

    .line 954
    .local v0, "firstVis":I
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getLastVisiblePosition()I

    move-result v1

    .line 955
    .local v1, "lastVis":I
    const/4 v2, -0x1

    if-ne v1, v2, :cond_1

    .line 956
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusGateRow()Z

    .line 957
    return-void

    .line 960
    :cond_1
    const/4 v2, 0x0

    if-eqz p1, :cond_3

    .line 961
    move v3, v1

    .line 963
    .local v3, "pos":I
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    sub-int v5, v3, v0

    invoke-virtual {v4, v5}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    .line 964
    .local v4, "child":Landroid/view/View;
    if-eqz v4, :cond_2

    if-le v3, v0, :cond_2

    .line 965
    invoke-virtual {v4}, Landroid/view/View;->getBottom()I

    move-result v5

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v6}, Landroid/widget/ListView;->getHeight()I

    move-result v6

    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v7}, Landroid/widget/ListView;->getPaddingBottom()I

    move-result v7

    sub-int/2addr v6, v7

    if-le v5, v6, :cond_2

    .line 966
    add-int/lit8 v3, v3, -0x1

    .line 968
    .end local v4
    :cond_2
    goto :goto_0

    .line 969
    .end local v3
    :cond_3
    move v3, v0

    .line 970
    .restart local v3
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v4, v2}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    .line 971
    .restart local v4
    if-eqz v4, :cond_4

    if-ge v3, v1, :cond_4

    .line 972
    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    move-result v5

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v6}, Landroid/widget/ListView;->getPaddingTop()I

    move-result v6

    if-ge v5, v6, :cond_4

    .line 973
    add-int/lit8 v3, v3, 0x1

    .line 976
    .end local v4
    :cond_4
    :goto_0
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    sub-int v5, v3, v0

    invoke-virtual {v4, v5}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    .line 977
    .local v4, "target":Landroid/view/View;
    if-eqz v4, :cond_5

    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    move-result v2

    .line 978
    .local v2, "top":I
    :cond_5
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v5}, Landroid/widget/ListView;->requestFocus()Z

    .line 979
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v5, v3, v2}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    .line 980
    return-void
.end method

.method private focusListForEntry()V
    .locals 2

    .line 704
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getCount()I

    move-result v0

    if-nez v0, :cond_0

    .line 705
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusGateRow()Z

    .line 706
    return-void

    .line 708
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->requestFocus()Z

    .line 709
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->unreadPositioned:Z

    if-nez v0, :cond_1

    .line 710
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getCount()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setSelection(I)V

    .line 712
    :cond_1
    return-void
.end method

.method private groupTooSmall()Z
    .locals 2

    .line 632
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v0, v0, Lcom/tzibbur/basic/model/TzbGroup;->kind:Ljava/lang/String;

    .line 633
    const-string v1, "standard"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v0, v0, Lcom/tzibbur/basic/model/TzbGroup;->memberCount:I

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v0, v0, Lcom/tzibbur/basic/model/TzbGroup;->memberCount:I

    .line 635
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->minMembersToPost()I

    move-result v1

    if-ge v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 632
    :goto_0
    return v0
.end method

.method private indexOfMessage(Ljava/lang/String;)I
    .locals 2
    .param p1, "messageId"    # Ljava/lang/String;

    .line 843
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 844
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/tzibbur/basic/model/TzbMessage;

    iget-object v1, v1, Lcom/tzibbur/basic/model/TzbMessage;->id:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return v0

    .line 843
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 846
    .end local v0
    :cond_1
    const/4 v0, -0x1

    return v0
.end method

.method private isAtBottom()Z
    .locals 6

    .line 915
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getCount()I

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    return v1

    .line 916
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getLastVisiblePosition()I

    move-result v0

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v2}, Landroid/widget/ListView;->getCount()I

    move-result v2

    add-int/lit8 v2, v2, -0x2

    const/4 v3, 0x0

    if-ge v0, v2, :cond_1

    return v3

    .line 917
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v2}, Landroid/widget/ListView;->getChildCount()I

    move-result v2

    sub-int/2addr v2, v1

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 918
    .local v0, "lastChild":Landroid/view/View;
    if-nez v0, :cond_2

    return v1

    .line 919
    :cond_2
    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v2

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v4}, Landroid/widget/ListView;->getHeight()I

    move-result v4

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v5}, Landroid/widget/ListView;->getPaddingBottom()I

    move-result v5

    sub-int/2addr v4, v5

    if-gt v2, v4, :cond_3

    goto :goto_0

    :cond_3
    move v1, v3

    :goto_0
    return v1
.end method

.method private isComposeCursorOnFirstLine()Z
    .locals 5

    .line 926
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object v0

    .line 927
    .local v0, "layout":Landroid/text/Layout;
    const/4 v1, 0x1

    if-eqz v0, :cond_2

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->length()I

    move-result v2

    if-nez v2, :cond_0

    goto :goto_1

    .line 928
    :cond_0
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->getSelectionStart()I

    move-result v2

    const/4 v3, 0x0

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 929
    .local v2, "selection":I
    invoke-virtual {v0, v2}, Landroid/text/Layout;->getLineForOffset(I)I

    move-result v4

    if-nez v4, :cond_1

    goto :goto_0

    :cond_1
    move v1, v3

    :goto_0
    return v1

    .line 927
    .end local v2
    :cond_2
    :goto_1
    return v1
.end method

.method private isComposeCursorOnLastLine()Z
    .locals 6

    .line 934
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object v0

    .line 935
    .local v0, "layout":Landroid/text/Layout;
    const/4 v1, 0x1

    if-eqz v0, :cond_2

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->length()I

    move-result v2

    if-nez v2, :cond_0

    goto :goto_1

    .line 936
    :cond_0
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->getSelectionStart()I

    move-result v2

    const/4 v3, 0x0

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 937
    .local v2, "selection":I
    invoke-virtual {v0, v2}, Landroid/text/Layout;->getLineForOffset(I)I

    move-result v4

    invoke-virtual {v0}, Landroid/text/Layout;->getLineCount()I

    move-result v5

    sub-int/2addr v5, v1

    if-ne v4, v5, :cond_1

    goto :goto_0

    :cond_1
    move v1, v3

    :goto_0
    return v1

    .line 935
    .end local v2
    :cond_2
    :goto_1
    return v1
.end method

.method private loadEarlier()V
    .locals 5

    .line 1011
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadingEarlier:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 1012
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadingEarlier:Z

    .line 1013
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    .line 1014
    .local v0, "gid":Ljava/lang/String;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/tzibbur/basic/model/TzbMessage;

    iget-wide v1, v1, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    .line 1015
    .local v1, "beforeSeq":J
    new-instance v3, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;

    invoke-direct {v3, p0, v0, v1, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;J)V

    new-instance v4, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;

    invoke-direct {v4, p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V

    invoke-static {v3, v4}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 1060
    return-void

    .line 1011
    .end local v0
    .end local v1
    :cond_1
    :goto_0
    return-void
.end method

.method private loadGroup()V
    .locals 3

    .line 503
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    .line 504
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$13;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;

    invoke-direct {v2, p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 533
    return-void
.end method

.method private markRead()V
    .locals 2

    .line 1199
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    .line 1200
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V

    invoke-static {v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/lang/Runnable;)V

    .line 1226
    return-void
.end method

.method private measureUnreadDividerHeight()I
    .locals 4

    .line 862
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$layout;->tzb_unread_divider:I

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    .line 863
    .local v0, "divider":Landroid/view/View;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getWidth()I

    move-result v1

    .line 864
    .local v1, "width":I
    if-lez v1, :cond_0

    .line 865
    const/high16 v2, 0x40000000

    invoke-static {v1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    goto :goto_0

    .line 866
    :cond_0
    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    :goto_0
    nop

    .line 867
    .local v2, "widthSpec":I
    nop

    .line 868
    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    .line 867
    invoke-virtual {v0, v2, v3}, Landroid/view/View;->measure(II)V

    .line 869
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v3

    return v3
.end method

.method private minMembersToPost()I
    .locals 1

    .line 643
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v0, v0, Lcom/tzibbur/basic/model/TzbGroup;->minMembersToPost:I

    if-ltz v0, :cond_0

    .line 644
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v0, v0, Lcom/tzibbur/basic/model/TzbGroup;->minMembersToPost:I

    return v0

    .line 646
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->minMembers()I

    move-result v0

    return v0
.end method

.method private noticeActionable()Z
    .locals 1

    .line 657
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->isFocusable()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private oldestUnreadIndex()I
    .locals 6

    .line 874
    iget-wide v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->prevReadSeq:J

    .line 875
    .local v0, "prev":J
    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    const/4 v3, -0x1

    if-gez v2, :cond_0

    return v3

    .line 876
    :cond_0
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-ge v2, v4, :cond_2

    .line 877
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/tzibbur/basic/model/TzbMessage;

    iget-wide v4, v4, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    cmp-long v4, v4, v0

    if-lez v4, :cond_1

    return v2

    .line 876
    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 879
    .end local v2
    :cond_2
    return v3
.end method

.method private openMembers()V
    .locals 3

    .line 675
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 676
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "tzb_group_id"

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 677
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->startActivity(Landroid/content/Intent;)V

    .line 678
    return-void
.end method

.method private pageOversizedSelectedRow(Z)Z
    .locals 11
    .param p1, "towardStart"    # Z

    .line 894
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedView()Landroid/view/View;

    move-result-object v0

    .line 895
    .local v0, "selected":Landroid/view/View;
    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 897
    :cond_0
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v2}, Landroid/widget/ListView;->getPaddingTop()I

    move-result v2

    .line 898
    .local v2, "viewportTop":I
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v3}, Landroid/widget/ListView;->getHeight()I

    move-result v3

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v4}, Landroid/widget/ListView;->getPaddingBottom()I

    move-result v4

    sub-int/2addr v3, v4

    .line 899
    .local v3, "viewportBottom":I
    sub-int v4, v3, v2

    .line 900
    .local v4, "viewport":I
    if-lez v4, :cond_5

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v5

    if-gt v5, v4, :cond_1

    goto :goto_2

    .line 902
    :cond_1
    if-eqz p1, :cond_2

    .line 903
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v5

    sub-int v5, v2, v5

    goto :goto_0

    .line 904
    :cond_2
    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v5

    sub-int/2addr v5, v3

    :goto_0
    nop

    .line 905
    .local v5, "remaining":I
    if-gtz v5, :cond_3

    return v1

    .line 907
    :cond_3
    mul-int/lit8 v1, v4, 0x2

    div-int/lit8 v1, v1, 0x3

    const/4 v6, 0x1

    invoke-static {v6, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 908
    .local v1, "page":I
    invoke-static {v5, v1}, Ljava/lang/Math;->min(II)I

    move-result v7

    .line 909
    .local v7, "distance":I
    iget-object v8, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    if-eqz p1, :cond_4

    neg-int v9, v7

    goto :goto_1

    :cond_4
    move v9, v7

    :goto_1
    const/16 v10, 0xa0

    invoke-virtual {v8, v9, v10}, Landroid/widget/ListView;->smoothScrollBy(II)V

    .line 910
    return v6

    .line 900
    .end local v1
    .end local v5
    .end local v7
    :cond_5
    :goto_2
    return v1
.end method

.method private requery(Z)V
    .locals 5
    .param p1, "forceScrollToBottom"    # Z

    .line 717
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    .line 718
    .local v0, "gid":Ljava/lang/String;
    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialPositionDone:Z

    xor-int/lit8 v1, v1, 0x1

    .line 720
    .local v1, "firstLoad":Z
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    add-int/lit8 v2, v2, 0x32

    .line 721
    .local v2, "baseLimit":I
    new-instance v3, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;

    invoke-direct {v3, p0, v2, v1, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;IZLjava/lang/String;)V

    new-instance v4, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;

    invoke-direct {v4, p0, v0, p1, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;ZZ)V

    invoke-static {v3, v4}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 840
    return-void
.end method

.method private scrollToEnd()V
    .locals 2

    .line 983
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$18;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$18;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->post(Ljava/lang/Runnable;)Z

    .line 989
    return-void
.end method

.method private send()V
    .locals 6

    .line 1065
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 1066
    .local v0, "text":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    .line 1070
    :cond_0
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupTooSmall()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    .line 1071
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->tooSmallNoticeText()Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 1072
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->applyGroup()V

    .line 1073
    return-void

    .line 1078
    :cond_1
    iget v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->maxBody:I

    if-lez v1, :cond_2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    iget v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->maxBody:I

    if-le v1, v4, :cond_2

    .line 1079
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_err_message_too_long_n:I

    iget v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->maxBody:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v5, v2, [Ljava/lang/Object;

    aput-object v4, v5, v3

    invoke-virtual {p0, v1, v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    .line 1080
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 1081
    return-void

    .line 1083
    :cond_2
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-interface {v1, v3, v0}, Lcom/tzibbur/basic/sync/TzbSync;->enqueueSend(Ljava/lang/String;Ljava/lang/String;)V

    .line 1084
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    const-string v3, ""

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 1085
    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V

    .line 1086
    return-void
.end method

.method private showCommandDetails(Lcom/tzibbur/basic/model/TzbCommandResult;)V
    .locals 3
    .param p1, "result"    # Lcom/tzibbur/basic/model/TzbCommandResult;

    .line 1164
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_system_sender_name:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbCommandResult;->text:Ljava/lang/String;

    iget-object v2, p1, Lcom/tzibbur/basic/model/TzbCommandResult;->text:Ljava/lang/String;

    invoke-direct {p0, v0, v1, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->showDetailsDialog(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1166
    return-void
.end method

.method private showDetailsDialog(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "copyText"    # Ljava/lang/String;
    .param p3, "displayText"    # Ljava/lang/String;

    .line 1170
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 1171
    invoke-virtual {v0, p3}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_msg_copy:I

    new-instance v2, Lcom/tzibbur/basic/ui/TzbConversationActivity$22;

    invoke-direct {v2, p0, p2}, Lcom/tzibbur/basic/ui/TzbConversationActivity$22;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V

    .line 1172
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_close:I

    .line 1184
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 1185
    .local v0, "builder":Landroid/app/AlertDialog$Builder;
    if-eqz p1, :cond_0

    invoke-virtual {v0, p1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 1186
    :cond_0
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v1

    .line 1189
    .local v1, "dialog":Landroid/app/AlertDialog;
    const v2, 0x102000b    # @android:id/message

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    .line 1190
    .local v2, "messageView":Landroid/widget/TextView;
    if-eqz v2, :cond_1

    .line 1191
    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextDirection(I)V

    .line 1192
    const/4 v3, 0x5

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextAlignment(I)V

    .line 1194
    :cond_1
    return-void
.end method

.method private showMessageDetails(Lcom/tzibbur/basic/model/TzbMessage;)V
    .locals 3
    .param p1, "message"    # Lcom/tzibbur/basic/model/TzbMessage;

    .line 1158
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbMessage;->createdAt:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->formatIso(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    iget-object v2, p1, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    invoke-direct {p0, v0, v1, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->showDetailsDialog(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1159
    return-void
.end method

.method private tooSmallNoticeText()Ljava/lang/String;
    .locals 6

    .line 650
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->minMembersToPost()I

    move-result v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->memberCount:I

    sub-int/2addr v0, v1

    const/4 v1, 0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 651
    .local v0, "missing":I
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcom/tzibbur/basic/R$plurals;->tzb_notice_group_too_small:I

    .line 652
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v4, v1, v5

    .line 651
    invoke-virtual {v2, v3, v0, v1}, Landroid/content/res/Resources;->getQuantityString(II[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private tzbKeyLogFocusName()Ljava/lang/String;
    .locals 4

    .line 63
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getCurrentFocus()Landroid/view/View;

    move-result-object v0

    .line 64
    .local v0, "f":Landroid/view/View;
    if-nez v0, :cond_0

    const-string v1, "null"

    return-object v1

    .line 66
    :cond_0
    :try_start_0
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v0}, Landroid/view/View;->getId()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    move-result-object v1

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    .line 67
    :catch_0
    move-exception v1

    .line 68
    .local v1, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "id="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Landroid/view/View;->getId()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method private updateCounter()V
    .locals 9

    .line 1094
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composerVisible()Z

    move-result v0

    if-eqz v0, :cond_3

    iget v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->maxBody:I

    if-gtz v0, :cond_0

    goto :goto_2

    .line 1095
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 1096
    .local v0, "text":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    .line 1097
    .local v1, "codePoints":I
    iget v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->maxBody:I

    const/4 v4, 0x1

    if-le v1, v3, :cond_1

    move v3, v4

    goto :goto_0

    :cond_1
    move v3, v2

    :goto_0
    iput-boolean v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeOverLimit:Z

    .line 1098
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->counterThreshold()I

    move-result v3

    if-le v1, v3, :cond_2

    .line 1099
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->counterView:Landroid/widget/TextView;

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_char_counter:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    iget v7, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->maxBody:I

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v8, 0x2

    new-array v8, v8, [Ljava/lang/Object;

    aput-object v6, v8, v2

    aput-object v7, v8, v4

    invoke-virtual {p0, v5, v8}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1100
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->counterView:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_1

    .line 1102
    :cond_2
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->counterView:Landroid/widget/TextView;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1105
    :goto_1
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->hasFocus()Z

    move-result v2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->applyComposeFocusStyle(Z)V

    .line 1106
    return-void

    .line 1094
    .end local v0
    .end local v1
    :cond_3
    :goto_2
    return-void
.end method

.method private updateLoadEarlierVisibility()V
    .locals 7

    .line 997
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noMoreEarlier:Z

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    .line 998
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    .line 999
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tzibbur/basic/model/TzbMessage;

    iget-wide v3, v0, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    const-wide/16 v5, 0x1

    cmp-long v0, v3, v5

    if-lez v0, :cond_0

    move v2, v1

    goto :goto_0

    :cond_0
    nop

    .line 1000
    .local v2, "show":Z
    :goto_0
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->headerShown:Z

    if-ne v2, v0, :cond_1

    return-void

    .line 1001
    :cond_1
    if-eqz v2, :cond_2

    .line 1002
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadEarlierHeader:Landroid/view/View;

    const/4 v4, 0x0

    invoke-virtual {v0, v3, v4, v1}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;Ljava/lang/Object;Z)V

    goto :goto_1

    .line 1004
    :cond_2
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadEarlierHeader:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->removeHeaderView(Landroid/view/View;)Z

    .line 1006
    :goto_1
    iput-boolean v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->headerShown:Z

    .line 1007
    return-void
.end method


# virtual methods
.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 2

    # tzib conversation: keys
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibConversationStyle;->key(Landroid/app/Activity;Landroid/view/KeyEvent;)Z
    move-result v0
    if-eqz v0, :tzib_guest_key
    return v0
    :tzib_guest_key
    .param p1, "event"    # Landroid/view/KeyEvent;

    .line 74
    sget-boolean v0, Lcom/tzibbur/basic/BuildConfig;->DEBUG:Z

    if-eqz v0, :cond_0

    .line 75
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "dispatch action="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " code="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " src=0x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 76
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getSource()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " scan="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 77
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getScanCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " dev="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 78
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " focus="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->tzbKeyLogFocusName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 75
    const-string v1, "TzbKey"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 80
    :cond_0
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result v0

    return v0
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onCommandResult(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbCommandResult;)V
    .locals 8
    .param p1, "commandGroupId"    # Ljava/lang/String;
    .param p2, "result"    # Lcom/tzibbur/basic/model/TzbCommandResult;

    .line 1237
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 1238
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->commandResults:Ljava/util/List;

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1239
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownOutbox:Ljava/util/List;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->commandResults:Ljava/util/List;

    iget-wide v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->dividerSeq:J

    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->muteGaps:Ljava/util/List;

    invoke-virtual/range {v1 .. v7}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->setData(Ljava/util/List;Ljava/util/List;Ljava/util/List;JLjava/util/List;)V

    .line 1240
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->scrollToEnd()V

    .line 1241
    const-string v0, "muted"

    iget-object v1, p2, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "unmuted"

    iget-object v1, p2, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 1243
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    .line 1245
    :cond_2
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4

    # tzib conversation: create
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->requestWindow(Landroid/app/Activity;)V
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 148
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onCreate(Landroid/os/Bundle;)V

    .line 150
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 151
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->finish()V

    .line 152
    return-void

    .line 156
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 157
    return-void

    .line 159
    :cond_1
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "tzb_group_id"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    .line 160
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    if-nez v0, :cond_2

    .line 161
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->finish()V

    .line 162
    return-void

    .line 164
    :cond_2
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_conversation_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->setContentView(I)V

    .line 168
    # Native Messages softkeys remain visible.

    .line 169
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_message_list:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    .line 170
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_compose_notice:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    .line 171
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_char_counter:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->counterView:Landroid/widget/TextView;

    .line 172
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_compose_panel:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composePanel:Landroid/view/View;

    .line 173
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_compose_label:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeLabel:Landroid/widget/TextView;

    .line 174
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_compose_edit:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    .line 175
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_send_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->sendBtn:Landroid/widget/Button;

    .line 176
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_menu_btn_bottom:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->bottomMenuBtn:Landroid/view/View;

    .line 182
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$1;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 193
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_app_name:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->setupTitleBar(Ljava/lang/CharSequence;Z)V

    .line 194
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->bottomMenuBtn:Landroid/view/View;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbConversationActivity$2;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 203
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->bottomMenuBtn:Landroid/view/View;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 227
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbConversationActivity$4;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 236
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noticeView:Landroid/widget/TextView;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbConversationActivity$5;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$5;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 251
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->sendBtn:Landroid/widget/Button;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbConversationActivity$6;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 265
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setItemsCanFocus(Z)V

    .line 266
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    sget v2, Lcom/tzibbur/basic/R$layout;->tzb_load_earlier_header:I

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    .line 267
    invoke-virtual {v0, v2, v3, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadEarlierHeader:Landroid/view/View;

    .line 269
    new-instance v0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbSession;->userId()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    .line 270
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 271
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$7;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$7;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 292
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->sendBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$8;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$8;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 298
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$9;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$9;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    .line 316
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 358
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 384
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$12;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$12;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 406
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadGroup()V

    .line 407
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V

    .line 408
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->install(Landroid/app/Activity;)V

    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 2
    .param p1, "menu"    # Landroid/view/Menu;

    .line 1301
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$menu;->tzb_conversation_menu:I

    invoke-virtual {v0, v1, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    .line 1302
    const/4 v0, 0x1

    return v0
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onGroupMessagesChanged(Ljava/lang/String;)V
    .locals 1
    .param p1, "changedGroupId"    # Ljava/lang/String;

    .line 1232
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V

    .line 1233
    :cond_0
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onGroupsChanged()V
    .locals 3

    .line 1250
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    .line 1251
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$24;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$24;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbConversationActivity$25;

    invoke-direct {v2, p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$25;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 1271
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 2
    .param p1, "keyCode"    # I
    .param p2, "event"    # Landroid/view/KeyEvent;

    .line 85
    sget-boolean v0, Lcom/tzibbur/basic/BuildConfig;->DEBUG:Z

    if-eqz v0, :cond_0

    .line 86
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "activity.onKeyDown code="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " action="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " src=0x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 87
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getSource()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " scan="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 88
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getScanCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " dev="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 89
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " focus="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->tzbKeyLogFocusName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 86
    const-string v1, "TzbKey"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 91
    :cond_0
    invoke-super {p0, p1, p2}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result v0

    return v0
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .locals 5
    .param p1, "intent"    # Landroid/content/Intent;

    .line 428
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onNewIntent(Landroid/content/Intent;)V

    .line 430
    const-string v0, "tzb_group_id"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 431
    .local v0, "newGroupId":Ljava/lang/String;
    if-nez v0, :cond_0

    return-void

    .line 432
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_2

    .line 439
    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->started:Z

    if-eqz v1, :cond_1

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V

    goto :goto_0

    :cond_1
    iput-boolean v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->scrollToNewestOnStart:Z

    .line 440
    :goto_0
    return-void

    .line 442
    :cond_2
    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->setIntent(Landroid/content/Intent;)V

    .line 443
    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    .line 444
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    .line 445
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 446
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownOutbox:Ljava/util/List;

    .line 447
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->commandResults:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 448
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->noMoreEarlier:Z

    .line 449
    iput-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialFocusDone:Z

    .line 450
    const-wide/16 v3, -0x1

    iput-wide v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->prevReadSeq:J

    .line 451
    iput-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialPositionDone:Z

    .line 452
    iput-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->unreadPositioned:Z

    .line 453
    iput-wide v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->dividerSeq:J

    .line 454
    iget-boolean v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->headerShown:Z

    if-eqz v3, :cond_3

    .line 455
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadEarlierHeader:Landroid/view/View;

    invoke-virtual {v3, v4}, Landroid/widget/ListView;->removeHeaderView(Landroid/view/View;)Z

    .line 456
    iput-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->headerShown:Z

    .line 458
    :cond_3
    new-instance v1, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v3}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v3

    invoke-interface {v3}, Lcom/tzibbur/basic/store/TzbSession;->userId()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, p0, v3}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    .line 459
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->list:Landroid/widget/ListView;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    invoke-virtual {v1, v3}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 460
    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->resumed:Z

    if-eqz v1, :cond_4

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-interface {v1, v3}, Lcom/tzibbur/basic/sync/TzbSync;->setActiveGroup(Ljava/lang/String;)V

    .line 461
    :cond_4
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadGroup()V

    .line 462
    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V

    .line 463
    return-void
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 6

    # tzib message actions: option
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibMessageActions;->option(Landroid/app/Activity;Landroid/view/MenuItem;)Z
    move-result v0
    if-eqz v0, :tzib_group_option
    return v0
    :tzib_group_option
    .param p1, "item"    # Landroid/view/MenuItem;

    .line 1324
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    .line 1325
    .local v0, "id":I
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_menu_group_info:I

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    .line 1326
    new-instance v1, Landroid/content/Intent;

    const-class v3, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-direct {v1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1327
    .local v1, "intent":Landroid/content/Intent;
    const-string v3, "tzb_group_id"

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-virtual {v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 1328
    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->startActivity(Landroid/content/Intent;)V

    .line 1329
    return v2

    .line 1331
    .end local v1
    :cond_0
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_menu_members:I

    if-ne v0, v1, :cond_1

    .line 1334
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->openMembers()V

    .line 1335
    return v2

    .line 1337
    :cond_1
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_menu_mute:I

    if-ne v0, v1, :cond_4

    .line 1341
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-boolean v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->muted:Z

    if-eqz v1, :cond_2

    move v1, v2

    goto :goto_0

    :cond_2
    const/4 v1, 0x0

    .line 1342
    .local v1, "muted":Z
    :goto_0
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v3}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v3

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    if-eqz v1, :cond_3

    const-string v5, "#unmute"

    goto :goto_1

    :cond_3
    const-string v5, "#mute"

    :goto_1
    invoke-interface {v3, v4, v5}, Lcom/tzibbur/basic/sync/TzbSync;->enqueueSend(Ljava/lang/String;Ljava/lang/String;)V

    .line 1343
    return v2

    .line 1345
    .end local v1
    :cond_4
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_menu_refresh:I

    if-ne v0, v1, :cond_5

    .line 1346
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/sync/TzbSync;->nudge()V

    .line 1347
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    .line 1348
    return v2

    .line 1350
    :cond_5
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result v1

    return v1
.end method

.method protected onPause()V
    .locals 2

    .line 495
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->resumed:Z

    .line 496
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/sync/TzbSync;->setActiveGroup(Ljava/lang/String;)V

    .line 497
    invoke-super {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onPause()V

    .line 498
    return-void
.end method

.method public onPrepareOptionsMenu(Landroid/view/Menu;)Z
    .locals 6
    .param p1, "menu"    # Landroid/view/Menu;

    .line 1307
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    .line 1308
    .local v0, "known":Z
    :goto_0
    if-eqz v0, :cond_1

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v3}, Lcom/tzibbur/basic/model/TzbGroup;->isSystem()Z

    move-result v3

    if-eqz v3, :cond_1

    move v3, v1

    goto :goto_1

    :cond_1
    move v3, v2

    .line 1312
    .local v3, "system":Z
    :goto_1
    sget v4, Lcom/tzibbur/basic/R$id;->tzb_menu_group_info:I

    invoke-interface {p1, v4}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v4

    if-eqz v0, :cond_2

    if-nez v3, :cond_2

    move v5, v1

    goto :goto_2

    :cond_2
    move v5, v2

    :goto_2
    invoke-interface {v4, v5}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 1313
    sget v4, Lcom/tzibbur/basic/R$id;->tzb_menu_members:I

    invoke-interface {p1, v4}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v4

    if-eqz v0, :cond_3

    if-nez v3, :cond_3

    move v5, v1

    goto :goto_3

    :cond_3
    move v5, v2

    :goto_3
    invoke-interface {v4, v5}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 1314
    sget v4, Lcom/tzibbur/basic/R$id;->tzb_menu_mute:I

    invoke-interface {p1, v4}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v4

    .line 1315
    .local v4, "mute":Landroid/view/MenuItem;
    if-eqz v0, :cond_4

    if-nez v3, :cond_4

    goto :goto_4

    :cond_4
    move v1, v2

    :goto_4
    invoke-interface {v4, v1}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 1316
    if-eqz v0, :cond_6

    if-nez v3, :cond_6

    .line 1317
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-boolean v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->muted:Z

    if-eqz v1, :cond_5

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_menu_unmute:I

    goto :goto_5

    :cond_5
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_menu_mute:I

    :goto_5
    invoke-interface {v4, v1}, Landroid/view/MenuItem;->setTitle(I)Landroid/view/MenuItem;

    .line 1319
    :cond_6
    # tzib message actions: prepare
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibMessageActions;->prepare(Landroid/app/Activity;Landroid/view/Menu;)V

    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onPrepareOptionsMenu(Landroid/view/Menu;)Z

    move-result v1

    return v1
.end method

.method protected onResume()V
    .locals 2

    .line 487
    invoke-super {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onResume()V

    .line 488
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->resumed:Z

    .line 489
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/sync/TzbSync;->setActiveGroup(Ljava/lang/String;)V

    .line 490
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->markRead()V

    .line 491
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onSendFailed(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
    .locals 3
    .param p1, "failedGroupId"    # Ljava/lang/String;
    .param p2, "problemCode"    # Ljava/lang/String;
    .param p3, "errors"    # Lorg/json/JSONObject;

    .line 1275
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->groupId:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 1276
    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, p2, p3, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->problemText(Ljava/lang/String;Lorg/json/JSONObject;I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 1277
    const-string v1, "posting_not_allowed"

    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 1280
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    goto :goto_1

    .line 1281
    :cond_1
    const-string v1, "not_found"

    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 1283
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    goto :goto_1

    .line 1284
    :cond_2
    const-string v1, "group_too_small"

    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    .line 1289
    if-eqz p3, :cond_3

    const-string v1, "minMembers"

    invoke-virtual {p3, v1, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    goto :goto_0

    :cond_3
    move v1, v0

    .line 1290
    .local v1, "minMembers":I
    :goto_0
    if-lez v1, :cond_4

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v2}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v2

    invoke-interface {v2, v1}, Lcom/tzibbur/basic/store/TzbSession;->setMinMembers(I)V

    .line 1291
    :cond_4
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    if-eqz v2, :cond_5

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->applyGroup()V

    .line 1292
    :cond_5
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v2}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v2

    invoke-interface {v2}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    .line 1294
    .end local v1
    :cond_6
    :goto_1
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V

    .line 1295
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onStart()V
    .locals 1

    .line 467
    invoke-super {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onStart()V

    .line 468
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->started:Z

    .line 475
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->initialPositionDone:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->scrollToNewestOnStart:Z

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V

    .line 476
    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->scrollToNewestOnStart:Z

    .line 477
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onStop()V
    .locals 1

    .line 481
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->started:Z

    .line 482
    invoke-super {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onStop()V

    .line 483
    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .locals 3
    .param p1, "hasFocus"    # Z

    .line 412
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onWindowFocusChanged(Z)V

    .line 417
    if-eqz p1, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 418
    nop

    .line 419
    const-string v0, "input_method"

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 420
    .local v0, "imm":Landroid/view/inputmethod/InputMethodManager;
    if-eqz v0, :cond_0

    .line 421
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->composeEdit:Landroid/widget/EditText;

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    .line 424
    .end local v0
    :cond_0
    # tzib conversation: refresh
    invoke-static {p0}, Lcom/android/mms/tzib/TzibConversationStyle;->refresh(Landroid/app/Activity;)V

    return-void
.end method

.method public tzibFocusMessages()V
    .locals 1
    const/4 v0, 0x1
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->focusListAtViewport(Z)V
    return-void
.end method

# Drop the exact local reply/object immediately; the adapter also filters stale sync snapshots.
.method public tzibRemoveMessage(Ljava/lang/Object;)V
    .locals 7
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownMessages:Ljava/util/List;
    invoke-interface {v1, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->shownOutbox:Ljava/util/List;
    invoke-interface {v2, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->commandResults:Ljava/util/List;
    invoke-interface {v3, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMessageListAdapter;
    iget-wide v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->dividerSeq:J
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->muteGaps:Ljava/util/List;
    invoke-virtual/range {v0 .. v6}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->setData(Ljava/util/List;Ljava/util/List;Ljava/util/List;JLjava/util/List;)V
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->updateLoadEarlierVisibility()V
    # Refill from older cached history when the last displayed stored message is deleted.
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z
    move-result v0
    if-eqz v0, :tzib_removed
    const/4 v0, 0x0
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V
    :tzib_removed
    return-void
.end method
