.class Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;
.super Ljava/lang/Object;
.source "TzbEnrollPhoneActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->startAuth()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbAuthStart;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

.field final synthetic val$phone:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 262
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->val$phone:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "error"    # Ljava/lang/Exception;

    .line 281
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$402(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)Z

    .line 282
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$500(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)V

    .line 283
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$700(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/Exception;)V

    .line 284
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbAuthStart;)V
    .locals 3
    .param p1, "start"    # Lcom/tzibbur/basic/model/TzbAuthStart;

    .line 265
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$402(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)Z

    .line 266
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$500(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)V

    .line 267
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const-string v1, ""

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$600(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V

    .line 268
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const-class v2, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 270
    .local v0, "next":Landroid/content/Intent;
    const-string v1, "tzb_challenge_id"

    iget-object v2, p1, Lcom/tzibbur/basic/model/TzbAuthStart;->challengeId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 271
    const-string v1, "tzb_phone"

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->val$phone:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 272
    const-string v1, "tzb_expires_at"

    iget-object v2, p1, Lcom/tzibbur/basic/model/TzbAuthStart;->expiresAt:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 273
    const-string v1, "tzb_resend_after_seconds"

    iget v2, p1, Lcom/tzibbur/basic/model/TzbAuthStart;->resendAfterSeconds:I

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 275
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-virtual {v1, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->startActivity(Landroid/content/Intent;)V

    .line 277
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 262
    check-cast p1, Lcom/tzibbur/basic/model/TzbAuthStart;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;->onResult(Lcom/tzibbur/basic/model/TzbAuthStart;)V

    return-void
.end method
