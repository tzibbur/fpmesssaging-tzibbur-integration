.class Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;
.super Ljava/lang/Object;
.source "TzbGroupCreateActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->create()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbGroup;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 214
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "error"    # Ljava/lang/Exception;

    .line 226
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$500(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/Button;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 227
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    iget-object v0, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    .line 228
    const-string v1, "invalid_category"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 230
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 231
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$000(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    goto :goto_0

    .line 233
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 235
    :goto_0
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbGroup;)V
    .locals 3
    .param p1, "group"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 217
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    const-class v2, Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 219
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "tzb_group_id"

    iget-object v2, p1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 220
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-virtual {v1, v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->startActivity(Landroid/content/Intent;)V

    .line 221
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-virtual {v1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->finish()V

    .line 222
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 214
    check-cast p1, Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;->onResult(Lcom/tzibbur/basic/model/TzbGroup;)V

    return-void
.end method
