.class Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$3;
.super Ljava/lang/Object;
.source "TzbEnrollCodeActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->armReceiver()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 260
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onOtpCode(Ljava/lang/String;)V
    .locals 1
    .param p1, "code"    # Ljava/lang/String;

    .line 263
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$200(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/String;)V

    .line 264
    return-void
.end method
