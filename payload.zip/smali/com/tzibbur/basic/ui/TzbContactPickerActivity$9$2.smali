.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

.field final synthetic val$cachedMatches:Ljava/util/List;

.field final synthetic val$names:Ljava/util/Map;

.field final synthetic val$uncached:Ljava/util/List;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;Ljava/util/Map;Ljava/util/List;Ljava/util/List;)V
    .locals 0
    .param p1, "this$1"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 322
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->val$names:Ljava/util/Map;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->val$cachedMatches:Ljava/util/List;

    iput-object p4, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->val$uncached:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 325
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$900(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Ljava/util/Map;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->val$names:Ljava/util/Map;

    invoke-interface {v0, v1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    .line 326
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$000(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->val$cachedMatches:Ljava/util/List;

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->addMatches(Ljava/util/List;)V

    .line 327
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 328
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Ljava/util/List;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->val$uncached:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 329
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1202(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;I)I

    .line 330
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->val$uncached:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1302(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;I)I

    .line 331
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    .line 332
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1400(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    .line 333
    return-void
.end method
