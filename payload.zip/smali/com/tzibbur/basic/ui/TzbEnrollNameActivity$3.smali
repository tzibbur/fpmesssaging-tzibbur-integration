.class Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$3;
.super Ljava/lang/Object;
.source "TzbEnrollNameActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 114
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 117
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->access$200(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V

    .line 118
    return-void
.end method
