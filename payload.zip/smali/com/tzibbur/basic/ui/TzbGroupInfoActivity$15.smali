.class Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;
.super Ljava/lang/Object;
.source "TzbGroupInfoActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->delete()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 302
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 302
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;->call()Ljava/lang/Void;

    move-result-object v0

    return-object v0
.end method

.method public call()Ljava/lang/Void;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 305
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/net/TzbApi;->deleteGroup(Ljava/lang/String;)V

    .line 306
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbStore;->removeGroup(Ljava/lang/String;)V

    .line 307
    const/4 v0, 0x0

    return-object v0
.end method
