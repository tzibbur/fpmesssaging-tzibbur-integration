.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$3;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 140
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 143
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$000(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->selectedPhones()Ljava/util/ArrayList;

    move-result-object v0

    .line 144
    .local v0, "phones":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    .line 145
    :cond_0
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const-string v2, "tzb_phones"

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putStringArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    move-result-object v1

    .line 146
    .local v1, "data":Landroid/content/Intent;
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    const/4 v3, -0x1

    invoke-virtual {v2, v3, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->setResult(ILandroid/content/Intent;)V

    .line 147
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-virtual {v2}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->finish()V

    .line 148
    return-void
.end method
