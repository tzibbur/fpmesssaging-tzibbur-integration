.class public final Lcom/tzibbur/basic/ui/TzbGroupListAdapter;
.super Landroid/widget/BaseAdapter;
.source "TzbGroupListAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;
    }
.end annotation


# static fields
.field private static final UNREAD_OVERFLOW:I = 0x3e7


# instance fields
.field private final context:Landroid/content/Context;

.field private final inflater:Landroid/view/LayoutInflater;

.field private final rows:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .line 39
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 37
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->rows:Ljava/util/List;

    .line 40
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->context:Landroid/content/Context;

    .line 41
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 42
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 52
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->rows:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 57
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->rows:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 62
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 10
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 67
    const/4 v0, 0x0

    if-eqz p2, :cond_0

    .line 68
    move-object v1, p2

    goto :goto_0

    .line 69
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v2, Lcom/tzibbur/basic/R$layout;->tzb_group_list_item:I

    invoke-virtual {v1, v2, p3, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    :goto_0
    nop

    .line 70
    .local v1, "view":Landroid/view/View;
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->rows:Ljava/util/List;

    invoke-interface {v2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;

    .line 72
    .local v2, "row":Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;
    sget v3, Lcom/tzibbur/basic/R$id;->tzb_group_name:I

    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    .line 73
    .local v3, "name":Landroid/widget/TextView;
    sget v4, Lcom/tzibbur/basic/R$id;->tzb_group_snippet:I

    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    .line 74
    .local v4, "snippet":Landroid/widget/TextView;
    sget v5, Lcom/tzibbur/basic/R$id;->tzb_group_muted:I

    invoke-virtual {v1, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    .line 75
    .local v5, "muted":Landroid/widget/TextView;
    sget v6, Lcom/tzibbur/basic/R$id;->tzb_group_unread:I

    invoke-virtual {v1, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 78
    .local v6, "unread":Landroid/widget/TextView;
    iget-object v7, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v7}, Lcom/tzibbur/basic/model/TzbGroup;->isSystem()Z

    move-result v7

    if-eqz v7, :cond_1

    .line 79
    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->context:Landroid/content/Context;

    sget v8, Lcom/tzibbur/basic/R$string;->tzb_system_sender_name:I

    invoke-virtual {v7, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 80
    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->context:Landroid/content/Context;

    sget v8, Lcom/tzibbur/basic/R$color;->tzb_accent:I

    invoke-virtual {v7, v8}, Landroid/content/Context;->getColor(I)I

    move-result v7

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_1

    .line 82
    :cond_1
    iget-object v7, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v7, v7, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 83
    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->context:Landroid/content/Context;

    sget v8, Lcom/tzibbur/basic/R$color;->tzb_text_primary:I

    invoke-virtual {v7, v8}, Landroid/content/Context;->getColor(I)I

    move-result v7

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 85
    :goto_1
    iget v7, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->unread:I

    if-lez v7, :cond_2

    const/4 v7, 0x1

    goto :goto_2

    :cond_2
    move v7, v0

    :goto_2
    const/4 v8, 0x0

    invoke-virtual {v3, v8, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 87
    iget-object v7, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->snippet:Ljava/lang/String;

    if-eqz v7, :cond_3

    .line 89
    iget-object v7, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->snippet:Ljava/lang/String;

    const/16 v8, 0xa

    const/16 v9, 0x20

    invoke-virtual {v7, v8, v9}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_3

    .line 91
    :cond_3
    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->context:Landroid/content/Context;

    sget v8, Lcom/tzibbur/basic/R$string;->tzb_no_messages_yet:I

    invoke-virtual {v7, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 94
    :goto_3
    iget-object v7, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-boolean v7, v7, Lcom/tzibbur/basic/model/TzbGroup;->muted:Z

    const/16 v8, 0x8

    if-eqz v7, :cond_4

    move v7, v0

    goto :goto_4

    :cond_4
    move v7, v8

    :goto_4
    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setVisibility(I)V

    .line 95
    iget v7, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->unread:I

    if-lez v7, :cond_6

    .line 98
    iget v7, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->unread:I

    const/16 v8, 0x3e7

    if-lt v7, v8, :cond_5

    .line 99
    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->context:Landroid/content/Context;

    sget v8, Lcom/tzibbur/basic/R$string;->tzb_unread_overflow:I

    invoke-virtual {v7, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    goto :goto_5

    .line 100
    :cond_5
    iget v7, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->unread:I

    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    .line 98
    :goto_5
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 101
    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_6

    .line 103
    :cond_6
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setVisibility(I)V

    .line 105
    :goto_6
    return-object v1
.end method

.method public setRows(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;",
            ">;)V"
        }
    .end annotation

    .line 45
    .local p1, "newRows":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->rows:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 46
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->rows:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 47
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->notifyDataSetChanged()V

    .line 48
    return-void
.end method
