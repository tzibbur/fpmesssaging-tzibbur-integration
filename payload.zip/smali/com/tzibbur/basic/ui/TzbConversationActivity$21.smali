.class Lcom/tzibbur/basic/ui/TzbConversationActivity$21;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->confirmResend(Lcom/tzibbur/basic/store/TzbOutboxItem;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

.field final synthetic val$item:Lcom/tzibbur/basic/store/TzbOutboxItem;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/store/TzbOutboxItem;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1135
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;->val$item:Lcom/tzibbur/basic/store/TzbOutboxItem;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 1138
    new-instance v0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21$1;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$21$1;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity$21;)V

    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/lang/Runnable;)V

    .line 1144
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;->val$item:Lcom/tzibbur/basic/store/TzbOutboxItem;

    iget-object v2, v2, Lcom/tzibbur/basic/store/TzbOutboxItem;->body:Ljava/lang/String;

    invoke-interface {v0, v1, v2}, Lcom/tzibbur/basic/sync/TzbSync;->enqueueSend(Ljava/lang/String;Ljava/lang/String;)V

    .line 1145
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4500(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)V

    .line 1146
    return-void
.end method
