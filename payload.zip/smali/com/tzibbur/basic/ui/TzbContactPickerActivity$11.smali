.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$11;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->post(Ljava/lang/Runnable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

.field final synthetic val$task:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/lang/Runnable;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 496
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$11;->val$task:Ljava/lang/Runnable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 499
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1900(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$11;->val$task:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 500
    :cond_0
    return-void
.end method
