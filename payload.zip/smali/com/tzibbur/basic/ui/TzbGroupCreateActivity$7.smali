.class Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;
.super Ljava/lang/Object;
.source "TzbGroupCreateActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->fetchCategories()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Ljava/util/List<",
        "Ljava/lang/String;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 169
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "error"    # Ljava/lang/Exception;

    .line 185
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/TextView;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_error_network:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 186
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$800(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/Button;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 187
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 188
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 169
    check-cast p1, Ljava/util/List;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->onResult(Ljava/util/List;)V

    return-void
.end method

.method public onResult(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 172
    .local p1, "result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$902(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;Ljava/util/List;)Ljava/util/List;

    .line 173
    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 174
    .local v0, "labels":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 175
    .local v2, "slug":Ljava/lang/String;
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v3, v2}, Lcom/tzibbur/basic/ui/TzbCategoryLabels;->label(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 176
    .end local v2
    goto :goto_0

    .line 177
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$300(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/ListView;

    move-result-object v1

    new-instance v2, Landroid/widget/ArrayAdapter;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    sget v4, Lcom/tzibbur/basic/R$layout;->tzb_category_item:I

    invoke-direct {v2, v3, v4, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 179
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/TextView;

    move-result-object v1

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 180
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$300(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/ListView;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setVisibility(I)V

    .line 181
    return-void
.end method
