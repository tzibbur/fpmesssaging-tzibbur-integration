.class Lcom/tzibbur/basic/ui/TzbApplyActivity$13;
.super Ljava/lang/Object;
.source "TzbApplyActivity.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;->scrollTopOnUp(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 712
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "keyCode"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .line 715
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/16 v0, 0x13

    if-ne p2, v0, :cond_0

    .line 717
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$2100(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/widget/ScrollView;

    move-result-object v0

    invoke-virtual {v0, v2, v2}, Landroid/widget/ScrollView;->smoothScrollTo(II)V

    .line 718
    return v1

    .line 721
    :cond_0
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_1

    const/16 v0, 0x14

    if-ne p2, v0, :cond_1

    .line 723
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$2200(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 724
    return v1

    .line 726
    :cond_1
    return v2
.end method
