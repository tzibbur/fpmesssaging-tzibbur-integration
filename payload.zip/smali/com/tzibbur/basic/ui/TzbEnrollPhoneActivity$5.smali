.class Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;
.super Ljava/lang/Object;
.source "TzbEnrollPhoneActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->runDetection()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 198
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 0
    .param p1, "error"    # Ljava/lang/Exception;

    .line 214
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 198
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;->onResult(Ljava/lang/String;)V

    return-void
.end method

.method public onResult(Ljava/lang/String;)V
    .locals 2
    .param p1, "number"    # Ljava/lang/String;

    .line 201
    if-eqz p1, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$100(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-interface {v0}, Landroid/text/Editable;->length()I

    move-result v0

    if-nez v0, :cond_0

    .line 202
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$100(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 203
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$100(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/EditText;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$100(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-interface {v1}, Landroid/text/Editable;->length()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSelection(I)V

    .line 204
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$200(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/TextView;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 207
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$100(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$300(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    .line 209
    :cond_0
    return-void
.end method
