.class public Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
.super Lcom/tzibbur/basic/ui/TzbBaseActivity;
.source "TzbGroupInfoActivity.java"


# static fields
.field private static final MAX_NAME_CODE_POINTS_FALLBACK:I = 0x64


# instance fields
.field private addValue:Landroid/widget/TextView;

.field private categoryValue:Landroid/widget/TextView;

.field private deleteBtn:Landroid/widget/Button;

.field private group:Lcom/tzibbur/basic/model/TzbGroup;

.field private groupId:Ljava/lang/String;

.field private leaveBtn:Landroid/widget/Button;

.field private membersValue:Landroid/widget/TextView;

.field private mutedValue:Landroid/widget/TextView;

.field private nameValue:Landroid/widget/TextView;

.field private postValue:Landroid/widget/TextView;

.field private renameBtn:Landroid/widget/Button;

.field private roleValue:Landroid/widget/TextView;

.field private toggleAddBtn:Landroid/widget/Button;

.field private togglePostBtn:Landroid/widget/Button;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->showRenameDialog()V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->togglePosting()V

    return-void
.end method

.method static synthetic access$1000(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->delete()V

    return-void
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->toggleAdding()V

    return-void
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->confirmLeave()V

    return-void
.end method

.method static synthetic access$400(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->confirmDelete()V

    return-void
.end method

.method static synthetic access$502(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Lcom/tzibbur/basic/model/TzbGroup;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 26
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    return-object p1
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->render()V

    return-void
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .param p1, "x1"    # Ljava/lang/String;
    .param p2, "x2"    # Ljava/lang/String;
    .param p3, "x3"    # Ljava/lang/String;

    .line 26
    invoke-direct {p0, p1, p2, p3}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->update(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$800(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->leave()V

    return-void
.end method

.method static synthetic access$900(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    .line 26
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->backToGroupList()V

    return-void
.end method

.method private backToGroupList()V
    .locals 2

    .line 324
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/android/mms/ui/ConversationList;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 325
    .local v0, "intent":Landroid/content/Intent;
    const/high16 v1, 0x24000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 326
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->startActivity(Landroid/content/Intent;)V

    .line 327
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->finish()V

    .line 328
    return-void
.end method

.method private confirmDelete()V
    .locals 3

    .line 276
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_action_delete:I

    .line 277
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_delete_confirm_1:I

    .line 278
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_delete:I

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    .line 279
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 296
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 297
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 298
    return-void
.end method

.method private confirmLeave()V
    .locals 3

    .line 239
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_action_leave:I

    .line 240
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_leave_confirm:I

    .line 241
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_leave:I

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$11;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$11;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    .line 242
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 248
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 249
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 250
    return-void
.end method

.method private delete()V
    .locals 3

    .line 301
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->groupId:Ljava/lang/String;

    .line 302
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$15;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Ljava/lang/String;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$16;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$16;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 320
    return-void
.end method

.method private leave()V
    .locals 3

    .line 253
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->groupId:Ljava/lang/String;

    .line 254
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$12;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$12;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Ljava/lang/String;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$13;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$13;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 272
    return-void
.end method

.method private loadGroup()V
    .locals 3

    .line 119
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->groupId:Ljava/lang/String;

    .line 120
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$6;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Ljava/lang/String;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$7;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$7;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 141
    return-void
.end method

.method private render()V
    .locals 5

    .line 144
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->nameValue:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 145
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->categoryValue:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->category:Ljava/lang/String;

    invoke-static {p0, v1}, Lcom/tzibbur/basic/ui/TzbCategoryLabels;->label(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 146
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->membersValue:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->memberCount:I

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 147
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->roleValue:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v1}, Lcom/tzibbur/basic/model/TzbGroup;->callerIsAdmin()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 148
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_role_admin:I

    goto :goto_0

    :cond_0
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_role_member:I

    .line 147
    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 149
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->mutedValue:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-boolean v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->muted:Z

    if-eqz v1, :cond_1

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_value_yes:I

    goto :goto_1

    :cond_1
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_value_no:I

    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 150
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->postValue:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->whoCanPost:Ljava/lang/String;

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->settingLabel(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 151
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->addValue:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v1, v1, Lcom/tzibbur/basic/model/TzbGroup;->whoCanAddMembers:Ljava/lang/String;

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->settingLabel(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 153
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v0}, Lcom/tzibbur/basic/model/TzbGroup;->callerIsAdmin()Z

    move-result v0

    .line 154
    .local v0, "admin":Z
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->renameBtn:Landroid/widget/Button;

    const/4 v2, 0x0

    const/16 v3, 0x8

    if-eqz v0, :cond_2

    move v4, v2

    goto :goto_2

    :cond_2
    move v4, v3

    :goto_2
    invoke-virtual {v1, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 155
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->togglePostBtn:Landroid/widget/Button;

    if-eqz v0, :cond_3

    move v4, v2

    goto :goto_3

    :cond_3
    move v4, v3

    :goto_3
    invoke-virtual {v1, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 156
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->toggleAddBtn:Landroid/widget/Button;

    if-eqz v0, :cond_4

    move v4, v2

    goto :goto_4

    :cond_4
    move v4, v3

    :goto_4
    invoke-virtual {v1, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 157
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->deleteBtn:Landroid/widget/Button;

    if-eqz v0, :cond_5

    goto :goto_5

    :cond_5
    move v2, v3

    :goto_5
    invoke-virtual {v1, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 158
    if-eqz v0, :cond_8

    .line 160
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->togglePostBtn:Landroid/widget/Button;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v2, v2, Lcom/tzibbur/basic/model/TzbGroup;->whoCanPost:Ljava/lang/String;

    const-string v3, "everyone"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    .line 161
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_action_post_admins:I

    goto :goto_6

    .line 162
    :cond_6
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_action_post_everyone:I

    .line 160
    :goto_6
    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(I)V

    .line 163
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->toggleAddBtn:Landroid/widget/Button;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v2, v2, Lcom/tzibbur/basic/model/TzbGroup;->whoCanAddMembers:Ljava/lang/String;

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    .line 164
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_action_add_admins:I

    goto :goto_7

    .line 165
    :cond_7
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_action_add_everyone:I

    .line 163
    :goto_7
    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(I)V

    .line 167
    :cond_8
    return-void
.end method

.method private settingLabel(Ljava/lang/String;)I
    .locals 1
    .param p1, "setting"    # Ljava/lang/String;

    .line 170
    const-string v0, "admins"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 171
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_value_admins:I

    goto :goto_0

    :cond_0
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_value_everyone:I

    .line 170
    :goto_0
    return v0
.end method

.method private showRenameDialog()V
    .locals 6

    .line 177
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$layout;->tzb_dialog_edit:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 178
    .local v0, "content":Landroid/view/View;
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_dialog_edit_text:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    .line 179
    .local v1, "edit":Landroid/widget/EditText;
    sget v3, Lcom/tzibbur/basic/R$string;->tzb_group_name_hint:I

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setHint(I)V

    .line 180
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v3, v3, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 181
    new-instance v3, Landroid/app/AlertDialog$Builder;

    invoke-direct {v3, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_action_rename:I

    .line 182
    invoke-virtual {v3, v4}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    .line 183
    invoke-virtual {v3, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_ok:I

    new-instance v5, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$8;

    invoke-direct {v5, p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$8;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Landroid/widget/EditText;)V

    .line 184
    invoke-virtual {v3, v4, v5}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 197
    invoke-virtual {v3, v4, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    .line 198
    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v2

    .line 199
    .local v2, "dialog":Landroid/app/AlertDialog;
    invoke-static {v2, v1}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->attachDialogIme(Landroid/app/AlertDialog;Landroid/widget/EditText;)V

    .line 200
    return-void
.end method

.method private toggleAdding()V
    .locals 2

    .line 208
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v0, v0, Lcom/tzibbur/basic/model/TzbGroup;->whoCanAddMembers:Ljava/lang/String;

    const-string v1, "everyone"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 209
    const-string v1, "admins"

    goto :goto_0

    :cond_0
    nop

    .line 208
    :goto_0
    const/4 v0, 0x0

    invoke-direct {p0, v0, v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->update(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 210
    return-void
.end method

.method private togglePosting()V
    .locals 2

    .line 203
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v0, v0, Lcom/tzibbur/basic/model/TzbGroup;->whoCanPost:Ljava/lang/String;

    const-string v1, "everyone"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 204
    const-string v1, "admins"

    goto :goto_0

    :cond_0
    nop

    .line 203
    :goto_0
    const/4 v0, 0x0

    invoke-direct {p0, v0, v1, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->update(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 205
    return-void
.end method

.method private update(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 6
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "whoCanPost"    # Ljava/lang/String;
    .param p3, "whoCanAddMembers"    # Ljava/lang/String;

    .line 214
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->groupId:Ljava/lang/String;

    .line 215
    .local v2, "gid":Ljava/lang/String;
    new-instance v0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;

    move-object v1, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    .end local p1
    .end local p2
    .end local p3
    .local v3, "name":Ljava/lang/String;
    .local v4, "whoCanPost":Ljava/lang/String;
    .local v5, "whoCanAddMembers":Ljava/lang/String;
    invoke-direct/range {v0 .. v5}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$9;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$10;

    invoke-direct {p1, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$10;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    invoke-static {v0, p1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 234
    return-void
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 48
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onCreate(Landroid/os/Bundle;)V

    .line 50
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 51
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->finish()V

    .line 52
    return-void

    .line 56
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 57
    return-void

    .line 59
    :cond_1
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "tzb_group_id"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->groupId:Ljava/lang/String;

    .line 60
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->groupId:Ljava/lang/String;

    if-nez v0, :cond_2

    .line 61
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->finish()V

    .line 62
    return-void

    .line 64
    :cond_2
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_group_info_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->setContentView(I)V

    .line 67
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 69
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_group_info_title:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->setupTitleBar(Ljava/lang/CharSequence;Z)V

    .line 71
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_info_name_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->nameValue:Landroid/widget/TextView;

    .line 72
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_info_category_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->categoryValue:Landroid/widget/TextView;

    .line 73
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_info_members_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->membersValue:Landroid/widget/TextView;

    .line 74
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_info_role_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->roleValue:Landroid/widget/TextView;

    .line 75
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_info_muted_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->mutedValue:Landroid/widget/TextView;

    .line 76
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_info_post_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->postValue:Landroid/widget/TextView;

    .line 77
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_info_add_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->addValue:Landroid/widget/TextView;

    .line 78
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_rename_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->renameBtn:Landroid/widget/Button;

    .line 79
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_toggle_post_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->togglePostBtn:Landroid/widget/Button;

    .line 80
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_toggle_add_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->toggleAddBtn:Landroid/widget/Button;

    .line 81
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_leave_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->leaveBtn:Landroid/widget/Button;

    .line 82
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_delete_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->deleteBtn:Landroid/widget/Button;

    .line 84
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->renameBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$1;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 90
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->togglePostBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$2;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 96
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->toggleAddBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$3;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 102
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->leaveBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$4;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 108
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->deleteBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$5;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$5;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 115
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->loadGroup()V

    .line 116
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onGroupsChanged()V
    .locals 0

    .line 334
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->loadGroup()V

    .line 335
    return-void
.end method
