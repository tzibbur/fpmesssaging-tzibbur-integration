.class Lcom/tzibbur/basic/ui/TzbConversationActivity$10;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 316
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "keyCode"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .line 320
    sget-boolean v0, Lcom/tzibbur/basic/BuildConfig;->DEBUG:Z

    if-eqz v0, :cond_0

    .line 321
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "editor.onKey action="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " code="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " firstLine="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 322
    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1500(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " lastLine="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 323
    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " selStart="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 324
    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getSelectionStart()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " selEnd="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 325
    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getSelectionEnd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " lineCount="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 326
    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getLineCount()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 321
    const-string v1, "TzbKey"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 329
    :cond_0
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    return v1

    .line 330
    :cond_1
    const/16 v0, 0x13

    const/4 v2, 0x1

    if-ne p2, v0, :cond_3

    .line 331
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1500(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 334
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$900(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)V

    .line 335
    return v2

    .line 337
    :cond_2
    return v1

    .line 339
    :cond_3
    const/16 v0, 0x14

    if-ne p2, v0, :cond_6

    .line 340
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 349
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$400(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    move-result v0

    if-eqz v0, :cond_4

    return v2

    .line 350
    :cond_4
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    return v0

    .line 352
    :cond_5
    return v1

    .line 354
    :cond_6
    return v1
.end method
