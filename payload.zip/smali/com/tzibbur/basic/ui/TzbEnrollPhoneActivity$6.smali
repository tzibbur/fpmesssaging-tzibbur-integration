.class Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;
.super Ljava/lang/Object;
.source "TzbEnrollPhoneActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->startAuth()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbAuthStart;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

.field final synthetic val$api:Lcom/tzibbur/basic/net/TzbApi;

.field final synthetic val$imei:Ljava/lang/String;

.field final synthetic val$phone:Ljava/lang/String;

.field final synthetic val$serial:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Lcom/tzibbur/basic/net/TzbApi;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 255
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->val$api:Lcom/tzibbur/basic/net/TzbApi;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->val$phone:Ljava/lang/String;

    iput-object p4, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->val$serial:Ljava/lang/String;

    iput-object p5, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->val$imei:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbAuthStart;
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 260
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->val$api:Lcom/tzibbur/basic/net/TzbApi;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->val$phone:Ljava/lang/String;

    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->val$serial:Ljava/lang/String;

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->val$imei:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface/range {v0 .. v6}, Lcom/tzibbur/basic/net/TzbApi;->authStart(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbAuthStart;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 255
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;->call()Lcom/tzibbur/basic/model/TzbAuthStart;

    move-result-object v0

    return-object v0
.end method
