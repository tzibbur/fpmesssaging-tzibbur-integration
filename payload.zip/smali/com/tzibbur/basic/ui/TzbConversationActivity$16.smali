.class Lcom/tzibbur/basic/ui/TzbConversationActivity$16;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "[",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

.field final synthetic val$baseLimit:I

.field final synthetic val$firstLoad:Z

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;IZLjava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 721
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iput p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$baseLimit:I

    iput-boolean p3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$firstLoad:Z

    iput-object p4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 721
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->call()[Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public call()[Ljava/lang/Object;
    .locals 10

    .line 724
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    .line 725
    .local v0, "store":Lcom/tzibbur/basic/store/TzbStore;
    iget v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$baseLimit:I

    .line 726
    .local v1, "limit":I
    iget-boolean v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$firstLoad:Z

    if-eqz v2, :cond_0

    .line 731
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$gid:Ljava/lang/String;

    invoke-static {v2, v0, v3}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2400(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/store/TzbStore;Ljava/lang/String;)J

    move-result-wide v2

    .line 732
    .local v2, "prev":J
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v4}, Lcom/tzibbur/basic/store/TzbStore;->maxSeq(Ljava/lang/String;)J

    move-result-wide v4

    sub-long/2addr v4, v2

    .line 733
    .local v4, "gap":J
    const-wide/16 v6, 0x0

    cmp-long v8, v2, v6

    if-ltz v8, :cond_0

    cmp-long v6, v4, v6

    if-lez v6, :cond_0

    .line 734
    const-wide/16 v6, 0x5

    add-long/2addr v6, v4

    const-wide/16 v8, 0x1f4

    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v6

    long-to-int v6, v6

    invoke-static {v1, v6}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 737
    .end local v2
    .end local v4
    :cond_0
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$gid:Ljava/lang/String;

    .line 738
    invoke-interface {v0, v2, v1}, Lcom/tzibbur/basic/store/TzbStore;->latestMessages(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v2

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$gid:Ljava/lang/String;

    .line 739
    invoke-interface {v0, v3}, Lcom/tzibbur/basic/store/TzbStore;->outbox(Ljava/lang/String;)Ljava/util/List;

    move-result-object v3

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$16;->val$gid:Ljava/lang/String;

    .line 740
    invoke-interface {v0, v4}, Lcom/tzibbur/basic/store/TzbStore;->muteGaps(Ljava/lang/String;)Ljava/util/List;

    move-result-object v4

    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    aput-object v2, v5, v6

    const/4 v2, 0x1

    aput-object v3, v5, v2

    const/4 v2, 0x2

    aput-object v4, v5, v2

    .line 737
    return-object v5
.end method
