.class Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$2;
.super Ljava/lang/Object;
.source "TzbEnrollNameActivity.java"

# interfaces
.implements Landroid/widget/TextView$OnEditorActionListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 101
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$2;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onEditorAction(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .locals 4
    .param p1, "v"    # Landroid/widget/TextView;
    .param p2, "actionId"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .line 104
    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p3, :cond_0

    .line 105
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v2

    const/16 v3, 0x42

    if-ne v2, v3, :cond_0

    .line 106
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v2

    if-nez v2, :cond_0

    move v2, v0

    goto :goto_0

    :cond_0
    move v2, v1

    .line 107
    .local v2, "enter":Z
    :goto_0
    const/4 v3, 0x6

    if-eq p2, v3, :cond_2

    if-eqz v2, :cond_1

    goto :goto_1

    .line 111
    :cond_1
    return v1

    .line 108
    :cond_2
    :goto_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$2;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->access$200(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V

    .line 109
    return v0
.end method
