.class Lcom/tzibbur/basic/ui/TzbApplyActivity$6;
.super Ljava/lang/Object;
.source "TzbApplyActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshStatus(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbApplicationStatus;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

.field final synthetic val$asked:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 324
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$6;->val$asked:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbApplicationStatus;
    .locals 2

    .line 329
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$6;->val$asked:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/core/TzbApplyGate;->check(Landroid/content/Context;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbApplicationStatus;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 324
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$6;->call()Lcom/tzibbur/basic/model/TzbApplicationStatus;

    move-result-object v0

    return-object v0
.end method
