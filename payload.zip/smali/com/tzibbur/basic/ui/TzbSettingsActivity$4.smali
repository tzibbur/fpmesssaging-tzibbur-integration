.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$4;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 103
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 106
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    const-class v3, Lcom/tzibbur/basic/ui/TzbAboutActivity;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->startActivity(Landroid/content/Intent;)V

    .line 107
    return-void
.end method
