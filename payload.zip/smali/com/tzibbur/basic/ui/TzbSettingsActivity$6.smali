.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$6;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->refreshLegalDocuments()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbLegalDocument;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

.field final synthetic val$key:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 125
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$6;->val$key:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbLegalDocument;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 128
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$6;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$6;->val$key:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/net/TzbApi;->legalDocument(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbLegalDocument;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 125
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$6;->call()Lcom/tzibbur/basic/model/TzbLegalDocument;

    move-result-object v0

    return-object v0
.end method
