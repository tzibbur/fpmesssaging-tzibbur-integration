.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$13;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->showDevicesDialog(Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcom/tzibbur/basic/model/TzbDevice;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

.field final synthetic val$selfDeviceId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 296
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$13;->val$selfDeviceId:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public compare(Lcom/tzibbur/basic/model/TzbDevice;Lcom/tzibbur/basic/model/TzbDevice;)I
    .locals 3
    .param p1, "a"    # Lcom/tzibbur/basic/model/TzbDevice;
    .param p2, "b"    # Lcom/tzibbur/basic/model/TzbDevice;

    .line 299
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$13;->val$selfDeviceId:Ljava/lang/String;

    invoke-static {p1, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$700(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)Z

    move-result v0

    .line 300
    .local v0, "aSelf":Z
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$13;->val$selfDeviceId:Ljava/lang/String;

    invoke-static {p2, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$700(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)Z

    move-result v1

    .line 301
    .local v1, "bSelf":Z
    if-ne v0, v1, :cond_0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    if-eqz v0, :cond_1

    const/4 v2, -0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    :goto_0
    return v2
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 296
    check-cast p1, Lcom/tzibbur/basic/model/TzbDevice;

    check-cast p2, Lcom/tzibbur/basic/model/TzbDevice;

    invoke-virtual {p0, p1, p2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$13;->compare(Lcom/tzibbur/basic/model/TzbDevice;Lcom/tzibbur/basic/model/TzbDevice;)I

    move-result p1

    return p1
.end method
