.class Lcom/tzibbur/basic/ui/TzbConversationActivity$23;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->markRead()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1200
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    .line 1203
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    .line 1206
    .local v0, "store":Lcom/tzibbur/basic/store/TzbStore;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 1210
    :try_start_0
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)J

    move-result-wide v2

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-gez v2, :cond_0

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->val$gid:Ljava/lang/String;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v3}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 1211
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v3}, Lcom/tzibbur/basic/store/TzbStore;->readSeq(Ljava/lang/String;)J

    move-result-wide v3

    invoke-static {v2, v3, v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4702(Lcom/tzibbur/basic/ui/TzbConversationActivity;J)J

    .line 1213
    :cond_0
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v2}, Lcom/tzibbur/basic/store/TzbStore;->readSeq(Ljava/lang/String;)J

    move-result-wide v2

    .line 1214
    .local v2, "before":J
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v4}, Lcom/tzibbur/basic/store/TzbStore;->maxSeq(Ljava/lang/String;)J

    move-result-wide v4

    .line 1215
    .local v4, "maxSeq":J
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->val$gid:Ljava/lang/String;

    invoke-interface {v0, v6, v4, v5}, Lcom/tzibbur/basic/store/TzbStore;->setReadSeq(Ljava/lang/String;J)V

    .line 1216
    monitor-exit v1

    .line 1221
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    cmp-long v1, v4, v2

    if-lez v1, :cond_1

    .line 1222
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v1

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$23;->val$gid:Ljava/lang/String;

    invoke-interface {v1, v6, v4, v5}, Lcom/tzibbur/basic/sync/TzbSync;->markRead(Ljava/lang/String;J)V

    .line 1224
    :cond_1
    return-void

    .line 1216
    .end local v2
    .end local v4
    :catchall_0
    move-exception v2

    :try_start_1
    monitor-exit v1

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v2
.end method
