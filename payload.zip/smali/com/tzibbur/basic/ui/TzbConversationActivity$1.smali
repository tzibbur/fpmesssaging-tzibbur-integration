.class Lcom/tzibbur/basic/ui/TzbConversationActivity$1;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 182
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFocusChange(Landroid/view/View;Z)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;
    .param p2, "hasFocus"    # Z

    .line 185
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0, p2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$000(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)V

    .line 186
    invoke-static {p1, p2}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->syncImeToFocus(Landroid/view/View;Z)V

    .line 187
    return-void
.end method
