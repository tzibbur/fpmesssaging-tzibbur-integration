.class Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$8;
.super Ljava/lang/Object;
.source "TzbGroupInfoActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->showRenameDialog()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

.field final synthetic val$edit:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Landroid/widget/EditText;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 184
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$8;->val$edit:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 4
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 187
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$8;->val$edit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 188
    .local v0, "name":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1

    .line 189
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    iget-object v2, v2, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v2}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v2

    const/16 v3, 0x64

    invoke-interface {v2, v3}, Lcom/tzibbur/basic/store/TzbSession;->groupNameMaxLength(I)I

    move-result v2

    if-le v1, v2, :cond_0

    goto :goto_0

    .line 194
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    const/4 v2, 0x0

    invoke-static {v1, v0, v2, v2}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->access$700(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 195
    return-void

    .line 190
    :cond_1
    :goto_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_err_invalid_group_name:I

    const/4 v3, 0x1

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v1

    .line 191
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 192
    return-void
.end method
