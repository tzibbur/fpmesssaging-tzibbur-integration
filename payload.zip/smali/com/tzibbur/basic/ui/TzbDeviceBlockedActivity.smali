.class public Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;
.super Landroid/app/Activity;
.source "TzbDeviceBlockedActivity.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method public static show(Landroid/content/Context;)V
    .locals 2
    .param p0, "context"    # Landroid/content/Context;

    .line 25
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 26
    .local v0, "intent":Landroid/content/Intent;
    const v1, 0x10008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 27
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 28
    return-void
.end method


# virtual methods
.method public onBackPressed()V
    .locals 0

    .line 46
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;->finishAffinity()V

    .line 47
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 32
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 34
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 35
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;->finish()V

    .line 36
    return-void

    .line 38
    :cond_0
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_device_blocked_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;->setContentView(I)V

    .line 41
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 42
    return-void
.end method
