.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$9;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->showAddDialog()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 268
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 271
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Landroid/app/AlertDialog;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Landroid/app/AlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V

    .line 272
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1200(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    .line 273
    return-void
.end method
