.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$15;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->confirmRevokeDevice(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

.field final synthetic val$device:Lcom/tzibbur/basic/model/TzbDevice;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Lcom/tzibbur/basic/model/TzbDevice;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 367
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$15;->val$device:Lcom/tzibbur/basic/model/TzbDevice;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 2
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 370
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$15;->val$device:Lcom/tzibbur/basic/model/TzbDevice;

    iget-object v1, v1, Lcom/tzibbur/basic/model/TzbDevice;->id:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$900(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V

    .line 371
    return-void
.end method
