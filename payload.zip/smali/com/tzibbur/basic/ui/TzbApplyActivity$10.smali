.class Lcom/tzibbur/basic/ui/TzbApplyActivity$10;
.super Ljava/lang/Object;
.source "TzbApplyActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;->submit()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbApplication;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

.field final synthetic val$number:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 451
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->val$number:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "error"    # Ljava/lang/Exception;

    .line 469
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$402(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)Z

    .line 470
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1600(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)V

    .line 471
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1800(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/Exception;)V

    .line 472
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbApplication;)V
    .locals 2
    .param p1, "application"    # Lcom/tzibbur/basic/model/TzbApplication;

    .line 454
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$402(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)Z

    .line 455
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1600(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)V

    .line 456
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->val$number:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1302(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)Ljava/lang/String;

    .line 457
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$600(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->val$number:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/store/TzbApplyStore;->setPendingPhone(Ljava/lang/String;)V

    .line 458
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$600(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v0

    const-string v1, "pending"

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/store/TzbApplyStore;->setLastStatus(Ljava/lang/String;)V

    .line 459
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, 0x2

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbApplyActivity;I)V

    .line 460
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const-string v1, ""

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V

    .line 463
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1700(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    .line 464
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/16 v1, 0xb4

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$700(Lcom/tzibbur/basic/ui/TzbApplyActivity;I)V

    .line 465
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 451
    check-cast p1, Lcom/tzibbur/basic/model/TzbApplication;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;->onResult(Lcom/tzibbur/basic/model/TzbApplication;)V

    return-void
.end method
