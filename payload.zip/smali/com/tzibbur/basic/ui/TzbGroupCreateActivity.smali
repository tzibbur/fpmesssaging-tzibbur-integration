.class public Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
.super Lcom/tzibbur/basic/ui/TzbBaseActivity;
.source "TzbGroupCreateActivity.java"


# static fields
.field private static final MAX_NAME_CODE_POINTS_FALLBACK:I = 0x64


# instance fields
.field private categoryList:Landroid/widget/ListView;

.field private categoryStatus:Landroid/widget/TextView;

.field private createBtn:Landroid/widget/Button;

.field private nameEdit:Landroid/widget/EditText;

.field private retryBtn:Landroid/widget/Button;

.field private slugs:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 27
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;-><init>()V

    .line 37
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->slugs:Ljava/util/List;

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    .line 27
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->fetchCategories()V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    .line 27
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->create()V

    return-void
.end method

.method static synthetic access$1000(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    .line 27
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryStatus:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    .line 27
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->focusBelowName()V

    return-void
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/ListView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    .line 27
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    return-object v0
.end method

.method static synthetic access$400(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/EditText;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    .line 27
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->nameEdit:Landroid/widget/EditText;

    return-object v0
.end method

.method static synthetic access$500(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    .line 27
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->createBtn:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    .line 27
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->listUsable()Z

    move-result v0

    return v0
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;Z)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
    .param p1, "x1"    # Z

    .line 27
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->focusCategoryList(Z)V

    return-void
.end method

.method static synthetic access$800(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    .line 27
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->retryBtn:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$902(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;Ljava/util/List;)Ljava/util/List;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
    .param p1, "x1"    # Ljava/util/List;

    .line 27
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->slugs:Ljava/util/List;

    return-object p1
.end method

.method private create()V
    .locals 6

    .line 193
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->nameEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 195
    .local v0, "name":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_3

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v4}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v4

    const/16 v5, 0x64

    invoke-interface {v4, v5}, Lcom/tzibbur/basic/store/TzbSession;->groupNameMaxLength(I)I

    move-result v4

    if-le v1, v4, :cond_0

    goto :goto_1

    .line 199
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getCheckedItemPosition()I

    move-result v1

    .line 200
    .local v1, "checked":I
    if-ltz v1, :cond_2

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->slugs:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-lt v1, v4, :cond_1

    goto :goto_0

    .line 204
    :cond_1
    move-object v2, v0

    .line 205
    .local v2, "groupName":Ljava/lang/String;
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->slugs:Ljava/util/List;

    invoke-interface {v4, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 206
    .local v4, "category":Ljava/lang/String;
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->createBtn:Landroid/widget/Button;

    invoke-virtual {v5, v3}, Landroid/widget/Button;->setEnabled(Z)V

    .line 207
    new-instance v3, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;

    invoke-direct {v3, p0, v2, v4}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;-><init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v5, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;

    invoke-direct {v5, p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$9;-><init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    invoke-static {v3, v5}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 237
    return-void

    .line 201
    .end local v2
    .end local v4
    :cond_2
    :goto_0
    sget v3, Lcom/tzibbur/basic/R$string;->tzb_pick_category:I

    invoke-static {p0, v3, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 202
    return-void

    .line 196
    .end local v1
    :cond_3
    :goto_1
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_err_invalid_group_name:I

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 197
    return-void
.end method

.method private fetchCategories()V
    .locals 2

    .line 160
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryStatus:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_loading:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 161
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryStatus:Landroid/widget/TextView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 162
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->retryBtn:Landroid/widget/Button;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 163
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setVisibility(I)V

    .line 164
    new-instance v0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$6;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$7;-><init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    invoke-static {v0, v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 190
    return-void
.end method

.method private focusBelowName()V
    .locals 1

    .line 140
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->listUsable()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 141
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->focusCategoryList(Z)V

    goto :goto_0

    .line 142
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->retryBtn:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->getVisibility()I

    move-result v0

    if-nez v0, :cond_1

    .line 143
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->retryBtn:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    goto :goto_0

    .line 145
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->createBtn:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    .line 147
    :goto_0
    return-void
.end method

.method private focusCategoryList(Z)V
    .locals 2
    .param p1, "fromTop"    # Z

    .line 151
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->requestFocus()Z

    .line 152
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getCheckedItemPosition()I

    move-result v0

    .line 153
    .local v0, "checked":I
    const/4 v1, -0x1

    if-ne v0, v1, :cond_1

    .line 154
    if-eqz p1, :cond_0

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getCount()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_0
    move v0, v1

    .line 156
    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    invoke-virtual {v1, v0}, Landroid/widget/ListView;->setSelection(I)V

    .line 157
    return-void
.end method

.method private listUsable()Z
    .locals 1

    .line 135
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getCount()I

    move-result v0

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 41
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onCreate(Landroid/os/Bundle;)V

    .line 43
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 44
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->finish()V

    .line 45
    return-void

    .line 49
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 50
    return-void

    .line 52
    :cond_1
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_group_create_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->setContentView(I)V

    .line 55
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 57
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_create_group_title:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->setupTitleBar(Ljava/lang/CharSequence;Z)V

    .line 59
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_group_name_edit:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->nameEdit:Landroid/widget/EditText;

    .line 60
    const/4 v0, 0x1

    new-array v0, v0, [Landroid/widget/EditText;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->nameEdit:Landroid/widget/EditText;

    aput-object v2, v0, v1

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->attachAutoIme([Landroid/widget/EditText;)V

    .line 61
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_category_status:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryStatus:Landroid/widget/TextView;

    .line 62
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_category_retry_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->retryBtn:Landroid/widget/Button;

    .line 63
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_category_list:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    .line 64
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_create_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->createBtn:Landroid/widget/Button;

    .line 66
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->retryBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$1;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 72
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->createBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$2;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 84
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->nameEdit:Landroid/widget/EditText;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$3;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 95
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->categoryList:Landroid/widget/ListView;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$4;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 113
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->createBtn:Landroid/widget/Button;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$5;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$5;-><init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 131
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->fetchCategories()V

    .line 132
    return-void
.end method
