.class Lcom/tzibbur/basic/ui/TzbGroupListActivity$1;
.super Ljava/lang/Object;
.source "TzbGroupListActivity.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupListActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupListActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 61
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 3
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 64
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    invoke-virtual {p1, p3}, Landroid/widget/AdapterView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v0

    .line 65
    .local v0, "item":Ljava/lang/Object;
    instance-of v1, v0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;

    if-eqz v1, :cond_0

    .line 66
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    move-object v2, v0

    check-cast v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;

    iget-object v2, v2, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v2, v2, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->access$000(Lcom/tzibbur/basic/ui/TzbGroupListActivity;Ljava/lang/String;)V

    .line 68
    :cond_0
    return-void
.end method
