.class public final Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;
.super Landroid/widget/BaseAdapter;
.source "TzbContactPickerAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;
    }
.end annotation


# instance fields
.field private final all:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;",
            ">;"
        }
    .end annotation
.end field

.field private final inflater:Landroid/view/LayoutInflater;

.field private query:Ljava/lang/String;

.field private final shown:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .line 46
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 42
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->all:Ljava/util/List;

    .line 43
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->shown:Ljava/util/List;

    .line 44
    const-string v0, ""

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->query:Ljava/lang/String;

    .line 47
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 48
    return-void
.end method

.method private applyFilter()V
    .locals 5

    .line 91
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->shown:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 92
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->query:Ljava/lang/String;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->searchKey(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 93
    .local v0, "needle":Ljava/lang/String;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->query:Ljava/lang/String;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->digitsOf(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 94
    .local v1, "needleDigits":Ljava/lang/String;
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->all:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;

    .line 95
    .local v3, "row":Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_0

    .line 96
    invoke-virtual {v3}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->label()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->searchKey(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_0

    .line 97
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_1

    iget-object v4, v3, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->phone:Ljava/lang/String;

    invoke-static {v4}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->digitsOf(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 98
    :cond_0
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->shown:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 100
    .end local v3
    :cond_1
    goto :goto_0

    .line 101
    :cond_2
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->notifyDataSetChanged()V

    .line 102
    return-void
.end method

.method private static digitsOf(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p0, "text"    # Ljava/lang/String;

    .line 122
    const-string v0, ""

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const-string v1, "[^0-9]"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method private static searchKey(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p0, "text"    # Ljava/lang/String;

    .line 109
    if-nez p0, :cond_0

    const-string v0, ""

    return-object v0

    .line 110
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 111
    .local v0, "sb":Ljava/lang/StringBuilder;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v1, v2, :cond_5

    .line 112
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    .line 113
    .local v2, "c":C
    const/16 v3, 0x200e

    if-eq v2, v3, :cond_3

    const/16 v3, 0x200f

    if-eq v2, v3, :cond_3

    const/16 v3, 0x202a

    if-lt v2, v3, :cond_1

    const/16 v3, 0x202e

    if-le v2, v3, :cond_3

    :cond_1
    const/16 v3, 0x2066

    if-lt v2, v3, :cond_2

    const/16 v3, 0x2069

    if-gt v2, v3, :cond_2

    goto :goto_1

    :cond_2
    const/4 v3, 0x0

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v3, 0x1

    .line 116
    .local v3, "bidiControl":Z
    :goto_2
    if-nez v3, :cond_4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 111
    .end local v2
    .end local v3
    :cond_4
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 118
    .end local v1
    :cond_5
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method


# virtual methods
.method public addMatches(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;",
            ">;)V"
        }
    .end annotation

    .line 52
    .local p1, "rows":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->all:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 53
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->applyFilter()V

    .line 54
    return-void
.end method

.method public areAllItemsEnabled()Z
    .locals 1

    .line 143
    const/4 v0, 0x1

    return v0
.end method

.method public getCount()I
    .locals 1

    .line 127
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->shown:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 132
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->shown:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 137
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 7
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 153
    const/4 v0, 0x0

    if-eqz p2, :cond_0

    .line 154
    move-object v1, p2

    goto :goto_0

    .line 155
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v2, Lcom/tzibbur/basic/R$layout;->tzb_contact_picker_item:I

    invoke-virtual {v1, v2, p3, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    :goto_0
    nop

    .line 156
    .local v1, "view":Landroid/view/View;
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->shown:Ljava/util/List;

    invoke-interface {v2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;

    .line 158
    .local v2, "row":Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;
    sget v3, Lcom/tzibbur/basic/R$id;->tzb_contact_check:I

    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    .line 159
    .local v3, "check":Landroid/widget/TextView;
    sget v4, Lcom/tzibbur/basic/R$id;->tzb_contact_name:I

    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    .line 160
    .local v4, "name":Landroid/widget/TextView;
    sget v5, Lcom/tzibbur/basic/R$id;->tzb_contact_phone:I

    invoke-virtual {v1, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    .line 162
    .local v5, "phone":Landroid/widget/TextView;
    invoke-virtual {v2}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->label()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 164
    iget-object v6, v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->name:Ljava/lang/String;

    if-eqz v6, :cond_1

    iget-object v6, v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->name:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_1

    .line 165
    iget-object v6, v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->phone:Ljava/lang/String;

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 166
    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_1

    .line 168
    :cond_1
    const/16 v0, 0x8

    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 171
    :goto_1
    iget-boolean v0, v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->selected:Z

    if-eqz v0, :cond_2

    sget v0, Lcom/tzibbur/basic/R$string;->tzb_check_on:I

    goto :goto_2

    :cond_2
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_check_off:I

    :goto_2
    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(I)V

    .line 172
    return-object v1
.end method

.method public isEnabled(I)Z
    .locals 1
    .param p1, "position"    # I

    .line 148
    const/4 v0, 0x1

    return v0
.end method

.method public selectedCount()I
    .locals 4

    .line 79
    const/4 v0, 0x0

    .line 80
    .local v0, "count":I
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->all:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;

    .line 81
    .local v2, "row":Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;
    iget-boolean v3, v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->selected:Z

    if-eqz v3, :cond_0

    add-int/lit8 v0, v0, 0x1

    .line 82
    .end local v2
    :cond_0
    goto :goto_0

    .line 83
    :cond_1
    return v0
.end method

.method public selectedPhones()Ljava/util/ArrayList;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 71
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 72
    .local v0, "phones":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->all:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;

    .line 73
    .local v2, "row":Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;
    iget-boolean v3, v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->selected:Z

    if-eqz v3, :cond_0

    iget-object v3, v2, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->phone:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 74
    .end local v2
    :cond_0
    goto :goto_0

    .line 75
    :cond_1
    return-object v0
.end method

.method public setQuery(Ljava/lang/String;)V
    .locals 1
    .param p1, "text"    # Ljava/lang/String;

    .line 57
    if-eqz p1, :cond_0

    move-object v0, p1

    goto :goto_0

    :cond_0
    const-string v0, ""

    :goto_0
    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->query:Ljava/lang/String;

    .line 58
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->applyFilter()V

    .line 59
    return-void
.end method

.method public toggle(I)Z
    .locals 3
    .param p1, "position"    # I

    .line 63
    if-ltz p1, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->shown:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lt p1, v0, :cond_0

    goto :goto_0

    .line 64
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->shown:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;

    .line 65
    .local v0, "row":Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;
    iget-boolean v1, v0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->selected:Z

    const/4 v2, 0x1

    xor-int/2addr v1, v2

    iput-boolean v1, v0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->selected:Z

    .line 66
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->notifyDataSetChanged()V

    .line 67
    return v2

    .line 63
    .end local v0
    :cond_1
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method public totalMatches()I
    .locals 1

    .line 87
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->all:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method
