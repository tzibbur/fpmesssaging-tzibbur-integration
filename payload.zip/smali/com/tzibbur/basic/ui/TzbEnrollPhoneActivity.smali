.class public Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
.super Landroid/app/Activity;
.source "TzbEnrollPhoneActivity.java"


# static fields
.field private static final DEFAULT_RETRY_SECONDS:I = 0x3c

.field private static final RC_APPLY:I = 0x2

.field private static final RC_PHONE_PERMS:I = 0x1

.field private static final STATE_AUTOFILL_DONE:Ljava/lang/String; = "tzb_autofill_done"

.field private static final STATE_PERM_REQUESTED:Ljava/lang/String; = "tzb_perm_requested"


# instance fields
.field private autofillDone:Z

.field private cooldownTimer:Landroid/os/CountDownTimer;

.field private final droppedIdentifiers:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private permissionRequested:Z

.field private phoneInput:Landroid/widget/EditText;

.field private rationaleView:Landroid/widget/TextView;

.field private sendButton:Landroid/widget/Button;

.field private sending:Z

.field private statusView:Landroid/widget/TextView;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 38
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 418
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->droppedIdentifiers:Ljava/util/Set;

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    .line 38
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->startAuth()V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/EditText;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    .line 38
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    return-object v0
.end method

.method static synthetic access$1000(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    .line 38
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->handleDeviceBlocked()V

    return-void
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    .line 38
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->rationaleView:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    .line 38
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->sendButton:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$402(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .param p1, "x1"    # Z

    .line 38
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->sending:Z

    return p1
.end method

.method static synthetic access$500(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .param p1, "x1"    # Z

    .line 38
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->setUiEnabled(Z)V

    return-void
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 38
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showStatus(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/Exception;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .param p1, "x1"    # Ljava/lang/Exception;

    .line 38
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->handleStartError(Ljava/lang/Exception;)V

    return-void
.end method

.method static synthetic access$800(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 38
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showError(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$902(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Landroid/os/CountDownTimer;)Landroid/os/CountDownTimer;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .param p1, "x1"    # Landroid/os/CountDownTimer;

    .line 38
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->cooldownTimer:Landroid/os/CountDownTimer;

    return-object p1
.end method

.method private checkApplication(Ljava/lang/String;)V
    .locals 2
    .param p1, "phone"    # Ljava/lang/String;

    .line 299
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->setUiEnabled(Z)V

    .line 300
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->sending:Z

    .line 301
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_apply_status_checking:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showStatus(Ljava/lang/String;)V

    .line 302
    new-instance v0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$8;

    invoke-direct {v0, p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$8;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V

    new-instance v1, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;

    invoke-direct {v1, p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V

    invoke-static {v0, v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 333
    return-void
.end method

.method private droppedIdentifier(Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .line 421
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->droppedIdentifiers:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private fetchCapabilities()V
    .locals 3

    .line 458
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    .line 459
    .local v0, "core":Lcom/tzibbur/basic/core/TzbCore;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$11;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$11;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Lcom/tzibbur/basic/core/TzbCore;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$12;

    invoke-direct {v2, p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$12;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Lcom/tzibbur/basic/core/TzbCore;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 479
    return-void
.end method

.method private handleDeviceBlocked()V
    .locals 1

    .line 446
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->setDeviceBlocked()V

    .line 447
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;->show(Landroid/content/Context;)V

    .line 448
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->finish()V

    .line 449
    return-void
.end method

.method private handleStartError(Ljava/lang/Exception;)V
    .locals 3
    .param p1, "error"    # Ljava/lang/Exception;

    .line 346
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_1

    .line 347
    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    .line 348
    .local v0, "blocked":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isDeviceBlocked()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 349
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->handleDeviceBlocked()V

    .line 350
    return-void

    .line 352
    :cond_0
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->dropIdentifierAndRetry(Lcom/tzibbur/basic/net/TzbProblem;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 355
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->startAuth()V

    .line 356
    return-void

    .line 359
    .end local v0
    :cond_1
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_8

    .line 360
    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    .line 361
    .local v0, "p":Lcom/tzibbur/basic/net/TzbProblem;
    const-string v1, "rate_limited"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isRateLimited()Z

    move-result v1

    if-eqz v1, :cond_2

    goto :goto_0

    .line 364
    :cond_2
    const-string v1, "sms_delivery_failed"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    .line 365
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_sms_failed:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showError(Ljava/lang/String;)V

    goto :goto_2

    .line 366
    :cond_3
    const-string v1, "not_implemented"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 367
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_unavailable:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showError(Ljava/lang/String;)V

    goto :goto_2

    .line 368
    :cond_4
    const-string v1, "validation_failed"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    .line 369
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_check_number:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showError(Ljava/lang/String;)V

    goto :goto_2

    .line 371
    :cond_5
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_error_generic:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showError(Ljava/lang/String;)V

    goto :goto_2

    .line 362
    :cond_6
    :goto_0
    iget v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    if-lez v1, :cond_7

    iget v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    goto :goto_1

    :cond_7
    const/16 v1, 0x3c

    .line 363
    .local v1, "wait":I
    :goto_1
    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->startCooldown(I)V

    .line 364
    .end local v1
    nop

    .line 373
    .end local v0
    :goto_2
    goto :goto_3

    .line 374
    :cond_8
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_error_network:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showError(Ljava/lang/String;)V

    .line 376
    :goto_3
    return-void
.end method

.method private hasAnyPhonePermission()Z
    .locals 4

    .line 174
    const-string v0, "android.permission.READ_PHONE_STATE"

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    .line 176
    .local v0, "state":Z
    :goto_0
    const-string v3, "android.permission.READ_PHONE_NUMBERS"

    invoke-virtual {p0, v3}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v3

    if-nez v3, :cond_1

    move v3, v1

    goto :goto_1

    :cond_1
    move v3, v2

    .line 178
    .local v3, "numbers":Z
    :goto_1
    if-nez v0, :cond_3

    if-eqz v3, :cond_2

    goto :goto_2

    :cond_2
    move v1, v2

    :cond_3
    :goto_2
    return v1
.end method

.method private maybeAutofillFromSim()V
    .locals 3

    .line 158
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->autofillDone:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-interface {v0}, Landroid/text/Editable;->length()I

    move-result v0

    if-lez v0, :cond_0

    goto :goto_1

    .line 159
    :cond_0
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->hasAnyPhonePermission()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 160
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->runDetection()V

    goto :goto_0

    .line 161
    :cond_1
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->permissionRequested:Z

    if-nez v0, :cond_2

    .line 162
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->permissionRequested:Z

    .line 165
    const-string v1, "android.permission.READ_PHONE_STATE"

    const-string v2, "android.permission.READ_PHONE_NUMBERS"

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->requestPermissions([Ljava/lang/String;I)V

    .line 171
    :cond_2
    :goto_0
    return-void

    .line 158
    :cond_3
    :goto_1
    return-void
.end method

.method private runDetection()V
    .locals 2

    .line 191
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->autofillDone:Z

    .line 193
    new-instance v0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$4;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V

    new-instance v1, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$5;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V

    invoke-static {v0, v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 216
    return-void
.end method

.method private setUiEnabled(Z)V
    .locals 1
    .param p1, "enabled"    # Z

    .line 399
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 400
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->sendButton:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 401
    return-void
.end method

.method private showError(Ljava/lang/String;)V
    .locals 2
    .param p1, "text"    # Ljava/lang/String;

    .line 409
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->statusView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$color;->tzb_error:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 410
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->statusView:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 411
    return-void
.end method

.method private showStatus(Ljava/lang/String;)V
    .locals 2
    .param p1, "text"    # Ljava/lang/String;

    .line 404
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->statusView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$color;->tzb_text_secondary:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 405
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->statusView:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 406
    return-void
.end method

.method private startAuth()V
    .locals 7

    .line 221
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->sending:Z

    if-eqz v0, :cond_0

    return-void

    .line 226
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    .line 227
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->stripPhoneFormatting(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 228
    .local v4, "phone":Ljava/lang/String;
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 229
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_check_number:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showError(Ljava/lang/String;)V

    .line 230
    return-void

    .line 239
    :cond_1
    invoke-static {p0, v4}, Lcom/tzibbur/basic/core/TzbApplyGate;->requiredFor(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 240
    invoke-direct {p0, v4}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->checkApplication(Ljava/lang/String;)V

    .line 241
    return-void

    .line 244
    :cond_2
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->setUiEnabled(Z)V

    .line 245
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->sending:Z

    .line 246
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_enroll_status_sending:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->showStatus(Ljava/lang/String;)V

    .line 248
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v3

    .line 251
    .local v3, "api":Lcom/tzibbur/basic/net/TzbApi;
    const-string v0, "serialNumber"

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->droppedIdentifier(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    .line 252
    move-object v5, v1

    goto :goto_0

    :cond_3
    invoke-static {p0}, Lcom/tzibbur/basic/auth/TzbHardwareIds;->serialNumber(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    move-object v5, v0

    .line 253
    .local v5, "serial":Ljava/lang/String;
    :goto_0
    const-string v0, "imei"

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->droppedIdentifier(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 254
    goto :goto_1

    :cond_4
    invoke-static {p0}, Lcom/tzibbur/basic/auth/TzbHardwareIds;->imei(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    :goto_1
    move-object v6, v1

    .line 255
    .local v6, "imei":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Lcom/tzibbur/basic/net/TzbApi;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;

    invoke-direct {v0, p0, v4}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$7;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V

    invoke-static {v1, v0}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 286
    return-void
.end method

.method private startCooldown(I)V
    .locals 7
    .param p1, "seconds"    # I

    .line 379
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->sendButton:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 380
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->cooldownTimer:Landroid/os/CountDownTimer;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->cooldownTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 381
    :cond_0
    new-instance v1, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$10;

    int-to-long v2, p1

    const-wide/16 v4, 0x3e8

    mul-long v3, v2, v4

    const-wide/16 v5, 0x3e8

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$10;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;JJ)V

    iput-object v1, v2, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->cooldownTimer:Landroid/os/CountDownTimer;

    .line 395
    iget-object v0, v2, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->cooldownTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->start()Landroid/os/CountDownTimer;

    .line 396
    return-void
.end method


# virtual methods
.method protected dropIdentifierAndRetry(Lcom/tzibbur/basic/net/TzbProblem;)Z
    .locals 3
    .param p1, "problem"    # Lcom/tzibbur/basic/net/TzbProblem;

    .line 426
    if-eqz p1, :cond_2

    iget v0, p1, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x190

    if-ne v0, v1, :cond_2

    iget-object v0, p1, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    .line 427
    const-string v1, "invalid_device_identifier"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 430
    :cond_0
    iget-object v0, p1, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    const-string v1, "identifier"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 431
    .local v0, "identifier":Ljava/lang/String;
    if-nez v0, :cond_1

    .line 433
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->droppedIdentifiers:Ljava/util/Set;

    const-string v2, "serialNumber"

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 434
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->droppedIdentifiers:Ljava/util/Set;

    const-string v2, "imei"

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 435
    const/4 v1, 0x1

    return v1

    .line 437
    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->droppedIdentifiers:Ljava/util/Set;

    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v1

    return v1

    .line 428
    .end local v0
    :cond_2
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 1
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 337
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 340
    const/4 v0, 0x2

    if-ne p1, v0, :cond_0

    const/4 v0, -0x1

    if-ne p2, v0, :cond_0

    .line 341
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->startAuth()V

    .line 343
    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 60
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 62
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 63
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->finish()V

    .line 64
    return-void

    .line 66
    :cond_0
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_enroll_phone_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->setContentView(I)V

    .line 69
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 71
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_title_text:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_app_name:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 73
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_enroll_phone_input:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    .line 75
    const/4 v0, 0x1

    new-array v1, v0, [Landroid/widget/EditText;

    const/4 v2, 0x0

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    aput-object v3, v1, v2

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->attachAutoIme([Landroid/widget/EditText;)V

    .line 79
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    new-instance v2, Landroid/telephony/PhoneNumberFormattingTextWatcher;

    invoke-direct {v2}, Landroid/telephony/PhoneNumberFormattingTextWatcher;-><init>()V

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 81
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_enroll_send_btn:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->sendButton:Landroid/widget/Button;

    .line 82
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_enroll_phone_status:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->statusView:Landroid/widget/TextView;

    .line 83
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_enroll_phone_rationale:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->rationaleView:Landroid/widget/TextView;

    .line 88
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    if-eqz v1, :cond_1

    .line 89
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    const-string v2, "tzb_apply_phone"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    .line 90
    .local v1, "supplied":Ljava/lang/String;
    :goto_0
    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_2

    .line 91
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v2, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 92
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-interface {v3}, Landroid/text/Editable;->length()I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->setSelection(I)V

    .line 93
    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->autofillDone:Z

    .line 96
    :cond_2
    if-eqz p1, :cond_3

    .line 97
    const-string v0, "tzb_perm_requested"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->permissionRequested:Z

    .line 98
    const-string v0, "tzb_autofill_done"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->autofillDone:Z

    .line 101
    :cond_3
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->sendButton:Landroid/widget/Button;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$1;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 109
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_enroll_terms_link:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v2, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$2;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 117
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_enroll_privacy_link:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v2, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$3;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 129
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 130
    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 148
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->cooldownTimer:Landroid/os/CountDownTimer;

    if-eqz v0, :cond_0

    .line 149
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->cooldownTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 150
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->cooldownTimer:Landroid/os/CountDownTimer;

    .line 152
    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 153
    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 1
    .param p1, "requestCode"    # I
    .param p2, "permissions"    # [Ljava/lang/String;
    .param p3, "grantResults"    # [I

    .line 184
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 185
    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->hasAnyPhonePermission()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 186
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->runDetection()V

    .line 188
    :cond_0
    return-void
.end method

.method protected onResume()V
    .locals 0

    .line 141
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 142
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->maybeAutofillFromSim()V

    .line 143
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->fetchCapabilities()V

    .line 144
    return-void
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "outState"    # Landroid/os/Bundle;

    .line 134
    invoke-super {p0, p1}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 135
    const-string v0, "tzb_perm_requested"

    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->permissionRequested:Z

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 136
    const-string v0, "tzb_autofill_done"

    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->autofillDone:Z

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 137
    return-void
.end method

# tzib public screens: Back from login returns to Messages settings.
.method public onBackPressed()V
    .locals 0
    invoke-static {p0}, Lcom/android/mms/tzib/TzibNavigation;->backToSettings(Landroid/app/Activity;)V
    return-void
.end method
