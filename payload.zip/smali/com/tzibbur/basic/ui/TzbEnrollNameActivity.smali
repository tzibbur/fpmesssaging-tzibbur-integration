.class public Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;
.super Landroid/app/Activity;
.source "TzbEnrollNameActivity.java"


# static fields
.field public static final EXTRA_INITIAL_NAME:Ljava/lang/String; = "tzb_initial_name"

.field public static final EXTRA_NAME:Ljava/lang/String; = "tzb_name"

.field public static final EXTRA_PROBLEM_CODE:Ljava/lang/String; = "tzb_problem_code"

.field private static final MAX_NAME_CODE_POINTS_FALLBACK:I = 0x40


# instance fields
.field private counterView:Landroid/widget/TextView;

.field private nameEdit:Landroid/widget/EditText;

.field private statusView:Landroid/widget/TextView;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 32
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    .line 32
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->updateCounter()V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    .line 32
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->statusView:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    .line 32
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->submit()V

    return-void
.end method

.method public static intent(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    .locals 2
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "initialName"    # Ljava/lang/String;
    .param p2, "problemCode"    # Ljava/lang/String;

    .line 49
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 50
    .local v0, "intent":Landroid/content/Intent;
    if-eqz p1, :cond_0

    const-string v1, "tzb_initial_name"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 51
    :cond_0
    if-eqz p2, :cond_1

    const-string v1, "tzb_problem_code"

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 52
    :cond_1
    return-object v0
.end method

.method private maxNameCodePoints(I)I
    .locals 1
    .param p1, "fallback"    # I

    .line 178
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/tzibbur/basic/store/TzbSession;->displayNameMaxLength(I)I

    move-result v0

    return v0
.end method

.method private problemText(Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p1, "code"    # Ljava/lang/String;

    .line 162
    const-string v0, "reserved_display_name"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 163
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_name_reserved:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 166
    :cond_0
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_enroll_name_invalid:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private showError(Ljava/lang/String;)V
    .locals 1
    .param p1, "text"    # Ljava/lang/String;

    .line 170
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->statusView:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 171
    return-void
.end method

.method private submit()V
    .locals 3

    .line 145
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 146
    .local v0, "name":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 147
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_name_empty:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->showError(Ljava/lang/String;)V

    .line 148
    return-void

    .line 150
    :cond_0
    const/4 v1, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    const/16 v2, 0x40

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->maxNameCodePoints(I)I

    move-result v2

    if-le v1, v2, :cond_1

    .line 151
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_name_long:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->showError(Ljava/lang/String;)V

    .line 152
    return-void

    .line 154
    :cond_1
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    .line 155
    .local v1, "result":Landroid/content/Intent;
    const-string v2, "tzb_name"

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 156
    const/4 v2, -0x1

    invoke-virtual {p0, v2, v1}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->setResult(ILandroid/content/Intent;)V

    .line 157
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->finish()V

    .line 158
    return-void
.end method

.method private updateCounter()V
    .locals 8

    .line 138
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 139
    .local v0, "text":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    .line 140
    .local v1, "used":I
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->counterView:Landroid/widget/TextView;

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_enroll_name_counter:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    .line 141
    const/16 v6, 0x40

    invoke-direct {p0, v6}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->maxNameCodePoints(I)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/Object;

    aput-object v5, v7, v2

    const/4 v2, 0x1

    aput-object v6, v7, v2

    .line 140
    invoke-virtual {p0, v4, v7}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 142
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 57
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 59
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 60
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->finish()V

    .line 61
    return-void

    .line 65
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 66
    return-void

    .line 68
    :cond_1
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_enroll_name_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->setContentView(I)V

    .line 71
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 73
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_title_text:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_name_title:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 75
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_enroll_name_edit:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    .line 76
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_enroll_name_counter:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->counterView:Landroid/widget/TextView;

    .line 77
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_enroll_name_status:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->statusView:Landroid/widget/TextView;

    .line 78
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_enroll_name_continue_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    .line 81
    .local v0, "continueButton":Landroid/widget/Button;
    const/4 v1, 0x1

    new-array v1, v1, [Landroid/widget/EditText;

    const/4 v2, 0x0

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    aput-object v3, v1, v2

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->attachAutoIme([Landroid/widget/EditText;)V

    .line 83
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$1;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 101
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$2;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    .line 114
    new-instance v1, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$3;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 121
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    .line 124
    .local v1, "from":Landroid/content/Intent;
    if-nez p1, :cond_3

    .line 125
    const-string v2, "tzb_initial_name"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 126
    .local v2, "initial":Ljava/lang/String;
    if-eqz v2, :cond_2

    .line 127
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    invoke-virtual {v3, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 128
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    invoke-virtual {v4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v4

    invoke-interface {v4}, Landroid/text/Editable;->length()I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/widget/EditText;->setSelection(I)V

    .line 130
    :cond_2
    const-string v3, "tzb_problem_code"

    invoke-virtual {v1, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 131
    .local v3, "problem":Ljava/lang/String;
    if-eqz v3, :cond_3

    invoke-direct {p0, v3}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->problemText(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v4}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->showError(Ljava/lang/String;)V

    .line 133
    .end local v2
    .end local v3
    :cond_3
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->updateCounter()V

    .line 134
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->nameEdit:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->requestFocus()Z

    .line 135
    return-void
.end method
