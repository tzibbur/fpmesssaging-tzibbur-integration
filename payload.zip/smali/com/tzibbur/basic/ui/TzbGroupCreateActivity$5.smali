.class Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$5;
.super Ljava/lang/Object;
.source "TzbGroupCreateActivity.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 113
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 2
    .param p1, "v"    # Landroid/view/View;
    .param p2, "keyCode"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .line 116
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_3

    const/16 v0, 0x13

    if-eq p2, v0, :cond_0

    goto :goto_1

    .line 120
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$600(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 121
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$700(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;Z)V

    goto :goto_0

    .line 122
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$800(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Button;->getVisibility()I

    move-result v0

    if-nez v0, :cond_2

    .line 123
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$800(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    goto :goto_0

    .line 125
    :cond_2
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->access$400(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 127
    :goto_0
    const/4 v0, 0x1

    return v0

    .line 118
    :cond_3
    :goto_1
    return v1
.end method
