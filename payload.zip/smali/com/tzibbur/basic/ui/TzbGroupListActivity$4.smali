.class Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;
.super Ljava/lang/Object;
.source "TzbGroupListActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupListActivity;->requery()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Ljava/util/List<",
        "Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupListActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 141
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 1
    .param p1, "error"    # Ljava/lang/Exception;

    .line 155
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 156
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 141
    check-cast p1, Ljava/util/List;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;->onResult(Ljava/util/List;)V

    return-void
.end method

.method public onResult(Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;",
            ">;)V"
        }
    .end annotation

    .line 144
    .local p1, "rows":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->access$100(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)Lcom/tzibbur/basic/ui/TzbGroupListAdapter;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupListAdapter;->setRows(Ljava/util/List;)V

    .line 145
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->access$200(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 147
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->access$202(Lcom/tzibbur/basic/ui/TzbGroupListActivity;Z)Z

    .line 148
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    .line 149
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->nudge()V

    .line 151
    :cond_0
    return-void
.end method
