.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$4;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 133
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemLongClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)Z
    .locals 3
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)Z"
        }
    .end annotation

    .line 137
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    invoke-virtual {p1, p3}, Landroid/widget/AdapterView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v0

    .line 138
    .local v0, "item":Ljava/lang/Object;
    instance-of v1, v0, Lcom/tzibbur/basic/model/TzbMember;

    if-nez v1, :cond_0

    const/4 v1, 0x0

    return v1

    .line 139
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    move-object v2, v0

    check-cast v2, Lcom/tzibbur/basic/model/TzbMember;

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$302(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)Lcom/tzibbur/basic/model/TzbMember;

    .line 140
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$300(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/model/TzbMember;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$400(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)V

    .line 141
    const/4 v1, 0x1

    return v1
.end method
