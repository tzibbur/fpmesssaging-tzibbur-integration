.class Lcom/tzibbur/basic/ui/TzbBaseActivity$2;
.super Ljava/lang/Object;
.source "TzbBaseActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbBaseActivity;->showMenuDialog(Ljava/lang/CharSequence;Landroid/view/Menu;Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbBaseActivity;

.field final synthetic val$items:Ljava/util/List;

.field final synthetic val$pick:Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbBaseActivity;Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;Ljava/util/List;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbBaseActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 223
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$2;->this$0:Lcom/tzibbur/basic/ui/TzbBaseActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$2;->val$pick:Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$2;->val$items:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 2
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 226
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$2;->val$pick:Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$2;->val$items:Ljava/util/List;

    invoke-interface {v1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/MenuItem;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;->onPick(Landroid/view/MenuItem;)V

    .line 227
    return-void
.end method
