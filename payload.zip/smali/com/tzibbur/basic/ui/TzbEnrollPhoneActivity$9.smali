.class Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;
.super Ljava/lang/Object;
.source "TzbEnrollPhoneActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->checkApplication(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbApplicationStatus;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

.field final synthetic val$phone:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 307
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->val$phone:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 3
    .param p1, "error"    # Ljava/lang/Exception;

    .line 325
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$402(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)Z

    .line 326
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$500(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)V

    .line 327
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const-string v1, ""

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$600(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V

    .line 328
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->val$phone:Ljava/lang/String;

    .line 329
    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->intent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    .line 328
    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 331
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbApplicationStatus;)V
    .locals 3
    .param p1, "status"    # Lcom/tzibbur/basic/model/TzbApplicationStatus;

    .line 310
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$402(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)Z

    .line 311
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$500(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Z)V

    .line 312
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    const-string v1, ""

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$600(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Ljava/lang/String;)V

    .line 313
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lcom/tzibbur/basic/model/TzbApplicationStatus;->isApproved()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 315
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->access$000(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;)V

    .line 316
    return-void

    .line 318
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->val$phone:Ljava/lang/String;

    .line 319
    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->intent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    .line 318
    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 321
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 307
    check-cast p1, Lcom/tzibbur/basic/model/TzbApplicationStatus;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$9;->onResult(Lcom/tzibbur/basic/model/TzbApplicationStatus;)V

    return-void
.end method
