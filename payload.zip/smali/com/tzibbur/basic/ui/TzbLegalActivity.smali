.class public Lcom/tzibbur/basic/ui/TzbLegalActivity;
.super Lcom/android/mms/tzib/TzibLegalScreen;
.source "TzbLegalActivity.java"

.method public constructor <init>()V
    .locals 0
    invoke-direct {p0}, Lcom/android/mms/tzib/TzibLegalScreen;-><init>()V
    return-void
.end method

.method public static intent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 1
    invoke-static {p0, p1}, Lcom/android/mms/tzib/TzibLegalScreen;->intent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    move-result-object v0
    return-object v0
.end method
