.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$12;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->loadDevices()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Ljava/util/List<",
        "Lcom/tzibbur/basic/model/TzbDevice;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 271
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$12;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 1
    .param p1, "error"    # Ljava/lang/Exception;

    .line 279
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$12;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 280
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 271
    check-cast p1, Ljava/util/List;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$12;->onResult(Ljava/util/List;)V

    return-void
.end method

.method public onResult(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbDevice;",
            ">;)V"
        }
    .end annotation

    .line 274
    .local p1, "devices":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbDevice;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$12;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$600(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/util/List;)V

    .line 275
    return-void
.end method
