.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->startDiscovery()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 284
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 10

    .line 288
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 289
    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactsSource;->readPhonebook(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    .line 290
    .local v0, "book":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/ui/TzbContactsSource$Contact;>;"
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 291
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$1;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$1;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$800(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/lang/Runnable;)V

    .line 299
    return-void

    .line 301
    :cond_0
    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 302
    .local v1, "names":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    new-instance v2, Ljava/util/LinkedHashSet;

    invoke-direct {v2}, Ljava/util/LinkedHashSet;-><init>()V

    .line 303
    .local v2, "numbers":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/tzibbur/basic/ui/TzbContactsSource$Contact;

    .line 304
    .local v4, "contact":Lcom/tzibbur/basic/ui/TzbContactsSource$Contact;
    iget-object v5, v4, Lcom/tzibbur/basic/ui/TzbContactsSource$Contact;->phone:Ljava/lang/String;

    iget-object v6, v4, Lcom/tzibbur/basic/ui/TzbContactsSource$Contact;->displayName:Ljava/lang/String;

    invoke-interface {v1, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 305
    iget-object v5, v4, Lcom/tzibbur/basic/ui/TzbContactsSource$Contact;->phone:Ljava/lang/String;

    invoke-interface {v2, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 306
    .end local v4
    goto :goto_0

    .line 309
    :cond_1
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v3, v2}, Lcom/tzibbur/basic/ui/TzbContactsSource;->loadCache(Landroid/content/Context;Ljava/util/Set;)Ljava/util/Map;

    move-result-object v3

    .line 311
    .local v3, "cached":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Boolean;>;"
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 312
    .local v4, "uncached":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 313
    .local v5, "cachedMatches":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_4

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .line 314
    .local v7, "phone":Ljava/lang/String;
    invoke-interface {v3, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Boolean;

    .line 315
    .local v8, "known":Ljava/lang/Boolean;
    if-nez v8, :cond_2

    .line 316
    invoke-interface {v4, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 317
    :cond_2
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-eqz v9, :cond_3

    .line 318
    invoke-interface {v5, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 320
    .end local v7
    .end local v8
    :cond_3
    :goto_2
    goto :goto_1

    .line 322
    :cond_4
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    new-instance v7, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;

    invoke-direct {v7, p0, v1, v5, v4}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$2;-><init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;Ljava/util/Map;Ljava/util/List;Ljava/util/List;)V

    invoke-static {v6, v7}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$800(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/lang/Runnable;)V

    .line 335
    return-void
.end method
