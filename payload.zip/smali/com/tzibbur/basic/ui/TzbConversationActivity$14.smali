.class Lcom/tzibbur/basic/ui/TzbConversationActivity$14;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadGroup()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbGroup;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 515
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "error"    # Ljava/lang/Exception;

    .line 525
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->val$gid:Ljava/lang/String;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 526
    :cond_0
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_1

    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    iget v0, v0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x194

    if-ne v0, v1, :cond_1

    .line 527
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    goto :goto_0

    .line 529
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 531
    :goto_0
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbGroup;)V
    .locals 2
    .param p1, "result"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 518
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->val$gid:Ljava/lang/String;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 519
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2102(Lcom/tzibbur/basic/ui/TzbConversationActivity;Lcom/tzibbur/basic/model/TzbGroup;)Lcom/tzibbur/basic/model/TzbGroup;

    .line 520
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    .line 521
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 515
    check-cast p1, Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity$14;->onResult(Lcom/tzibbur/basic/model/TzbGroup;)V

    return-void
.end method
