.class Lcom/tzibbur/basic/ui/TzbApplyActivity$11;
.super Landroid/os/CountDownTimer;
.source "TzbApplyActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;->startRefreshCooldown(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;JJ)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p2, "arg0"    # J
    .param p4, "arg1"    # J
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .line 664
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-direct {p0, p2, p3, p4, p5}, Landroid/os/CountDownTimer;-><init>(JJ)V

    return-void
.end method


# virtual methods
.method public onFinish()V
    .locals 2

    .line 674
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$2002(Lcom/tzibbur/basic/ui/TzbApplyActivity;Landroid/os/CountDownTimer;)Landroid/os/CountDownTimer;

    .line 675
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1900(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/widget/Button;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 676
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1900(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/widget/Button;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_apply_refresh_btn:I

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(I)V

    .line 677
    return-void
.end method

.method public onTick(J)V
    .locals 7
    .param p1, "millisUntilFinished"    # J

    .line 667
    const-wide/16 v0, 0x3e7

    add-long/2addr v0, p1

    const-wide/16 v2, 0x3e8

    div-long/2addr v0, v2

    long-to-int v0, v0

    .line 668
    .local v0, "left":I
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1900(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/widget/Button;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_apply_refresh_btn_wait:I

    .line 669
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    aput-object v4, v5, v6

    invoke-virtual {v2, v3, v5}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 668
    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 670
    return-void
.end method
