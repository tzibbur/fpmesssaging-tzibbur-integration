.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

.field final synthetic val$matchedInOrder:Ljava/util/List;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;Ljava/util/List;)V
    .locals 0
    .param p1, "this$1"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 363
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->val$matchedInOrder:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 366
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1602(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Z)Z

    .line 367
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Ljava/util/List;

    move-result-object v0

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v2, v2, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->val$chunk:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    invoke-interface {v0, v1, v2}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 368
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->val$chunk:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1212(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;I)I

    .line 369
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$000(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->val$matchedInOrder:Ljava/util/List;

    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->addMatches(Ljava/util/List;)V

    .line 370
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1700(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    .line 371
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1400(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    .line 372
    return-void
.end method
