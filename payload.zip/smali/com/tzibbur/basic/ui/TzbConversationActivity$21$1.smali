.class Lcom/tzibbur/basic/ui/TzbConversationActivity$21$1;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity$21;->onClick(Landroid/content/DialogInterface;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/tzibbur/basic/ui/TzbConversationActivity$21;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity$21;)V
    .locals 0
    .param p1, "this$1"    # Lcom/tzibbur/basic/ui/TzbConversationActivity$21;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 1138
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21$1;->this$1:Lcom/tzibbur/basic/ui/TzbConversationActivity$21;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 1141
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21$1;->this$1:Lcom/tzibbur/basic/ui/TzbConversationActivity$21;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$21$1;->this$1:Lcom/tzibbur/basic/ui/TzbConversationActivity$21;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbConversationActivity$21;->val$item:Lcom/tzibbur/basic/store/TzbOutboxItem;

    iget-object v1, v1, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbStore;->outboxDone(Ljava/lang/String;)V

    .line 1142
    return-void
.end method
