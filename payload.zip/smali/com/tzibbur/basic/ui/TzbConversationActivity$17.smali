.class Lcom/tzibbur/basic/ui/TzbConversationActivity$17;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->requery(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "[",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

.field final synthetic val$firstLoad:Z

.field final synthetic val$forceScrollToBottom:Z

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;ZZ)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 743
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->val$gid:Ljava/lang/String;

    iput-boolean p3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->val$forceScrollToBottom:Z

    iput-boolean p4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->val$firstLoad:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 1
    .param p1, "error"    # Ljava/lang/Exception;

    .line 837
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 838
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 743
    check-cast p1, [Ljava/lang/Object;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->onResult([Ljava/lang/Object;)V

    return-void
.end method

.method public onResult([Ljava/lang/Object;)V
    .locals 13
    .param p1, "result"    # [Ljava/lang/Object;

    .line 747
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->val$gid:Ljava/lang/String;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 748
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2500(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    .line 751
    .local v0, "wasAtBottom":Z
    const/4 v1, 0x0

    .line 752
    .local v1, "anchorId":Ljava/lang/String;
    const/4 v2, 0x0

    .line 753
    .local v2, "anchorTop":I
    iget-boolean v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->val$forceScrollToBottom:Z

    const/4 v4, 0x0

    if-nez v3, :cond_5

    if-nez v0, :cond_5

    .line 754
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v3}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v3

    .line 755
    .local v3, "selPos":I
    const/4 v5, -0x1

    if-eq v3, v5, :cond_2

    .line 756
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v5

    invoke-virtual {v5, v3}, Landroid/widget/ListView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v5

    .line 757
    .local v5, "selected":Ljava/lang/Object;
    instance-of v6, v5, Lcom/tzibbur/basic/model/TzbMessage;

    if-eqz v6, :cond_2

    .line 758
    move-object v6, v5

    check-cast v6, Lcom/tzibbur/basic/model/TzbMessage;

    iget-object v1, v6, Lcom/tzibbur/basic/model/TzbMessage;->id:Ljava/lang/String;

    .line 759
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v6}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/ListView;->getSelectedView()Landroid/view/View;

    move-result-object v6

    .line 760
    .local v6, "selectedView":Landroid/view/View;
    if-eqz v6, :cond_1

    invoke-virtual {v6}, Landroid/view/View;->getTop()I

    move-result v7

    goto :goto_0

    :cond_1
    move v7, v4

    :goto_0
    move v2, v7

    .line 763
    .end local v5
    .end local v6
    :cond_2
    if-nez v1, :cond_5

    .line 764
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/ListView;->getFirstVisiblePosition()I

    move-result v5

    .line 765
    .local v5, "firstVis":I
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v6}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/widget/ListView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v6

    .line 766
    .local v6, "firstItem":Ljava/lang/Object;
    if-nez v6, :cond_3

    add-int/lit8 v7, v5, 0x1

    iget-object v8, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v8}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/ListView;->getCount()I

    move-result v8

    if-ge v7, v8, :cond_3

    .line 767
    add-int/lit8 v5, v5, 0x1

    .line 768
    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v7}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v7

    invoke-virtual {v7, v5}, Landroid/widget/ListView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v6

    .line 770
    :cond_3
    instance-of v7, v6, Lcom/tzibbur/basic/model/TzbMessage;

    if-eqz v7, :cond_5

    .line 771
    move-object v7, v6

    check-cast v7, Lcom/tzibbur/basic/model/TzbMessage;

    iget-object v1, v7, Lcom/tzibbur/basic/model/TzbMessage;->id:Ljava/lang/String;

    .line 772
    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v7}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v7

    iget-object v8, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 773
    invoke-static {v8}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/ListView;->getFirstVisiblePosition()I

    move-result v8

    sub-int v8, v5, v8

    .line 772
    invoke-virtual {v7, v8}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    .line 774
    .local v7, "child":Landroid/view/View;
    if-eqz v7, :cond_4

    invoke-virtual {v7}, Landroid/view/View;->getTop()I

    move-result v8

    goto :goto_1

    :cond_4
    move v8, v4

    :goto_1
    move v2, v8

    .line 778
    .end local v3
    .end local v5
    .end local v6
    .end local v7
    :cond_5
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v3}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->clear()V

    .line 779
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v3}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v3

    aget-object v4, p1, v4

    check-cast v4, Ljava/util/List;

    invoke-interface {v3, v4}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 780
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    const/4 v4, 0x1

    aget-object v5, p1, v4

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2702(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/util/List;)Ljava/util/List;

    .line 781
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    const/4 v5, 0x2

    aget-object v5, p1, v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2802(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/util/List;)Ljava/util/List;

    .line 782
    const/4 v3, -0x1

    .line 783
    .local v3, "unreadIndex":I
    iget-boolean v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->val$firstLoad:Z

    if-eqz v5, :cond_7

    .line 786
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2900(Lcom/tzibbur/basic/ui/TzbConversationActivity;)I

    move-result v3

    .line 787
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    if-ltz v3, :cond_6

    .line 788
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v6}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v6

    invoke-interface {v6, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/tzibbur/basic/model/TzbMessage;

    iget-wide v6, v6, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    goto :goto_2

    :cond_6
    const-wide/16 v6, -0x1

    .line 787
    :goto_2
    invoke-static {v5, v6, v7}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3002(Lcom/tzibbur/basic/ui/TzbConversationActivity;J)J

    .line 790
    :cond_7
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    move-result-object v6

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v7

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v8

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v9

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)J

    move-result-wide v10

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2800(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v12

    invoke-virtual/range {v6 .. v12}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->setData(Ljava/util/List;Ljava/util/List;Ljava/util/List;JLjava/util/List;)V

    .line 791
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    .line 792
    iget-boolean v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->val$firstLoad:Z

    if-eqz v5, :cond_9

    .line 793
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5, v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3402(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z

    .line 796
    if-ltz v3, :cond_8

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    sub-int/2addr v5, v4

    if-ge v3, v5, :cond_8

    .line 797
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5, v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3502(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z

    .line 802
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5, v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3602(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z

    .line 804
    add-int/lit8 v4, v3, 0x1

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 805
    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/ListView;->getHeaderViewsCount()I

    move-result v5

    add-int/2addr v4, v5

    .line 806
    .local v4, "position":I
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v5

    new-instance v6, Lcom/tzibbur/basic/ui/TzbConversationActivity$17$1;

    invoke-direct {v6, p0, v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity$17$1;-><init>(Lcom/tzibbur/basic/ui/TzbConversationActivity$17;I)V

    invoke-virtual {v5, v6}, Landroid/widget/ListView;->post(Ljava/lang/Runnable;)Z

    .line 816
    .end local v4
    goto :goto_4

    .line 817
    :cond_8
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3800(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    .line 821
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v4

    if-eqz v4, :cond_c

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3900(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    goto :goto_4

    .line 823
    :cond_9
    iget-boolean v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->val$forceScrollToBottom:Z

    if-nez v4, :cond_b

    if-eqz v0, :cond_a

    goto :goto_3

    .line 825
    :cond_a
    if-eqz v1, :cond_c

    .line 826
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v4, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4000(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)I

    move-result v4

    .line 827
    .local v4, "index":I
    if-ltz v4, :cond_c

    .line 828
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v5}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v5

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 829
    invoke-static {v6}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/ListView;->getHeaderViewsCount()I

    move-result v6

    add-int/2addr v6, v4

    .line 828
    invoke-virtual {v5, v6, v2}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    goto :goto_4

    .line 824
    .end local v4
    :cond_b
    :goto_3
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3800(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    .line 832
    :cond_c
    :goto_4
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v4

    if-eqz v4, :cond_d

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v4}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    .line 833
    :cond_d
    return-void
.end method
