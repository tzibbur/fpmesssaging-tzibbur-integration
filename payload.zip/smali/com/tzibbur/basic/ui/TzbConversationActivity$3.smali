.class Lcom/tzibbur/basic/ui/TzbConversationActivity$3;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 203
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "keyCode"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .line 206
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    .line 207
    :cond_0
    const/16 v0, 0x13

    const/4 v2, 0x1

    if-ne p2, v0, :cond_3

    .line 208
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 209
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 210
    return v2

    .line 212
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->getCount()I

    move-result v0

    if-lez v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->requestFocus()Z

    move-result v0

    if-eqz v0, :cond_2

    move v1, v2

    :cond_2
    return v1

    .line 214
    :cond_3
    const/16 v0, 0x16

    if-ne p2, v0, :cond_6

    .line 215
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 216
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$400(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    .line 217
    return v2

    .line 219
    :cond_4
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$500(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/TextView;->requestFocus()Z

    move-result v0

    if-eqz v0, :cond_5

    move v1, v2

    :cond_5
    return v1

    .line 221
    :cond_6
    return v1
.end method
