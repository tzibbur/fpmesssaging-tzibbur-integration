.class Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$11;
.super Ljava/lang/Object;
.source "TzbEnrollPhoneActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;->fetchCapabilities()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbCapabilities;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

.field final synthetic val$core:Lcom/tzibbur/basic/core/TzbCore;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;Lcom/tzibbur/basic/core/TzbCore;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 459
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$11;->val$core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbCapabilities;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 462
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$11;->val$core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    const-string v1, "kosher"

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/net/TzbApi;->capabilities(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbCapabilities;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 459
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity$11;->call()Lcom/tzibbur/basic/model/TzbCapabilities;

    move-result-object v0

    return-object v0
.end method
