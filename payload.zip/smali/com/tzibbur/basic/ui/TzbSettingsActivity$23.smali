.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$23;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->finishSignOut()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 495
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 1
    .param p1, "error"    # Ljava/lang/Exception;

    .line 504
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->routeToEnrollment()V

    .line 505
    :cond_0
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 495
    check-cast p1, Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$23;->onResult(Ljava/lang/Void;)V

    return-void
.end method

.method public onResult(Ljava/lang/Void;)V
    .locals 1
    .param p1, "result"    # Ljava/lang/Void;

    .line 498
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$23;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->routeToEnrollment()V

    .line 499
    :cond_0
    return-void
.end method
