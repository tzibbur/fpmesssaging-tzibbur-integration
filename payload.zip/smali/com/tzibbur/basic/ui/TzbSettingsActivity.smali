.class public Lcom/tzibbur/basic/ui/TzbSettingsActivity;
.super Lcom/tzibbur/basic/ui/TzbBaseActivity;
.source "TzbSettingsActivity.java"


# static fields
.field private static final MAX_NAME_CODE_POINTS_FALLBACK:I = 0x40


# instance fields
.field private connectionValue:Landroid/widget/TextView;

.field private nameValue:Landroid/widget/TextView;

.field private notificationDesc:Landroid/widget/TextView;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 44
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    .line 44
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->showNameDialog()V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    .line 44
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->openNotificationSettings()V

    return-void
.end method

.method static synthetic access$1000(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    .line 44
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->signOut()V

    return-void
.end method

.method static synthetic access$1100(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    .line 44
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->finishSignOut()V

    return-void
.end method

.method static synthetic access$1200(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    .line 44
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->confirmSignOutOffline()V

    return-void
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    .line 44
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->loadDevices()V

    return-void
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    .line 44
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->confirmSignOut()V

    return-void
.end method

.method static synthetic access$400(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 44
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->submitName(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$500(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    .line 44
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->nameValue:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/util/List;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .param p1, "x1"    # Ljava/util/List;

    .line 44
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->showDevicesDialog(Ljava/util/List;)V

    return-void
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/model/TzbDevice;
    .param p1, "x1"    # Ljava/lang/String;

    .line 44
    invoke-static {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->isThisPhone(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method static synthetic access$800(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbDevice;
    .param p2, "x2"    # Ljava/lang/String;

    .line 44
    invoke-direct {p0, p1, p2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->confirmRevokeDevice(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$900(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 44
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->revokeDevice(Ljava/lang/String;)V

    return-void
.end method

.method private confirmRevokeDevice(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)V
    .locals 4
    .param p1, "device"    # Lcom/tzibbur/basic/model/TzbDevice;
    .param p2, "label"    # Ljava/lang/String;

    .line 363
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_devices_revoke_title:I

    .line 364
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_devices_revoke_msg:I

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p2, v2, v3

    .line 365
    invoke-virtual {p0, v1, v2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_settings_sign_out:I

    new-instance v2, Lcom/tzibbur/basic/ui/TzbSettingsActivity$15;

    invoke-direct {v2, p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$15;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Lcom/tzibbur/basic/model/TzbDevice;)V

    .line 366
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 373
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 374
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 375
    return-void
.end method

.method private confirmSignOut()V
    .locals 3

    .line 410
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_settings_sign_out:I

    .line 411
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_sign_out_confirm_1:I

    .line 412
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_settings_sign_out:I

    new-instance v2, Lcom/tzibbur/basic/ui/TzbSettingsActivity$18;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$18;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    .line 413
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 431
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 432
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 433
    return-void
.end method

.method private confirmSignOutOffline()V
    .locals 3

    .line 468
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 469
    :cond_0
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_signout_offline_title:I

    .line 470
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_signout_offline_msg:I

    .line 471
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_settings_sign_out:I

    new-instance v2, Lcom/tzibbur/basic/ui/TzbSettingsActivity$21;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$21;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    .line 472
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 479
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 480
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 481
    return-void
.end method

.method private deviceLine(Lcom/tzibbur/basic/model/TzbDevice;)Ljava/lang/String;
    .locals 5
    .param p1, "device"    # Lcom/tzibbur/basic/model/TzbDevice;

    .line 336
    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbDevice;->deviceModel:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbDevice;->deviceModel:Ljava/lang/String;

    goto :goto_0

    :cond_0
    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbDevice;->platform:Ljava/lang/String;

    .line 337
    .local v0, "model":Ljava/lang/String;
    :goto_0
    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbDevice;->lastSeenAt:Ljava/lang/String;

    if-eqz v1, :cond_1

    .line 338
    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbDevice;->lastSeenAt:Ljava/lang/String;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->formatLastSeen(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    .line 339
    :cond_1
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_device_never_seen:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    :goto_1
    nop

    .line 340
    .local v1, "lastSeen":Ljava/lang/String;
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_devices_line:I

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v0, v3, v4

    const/4 v4, 0x1

    aput-object v1, v3, v4

    invoke-virtual {p0, v2, v3}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method private finishSignOut()V
    .locals 2

    .line 489
    new-instance v0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$22;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$22;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    new-instance v1, Lcom/tzibbur/basic/ui/TzbSettingsActivity$23;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$23;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    invoke-static {v0, v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 507
    return-void
.end method

.method private static formatLastSeen(Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    .param p0, "iso"    # Ljava/lang/String;

    .line 348
    const-string v0, "yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'"

    const-string v1, "yyyy-MM-dd\'T\'HH:mm:ss\'Z\'"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    .line 349
    .local v0, "patterns":[Ljava/lang/String;
    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-object v3, v0, v2

    .line 350
    .local v3, "pattern":Ljava/lang/String;
    new-instance v4, Ljava/text/SimpleDateFormat;

    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v4, v3, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 351
    .local v4, "parser":Ljava/text/SimpleDateFormat;
    const-string v5, "UTC"

    invoke-static {v5}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/text/SimpleDateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 353
    :try_start_0
    invoke-virtual {v4, p0}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v5

    .line 354
    .local v5, "date":Ljava/util/Date;
    const/4 v6, 0x3

    invoke-static {v6}, Ljava/text/DateFormat;->getDateInstance(I)Ljava/text/DateFormat;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    :try_end_0
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    .line 355
    .end local v5
    :catch_0
    move-exception v5

    .line 349
    .end local v3
    .end local v4
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 359
    :cond_0
    return-object p0
.end method

.method private static isThisPhone(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)Z
    .locals 1
    .param p0, "device"    # Lcom/tzibbur/basic/model/TzbDevice;
    .param p1, "selfDeviceId"    # Ljava/lang/String;

    .line 330
    if-eqz p1, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/model/TzbDevice;->id:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private loadDevices()V
    .locals 2

    .line 266
    new-instance v0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$11;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$11;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    new-instance v1, Lcom/tzibbur/basic/ui/TzbSettingsActivity$12;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$12;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    invoke-static {v0, v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 282
    return-void
.end method

.method private openNotificationSettings()V
    .locals 4

    .line 183
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_1

    .line 184
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.CHANNEL_NOTIFICATION_SETTINGS"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 185
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "android.provider.extra.APP_PACKAGE"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 186
    const-string v1, "android.provider.extra.CHANNEL_ID"

    const-string v3, "tzb_service_quiet"

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 187
    .local v0, "channelIntent":Landroid/content/Intent;
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->tryStart(Landroid/content/Intent;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    .line 188
    :cond_0
    new-instance v1, Landroid/content/Intent;

    const-string v3, "android.settings.APP_NOTIFICATION_SETTINGS"

    invoke-direct {v1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 189
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    .line 190
    .local v1, "appIntent":Landroid/content/Intent;
    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->tryStart(Landroid/content/Intent;)Z

    move-result v2

    if-eqz v2, :cond_1

    return-void

    .line 192
    .end local v0
    .end local v1
    :cond_1
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.APPLICATION_DETAILS_SETTINGS"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 193
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const-string v3, "package"

    invoke-static {v3, v1, v2}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    move-result-object v0

    .line 194
    .local v0, "detailsIntent":Landroid/content/Intent;
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->tryStart(Landroid/content/Intent;)Z

    move-result v1

    if-eqz v1, :cond_2

    return-void

    .line 195
    :cond_2
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_not_available_on_device:I

    const/4 v2, 0x1

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 196
    return-void
.end method

.method private refreshLegalDocuments()V
    .locals 7

    .line 122
    new-instance v0, Lcom/tzibbur/basic/store/TzbLegalCache;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/store/TzbLegalCache;-><init>(Landroid/content/Context;)V

    .line 123
    .local v0, "cache":Lcom/tzibbur/basic/store/TzbLegalCache;
    const-string v1, "terms"

    const-string v2, "privacy"

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    .line 124
    .local v1, "keys":[Ljava/lang/String;
    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_0

    aget-object v4, v1, v3

    .line 125
    .local v4, "key":Ljava/lang/String;
    new-instance v5, Lcom/tzibbur/basic/ui/TzbSettingsActivity$6;

    invoke-direct {v5, p0, v4}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V

    new-instance v6, Lcom/tzibbur/basic/ui/TzbSettingsActivity$7;

    invoke-direct {v6, p0, v0, v4}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$7;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Lcom/tzibbur/basic/store/TzbLegalCache;Ljava/lang/String;)V

    invoke-static {v5, v6}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 124
    .end local v4
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 142
    :cond_0
    return-void
.end method

.method private revokeDevice(Ljava/lang/String;)V
    .locals 2
    .param p1, "deviceId"    # Ljava/lang/String;

    .line 378
    new-instance v0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$16;

    invoke-direct {v0, p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$16;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V

    new-instance v1, Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    invoke-static {v0, v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 404
    return-void
.end method

.method private showDevicesDialog(Ljava/util/List;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbDevice;",
            ">;)V"
        }
    .end annotation

    .line 290
    .local p1, "fetched":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbDevice;>;"
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    .line 291
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_devices_empty:I

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 292
    return-void

    .line 294
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->deviceId()Ljava/lang/String;

    move-result-object v0

    .line 295
    .local v0, "selfDeviceId":Ljava/lang/String;
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 296
    .local v2, "devices":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbDevice;>;"
    new-instance v3, Lcom/tzibbur/basic/ui/TzbSettingsActivity$13;

    invoke-direct {v3, p0, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$13;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V

    invoke-static {v2, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 304
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    new-array v3, v3, [Ljava/lang/String;

    .line 305
    .local v3, "lines":[Ljava/lang/String;
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_2

    .line 306
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/tzibbur/basic/model/TzbDevice;

    .line 307
    .local v5, "device":Lcom/tzibbur/basic/model/TzbDevice;
    invoke-direct {p0, v5}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->deviceLine(Lcom/tzibbur/basic/model/TzbDevice;)Ljava/lang/String;

    move-result-object v6

    .line 308
    .local v6, "line":Ljava/lang/String;
    invoke-static {v5, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->isThisPhone(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    .line 309
    sget v7, Lcom/tzibbur/basic/R$string;->tzb_devices_this_phone:I

    new-array v8, v1, [Ljava/lang/Object;

    const/4 v9, 0x0

    aput-object v6, v8, v9

    invoke-virtual {p0, v7, v8}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    goto :goto_1

    :cond_1
    move-object v7, v6

    :goto_1
    aput-object v7, v3, v4

    .line 305
    .end local v5
    .end local v6
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 311
    .end local v4
    :cond_2
    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_settings_devices:I

    .line 312
    invoke-virtual {v1, v4}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v4, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;

    invoke-direct {v4, p0, v2, v0, v3}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/util/List;Ljava/lang/String;[Ljava/lang/String;)V

    .line 313
    invoke-virtual {v1, v3, v4}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_close:I

    .line 325
    const/4 v5, 0x0

    invoke-virtual {v1, v4, v5}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 326
    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 327
    return-void
.end method

.method private showNameDialog()V
    .locals 7

    .line 218
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$layout;->tzb_dialog_edit:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 219
    .local v0, "content":Landroid/view/View;
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_dialog_edit_text:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    .line 220
    .local v1, "edit":Landroid/widget/EditText;
    sget v3, Lcom/tzibbur/basic/R$string;->tzb_settings_name:I

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setHint(I)V

    .line 221
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v3}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v3

    invoke-interface {v3}, Lcom/tzibbur/basic/store/TzbSession;->displayName()Ljava/lang/String;

    move-result-object v3

    .line 222
    .local v3, "current":Ljava/lang/String;
    if-eqz v3, :cond_0

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 223
    :cond_0
    new-instance v4, Landroid/app/AlertDialog$Builder;

    invoke-direct {v4, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_settings_name:I

    .line 224
    invoke-virtual {v4, v5}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    .line 225
    invoke-virtual {v4, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_ok:I

    new-instance v6, Lcom/tzibbur/basic/ui/TzbSettingsActivity$8;

    invoke-direct {v6, p0, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$8;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Landroid/widget/EditText;)V

    .line 226
    invoke-virtual {v4, v5, v6}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 232
    invoke-virtual {v4, v5, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    .line 233
    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v2

    .line 234
    .local v2, "dialog":Landroid/app/AlertDialog;
    invoke-static {v2, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->attachDialogIme(Landroid/app/AlertDialog;Landroid/widget/EditText;)V

    .line 235
    return-void
.end method

.method private signOut()V
    .locals 2

    .line 441
    new-instance v0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$19;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$19;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    new-instance v1, Lcom/tzibbur/basic/ui/TzbSettingsActivity$20;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$20;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    invoke-static {v0, v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 465
    return-void
.end method

.method private submitName(Ljava/lang/String;)V
    .locals 3
    .param p1, "name"    # Ljava/lang/String;

    .line 239
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    const/4 v0, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    const/16 v2, 0x40

    invoke-interface {v1, v2}, Lcom/tzibbur/basic/store/TzbSession;->displayNameMaxLength(I)I

    move-result v1

    if-le v0, v1, :cond_0

    goto :goto_0

    .line 243
    :cond_0
    new-instance v0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$9;

    invoke-direct {v0, p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$9;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V

    new-instance v1, Lcom/tzibbur/basic/ui/TzbSettingsActivity$10;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$10;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    invoke-static {v0, v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 261
    return-void

    .line 240
    :cond_1
    :goto_0
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_err_invalid_display_name:I

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 241
    return-void
.end method

.method private tryStart(Landroid/content/Intent;)Z
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;

    .line 200
    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->startActivity(Landroid/content/Intent;)V

    .line 201
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v0, 0x1

    return v0

    .line 204
    :catch_0
    move-exception v1

    .line 206
    .local v1, "e":Ljava/lang/SecurityException;
    return v0

    .line 202
    .end local v1
    :catch_1
    move-exception v1

    .line 203
    .local v1, "e":Landroid/content/ActivityNotFoundException;
    return v0
.end method

.method private updateConnection(I)V
    .locals 2
    .param p1, "state"    # I

    .line 145
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->connectionValue:Landroid/widget/TextView;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->connectionStateText(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 146
    return-void
.end method

.method private updateNotificationState()V
    .locals 5

    .line 164
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-ge v0, v1, :cond_0

    return-void

    .line 165
    :cond_0
    nop

    .line 166
    const-string v0, "notification"

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 167
    .local v0, "manager":Landroid/app/NotificationManager;
    if-nez v0, :cond_1

    return-void

    .line 168
    :cond_1
    nop

    .line 169
    const-string v1, "tzb_service_quiet"

    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->getNotificationChannel(Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object v1

    .line 170
    .local v1, "channel":Landroid/app/NotificationChannel;
    if-nez v1, :cond_2

    return-void

    .line 171
    :cond_2
    invoke-virtual {v1}, Landroid/app/NotificationChannel;->getImportance()I

    move-result v2

    if-nez v2, :cond_3

    const/4 v2, 0x1

    goto :goto_0

    :cond_3
    const/4 v2, 0x0

    .line 172
    .local v2, "hidden":Z
    :goto_0
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->notificationDesc:Landroid/widget/TextView;

    if-eqz v2, :cond_4

    .line 173
    sget v4, Lcom/tzibbur/basic/R$string;->tzb_settings_notification_hidden:I

    goto :goto_1

    .line 174
    :cond_4
    sget v4, Lcom/tzibbur/basic/R$string;->tzb_settings_notification_shown:I

    .line 172
    :goto_1
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(I)V

    .line 175
    return-void
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onConnectionChanged(I)V
    .locals 0
    .param p1, "state"    # I

    .line 212
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->updateConnection(I)V

    .line 213
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 54
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onCreate(Landroid/os/Bundle;)V

    .line 56
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 57
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->finish()V

    .line 58
    return-void

    .line 62
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 63
    return-void

    .line 65
    :cond_1
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_settings_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->setContentView(I)V

    .line 68
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 70
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_settings_title:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->setupTitleBar(Ljava/lang/CharSequence;Z)V

    .line 72
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_settings_name_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->nameValue:Landroid/widget/TextView;

    .line 73
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_settings_connection_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->connectionValue:Landroid/widget/TextView;

    .line 74
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_settings_phone_value:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 75
    .local v0, "phoneValue":Landroid/widget/TextView;
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_settings_version_value:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    .line 77
    .local v1, "versionValue":Landroid/widget/TextView;
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->nameValue:Landroid/widget/TextView;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v3}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v3

    invoke-interface {v3}, Lcom/tzibbur/basic/store/TzbSession;->displayName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 78
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v2}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v2

    invoke-interface {v2}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 79
    const-string v2, "0.1.60"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 80
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v2}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v2

    invoke-interface {v2}, Lcom/tzibbur/basic/sync/TzbSync;->connectionState()I

    move-result v2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->updateConnection(I)V

    .line 82
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_settings_name_row:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    new-instance v3, Lcom/tzibbur/basic/ui/TzbSettingsActivity$1;

    invoke-direct {v3, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 88
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_settings_notification_desc:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->notificationDesc:Landroid/widget/TextView;

    .line 89
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_settings_notification_row:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    new-instance v3, Lcom/tzibbur/basic/ui/TzbSettingsActivity$2;

    invoke-direct {v3, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    .line 90
    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 97
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_settings_devices_row:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    new-instance v3, Lcom/tzibbur/basic/ui/TzbSettingsActivity$3;

    invoke-direct {v3, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 103
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_settings_about_row:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    new-instance v3, Lcom/tzibbur/basic/ui/TzbSettingsActivity$4;

    invoke-direct {v3, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 109
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_settings_signout_row:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    new-instance v3, Lcom/tzibbur/basic/ui/TzbSettingsActivity$5;

    invoke-direct {v3, p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$5;-><init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 115
    return-void
.end method

.method protected onResume()V
    .locals 0

    .line 150
    invoke-super {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onResume()V

    .line 152
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->updateNotificationState()V

    .line 153
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->refreshLegalDocuments()V

    .line 154
    return-void
.end method
