.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$5;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 156
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 159
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->setResult(I)V

    .line 160
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->finish()V

    .line 161
    return-void
.end method
