.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$10;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->submitName(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbUser;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 248
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 1
    .param p1, "error"    # Ljava/lang/Exception;

    .line 258
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 259
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbUser;)V
    .locals 2
    .param p1, "user"    # Lcom/tzibbur/basic/model/TzbUser;

    .line 251
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbUser;->displayName:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbSession;->setDisplayName(Ljava/lang/String;)V

    .line 252
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$500(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)Landroid/widget/TextView;

    move-result-object v0

    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbUser;->displayName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 253
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 248
    check-cast p1, Lcom/tzibbur/basic/model/TzbUser;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$10;->onResult(Lcom/tzibbur/basic/model/TzbUser;)V

    return-void
.end method
