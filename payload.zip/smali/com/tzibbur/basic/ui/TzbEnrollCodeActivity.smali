.class public Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
.super Landroid/app/Activity;
.source "TzbEnrollCodeActivity.java"


# static fields
.field private static final DEFAULT_RETRY_SECONDS:I = 0x3c

.field public static final EXTRA_CHALLENGE_ID:Ljava/lang/String; = "tzb_challenge_id"

.field public static final EXTRA_EXPIRES_AT:Ljava/lang/String; = "tzb_expires_at"

.field public static final EXTRA_PHONE:Ljava/lang/String; = "tzb_phone"

.field public static final EXTRA_RESEND_AFTER_SECONDS:Ljava/lang/String; = "tzb_resend_after_seconds"

.field private static final FAILURES_BEFORE_FRESH_CODE_HINT:I = 0x3

.field private static final RC_NAME:I = 0x3

.field private static final RC_SMS_PERM:I = 0x2

.field private static final STATE_CHALLENGE_ID:Ljava/lang/String; = "tzb_challenge_id"

.field private static final STATE_DISPLAY_NAME:Ljava/lang/String; = "tzb_display_name"

.field private static final STATE_EXPIRES_AT_MILLIS:Ljava/lang/String; = "tzb_expires_at_millis"

.field private static final STATE_FAILED_ATTEMPTS:Ljava/lang/String; = "tzb_failed_attempts"

.field private static final STATE_NAME_REQUIRED:Ljava/lang/String; = "tzb_name_required"

.field private static final STATE_NAME_STEP_OPEN:Ljava/lang/String; = "tzb_name_step_open"

.field private static final STATE_SMS_PERM_REQUESTED:Ljava/lang/String; = "tzb_sms_perm_requested"


# instance fields
.field private busy:Z

.field private challengeId:Ljava/lang/String;

.field private codeInput:Landroid/widget/EditText;

.field private displayName:Ljava/lang/String;

.field private done:Z

.field private final droppedIdentifiers:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private expiresAtMillis:J

.field private failedAttempts:I

.field private nameRequired:Z

.field private nameStepOpen:Z

.field private otpReceiver:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;

.field private phone:Ljava/lang/String;

.field private rateLimitTimer:Landroid/os/CountDownTimer;

.field private receiverRegistered:Z

.field private resendButton:Landroid/widget/Button;

.field private resendTimer:Landroid/os/CountDownTimer;

.field private smsHintView:Landroid/widget/TextView;

.field private smsPermRequested:Z

.field private statusView:Landroid/widget/TextView;

.field private verifyButton:Landroid/widget/Button;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 49
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 559
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->droppedIdentifiers:Ljava/util/Set;

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    .line 49
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verify()V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    .line 49
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resend()V

    return-void
.end method

.method static synthetic access$1000(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    .line 49
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->done:Z

    return v0
.end method

.method static synthetic access$1100(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    .line 49
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verifyButton:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$1200(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 49
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showStatus(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1300(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    .line 49
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->phone:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$1402(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;J)J
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # J

    .line 49
    iput-wide p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->expiresAtMillis:J

    return-wide p1
.end method

.method static synthetic access$1500(Ljava/lang/String;)J
    .locals 2
    .param p0, "x0"    # Ljava/lang/String;

    .line 49
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->parseIso(Ljava/lang/String;)J

    move-result-wide v0

    return-wide v0
.end method

.method static synthetic access$1602(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;I)I
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # I

    .line 49
    iput p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->failedAttempts:I

    return p1
.end method

.method static synthetic access$1700(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;I)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # I

    .line 49
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->startResendCountdown(I)V

    return-void
.end method

.method static synthetic access$1800(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/Exception;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Ljava/lang/Exception;

    .line 49
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->handleResendError(Ljava/lang/Exception;)V

    return-void
.end method

.method static synthetic access$1900(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    .line 49
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendButton:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 49
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->onSmsCode(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$2002(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Landroid/os/CountDownTimer;)Landroid/os/CountDownTimer;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Landroid/os/CountDownTimer;

    .line 49
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendTimer:Landroid/os/CountDownTimer;

    return-object p1
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    .line 49
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->challengeId:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$302(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 49
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->challengeId:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic access$402(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Z

    .line 49
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->busy:Z

    return p1
.end method

.method static synthetic access$500(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Lcom/tzibbur/basic/model/TzbEnrollment;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbEnrollment;

    .line 49
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->onEnrolled(Lcom/tzibbur/basic/model/TzbEnrollment;)V

    return-void
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Z)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Z

    .line 49
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->setUiEnabled(Z)V

    return-void
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/Exception;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Ljava/lang/Exception;

    .line 49
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->handleVerifyError(Ljava/lang/Exception;)V

    return-void
.end method

.method static synthetic access$800(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 49
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$902(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Landroid/os/CountDownTimer;)Landroid/os/CountDownTimer;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p1, "x1"    # Landroid/os/CountDownTimer;

    .line 49
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->rateLimitTimer:Landroid/os/CountDownTimer;

    return-object p1
.end method

.method private armReceiver()V
    .locals 3

    .line 258
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->receiverRegistered:Z

    if-eqz v0, :cond_0

    return-void

    .line 259
    :cond_0
    new-instance v0, Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;

    invoke-direct {v0}, Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->otpReceiver:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;

    .line 260
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->otpReceiver:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$3;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;->setListener(Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;)V

    .line 266
    new-instance v0, Landroid/content/IntentFilter;

    const-string v1, "android.provider.Telephony.SMS_RECEIVED"

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 269
    .local v0, "filter":Landroid/content/IntentFilter;
    const/16 v1, 0x3e7

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->setPriority(I)V

    .line 270
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->otpReceiver:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;

    invoke-virtual {p0, v1, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 271
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->receiverRegistered:Z

    .line 272
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->smsHintView:Landroid/widget/TextView;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 273
    return-void
.end method

.method private droppedIdentifier(Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .line 562
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->droppedIdentifiers:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private handleDeviceBlocked()V
    .locals 1

    .line 587
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->setDeviceBlocked()V

    .line 588
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;->show(Landroid/content/Context;)V

    .line 589
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->finish()V

    .line 590
    return-void
.end method

.method private handleResendError(Ljava/lang/Exception;)V
    .locals 6
    .param p1, "error"    # Ljava/lang/Exception;

    .line 464
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_6

    .line 465
    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    .line 466
    .local v0, "p":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isDeviceBlocked()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 467
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->handleDeviceBlocked()V

    .line 468
    return-void

    .line 470
    :cond_0
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->dropIdentifierAndRetry(Lcom/tzibbur/basic/net/TzbProblem;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 471
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resend()V

    .line 472
    return-void

    .line 474
    :cond_1
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isRateLimited()Z

    move-result v1

    if-eqz v1, :cond_3

    .line 475
    iget v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    if-lez v1, :cond_2

    iget v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    goto :goto_0

    :cond_2
    const/16 v1, 0x3c

    .line 476
    .local v1, "wait":I
    :goto_0
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_rate_limited:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v3, v4, v5

    invoke-virtual {p0, v2, v4}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    .line 477
    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->startResendCountdown(I)V

    .line 478
    .end local v1
    goto :goto_1

    :cond_3
    const-string v1, "sms_delivery_failed"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 479
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_sms_failed:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    goto :goto_1

    .line 480
    :cond_4
    const-string v1, "not_implemented"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    .line 481
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_unavailable:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    goto :goto_1

    .line 483
    :cond_5
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_error_generic:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    .line 485
    .end local v0
    :goto_1
    goto :goto_2

    .line 486
    :cond_6
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_error_network:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    .line 488
    :goto_2
    return-void
.end method

.method private handleVerifyError(Ljava/lang/Exception;)V
    .locals 7
    .param p1, "error"    # Ljava/lang/Exception;

    .line 349
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_a

    .line 350
    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    .line 351
    .local v0, "p":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isDeviceBlocked()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 353
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->handleDeviceBlocked()V

    .line 354
    return-void

    .line 356
    :cond_0
    const-string v1, "additional_factors_required"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 358
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_unavailable:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    .line 359
    return-void

    .line 361
    :cond_1
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isRateLimited()Z

    move-result v1

    if-eqz v1, :cond_3

    .line 362
    iget v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    if-lez v1, :cond_2

    iget v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    goto :goto_0

    :cond_2
    const/16 v1, 0x3c

    .line 363
    .local v1, "wait":I
    :goto_0
    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->startRateLimitCountdown(I)V

    .line 364
    return-void

    .line 369
    .end local v1
    :cond_3
    const-string v1, "display_name_required"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_4

    .line 370
    iput-boolean v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameRequired:Z

    .line 371
    const/4 v1, 0x0

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->openNameStep(Ljava/lang/String;)V

    .line 372
    return-void

    .line 376
    :cond_4
    const-string v1, "invalid_display_name"

    iget-object v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    .line 377
    const-string v3, "reserved_display_name"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    goto :goto_4

    .line 384
    :cond_5
    iget v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->failedAttempts:I

    add-int/2addr v1, v2

    iput v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->failedAttempts:I

    .line 385
    iget v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->failedAttempts:I

    const/4 v3, 0x3

    if-ge v1, v3, :cond_7

    iget-wide v3, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->expiresAtMillis:J

    const-wide/16 v5, 0x0

    cmp-long v1, v3, v5

    if-lez v1, :cond_6

    .line 386
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iget-wide v5, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->expiresAtMillis:J

    cmp-long v1, v3, v5

    if-lez v1, :cond_6

    goto :goto_1

    :cond_6
    const/4 v2, 0x0

    goto :goto_2

    :cond_7
    :goto_1
    nop

    .line 387
    .local v2, "challengeStale":Z
    :goto_2
    if-eqz v2, :cond_8

    .line 388
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_code_stale:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    goto :goto_3

    .line 390
    :cond_8
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_wrong_code:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    .line 392
    .end local v0
    .end local v2
    :goto_3
    goto :goto_5

    .line 378
    .restart local v0
    :cond_9
    :goto_4
    iput-boolean v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameRequired:Z

    .line 379
    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->openNameStep(Ljava/lang/String;)V

    .line 380
    return-void

    .line 394
    .end local v0
    :cond_a
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_error_network:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    .line 396
    :goto_5
    return-void
.end method

.method private onEnrolled(Lcom/tzibbur/basic/model/TzbEnrollment;)V
    .locals 2
    .param p1, "enrollment"    # Lcom/tzibbur/basic/model/TzbEnrollment;

    .line 329
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->done:Z

    .line 331
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/tzibbur/basic/store/TzbSession;->saveEnrollment(Lcom/tzibbur/basic/model/TzbEnrollment;)V

    .line 336
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->onEnrolled(Landroid/content/Context;)V

    .line 339
    invoke-static {p0}, Lcom/tzibbur/basic/sync/TzbSyncService;->ensureRunning(Landroid/content/Context;)V

    .line 340
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 342
    .local v0, "next":Landroid/content/Intent;
    const-string v1, "com.android.mms.ui.ConversationList"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 343
    const v1, 0x10008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 344
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->startActivity(Landroid/content/Intent;)V

    .line 345
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->finish()V

    .line 346
    return-void
.end method

.method private onSmsCode(Ljava/lang/String;)V
    .locals 2
    .param p1, "code"    # Ljava/lang/String;

    .line 276
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->done:Z

    if-nez v0, :cond_2

    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 277
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->codeInput:Landroid/widget/EditText;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 278
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->codeInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->codeInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-interface {v1}, Landroid/text/Editable;->length()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSelection(I)V

    .line 279
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_enroll_status_code_received:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showStatus(Ljava/lang/String;)V

    .line 280
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->busy:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameStepOpen:Z

    if-nez v0, :cond_1

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verify()V

    .line 281
    :cond_1
    return-void

    .line 276
    :cond_2
    :goto_0
    return-void
.end method

.method private openNameStep(Ljava/lang/String;)V
    .locals 2
    .param p1, "problemCode"    # Ljava/lang/String;

    .line 189
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameStepOpen:Z

    .line 190
    const-string v0, ""

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showStatus(Ljava/lang/String;)V

    .line 191
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->displayName:Ljava/lang/String;

    .line 192
    invoke-static {p0, v0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollNameActivity;->intent(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 191
    const/4 v1, 0x3

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 193
    return-void
.end method

.method private static parseIso(Ljava/lang/String;)J
    .locals 5
    .param p0, "iso"    # Ljava/lang/String;

    .line 543
    const-wide/16 v0, 0x0

    if-nez p0, :cond_0

    return-wide v0

    .line 544
    :cond_0
    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'"

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v2, v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 546
    .local v2, "fmt":Ljava/text/SimpleDateFormat;
    const-string v3, "UTC"

    invoke-static {v3}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/text/SimpleDateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 548
    :try_start_0
    invoke-virtual {v2, p0}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    :try_end_0
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_0} :catch_0

    return-wide v0

    .line 549
    :catch_0
    move-exception v3

    .line 550
    .local v3, "e":Ljava/text/ParseException;
    return-wide v0
.end method

.method private resend()V
    .locals 5

    .line 423
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->busy:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->done:Z

    if-eqz v0, :cond_0

    goto :goto_2

    .line 424
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->busy:Z

    .line 425
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->setUiEnabled(Z)V

    .line 426
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_enroll_status_sending:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showStatus(Ljava/lang/String;)V

    .line 428
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    .line 431
    .local v0, "api":Lcom/tzibbur/basic/net/TzbApi;
    const-string v1, "serialNumber"

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->droppedIdentifier(Ljava/lang/String;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    .line 432
    move-object v1, v2

    goto :goto_0

    :cond_1
    invoke-static {p0}, Lcom/tzibbur/basic/auth/TzbHardwareIds;->serialNumber(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 433
    .local v1, "serial":Ljava/lang/String;
    :goto_0
    const-string v3, "imei"

    invoke-direct {p0, v3}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->droppedIdentifier(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_2

    .line 434
    goto :goto_1

    :cond_2
    invoke-static {p0}, Lcom/tzibbur/basic/auth/TzbHardwareIds;->imei(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    .line 435
    .local v2, "imei":Ljava/lang/String;
    :goto_1
    new-instance v3, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$7;

    invoke-direct {v3, p0, v0, v1, v2}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$7;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Lcom/tzibbur/basic/net/TzbApi;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;

    invoke-direct {v4, p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V

    invoke-static {v3, v4}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 461
    return-void

    .line 423
    .end local v0
    .end local v1
    .end local v2
    :cond_3
    :goto_2
    return-void
.end method

.method private setUiEnabled(Z)V
    .locals 2
    .param p1, "enabled"    # Z

    .line 521
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->codeInput:Landroid/widget/EditText;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 522
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verifyButton:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 524
    if-nez p1, :cond_0

    .line 525
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendButton:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    goto :goto_0

    .line 526
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendTimer:Landroid/os/CountDownTimer;

    if-nez v0, :cond_1

    .line 527
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendButton:Landroid/widget/Button;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 529
    :cond_1
    :goto_0
    return-void
.end method

.method private setUpOtpAutoRead()V
    .locals 3

    .line 231
    const-string v0, "android.permission.RECEIVE_SMS"

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_0

    .line 233
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->armReceiver()V

    goto :goto_0

    .line 234
    :cond_0
    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->smsPermRequested:Z

    const/16 v2, 0x8

    if-nez v1, :cond_1

    .line 235
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->smsPermRequested:Z

    .line 236
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->smsHintView:Landroid/widget/TextView;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 237
    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->requestPermissions([Ljava/lang/String;I)V

    goto :goto_0

    .line 239
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->smsHintView:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 241
    :goto_0
    return-void
.end method

.method private showError(Ljava/lang/String;)V
    .locals 2
    .param p1, "text"    # Ljava/lang/String;

    .line 537
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->statusView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$color;->tzb_error:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 538
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->statusView:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 539
    return-void
.end method

.method private showStatus(Ljava/lang/String;)V
    .locals 2
    .param p1, "text"    # Ljava/lang/String;

    .line 532
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->statusView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$color;->tzb_text_secondary:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 533
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->statusView:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 534
    return-void
.end method

.method private startRateLimitCountdown(I)V
    .locals 7
    .param p1, "seconds"    # I

    .line 399
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verifyButton:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 400
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->rateLimitTimer:Landroid/os/CountDownTimer;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->rateLimitTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 401
    :cond_0
    new-instance v1, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$6;

    int-to-long v2, p1

    const-wide/16 v4, 0x3e8

    mul-long v3, v2, v4

    const-wide/16 v5, 0x3e8

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;JJ)V

    iput-object v1, v2, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->rateLimitTimer:Landroid/os/CountDownTimer;

    .line 417
    iget-object v0, v2, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->rateLimitTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->start()Landroid/os/CountDownTimer;

    .line 418
    return-void
.end method

.method private startResendCountdown(I)V
    .locals 8
    .param p1, "seconds"    # I

    .line 491
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendTimer:Landroid/os/CountDownTimer;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 492
    :cond_0
    if-gtz p1, :cond_1

    .line 493
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendButton:Landroid/widget/Button;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 494
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendButton:Landroid/widget/Button;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_resend_btn:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 495
    return-void

    .line 497
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendButton:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 498
    new-instance v2, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;

    int-to-long v0, p1

    const-wide/16 v3, 0x3e8

    mul-long v4, v0, v3

    const-wide/16 v6, 0x3e8

    move-object v3, p0

    invoke-direct/range {v2 .. v7}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;JJ)V

    iput-object v2, v3, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendTimer:Landroid/os/CountDownTimer;

    .line 515
    iget-object v0, v3, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->start()Landroid/os/CountDownTimer;

    .line 516
    return-void
.end method

.method private verify()V
    .locals 5

    .line 286
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->busy:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->done:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameStepOpen:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 287
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->codeInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 288
    .local v0, "code":Ljava/lang/String;
    const-string v1, "\\d{6}"

    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 289
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_err_enter_code:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showError(Ljava/lang/String;)V

    .line 290
    return-void

    .line 292
    :cond_1
    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameRequired:Z

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->displayName:Ljava/lang/String;

    if-nez v1, :cond_2

    .line 295
    const/4 v1, 0x0

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->openNameStep(Ljava/lang/String;)V

    .line 296
    return-void

    .line 299
    :cond_2
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->busy:Z

    .line 300
    const/4 v1, 0x0

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->setUiEnabled(Z)V

    .line 301
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_status_verifying:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showStatus(Ljava/lang/String;)V

    .line 303
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v1

    .line 304
    .local v1, "api":Lcom/tzibbur/basic/net/TzbApi;
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->displayName:Ljava/lang/String;

    .line 305
    .local v2, "name":Ljava/lang/String;
    new-instance v3, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;

    invoke-direct {v3, p0, v1, v0, v2}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Lcom/tzibbur/basic/net/TzbApi;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;

    invoke-direct {v4, p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$5;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V

    invoke-static {v3, v4}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 326
    return-void

    .line 286
    .end local v0
    .end local v1
    .end local v2
    :cond_3
    :goto_0
    return-void
.end method


# virtual methods
.method protected dropIdentifierAndRetry(Lcom/tzibbur/basic/net/TzbProblem;)Z
    .locals 3
    .param p1, "problem"    # Lcom/tzibbur/basic/net/TzbProblem;

    .line 567
    if-eqz p1, :cond_2

    iget v0, p1, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x190

    if-ne v0, v1, :cond_2

    iget-object v0, p1, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    .line 568
    const-string v1, "invalid_device_identifier"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 571
    :cond_0
    iget-object v0, p1, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    const-string v1, "identifier"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 572
    .local v0, "identifier":Ljava/lang/String;
    if-nez v0, :cond_1

    .line 574
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->droppedIdentifiers:Ljava/util/Set;

    const-string v2, "serialNumber"

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 575
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->droppedIdentifiers:Ljava/util/Set;

    const-string v2, "imei"

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 576
    const/4 v1, 0x1

    return v1

    .line 578
    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->droppedIdentifiers:Ljava/util/Set;

    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v1

    return v1

    .line 569
    .end local v0
    :cond_2
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 2
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 197
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 198
    const/4 v0, 0x3

    if-eq p1, v0, :cond_0

    return-void

    .line 199
    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameStepOpen:Z

    .line 200
    const/4 v0, -0x1

    if-ne p2, v0, :cond_1

    if-eqz p3, :cond_1

    .line 201
    const-string v0, "tzb_name"

    invoke-virtual {p3, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    .line 202
    .local v0, "name":Ljava/lang/String;
    :goto_0
    if-eqz v0, :cond_2

    .line 203
    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->displayName:Ljava/lang/String;

    .line 205
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verify()V

    goto :goto_1

    .line 209
    :cond_2
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_name_needed:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->showStatus(Ljava/lang/String;)V

    .line 211
    :goto_1
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 99
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 101
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 102
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->finish()V

    .line 103
    return-void

    .line 107
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 108
    return-void

    .line 110
    :cond_1
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_enroll_code_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->setContentView(I)V

    .line 113
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 116
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_title_text:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_enroll_code_title:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 118
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_enroll_code_input:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->codeInput:Landroid/widget/EditText;

    .line 120
    const/4 v0, 0x1

    new-array v1, v0, [Landroid/widget/EditText;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->codeInput:Landroid/widget/EditText;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->attachAutoIme([Landroid/widget/EditText;)V

    .line 121
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_enroll_verify_btn:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verifyButton:Landroid/widget/Button;

    .line 122
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_enroll_resend_btn:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendButton:Landroid/widget/Button;

    .line 123
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_enroll_code_status:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->statusView:Landroid/widget/TextView;

    .line 124
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_enroll_sms_hint:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->smsHintView:Landroid/widget/TextView;

    .line 126
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    .line 127
    .local v1, "from":Landroid/content/Intent;
    const-string v2, "tzb_challenge_id"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->challengeId:Ljava/lang/String;

    .line 128
    const-string v4, "tzb_phone"

    invoke-virtual {v1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->phone:Ljava/lang/String;

    .line 129
    const-string v4, "tzb_expires_at"

    invoke-virtual {v1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->parseIso(Ljava/lang/String;)J

    move-result-wide v4

    iput-wide v4, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->expiresAtMillis:J

    .line 130
    const-string v4, "tzb_resend_after_seconds"

    const/16 v5, 0x3c

    invoke-virtual {v1, v4, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    .line 132
    .local v4, "resendAfter":I
    if-eqz p1, :cond_3

    .line 133
    const-string v5, "tzb_sms_perm_requested"

    invoke-virtual {p1, v5}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v5

    iput-boolean v5, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->smsPermRequested:Z

    .line 134
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 135
    .local v2, "savedChallenge":Ljava/lang/String;
    if-eqz v2, :cond_2

    .line 136
    iput-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->challengeId:Ljava/lang/String;

    .line 137
    const-string v5, "tzb_expires_at_millis"

    invoke-virtual {p1, v5}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v5

    iput-wide v5, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->expiresAtMillis:J

    .line 139
    :cond_2
    const-string v5, "tzb_failed_attempts"

    invoke-virtual {p1, v5}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v5

    iput v5, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->failedAttempts:I

    .line 140
    const-string v5, "tzb_display_name"

    invoke-virtual {p1, v5}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->displayName:Ljava/lang/String;

    .line 141
    const-string v5, "tzb_name_required"

    invoke-virtual {p1, v5}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v5

    iput-boolean v5, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameRequired:Z

    .line 144
    const-string v5, "tzb_name_step_open"

    invoke-virtual {p1, v5}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v5

    iput-boolean v5, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameStepOpen:Z

    .line 147
    .end local v2
    :cond_3
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_enroll_code_sent:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    .line 149
    .local v2, "sentTo":Landroid/widget/TextView;
    sget v5, Lcom/tzibbur/basic/R$string;->tzb_enroll_code_sent_to:I

    .line 150
    invoke-static {}, Landroid/text/BidiFormatter;->getInstance()Landroid/text/BidiFormatter;

    move-result-object v6

    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->phone:Ljava/lang/String;

    if-nez v7, :cond_4

    const-string v7, ""

    goto :goto_0

    :cond_4
    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->phone:Ljava/lang/String;

    :goto_0
    invoke-virtual {v6, v7}, Landroid/text/BidiFormatter;->unicodeWrap(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-array v0, v0, [Ljava/lang/Object;

    aput-object v6, v0, v3

    .line 149
    invoke-virtual {p0, v5, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 152
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verifyButton:Landroid/widget/Button;

    new-instance v3, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$1;

    invoke-direct {v3, p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 158
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendButton:Landroid/widget/Button;

    new-instance v3, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$2;

    invoke-direct {v3, p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 165
    invoke-direct {p0, v4}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->startResendCountdown(I)V

    .line 166
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->setUpOtpAutoRead()V

    .line 167
    return-void
.end method

.method protected onDestroy()V
    .locals 2

    .line 215
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->receiverRegistered:Z

    if-eqz v0, :cond_0

    .line 216
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->receiverRegistered:Z

    .line 218
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->otpReceiver:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 220
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 219
    :catch_0
    move-exception v0

    .line 222
    :cond_0
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->otpReceiver:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->otpReceiver:Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver;->setListener(Lcom/tzibbur/basic/auth/TzbOtpSmsReceiver$Listener;)V

    .line 223
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendTimer:Landroid/os/CountDownTimer;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resendTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 224
    :cond_2
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->rateLimitTimer:Landroid/os/CountDownTimer;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->rateLimitTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 225
    :cond_3
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 226
    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 2
    .param p1, "requestCode"    # I
    .param p2, "permissions"    # [Ljava/lang/String;
    .param p3, "grantResults"    # [I

    .line 246
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 247
    const/4 v0, 0x2

    if-ne p1, v0, :cond_1

    .line 248
    const-string v0, "android.permission.RECEIVE_SMS"

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    .line 250
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->armReceiver()V

    goto :goto_0

    .line 252
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->smsHintView:Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 255
    :cond_1
    :goto_0
    return-void
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "outState"    # Landroid/os/Bundle;

    .line 171
    invoke-super {p0, p1}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 172
    const-string v0, "tzb_sms_perm_requested"

    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->smsPermRequested:Z

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 173
    const-string v0, "tzb_challenge_id"

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->challengeId:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 174
    const-string v0, "tzb_expires_at_millis"

    iget-wide v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->expiresAtMillis:J

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 175
    const-string v0, "tzb_failed_attempts"

    iget v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->failedAttempts:I

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 176
    const-string v0, "tzb_display_name"

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->displayName:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 177
    const-string v0, "tzb_name_required"

    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameRequired:Z

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 178
    const-string v0, "tzb_name_step_open"

    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->nameStepOpen:Z

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 179
    return-void
.end method
