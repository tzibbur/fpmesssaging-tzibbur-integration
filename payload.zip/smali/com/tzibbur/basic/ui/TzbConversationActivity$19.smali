.class Lcom/tzibbur/basic/ui/TzbConversationActivity$19;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadEarlier()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Ljava/util/List<",
        "Lcom/tzibbur/basic/model/TzbMessage;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

.field final synthetic val$beforeSeq:J

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;J)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1015
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->val$gid:Ljava/lang/String;

    iput-wide p3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->val$beforeSeq:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 1015
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->call()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public call()Ljava/util/List;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 1018
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->val$gid:Ljava/lang/String;

    iget-wide v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->val$beforeSeq:J

    const/16 v4, 0x32

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tzibbur/basic/store/TzbStore;->messagesBefore(Ljava/lang/String;JI)Ljava/util/List;

    move-result-object v0

    .line 1019
    .local v0, "older":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-wide v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->val$beforeSeq:J

    const-wide/16 v5, 0x1

    cmp-long v1, v1, v5

    if-lez v1, :cond_1

    .line 1020
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->val$gid:Ljava/lang/String;

    iget-wide v5, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->val$beforeSeq:J

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v5, 0x0

    invoke-interface {v1, v2, v5, v3, v4}, Lcom/tzibbur/basic/net/TzbApi;->listMessages(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Integer;)Lcom/tzibbur/basic/model/TzbMessagePage;

    move-result-object v1

    .line 1021
    .local v1, "page":Lcom/tzibbur/basic/model/TzbMessagePage;
    iget-object v2, v1, Lcom/tzibbur/basic/model/TzbMessagePage;->items:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_0

    .line 1022
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$19;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iget-object v2, v2, Lcom/tzibbur/basic/ui/TzbConversationActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v2}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v2

    iget-object v3, v1, Lcom/tzibbur/basic/model/TzbMessagePage;->items:Ljava/util/List;

    invoke-interface {v2, v3}, Lcom/tzibbur/basic/store/TzbStore;->insertMessages(Ljava/util/List;)I

    .line 1024
    :cond_0
    iget-object v0, v1, Lcom/tzibbur/basic/model/TzbMessagePage;->items:Ljava/util/List;

    .line 1026
    .end local v1
    :cond_1
    return-object v0
.end method
