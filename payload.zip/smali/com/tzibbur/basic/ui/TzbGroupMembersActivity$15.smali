.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->showMemberActions(Lcom/tzibbur/basic/model/TzbMember;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

.field final synthetic val$isAdmin:Z

.field final synthetic val$member:Lcom/tzibbur/basic/model/TzbMember;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;Z)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 446
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;->val$member:Lcom/tzibbur/basic/model/TzbMember;

    iput-boolean p3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;->val$isAdmin:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 449
    if-nez p2, :cond_0

    .line 450
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;->val$member:Lcom/tzibbur/basic/model/TzbMember;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1700(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)V

    goto :goto_1

    .line 452
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;->val$member:Lcom/tzibbur/basic/model/TzbMember;

    iget-boolean v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;->val$isAdmin:Z

    if-eqz v2, :cond_1

    .line 453
    const-string v2, "member"

    goto :goto_0

    :cond_1
    const-string v2, "admin"

    .line 452
    :goto_0
    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1800(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V

    .line 455
    :goto_1
    return-void
.end method
