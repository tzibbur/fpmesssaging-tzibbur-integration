.class Lcom/tzibbur/basic/ui/TzbApplyActivity$7;
.super Ljava/lang/Object;
.source "TzbApplyActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshStatus(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbApplicationStatus;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

.field final synthetic val$manual:Z


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 331
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iput-boolean p2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->val$manual:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 3
    .param p1, "error"    # Ljava/lang/Exception;

    .line 358
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$402(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)Z

    .line 359
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->val$manual:Z

    if-eqz v0, :cond_0

    .line 360
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_apply_err_offline:I

    invoke-virtual {v1, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$500(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V

    .line 362
    :cond_0
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbApplicationStatus;)V
    .locals 3
    .param p1, "status"    # Lcom/tzibbur/basic/model/TzbApplicationStatus;

    .line 334
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$402(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)Z

    .line 335
    if-nez p1, :cond_1

    .line 338
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->val$manual:Z

    if-eqz v0, :cond_0

    .line 339
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_apply_err_offline:I

    invoke-virtual {v1, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$500(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V

    .line 340
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$600(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tzibbur/basic/store/TzbApplyStore;->secondsUntilAllowed()I

    move-result v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$700(Lcom/tzibbur/basic/ui/TzbApplyActivity;I)V

    .line 342
    :cond_0
    return-void

    .line 344
    :cond_1
    invoke-virtual {p1}, Lcom/tzibbur/basic/model/TzbApplicationStatus;->isApproved()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 345
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$800(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    .line 346
    return-void

    .line 348
    :cond_2
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v1, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$900(Lcom/tzibbur/basic/ui/TzbApplyActivity;Lcom/tzibbur/basic/model/TzbApplicationStatus;)I

    move-result v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbApplyActivity;I)V

    .line 349
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->val$manual:Z

    if-eqz v0, :cond_4

    .line 350
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-virtual {p1}, Lcom/tzibbur/basic/model/TzbApplicationStatus;->isPending()Z

    move-result v1

    if-eqz v1, :cond_3

    .line 351
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_apply_status_still_pending:I

    invoke-virtual {v1, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_3
    const-string v1, ""

    .line 350
    :goto_0
    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V

    .line 352
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/16 v1, 0xb4

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$700(Lcom/tzibbur/basic/ui/TzbApplyActivity;I)V

    .line 354
    :cond_4
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 331
    check-cast p1, Lcom/tzibbur/basic/model/TzbApplicationStatus;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;->onResult(Lcom/tzibbur/basic/model/TzbApplicationStatus;)V

    return-void
.end method
