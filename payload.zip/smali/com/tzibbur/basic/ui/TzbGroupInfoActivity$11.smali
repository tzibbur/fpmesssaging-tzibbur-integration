.class Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$11;
.super Ljava/lang/Object;
.source "TzbGroupInfoActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->confirmLeave()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 242
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 1
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 245
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->access$800(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    .line 246
    return-void
.end method
