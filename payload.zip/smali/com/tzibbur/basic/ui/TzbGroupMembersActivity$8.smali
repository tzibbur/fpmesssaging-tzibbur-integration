.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadMembers(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbPage<",
        "Lcom/tzibbur/basic/model/TzbMember;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

.field final synthetic val$reset:Z


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 215
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iput-boolean p2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->val$reset:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 3
    .param p1, "error"    # Ljava/lang/Exception;

    .line 230
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$802(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)Z

    .line 231
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    iget v0, v0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x194

    if-ne v0, v1, :cond_0

    .line 232
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_no_longer_member:I

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    .line 233
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 234
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->finish()V

    goto :goto_0

    .line 236
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 238
    :goto_0
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbPage;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/tzibbur/basic/model/TzbPage<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;)V"
        }
    .end annotation

    .line 218
    .local p1, "page":Lcom/tzibbur/basic/model/TzbPage;, "Lcom/tzibbur/basic/model/TzbPage<Lcom/tzibbur/basic/model/TzbMember;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$802(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)Z

    .line 219
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->val$reset:Z

    if-eqz v0, :cond_0

    .line 220
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$900(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

    move-result-object v0

    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbPage;->items:Ljava/util/List;

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->setMembers(Ljava/util/List;)V

    goto :goto_0

    .line 222
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$900(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

    move-result-object v0

    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbPage;->items:Ljava/util/List;

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->addMembers(Ljava/util/List;)V

    .line 224
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbPage;->nextCursor:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$102(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/lang/String;)Ljava/lang/String;

    .line 225
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    .line 226
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 215
    check-cast p1, Lcom/tzibbur/basic/model/TzbPage;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;->onResult(Lcom/tzibbur/basic/model/TzbPage;)V

    return-void
.end method
