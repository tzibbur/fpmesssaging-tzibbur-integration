.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$2;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

.field final synthetic val$error:Ljava/lang/Exception;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;Ljava/lang/Exception;)V
    .locals 0
    .param p1, "this$1"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 375
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$2;->val$error:Ljava/lang/Exception;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 378
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1602(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Z)Z

    .line 379
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$2;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$10$2;->val$error:Ljava/lang/Exception;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$1800(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;Ljava/lang/Exception;)V

    .line 380
    return-void
.end method
