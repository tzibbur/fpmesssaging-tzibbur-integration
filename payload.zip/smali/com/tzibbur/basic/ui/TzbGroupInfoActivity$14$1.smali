.class Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14$1;
.super Ljava/lang/Object;
.source "TzbGroupInfoActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;->onClick(Landroid/content/DialogInterface;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;)V
    .locals 0
    .param p1, "this$1"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 286
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14$1;->this$1:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 1
    .param p1, "d"    # Landroid/content/DialogInterface;
    .param p2, "w"    # I

    .line 289
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14$1;->this$1:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    .line 290
    return-void
.end method
