.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$21;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->confirmSignOutOffline()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 473
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$21;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 1
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 476
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$21;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    .line 477
    return-void
.end method
