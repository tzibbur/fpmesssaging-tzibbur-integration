.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$18;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->removeMember(Lcom/tzibbur/basic/model/TzbMember;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 483
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$18;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 1
    .param p1, "error"    # Ljava/lang/Exception;

    .line 492
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$18;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 493
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 483
    check-cast p1, Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$18;->onResult(Ljava/lang/Void;)V

    return-void
.end method

.method public onResult(Ljava/lang/Void;)V
    .locals 2
    .param p1, "result"    # Ljava/lang/Void;

    .line 486
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$18;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$200(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)V

    .line 487
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$18;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->refreshGroups()V

    .line 488
    return-void
.end method
