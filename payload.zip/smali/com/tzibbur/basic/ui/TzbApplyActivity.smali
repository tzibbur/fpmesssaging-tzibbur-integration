.class public Lcom/tzibbur/basic/ui/TzbApplyActivity;
.super Landroid/app/Activity;
.source "TzbApplyActivity.java"


# static fields
.field private static final APPROVED_PAUSE_MS:J = 0x384L

.field private static final AUTO_REFRESH_STEPS_MS:[J

.field private static final DEFAULT_RETRY_SECONDS:I = 0x3c

.field private static final MANUAL_REFRESH_FLOOR_SECONDS:I = 0xb4

.field private static final STATE_APPROVED:I = 0x4

.field private static final STATE_BANNED:I = 0x3

.field private static final STATE_CHECKING:I = 0x0

.field private static final STATE_FORM:I = 0x1

.field private static final STATE_PENDING:I = 0x2


# instance fields
.field private final autoRefresh:Ljava/lang/Runnable;

.field private autoRefreshStep:I

.field private bodyView:Landroid/widget/TextView;

.field private busy:Z

.field private formView:Landroid/view/View;

.field private final handler:Landroid/os/Handler;

.field private headView:Landroid/widget/TextView;

.field private held:Z

.field private nameInput:Landroid/widget/EditText;

.field private notesInput:Landroid/widget/EditText;

.field private orgInput:Landroid/widget/EditText;

.field private phone:Ljava/lang/String;

.field private phoneHintView:Landroid/widget/TextView;

.field private phoneInput:Landroid/widget/EditText;

.field private reasonInput:Landroid/widget/EditText;

.field private refreshButton:Landroid/widget/Button;

.field private refreshTimer:Landroid/os/CountDownTimer;

.field private scrollView:Landroid/widget/ScrollView;

.field private state:I

.field private statusView:Landroid/widget/TextView;

.field private store:Lcom/tzibbur/basic/store/TzbApplyStore;

.field private submitButton:Landroid/widget/Button;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 67
    const/4 v0, 0x5

    new-array v0, v0, [J

    fill-array-data v0, :array_0

    sput-object v0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->AUTO_REFRESH_STEPS_MS:[J

    return-void

    nop

    :array_0
    .array-data 8
        0x2710
        0x4e20
        0x9c40
        0xea60
        0x1d4c0
    .end array-data
.end method

.method public constructor <init>()V
    .locals 1

    .line 50
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 94
    const/4 v0, -0x1

    iput v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->state:I

    .line 99
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->handler:Landroid/os/Handler;

    .line 102
    new-instance v0, Lcom/tzibbur/basic/ui/TzbApplyActivity$1;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefresh:Ljava/lang/Runnable;

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # Z

    .line 50
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshStatus(Z)V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbApplyActivity;)J
    .locals 2
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nextAutoRefreshDelay()J

    move-result-wide v0

    return-wide v0
.end method

.method static synthetic access$1000(Lcom/tzibbur/basic/ui/TzbApplyActivity;I)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # I

    .line 50
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->applyState(I)V

    return-void
.end method

.method static synthetic access$1100(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 50
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showStatus(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1200(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->held:Z

    return v0
.end method

.method static synthetic access$1300(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$1302(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 50
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic access$1400(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->switchToApprovedNumber()V

    return-void
.end method

.method static synthetic access$1500(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->resumeApp()V

    return-void
.end method

.method static synthetic access$1600(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # Z

    .line 50
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->setFormEnabled(Z)V

    return-void
.end method

.method static synthetic access$1700(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->restartAutoRefresh()V

    return-void
.end method

.method static synthetic access$1800(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/Exception;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # Ljava/lang/Exception;

    .line 50
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->handleSubmitError(Ljava/lang/Exception;)V

    return-void
.end method

.method static synthetic access$1900(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshButton:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/os/Handler;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->handler:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$2002(Lcom/tzibbur/basic/ui/TzbApplyActivity;Landroid/os/CountDownTimer;)Landroid/os/CountDownTimer;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # Landroid/os/CountDownTimer;

    .line 50
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshTimer:Landroid/os/CountDownTimer;

    return-object p1
.end method

.method static synthetic access$2100(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/widget/ScrollView;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->scrollView:Landroid/widget/ScrollView;

    return-object v0
.end method

.method static synthetic access$2200(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/widget/EditText;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nameInput:Landroid/widget/EditText;

    return-object v0
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->submit()V

    return-void
.end method

.method static synthetic access$402(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # Z

    .line 50
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->busy:Z

    return p1
.end method

.method static synthetic access$500(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 50
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Lcom/tzibbur/basic/store/TzbApplyStore;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->store:Lcom/tzibbur/basic/store/TzbApplyStore;

    return-object v0
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/ui/TzbApplyActivity;I)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # I

    .line 50
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->startRefreshCooldown(I)V

    return-void
.end method

.method static synthetic access$800(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;

    .line 50
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->onApproved()V

    return-void
.end method

.method static synthetic access$900(Lcom/tzibbur/basic/ui/TzbApplyActivity;Lcom/tzibbur/basic/model/TzbApplicationStatus;)I
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbApplicationStatus;

    .line 50
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->stateFor(Lcom/tzibbur/basic/model/TzbApplicationStatus;)I

    move-result v0

    return v0
.end method

.method private applyState(I)V
    .locals 6
    .param p1, "next"    # I

    .line 587
    iget v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->state:I

    if-ne p1, v0, :cond_0

    .line 588
    return-void

    .line 590
    :cond_0
    iput p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->state:I

    .line 591
    const/4 v0, 0x1

    const/4 v1, 0x0

    if-ne p1, v0, :cond_1

    move v2, v0

    goto :goto_0

    :cond_1
    move v2, v1

    .line 592
    .local v2, "showForm":Z
    :goto_0
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->formView:Landroid/view/View;

    const/16 v4, 0x8

    if-eqz v2, :cond_2

    move v5, v1

    goto :goto_1

    :cond_2
    move v5, v4

    :goto_1
    invoke-virtual {v3, v5}, Landroid/view/View;->setVisibility(I)V

    .line 593
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshButton:Landroid/widget/Button;

    .line 594
    const/4 v5, 0x2

    if-eq p1, v5, :cond_3

    const/4 v5, 0x3

    if-ne p1, v5, :cond_4

    :cond_3
    move v4, v1

    .line 593
    :cond_4
    invoke-virtual {v3, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 596
    const-string v3, ""

    packed-switch p1, :pswitch_data_0

    .line 619
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->headView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_apply_checking_head:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 620
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->bodyView:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2

    .line 614
    :pswitch_0    # 0x4
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->headView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_apply_approved_head:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 615
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->bodyView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_apply_approved_body:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 616
    invoke-direct {p0, v3}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showStatus(Ljava/lang/String;)V

    .line 617
    goto :goto_2

    .line 610
    :pswitch_1    # 0x3
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->headView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_apply_banned_head:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 611
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->bodyView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_apply_banned_body:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 612
    goto :goto_2

    .line 604
    :pswitch_2    # 0x2
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->headView:Landroid/widget/TextView;

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_apply_pending_head:I

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(I)V

    .line 605
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->bodyView:Landroid/widget/TextView;

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_apply_pending_body:I

    .line 606
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->displayPhone()Ljava/lang/String;

    move-result-object v5

    new-array v0, v0, [Ljava/lang/Object;

    aput-object v5, v0, v1

    .line 605
    invoke-virtual {p0, v4, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 607
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshButton:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->requestFocus()Z

    .line 608
    goto :goto_2

    .line 598
    :pswitch_3    # 0x1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->headView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_apply_form_head:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 599
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->bodyView:Landroid/widget/TextView;

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->denyAware()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 601
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 602
    nop

    .line 623
    :goto_2
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3    # 0x1
        :pswitch_2    # 0x2
        :pswitch_1    # 0x3
        :pswitch_0    # 0x4
    .end packed-switch
.end method

.method private cachedState(Ljava/lang/String;)I
    .locals 1
    .param p1, "status"    # Ljava/lang/String;

    .line 570
    const-string v0, "banned"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x3

    return v0

    .line 571
    :cond_0
    const-string v0, "pending"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x2

    return v0

    .line 572
    :cond_1
    if-eqz p1, :cond_3

    const-string v0, "approved"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    goto :goto_0

    .line 575
    :cond_2
    const/4 v0, 0x1

    return v0

    .line 573
    :cond_3
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method private denyAware()Ljava/lang/String;
    .locals 2

    .line 634
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->store:Lcom/tzibbur/basic/store/TzbApplyStore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/store/TzbApplyStore;->lastStatus()Ljava/lang/String;

    move-result-object v0

    const-string v1, "denied"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 635
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_apply_denied_body:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 636
    :cond_0
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_apply_form_body:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 634
    :goto_0
    return-object v0
.end method

.method private displayPhone()Ljava/lang/String;
    .locals 2

    .line 627
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    if-nez v0, :cond_0

    const-string v0, ""

    return-object v0

    .line 628
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 629
    .local v0, "typed":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_1

    move-object v1, v0

    goto :goto_0

    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    :goto_0
    return-object v1
.end method

.method private focusField(Ljava/lang/String;)V
    .locals 1
    .param p1, "field"    # Ljava/lang/String;

    .line 534
    if-nez p1, :cond_0

    return-void

    .line 535
    :cond_0
    const-string v0, "displayName"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nameInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    goto :goto_0

    .line 536
    :cond_1
    const-string v0, "reason"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->reasonInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    goto :goto_0

    .line 537
    :cond_2
    const-string v0, "organization"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->orgInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    goto :goto_0

    .line 538
    :cond_3
    const-string v0, "notes"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->notesInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    goto :goto_0

    .line 539
    :cond_4
    const-string v0, "phone"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 540
    :cond_5
    :goto_0
    return-void
.end method

.method private handleSubmitError(Ljava/lang/Exception;)V
    .locals 7
    .param p1, "error"    # Ljava/lang/Exception;

    .line 477
    sget-boolean v0, Lcom/tzibbur/basic/BuildConfig;->DEBUG:Z

    if-eqz v0, :cond_0

    .line 480
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "submit failed: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 481
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 480
    const-string v1, "TzbApply"

    invoke-static {v1, v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 483
    :cond_0
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-nez v0, :cond_1

    .line 484
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_apply_err_offline:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    .line 485
    return-void

    .line 487
    :cond_1
    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    .line 488
    .local v0, "p":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isRateLimited()Z

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_3

    .line 489
    iget v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    if-lez v1, :cond_2

    iget v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    goto :goto_0

    :cond_2
    const/16 v1, 0x3c

    .line 490
    .local v1, "wait":I
    :goto_0
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->store:Lcom/tzibbur/basic/store/TzbApplyStore;

    invoke-virtual {v4, v1}, Lcom/tzibbur/basic/store/TzbApplyStore;->holdStatusCalls(I)V

    .line 491
    sget v4, Lcom/tzibbur/basic/R$string;->tzb_apply_err_rate_limited:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v5, v2, v3

    invoke-virtual {p0, v4, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    .line 492
    return-void

    .line 494
    .end local v1
    :cond_3
    const-string v1, "invalid_application_field"

    iget-object v4, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v4, ""

    const-string v5, "reason"

    if-eqz v1, :cond_6

    .line 497
    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    invoke-virtual {v1, v5, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 498
    .local v1, "reason":Ljava/lang/String;
    iget-object v4, v0, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    const-string v5, "maxLength"

    invoke-virtual {v4, v5, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v4

    .line 499
    .local v4, "maxLength":I
    const-string v5, "invalid_characters"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4

    .line 500
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_apply_err_bad_characters:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    goto :goto_1

    .line 501
    :cond_4
    if-lez v4, :cond_5

    .line 502
    sget v5, Lcom/tzibbur/basic/R$string;->tzb_apply_err_too_long:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v6, v2, v3

    invoke-virtual {p0, v5, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    goto :goto_1

    .line 504
    :cond_5
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_error_generic:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    .line 506
    :goto_1
    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    const-string v3, "field"

    const/4 v5, 0x0

    invoke-virtual {v2, v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->focusField(Ljava/lang/String;)V

    .line 507
    return-void

    .line 509
    .end local v1
    .end local v4
    :cond_6
    const-string v1, "application_not_allowed"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    .line 513
    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    invoke-virtual {v1, v5, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 514
    .restart local v1
    const-string v2, "banned"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    .line 515
    const/4 v2, 0x3

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->applyState(I)V

    goto :goto_2

    .line 516
    :cond_7
    const-string v2, "pending"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8

    .line 517
    const/4 v2, 0x2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->applyState(I)V

    goto :goto_2

    .line 519
    :cond_8
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_apply_err_cannot_apply:I

    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    .line 520
    invoke-direct {p0, v3}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshStatus(Z)V

    .line 522
    :goto_2
    return-void

    .line 524
    .end local v1
    :cond_9
    const-string v1, "validation_failed"

    iget-object v2, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a

    .line 525
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_apply_err_check_number:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    .line 526
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->requestFocus()Z

    .line 527
    return-void

    .line 529
    :cond_a
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_error_generic:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    .line 530
    return-void
.end method

.method public static intent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 2
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "phoneE164"    # Ljava/lang/String;

    .line 127
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 128
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "tzb_apply_phone"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 129
    return-object v0
.end method

.method private static linkKeys(Landroid/view/View;Landroid/view/View;Landroid/view/View;)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;
    .param p1, "up"    # Landroid/view/View;
    .param p2, "down"    # Landroid/view/View;

    .line 687
    new-instance v0, Lcom/tzibbur/basic/ui/TzbApplyActivity$12;

    invoke-direct {v0, p2, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity$12;-><init>(Landroid/view/View;Landroid/view/View;)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 704
    return-void
.end method

.method private nextAutoRefreshDelay()J
    .locals 4

    .line 111
    iget v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefreshStep:I

    .line 112
    .local v0, "i":I
    sget-object v1, Lcom/tzibbur/basic/ui/TzbApplyActivity;->AUTO_REFRESH_STEPS_MS:[J

    array-length v1, v1

    add-int/lit8 v1, v1, -0x1

    if-ge v0, v1, :cond_0

    .line 113
    iget v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefreshStep:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefreshStep:I

    .line 115
    :cond_0
    sget-object v1, Lcom/tzibbur/basic/ui/TzbApplyActivity;->AUTO_REFRESH_STEPS_MS:[J

    aget-wide v2, v1, v0

    return-wide v2
.end method

.method private onApproved()V
    .locals 4

    .line 368
    const/4 v0, 0x4

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->applyState(I)V

    .line 369
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefresh:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 370
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->handler:Landroid/os/Handler;

    new-instance v1, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    const-wide/16 v2, 0x384

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 394
    return-void
.end method

.method private refreshStatus(Z)V
    .locals 3
    .param p1, "manual"    # Z

    .line 308
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->busy:Z

    if-nez v0, :cond_4

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 311
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->store:Lcom/tzibbur/basic/store/TzbApplyStore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/store/TzbApplyStore;->statusCallAllowed()Z

    move-result v0

    if-nez v0, :cond_2

    .line 314
    if-eqz p1, :cond_1

    .line 315
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->store:Lcom/tzibbur/basic/store/TzbApplyStore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/store/TzbApplyStore;->secondsUntilAllowed()I

    move-result v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->startRefreshCooldown(I)V

    .line 317
    :cond_1
    return-void

    .line 319
    :cond_2
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->busy:Z

    .line 320
    if-eqz p1, :cond_3

    .line 321
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_apply_status_checking:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showStatus(Ljava/lang/String;)V

    .line 323
    :cond_3
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    .line 324
    .local v0, "asked":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbApplyActivity$6;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;

    invoke-direct {v2, p0, p1}, Lcom/tzibbur/basic/ui/TzbApplyActivity$7;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 364
    return-void

    .line 309
    .end local v0
    :cond_4
    :goto_0
    return-void
.end method

.method private restartAutoRefresh()V
    .locals 4

    .line 120
    const/4 v0, 0x0

    iput v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefreshStep:I

    .line 121
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefresh:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 122
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefresh:Ljava/lang/Runnable;

    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nextAutoRefreshDelay()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 123
    return-void
.end method

.method private resumeApp()V
    .locals 2

    .line 416
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 417
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "com.tzibbur.basic.ui.TzbLaunchActivity"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 418
    const v1, 0x10008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 419
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->startActivity(Landroid/content/Intent;)V

    .line 420
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->finish()V

    .line 421
    return-void
.end method

.method private scrollTopOnUp(Landroid/view/View;)V
    .locals 1
    .param p1, "view"    # Landroid/view/View;

    .line 712
    new-instance v0, Lcom/tzibbur/basic/ui/TzbApplyActivity$13;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$13;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 729
    return-void
.end method

.method private setFormEnabled(Z)V
    .locals 1
    .param p1, "enabled"    # Z

    .line 640
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 641
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nameInput:Landroid/widget/EditText;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 642
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->reasonInput:Landroid/widget/EditText;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 643
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->orgInput:Landroid/widget/EditText;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 644
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->notesInput:Landroid/widget/EditText;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 645
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->submitButton:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 646
    return-void
.end method

.method private showError(Ljava/lang/String;)V
    .locals 2
    .param p1, "text"    # Ljava/lang/String;

    .line 742
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->statusView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$color;->tzb_error:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 743
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->statusView:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 744
    return-void
.end method

.method private showStatus(Ljava/lang/String;)V
    .locals 2
    .param p1, "text"    # Ljava/lang/String;

    .line 737
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->statusView:Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$color;->tzb_text_secondary:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 738
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->statusView:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 739
    return-void
.end method

.method private startRefreshCooldown(I)V
    .locals 7
    .param p1, "seconds"    # I

    .line 654
    if-gtz p1, :cond_0

    .line 655
    return-void

    .line 662
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshButton:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 663
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshTimer:Landroid/os/CountDownTimer;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 664
    :cond_1
    new-instance v1, Lcom/tzibbur/basic/ui/TzbApplyActivity$11;

    int-to-long v2, p1

    const-wide/16 v4, 0x3e8

    mul-long v3, v2, v4

    const-wide/16 v5, 0x3e8

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/tzibbur/basic/ui/TzbApplyActivity$11;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;JJ)V

    iput-object v1, v2, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshTimer:Landroid/os/CountDownTimer;

    .line 679
    iget-object v0, v2, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->start()Landroid/os/CountDownTimer;

    .line 680
    return-void
.end method

.method private stateFor(Lcom/tzibbur/basic/model/TzbApplicationStatus;)I
    .locals 1
    .param p1, "status"    # Lcom/tzibbur/basic/model/TzbApplicationStatus;

    .line 552
    invoke-virtual {p1}, Lcom/tzibbur/basic/model/TzbApplicationStatus;->isApproved()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x4

    return v0

    .line 553
    :cond_0
    invoke-virtual {p1}, Lcom/tzibbur/basic/model/TzbApplicationStatus;->isBanned()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x3

    return v0

    .line 554
    :cond_1
    iget-boolean v0, p1, Lcom/tzibbur/basic/model/TzbApplicationStatus;->canApply:Z

    if-eqz v0, :cond_2

    const/4 v0, 0x1

    return v0

    .line 558
    :cond_2
    const/4 v0, 0x2

    return v0
.end method

.method private submit()V
    .locals 8

    .line 426
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->busy:Z

    if-eqz v0, :cond_0

    .line 427
    return-void

    .line 431
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    .line 432
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->stripPhoneFormatting(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 433
    .local v3, "number":Ljava/lang/String;
    if-eqz v3, :cond_2

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_1

    move-object v2, p0

    goto :goto_0

    .line 437
    :cond_1
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->busy:Z

    .line 438
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->setFormEnabled(Z)V

    .line 439
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_apply_status_sending:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showStatus(Ljava/lang/String;)V

    .line 441
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nameInput:Landroid/widget/EditText;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->text(Landroid/widget/EditText;)Ljava/lang/String;

    move-result-object v4

    .line 442
    .local v4, "displayName":Ljava/lang/String;
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->reasonInput:Landroid/widget/EditText;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->text(Landroid/widget/EditText;)Ljava/lang/String;

    move-result-object v5

    .line 443
    .local v5, "reason":Ljava/lang/String;
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->orgInput:Landroid/widget/EditText;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->text(Landroid/widget/EditText;)Ljava/lang/String;

    move-result-object v6

    .line 444
    .local v6, "organization":Ljava/lang/String;
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->notesInput:Landroid/widget/EditText;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->text(Landroid/widget/EditText;)Ljava/lang/String;

    move-result-object v7

    .line 445
    .local v7, "notes":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;

    move-object v2, p0

    invoke-direct/range {v1 .. v7}, Lcom/tzibbur/basic/ui/TzbApplyActivity$9;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;

    invoke-direct {v0, p0, v3}, Lcom/tzibbur/basic/ui/TzbApplyActivity$10;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;Ljava/lang/String;)V

    invoke-static {v1, v0}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 474
    return-void

    .line 433
    .end local v4
    .end local v5
    .end local v6
    .end local v7
    :cond_2
    move-object v2, p0

    .line 434
    :goto_0
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_apply_err_check_number:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->showError(Ljava/lang/String;)V

    .line 435
    return-void
.end method

.method private switchToApprovedNumber()V
    .locals 3

    .line 404
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    .line 405
    .local v0, "approved":Ljava/lang/String;
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->signOutLocally()V

    .line 406
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    .line 407
    .local v1, "intent":Landroid/content/Intent;
    const-string v2, "com.tzibbur.basic.ui.TzbEnrollPhoneActivity"

    invoke-virtual {v1, p0, v2}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 408
    const v2, 0x10008000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 409
    const-string v2, "tzb_apply_phone"

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 410
    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->startActivity(Landroid/content/Intent;)V

    .line 411
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->finish()V

    .line 412
    return-void
.end method

.method private static text(Landroid/widget/EditText;)Ljava/lang/String;
    .locals 2
    .param p0, "field"    # Landroid/widget/EditText;

    .line 732
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 733
    .local v0, "s":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_0

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    move-object v1, v0

    :goto_0
    return-object v1
.end method


# virtual methods
.method public onBackPressed()V
    .locals 1

    .line 291
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->held:Z

    if-eqz v0, :cond_0

    .line 292
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->finishAffinity()V

    goto :goto_0

    .line 294
    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    .line 296
    :goto_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 134
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 137
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 138
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->finish()V

    .line 139
    return-void

    .line 141
    :cond_0
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_apply_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->setContentView(I)V

    .line 144
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 145
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_title_text:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_apply_title:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 147
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->applyStore()Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->store:Lcom/tzibbur/basic/store/TzbApplyStore;

    .line 148
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v0

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->held:Z

    .line 150
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    .line 151
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v2, "tzb_apply_phone"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    move-object v0, v1

    :goto_0
    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    .line 152
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    if-nez v0, :cond_3

    .line 155
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->held:Z

    if-eqz v0, :cond_2

    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_2
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->store:Lcom/tzibbur/basic/store/TzbApplyStore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/store/TzbApplyStore;->pendingPhone()Ljava/lang/String;

    move-result-object v0

    :goto_1
    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    .line 158
    :cond_3
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_head:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->headView:Landroid/widget/TextView;

    .line 159
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_body:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->bodyView:Landroid/widget/TextView;

    .line 160
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_form:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->formView:Landroid/view/View;

    .line 161
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_phone_input:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    .line 162
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_name_input:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nameInput:Landroid/widget/EditText;

    .line 163
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_reason_input:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->reasonInput:Landroid/widget/EditText;

    .line 164
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_org_input:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->orgInput:Landroid/widget/EditText;

    .line 165
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_notes_input:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->notesInput:Landroid/widget/EditText;

    .line 166
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_submit_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->submitButton:Landroid/widget/Button;

    .line 167
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_refresh_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshButton:Landroid/widget/Button;

    .line 168
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_status:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->statusView:Landroid/widget/TextView;

    .line 169
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_phone_hint_text:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneHintView:Landroid/widget/TextView;

    .line 170
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_apply_scroll:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ScrollView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->scrollView:Landroid/widget/ScrollView;

    .line 173
    const/4 v0, 0x5

    new-array v0, v0, [Landroid/widget/EditText;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    const/4 v3, 0x0

    aput-object v2, v0, v3

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nameInput:Landroid/widget/EditText;

    const/4 v4, 0x1

    aput-object v2, v0, v4

    const/4 v2, 0x2

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->reasonInput:Landroid/widget/EditText;

    aput-object v5, v0, v2

    const/4 v2, 0x3

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->orgInput:Landroid/widget/EditText;

    aput-object v5, v0, v2

    const/4 v2, 0x4

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->notesInput:Landroid/widget/EditText;

    aput-object v5, v0, v2

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->attachAutoIme([Landroid/widget/EditText;)V

    .line 177
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    new-instance v2, Landroid/telephony/PhoneNumberFormattingTextWatcher;

    invoke-direct {v2}, Landroid/telephony/PhoneNumberFormattingTextWatcher;-><init>()V

    invoke-virtual {v0, v2}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 179
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    if-eqz v0, :cond_4

    .line 180
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    invoke-virtual {v0, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 186
    :cond_4
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->held:Z

    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phone:Ljava/lang/String;

    if-eqz v0, :cond_5

    .line 189
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneHintView:Landroid/widget/TextView;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_apply_signed_in_hint:I

    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    .line 190
    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    new-array v4, v4, [Ljava/lang/Object;

    aput-object v5, v4, v3

    .line 189
    invoke-virtual {p0, v2, v4}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 191
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneHintView:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 194
    :cond_5
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->displayName()Ljava/lang/String;

    move-result-object v0

    .line 195
    .local v0, "known":Ljava/lang/String;
    if-eqz v0, :cond_6

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_6

    .line 196
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nameInput:Landroid/widget/EditText;

    invoke-virtual {v2, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 211
    :cond_6
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->scrollTopOnUp(Landroid/view/View;)V

    .line 212
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nameInput:Landroid/widget/EditText;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->phoneInput:Landroid/widget/EditText;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->reasonInput:Landroid/widget/EditText;

    invoke-static {v2, v3, v4}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->linkKeys(Landroid/view/View;Landroid/view/View;Landroid/view/View;)V

    .line 213
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->reasonInput:Landroid/widget/EditText;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->nameInput:Landroid/widget/EditText;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->orgInput:Landroid/widget/EditText;

    invoke-static {v2, v3, v4}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->linkKeys(Landroid/view/View;Landroid/view/View;Landroid/view/View;)V

    .line 214
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->orgInput:Landroid/widget/EditText;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->reasonInput:Landroid/widget/EditText;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->notesInput:Landroid/widget/EditText;

    invoke-static {v2, v3, v4}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->linkKeys(Landroid/view/View;Landroid/view/View;Landroid/view/View;)V

    .line 215
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->notesInput:Landroid/widget/EditText;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->orgInput:Landroid/widget/EditText;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->submitButton:Landroid/widget/Button;

    invoke-static {v2, v3, v4}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->linkKeys(Landroid/view/View;Landroid/view/View;Landroid/view/View;)V

    .line 218
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->submitButton:Landroid/widget/Button;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->notesInput:Landroid/widget/EditText;

    invoke-static {v2, v3, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->linkKeys(Landroid/view/View;Landroid/view/View;Landroid/view/View;)V

    .line 220
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->submitButton:Landroid/widget/Button;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbApplyActivity$2;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 226
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshButton:Landroid/widget/Button;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbApplyActivity$3;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 232
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_apply_terms_link:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcom/tzibbur/basic/ui/TzbApplyActivity$4;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 239
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_apply_privacy_link:I

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcom/tzibbur/basic/ui/TzbApplyActivity$5;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity$5;-><init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 249
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->store:Lcom/tzibbur/basic/store/TzbApplyStore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/store/TzbApplyStore;->lastStatus()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->cachedState(Ljava/lang/String;)I

    move-result v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->applyState(I)V

    .line 250
    return-void
.end method

.method protected onDestroy()V
    .locals 2

    .line 275
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefresh:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 276
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshTimer:Landroid/os/CountDownTimer;

    if-eqz v0, :cond_0

    .line 277
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshTimer:Landroid/os/CountDownTimer;

    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 278
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshTimer:Landroid/os/CountDownTimer;

    .line 280
    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 281
    return-void
.end method

.method protected onPause()V
    .locals 2

    .line 269
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->autoRefresh:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 270
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    .line 271
    return-void
.end method

.method protected onResume()V
    .locals 1

    .line 254
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 258
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enabled(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity;->held:Z

    if-eqz v0, :cond_0

    .line 259
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->resumeApp()V

    .line 260
    return-void

    .line 262
    :cond_0
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->refreshStatus(Z)V

    .line 263
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->restartAutoRefresh()V

    .line 264
    return-void
.end method
