.class Lcom/tzibbur/basic/ui/TzbConversationActivity$4;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 227
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 230
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$500(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    .line 231
    :cond_0
    return-void
.end method
