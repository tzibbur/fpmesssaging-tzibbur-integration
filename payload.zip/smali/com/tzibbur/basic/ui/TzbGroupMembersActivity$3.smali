.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$3;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 118
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 3
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 121
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    invoke-virtual {p1, p3}, Landroid/widget/AdapterView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v0

    .line 122
    .local v0, "item":Ljava/lang/Object;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    instance-of v2, v0, Lcom/tzibbur/basic/model/TzbMember;

    if-eqz v2, :cond_0

    move-object v2, v0

    check-cast v2, Lcom/tzibbur/basic/model/TzbMember;

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    invoke-static {v1, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$302(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)Lcom/tzibbur/basic/model/TzbMember;

    .line 123
    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    .line 127
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$302(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)Lcom/tzibbur/basic/model/TzbMember;

    .line 128
    return-void
.end method
