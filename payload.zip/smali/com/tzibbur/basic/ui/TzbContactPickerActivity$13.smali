.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$13;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->wireKeyChain()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 537
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 4
    .param p1, "v"    # Landroid/view/View;
    .param p2, "keyCode"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .line 540
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    .line 541
    :cond_0
    const/16 v0, 0x13

    const/4 v2, 0x1

    if-ne p2, v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 542
    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$2100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v0

    if-gtz v0, :cond_1

    .line 543
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$2200(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    .line 544
    return v2

    .line 546
    :cond_1
    const/16 v0, 0x14

    if-ne p2, v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    .line 547
    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$2100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v0

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v3}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$2100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Landroid/widget/ListView;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/ListView;->getCount()I

    move-result v3

    sub-int/2addr v3, v2

    if-lt v0, v3, :cond_2

    .line 548
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$13;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$2300(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    .line 549
    return v2

    .line 551
    :cond_2
    return v1
.end method
