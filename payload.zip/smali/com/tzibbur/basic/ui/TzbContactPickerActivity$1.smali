.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$1;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 120
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 1
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 123
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$000(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;

    move-result-object v0

    invoke-virtual {v0, p3}, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;->toggle(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$100(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    .line 124
    :cond_0
    return-void
.end method
