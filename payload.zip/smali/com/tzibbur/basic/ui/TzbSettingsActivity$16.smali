.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$16;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->revokeDevice(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

.field final synthetic val$deviceId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 378
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$16;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$16;->val$deviceId:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 378
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$16;->call()Ljava/lang/Void;

    move-result-object v0

    return-object v0
.end method

.method public call()Ljava/lang/Void;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 381
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$16;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$16;->val$deviceId:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/net/TzbApi;->revokeDevice(Ljava/lang/String;)V

    .line 382
    const/4 v0, 0x0

    return-object v0
.end method
