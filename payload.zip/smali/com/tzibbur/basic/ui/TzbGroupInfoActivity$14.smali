.class Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;
.super Ljava/lang/Object;
.source "TzbGroupInfoActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->confirmDelete()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 279
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 282
    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_action_delete:I

    .line 283
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_delete_confirm_2:I

    .line 284
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_delete:I

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14$1;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14$1;-><init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$14;)V

    .line 285
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 292
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 293
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 294
    return-void
.end method
