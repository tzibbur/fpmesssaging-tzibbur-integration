.class Lcom/tzibbur/basic/ui/TzbGroupListActivity$3;
.super Ljava/lang/Object;
.source "TzbGroupListActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupListActivity;->requery()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Ljava/util/List<",
        "Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupListActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupListActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 126
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 126
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupListActivity$3;->call()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public call()Ljava/util/List;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;",
            ">;"
        }
    .end annotation

    .line 129
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupListActivity$3;->this$0:Lcom/tzibbur/basic/ui/TzbGroupListActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupListActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    .line 130
    .local v0, "store":Lcom/tzibbur/basic/store/TzbStore;
    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbStore;->groups()Ljava/util/List;

    move-result-object v1

    .line 131
    .local v1, "groups":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbGroup;>;"
    new-instance v2, Ljava/util/ArrayList;

    .line 132
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 133
    .local v2, "rows":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;>;"
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/tzibbur/basic/model/TzbGroup;

    .line 134
    .local v4, "group":Lcom/tzibbur/basic/model/TzbGroup;
    iget-object v5, v4, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-interface {v0, v5}, Lcom/tzibbur/basic/store/TzbStore;->lastMessage(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMessage;

    move-result-object v5

    .line 135
    .local v5, "last":Lcom/tzibbur/basic/model/TzbMessage;
    if-eqz v5, :cond_0

    iget-object v6, v5, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    goto :goto_1

    :cond_0
    const/4 v6, 0x0

    .line 136
    .local v6, "snippet":Ljava/lang/String;
    :goto_1
    new-instance v7, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;

    iget-object v8, v4, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    .line 137
    invoke-interface {v0, v8}, Lcom/tzibbur/basic/store/TzbStore;->unreadCount(Ljava/lang/String;)I

    move-result v8

    invoke-direct {v7, v4, v6, v8}, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;-><init>(Lcom/tzibbur/basic/model/TzbGroup;Ljava/lang/String;I)V

    .line 136
    invoke-interface {v2, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 138
    .end local v4
    .end local v5
    .end local v6
    goto :goto_0

    .line 139
    :cond_1
    return-object v2
.end method
