.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->revokeDevice(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 384
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 3
    .param p1, "error"    # Ljava/lang/Exception;

    .line 394
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    iget v0, v0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x194

    if-ne v0, v1, :cond_0

    .line 396
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_err_not_found:I

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    .line 397
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 398
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$200(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    .line 399
    return-void

    .line 401
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 402
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 384
    check-cast p1, Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;->onResult(Ljava/lang/Void;)V

    return-void
.end method

.method public onResult(Ljava/lang/Void;)V
    .locals 3
    .param p1, "result"    # Ljava/lang/Void;

    .line 387
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_devices_revoked:I

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    .line 388
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 389
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$200(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    .line 390
    return-void
.end method
