# extended-by: Lcom/tzibbur/basic/ui/TzbComposeEditText;
.class public Lcom/tzibbur/basic/ui/TzbKeypadEditText;
.super Landroid/widget/EditText;
.source "TzbKeypadEditText.java"


# static fields
.field static final CENTER_NEWLINE_WINDOW_MS:J = 0x258L

.field static final TAG:Ljava/lang/String; = "TzbKey"


# instance fields
.field private lastCenterKeyUptimeMs:J


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;

    .line 61
    invoke-direct {p0, p1}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 62
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .line 65
    invoke-direct {p0, p1, p2}, Landroid/widget/EditText;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 66
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyleAttr"    # I

    .line 69
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/EditText;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 70
    return-void
.end method

.method static show(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 3
    .param p0, "text"    # Ljava/lang/CharSequence;

    .line 154
    if-nez p0, :cond_0

    .line 155
    const-string v0, "null"

    return-object v0

    .line 157
    :cond_0
    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\n"

    const-string v2, "\\n"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method protected centerKeySeenRecently()Z
    .locals 4

    .line 80
    iget-wide v0, p0, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->lastCenterKeyUptimeMs:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-eqz v0, :cond_0

    .line 81
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->lastCenterKeyUptimeMs:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x258

    cmp-long v0, v0, v2

    if-gtz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 80
    :goto_0
    return v0
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 3
    .param p1, "event"    # Landroid/view/KeyEvent;

    .line 89
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    .line 90
    .local v0, "code":I
    const/16 v1, 0x17

    if-eq v0, v1, :cond_0

    const/16 v1, 0x42

    if-ne v0, v1, :cond_1

    .line 91
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    iput-wide v1, p0, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->lastCenterKeyUptimeMs:J

    .line 93
    :cond_1
    invoke-super {p0, p1}, Landroid/widget/EditText;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result v1

    return v1
.end method

.method protected hasKeypad()Z
    .locals 3

    .line 74
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    .line 75
    .local v0, "config":Landroid/content/res/Configuration;
    iget v1, v0, Landroid/content/res/Configuration;->keyboard:I

    const/4 v2, 0x3

    if-eq v1, v2, :cond_1

    iget v1, v0, Landroid/content/res/Configuration;->navigation:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x1

    :goto_1
    return v1
.end method

.method public onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 3
    .param p1, "outAttrs"    # Landroid/view/inputmethod/EditorInfo;

    .line 162
    invoke-super {p0, p1}, Landroid/widget/EditText;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    move-result-object v0

    .line 163
    .local v0, "ic":Landroid/view/inputmethod/InputConnection;
    sget-boolean v1, Lcom/tzibbur/basic/BuildConfig;->DEBUG:Z

    if-eqz v1, :cond_1

    .line 164
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "onCreateInputConnection ic="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    if-nez v0, :cond_0

    const-string v2, "null"

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    :goto_0
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " imeOptions=0x"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 165
    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " inputType=0x"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    .line 166
    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " privateImeOptions="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p1, Landroid/view/inputmethod/EditorInfo;->privateImeOptions:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " keypad="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 168
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->hasKeypad()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " view="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 164
    const-string v2, "TzbKey"

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 170
    :cond_1
    if-nez v0, :cond_2

    .line 171
    const/4 v1, 0x0

    return-object v1

    .line 173
    :cond_2
    new-instance v1, Lcom/tzibbur/basic/ui/TzbKeypadEditText$1;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v0, v2}, Lcom/tzibbur/basic/ui/TzbKeypadEditText$1;-><init>(Lcom/tzibbur/basic/ui/TzbKeypadEditText;Landroid/view/inputmethod/InputConnection;Z)V

    return-object v1
.end method

# implemented-by: Lcom/tzibbur/basic/ui/TzbComposeEditText;
.method protected onImeEditorAction(I)Z
    .locals 1
    .param p1, "actionCode"    # I

    .line 149
    const/4 v0, 0x0

    return v0
.end method

.method protected onImeNewline(ZLjava/lang/String;)Z
    .locals 3
    .param p1, "afterCenter"    # Z
    .param p2, "origin"    # Ljava/lang/String;

    .line 103
    const/4 v0, 0x1

    if-eqz p1, :cond_1

    .line 104
    sget-boolean v1, Lcom/tzibbur/basic/BuildConfig;->DEBUG:Z

    if-eqz v1, :cond_0

    .line 105
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " after CENTER -> swallowed"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "TzbKey"

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 107
    :cond_0
    return v0

    .line 113
    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " without CENTER"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->synthesizeDpadDown(Ljava/lang/String;)Z

    .line 114
    return v0
.end method

.method protected synthesizeDpadDown(Ljava/lang/String;)Z
    .locals 18
    .param p1, "origin"    # Ljava/lang/String;

    .line 126
    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->getSelectionStart()I

    move-result v1

    .line 127
    .local v1, "selBefore":I
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    .line 128
    .local v3, "now":J
    new-instance v2, Landroid/view/KeyEvent;

    const/4 v13, 0x2

    const/16 v14, 0x201

    const/4 v7, 0x0

    const/16 v8, 0x14

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, -0x1

    const/4 v12, 0x0

    move-wide v5, v3

    invoke-direct/range {v2 .. v14}, Landroid/view/KeyEvent;-><init>(JJIIIIIIII)V

    move-object v15, v2

    .line 131
    .local v15, "down":Landroid/view/KeyEvent;
    invoke-virtual {v0, v15}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result v2

    .line 132
    .local v2, "handled":Z
    move v5, v2

    .end local v2
    .local v5, "handled":Z
    new-instance v2, Landroid/view/KeyEvent;

    move v7, v5

    .end local v5
    .local v7, "handled":Z
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    move v8, v7

    .end local v7
    .local v8, "handled":Z
    const/4 v7, 0x1

    move v9, v8

    .end local v8
    .local v9, "handled":Z
    const/16 v8, 0x14

    move v10, v9

    .end local v9
    .local v10, "handled":Z
    const/4 v9, 0x0

    move v11, v10

    .end local v10
    .local v11, "handled":Z
    const/4 v10, 0x0

    move v12, v11

    .end local v11
    .local v12, "handled":Z
    const/4 v11, -0x1

    move/from16 v16, v12

    .end local v12
    .local v16, "handled":Z
    const/4 v12, 0x0

    move-object/from16 v17, v15

    move/from16 v15, v16

    .end local v16
    .local v15, "handled":Z
    .local v17, "down":Landroid/view/KeyEvent;
    invoke-direct/range {v2 .. v14}, Landroid/view/KeyEvent;-><init>(JJIIIIIIII)V

    .line 135
    .local v2, "up":Landroid/view/KeyEvent;
    invoke-virtual {v0, v2}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 136
    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->hasFocus()Z

    move-result v5

    const/4 v6, 0x1

    xor-int/2addr v5, v6

    .line 137
    .local v5, "focusMoved":Z
    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbKeypadEditText;->getSelectionStart()I

    move-result v7

    const/4 v8, 0x0

    if-eq v7, v1, :cond_0

    move v7, v6

    goto :goto_0

    :cond_0
    move v7, v8

    .line 138
    .local v7, "cursorMoved":Z
    :goto_0
    if-nez v5, :cond_2

    if-eqz v7, :cond_1

    goto :goto_1

    :cond_1
    move v6, v8

    .line 139
    .local v6, "moved":Z
    :cond_2
    :goto_1
    sget-boolean v8, Lcom/tzibbur/basic/BuildConfig;->DEBUG:Z

    if-eqz v8, :cond_4

    .line 140
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v9, p1

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v10, " -> synthesized DPAD_DOWN handled="

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v15}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v10, " focusMoved="

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v10, " cursorMoved="

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 142
    if-eqz v6, :cond_3

    const-string v10, ""

    goto :goto_2

    :cond_3
    const-string v10, " (no-op: nothing below, newline withheld)"

    :goto_2
    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 140
    const-string v10, "TzbKey"

    invoke-static {v10, v8}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_3

    .line 139
    :cond_4
    move-object/from16 v9, p1

    .line 144
    :goto_3
    return v6
.end method
