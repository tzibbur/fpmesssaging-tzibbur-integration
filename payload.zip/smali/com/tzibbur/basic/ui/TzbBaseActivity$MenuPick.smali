.class public interface abstract Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;
.super Ljava/lang/Object;
.source "TzbBaseActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/ui/TzbBaseActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x60c
    name = "MenuPick"
.end annotation


# virtual methods
# implemented-by: Lcom/tzibbur/basic/ui/TzbBaseActivity$1;
.method public abstract onPick(Landroid/view/MenuItem;)V
.end method
