.class Lcom/tzibbur/basic/ui/TzbApplyActivity$1;
.super Ljava/lang/Object;
.source "TzbApplyActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 102
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 105
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$000(Lcom/tzibbur/basic/ui/TzbApplyActivity;Z)V

    .line 106
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$200(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$100(Lcom/tzibbur/basic/ui/TzbApplyActivity;)J

    move-result-wide v1

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 107
    return-void
.end method
