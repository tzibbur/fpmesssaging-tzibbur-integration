.class public final Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;
.super Ljava/lang/Object;
.source "TzbContactPickerAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Row"
.end annotation


# instance fields
.field public final name:Ljava/lang/String;

.field public final phone:Ljava/lang/String;

.field selected:Z


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "phone"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->phone:Ljava/lang/String;

    .line 33
    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->name:Ljava/lang/String;

    .line 34
    return-void
.end method


# virtual methods
.method label()Ljava/lang/String;
    .locals 1

    .line 37
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->name:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->name:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->name:Ljava/lang/String;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerAdapter$Row;->phone:Ljava/lang/String;

    :goto_0
    return-object v0
.end method
