.class Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;
.super Ljava/lang/Object;
.source "TzbGroupCreateActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->create()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbGroup;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

.field final synthetic val$category:Ljava/lang/String;

.field final synthetic val$groupName:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 207
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;->val$groupName:Ljava/lang/String;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;->val$category:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbGroup;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 210
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;->val$groupName:Ljava/lang/String;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;->val$category:Ljava/lang/String;

    invoke-interface {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApi;->createGroup(Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    .line 211
    .local v0, "group":Lcom/tzibbur/basic/model/TzbGroup;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;

    iget-object v1, v1, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v1

    invoke-interface {v1, v0}, Lcom/tzibbur/basic/store/TzbStore;->upsertGroup(Lcom/tzibbur/basic/model/TzbGroup;)V

    .line 212
    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 207
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupCreateActivity$8;->call()Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v0

    return-object v0
.end method
