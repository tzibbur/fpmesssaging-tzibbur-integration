.class Lcom/tzibbur/basic/ui/TzbConversationActivity$20;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->loadEarlier()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Ljava/util/List<",
        "Lcom/tzibbur/basic/model/TzbMessage;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

.field final synthetic val$gid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1028
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "error"    # Ljava/lang/Exception;

    .line 1056
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4302(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z

    .line 1057
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 1058
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 1028
    check-cast p1, Ljava/util/List;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->onResult(Ljava/util/List;)V

    return-void
.end method

.method public onResult(Ljava/util/List;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;)V"
        }
    .end annotation

    .line 1031
    .local p1, "older":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4302(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z

    .line 1032
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->val$gid:Ljava/lang/String;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 1033
    :cond_0
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 1034
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$4402(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z

    .line 1035
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    .line 1036
    return-void

    .line 1040
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->getHeaderViewsCount()I

    move-result v0

    .line 1041
    .local v0, "headersBefore":I
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/ListView;->getFirstVisiblePosition()I

    move-result v2

    .line 1042
    .local v2, "firstVis":I
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v3}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 1043
    .local v3, "firstChild":Landroid/view/View;
    if-eqz v3, :cond_2

    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    move-result v4

    goto :goto_0

    :cond_2
    move v4, v1

    .line 1044
    .local v4, "offset":I
    :goto_0
    sub-int v5, v2, v0

    invoke-static {v1, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    .line 1046
    .local v5, "anchorAdapterPos":I
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v6}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v6

    invoke-interface {v6, v1, p1}, Ljava/util/List;->addAll(ILjava/util/Collection;)Z

    .line 1047
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Lcom/tzibbur/basic/ui/TzbMessageListAdapter;

    move-result-object v6

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2600(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v7

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v8

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v9

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3000(Lcom/tzibbur/basic/ui/TzbConversationActivity;)J

    move-result-wide v10

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$2800(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Ljava/util/List;

    move-result-object v12

    invoke-virtual/range {v6 .. v12}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->setData(Ljava/util/List;Ljava/util/List;Ljava/util/List;JLjava/util/List;)V

    .line 1048
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V

    .line 1049
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v1

    .line 1050
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v6

    add-int/2addr v6, v5

    iget-object v7, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v7}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/ListView;->getHeaderViewsCount()I

    move-result v7

    add-int/2addr v6, v7

    .line 1049
    invoke-virtual {v1, v6, v4}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    .line 1052
    return-void
.end method
