.class Lcom/tzibbur/basic/ui/TzbBaseActivity$1;
.super Ljava/lang/Object;
.source "TzbBaseActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbBaseActivity;->showAppMenu()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbBaseActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbBaseActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbBaseActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 195
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbBaseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity$MenuPick;
.method public onPick(Landroid/view/MenuItem;)V
    .locals 1
    .param p1, "item"    # Landroid/view/MenuItem;

    .line 198
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$1;->this$0:Lcom/tzibbur/basic/ui/TzbBaseActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    .line 199
    return-void
.end method
