.class public Lcom/tzibbur/basic/ui/TzbLaunchActivity;
.super Landroid/app/Activity;
.source "TzbLaunchActivity.java"


# static fields
.field private static final EXTRA_GROUP_ID:Ljava/lang/String; = "tzb_group_id"

.field private static final GROUP_LIST_CLASS:Ljava/lang/String; = "com.tzibbur.basic.ui.TzbGroupListActivity"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 17
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 28
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 30
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 31
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbLaunchActivity;->finish()V

    .line 32
    return-void

    .line 35
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->deviceBlocked()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 38
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/tzibbur/basic/ui/TzbDeviceBlockedActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .local v0, "next":Landroid/content/Intent;
    goto :goto_1

    .line 39
    .end local v0
    :cond_1
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->holding(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 43
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/tzibbur/basic/core/TzbApplyGate;->show(Landroid/content/Context;Ljava/lang/String;)V

    .line 44
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbLaunchActivity;->finish()V

    .line 45
    return-void

    .line 46
    :cond_2
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v0

    if-eqz v0, :cond_5

    .line 53
    invoke-static {p0}, Lcom/tzibbur/basic/sync/TzbSyncService;->ensureRunning(Landroid/content/Context;)V

    .line 54
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 55
    .restart local v0
    const-string v1, "com.android.mms.ui.ConversationList"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 56
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbLaunchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    const-string v2, "tzb_group_id"

    if-eqz v1, :cond_3

    .line 57
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbLaunchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_3
    const/4 v1, 0x0

    .line 58
    .local v1, "groupId":Ljava/lang/String;
    :goto_0
    if-eqz v1, :cond_4

    .line 59
    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 61
    .end local v1
    :cond_4
    goto :goto_1

    .line 62
    .end local v0
    :cond_5
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/tzibbur/basic/ui/TzbEnrollPhoneActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 64
    .restart local v0
    :goto_1
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbLaunchActivity;->startActivity(Landroid/content/Intent;)V

    .line 65
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbLaunchActivity;->finish()V

    .line 66
    return-void
.end method
