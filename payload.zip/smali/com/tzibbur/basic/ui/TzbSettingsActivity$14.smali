.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->showDevicesDialog(Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

.field final synthetic val$devices:Ljava/util/List;

.field final synthetic val$lines:[Ljava/lang/String;

.field final synthetic val$selfDeviceId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Ljava/util/List;Ljava/lang/String;[Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 313
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;->val$devices:Ljava/util/List;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;->val$selfDeviceId:Ljava/lang/String;

    iput-object p4, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;->val$lines:[Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 4
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 316
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;->val$devices:Ljava/util/List;

    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tzibbur/basic/model/TzbDevice;

    .line 317
    .local v0, "device":Lcom/tzibbur/basic/model/TzbDevice;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;->val$selfDeviceId:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$700(Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 318
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_devices_use_signout:I

    const/4 v3, 0x1

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v1

    .line 319
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 321
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$14;->val$lines:[Ljava/lang/String;

    aget-object v2, v2, p2

    invoke-static {v1, v0, v2}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$800(Lcom/tzibbur/basic/ui/TzbSettingsActivity;Lcom/tzibbur/basic/model/TzbDevice;Ljava/lang/String;)V

    .line 323
    :goto_0
    return-void
.end method
