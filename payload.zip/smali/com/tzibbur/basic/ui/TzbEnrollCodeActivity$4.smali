.class Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;
.super Ljava/lang/Object;
.source "TzbEnrollCodeActivity.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->verify()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/tzibbur/basic/model/TzbEnrollment;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

.field final synthetic val$api:Lcom/tzibbur/basic/net/TzbApi;

.field final synthetic val$code:Ljava/lang/String;

.field final synthetic val$name:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Lcom/tzibbur/basic/net/TzbApi;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 305
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;->val$api:Lcom/tzibbur/basic/net/TzbApi;

    iput-object p3, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;->val$code:Ljava/lang/String;

    iput-object p4, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;->val$name:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Lcom/tzibbur/basic/model/TzbEnrollment;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 310
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;->val$api:Lcom/tzibbur/basic/net/TzbApi;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$300(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;->val$code:Ljava/lang/String;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;->val$name:Ljava/lang/String;

    invoke-interface {v0, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbApi;->authVerify(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbEnrollment;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 305
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$4;->call()Lcom/tzibbur/basic/model/TzbEnrollment;

    move-result-object v0

    return-object v0
.end method
