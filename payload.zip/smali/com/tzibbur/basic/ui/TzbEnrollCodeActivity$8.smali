.class Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;
.super Ljava/lang/Object;
.source "TzbEnrollCodeActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->resend()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbAuthStart;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 442
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "error"    # Ljava/lang/Exception;

    .line 456
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$402(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Z)Z

    .line 457
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$600(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Z)V

    .line 458
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1800(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/Exception;)V

    .line 459
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbAuthStart;)V
    .locals 4
    .param p1, "start"    # Lcom/tzibbur/basic/model/TzbAuthStart;

    .line 445
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$402(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Z)Z

    .line 446
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    const/4 v2, 0x1

    invoke-static {v0, v2}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$600(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Z)V

    .line 447
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    iget-object v2, p1, Lcom/tzibbur/basic/model/TzbAuthStart;->challengeId:Ljava/lang/String;

    invoke-static {v0, v2}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$302(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/String;)Ljava/lang/String;

    .line 448
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    iget-object v2, p1, Lcom/tzibbur/basic/model/TzbAuthStart;->expiresAt:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1500(Ljava/lang/String;)J

    move-result-wide v2

    invoke-static {v0, v2, v3}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1402(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;J)J

    .line 449
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1602(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;I)I

    .line 450
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_enroll_status_code_resent:I

    invoke-virtual {v1, v2}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1200(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Ljava/lang/String;)V

    .line 451
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    iget v1, p1, Lcom/tzibbur/basic/model/TzbAuthStart;->resendAfterSeconds:I

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1700(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;I)V

    .line 452
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 442
    check-cast p1, Lcom/tzibbur/basic/model/TzbAuthStart;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$8;->onResult(Lcom/tzibbur/basic/model/TzbAuthStart;)V

    return-void
.end method
