.class Lcom/tzibbur/basic/ui/TzbApplyActivity$8;
.super Ljava/lang/Object;
.source "TzbApplyActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;->onApproved()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbApplyActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 370
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 373
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 374
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1200(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 375
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    .line 376
    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v0

    .line 377
    .local v0, "signedInAs":Ljava/lang/String;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1300(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1300(Lcom/tzibbur/basic/ui/TzbApplyActivity;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 382
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1400(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    goto :goto_0

    .line 384
    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->access$1500(Lcom/tzibbur/basic/ui/TzbApplyActivity;)V

    .line 386
    .end local v0
    :goto_0
    goto :goto_1

    .line 389
    :cond_2
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->setResult(I)V

    .line 390
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$8;->this$0:Lcom/tzibbur/basic/ui/TzbApplyActivity;

    invoke-virtual {v0}, Lcom/tzibbur/basic/ui/TzbApplyActivity;->finish()V

    .line 392
    :goto_1
    return-void
.end method
