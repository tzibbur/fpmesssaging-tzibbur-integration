.class public final Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;
.super Ljava/lang/Object;
.source "TzbGroupListAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/ui/TzbGroupListAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Row"
.end annotation


# instance fields
.field public final group:Lcom/tzibbur/basic/model/TzbGroup;

.field public final snippet:Ljava/lang/String;

.field public final unread:I


# direct methods
.method public constructor <init>(Lcom/tzibbur/basic/model/TzbGroup;Ljava/lang/String;I)V
    .locals 0
    .param p1, "group"    # Lcom/tzibbur/basic/model/TzbGroup;
    .param p2, "snippet"    # Ljava/lang/String;
    .param p3, "unread"    # I

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->group:Lcom/tzibbur/basic/model/TzbGroup;

    .line 28
    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->snippet:Ljava/lang/String;

    .line 29
    iput p3, p0, Lcom/tzibbur/basic/ui/TzbGroupListAdapter$Row;->unread:I

    .line 30
    return-void
.end method
