.class Lcom/tzibbur/basic/ui/TzbConversationActivity$5;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 236
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 2
    .param p1, "v"    # Landroid/view/View;
    .param p2, "keyCode"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .line 239
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    .line 240
    :cond_0
    const/16 v0, 0x15

    if-ne p2, v0, :cond_1

    .line 241
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$800(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    return v0

    .line 243
    :cond_1
    const/16 v0, 0x13

    if-ne p2, v0, :cond_2

    .line 244
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$900(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)V

    .line 245
    return v1

    .line 247
    :cond_2
    return v1
.end method
