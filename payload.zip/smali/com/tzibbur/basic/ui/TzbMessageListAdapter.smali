.class public final Lcom/tzibbur/basic/ui/TzbMessageListAdapter;
.super Landroid/widget/BaseAdapter;
.source "TzbMessageListAdapter.java"


# static fields
.field public static final MUTED_DIVIDER:Ljava/lang/Object;

.field private static final TYPE_IN:I = 0x0

.field private static final TYPE_MUTED_DIVIDER:I = 0x5

.field private static final TYPE_OUT:I = 0x1

.field private static final TYPE_SPONSORED:I = 0x4

.field private static final TYPE_SYSTEM:I = 0x2

.field private static final TYPE_UNREAD_DIVIDER:I = 0x3

.field public static final UNREAD_DIVIDER:Ljava/lang/Object;


# instance fields
.field private final context:Landroid/content/Context;

.field private final inflater:Landroid/view/LayoutInflater;

.field private final isoMillis:Ljava/text/SimpleDateFormat;

.field private final isoSeconds:Ljava/text/SimpleDateFormat;

.field private final items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private final selfUserId:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 46
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->UNREAD_DIVIDER:Ljava/lang/Object;

    .line 49
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->MUTED_DIVIDER:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "selfUserId"    # Ljava/lang/String;

    .line 60
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 54
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    .line 61
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->context:Landroid/content/Context;

    .line 62
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 63
    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->selfUserId:Ljava/lang/String;

    .line 64
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'"

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->isoMillis:Ljava/text/SimpleDateFormat;

    .line 65
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->isoMillis:Ljava/text/SimpleDateFormat;

    const-string v1, "UTC"

    invoke-static {v1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/text/SimpleDateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 66
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v2, "yyyy-MM-dd\'T\'HH:mm:ss\'Z\'"

    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->isoSeconds:Ljava/text/SimpleDateFormat;

    .line 67
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->isoSeconds:Ljava/text/SimpleDateFormat;

    invoke-static {v1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 68
    return-void
.end method


# virtual methods
.method public areAllItemsEnabled()Z
    .locals 1

    .line 129
    const/4 v0, 0x0

    return v0
.end method

.method public formatDate(Ljava/util/Date;)Ljava/lang/String;
    .locals 5
    .param p1, "date"    # Ljava/util/Date;

    .line 246
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    .line 247
    .local v0, "now":Ljava/util/Calendar;
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v1

    .line 248
    .local v1, "then":Ljava/util/Calendar;
    invoke-virtual {v1, p1}, Ljava/util/Calendar;->setTime(Ljava/util/Date;)V

    .line 249
    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Ljava/util/Calendar;->get(I)I

    move-result v3

    invoke-virtual {v1, v2}, Ljava/util/Calendar;->get(I)I

    move-result v4

    if-ne v3, v4, :cond_0

    .line 250
    const/4 v3, 0x6

    invoke-virtual {v0, v3}, Ljava/util/Calendar;->get(I)I

    move-result v4

    invoke-virtual {v1, v3}, Ljava/util/Calendar;->get(I)I

    move-result v3

    if-ne v4, v3, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    .line 251
    .local v2, "sameDay":Z
    :goto_0
    const/4 v3, 0x3

    if-eqz v2, :cond_1

    .line 252
    invoke-static {v3}, Ljava/text/DateFormat;->getTimeInstance(I)Ljava/text/DateFormat;

    move-result-object v3

    goto :goto_1

    .line 253
    :cond_1
    invoke-static {v3, v3}, Ljava/text/DateFormat;->getDateTimeInstance(II)Ljava/text/DateFormat;

    move-result-object v3

    :goto_1
    nop

    .line 254
    .local v3, "format":Ljava/text/DateFormat;
    invoke-virtual {v3, p1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    return-object v4
.end method

.method public formatIso(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p1, "iso"    # Ljava/lang/String;

    .line 230
    if-nez p1, :cond_0

    const-string v0, ""

    return-object v0

    .line 233
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->isoMillis:Ljava/text/SimpleDateFormat;

    invoke-virtual {v0, p1}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v0

    .line 240
    .local v0, "date":Ljava/util/Date;
    :try_end_0
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 234
    .end local v0
    :catch_0
    move-exception v0

    .line 236
    .local v0, "first":Ljava/text/ParseException;
    :try_start_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->isoSeconds:Ljava/text/SimpleDateFormat;

    invoke-virtual {v1, p1}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v1

    .line 239
    .local v1, "date":Ljava/util/Date;
    :try_end_1
    .catch Ljava/text/ParseException; {:try_start_1 .. :try_end_1} :catch_1

    move-object v0, v1

    .line 241
    .end local v1
    .local v0, "date":Ljava/util/Date;
    :goto_0
    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->formatDate(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 237
    .local v0, "first":Ljava/text/ParseException;
    :catch_1
    move-exception v1

    .line 238
    .local v1, "second":Ljava/text/ParseException;
    return-object p1
.end method

.method public getCount()I
    .locals 1

    .line 112
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 117
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 122
    int-to-long v0, p1

    return-wide v0
.end method

.method public getItemViewType(I)I
    .locals 6
    .param p1, "position"    # I

    .line 145
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    .line 146
    .local v0, "item":Ljava/lang/Object;
    sget-object v1, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->UNREAD_DIVIDER:Ljava/lang/Object;

    if-ne v0, v1, :cond_0

    const/4 v1, 0x3

    return v1

    .line 147
    :cond_0
    sget-object v1, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->MUTED_DIVIDER:Ljava/lang/Object;

    if-ne v0, v1, :cond_1

    const/4 v1, 0x5

    return v1

    .line 148
    :cond_1
    instance-of v1, v0, Lcom/tzibbur/basic/model/TzbMessage;

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v1, :cond_5

    .line 149
    move-object v1, v0

    check-cast v1, Lcom/tzibbur/basic/model/TzbMessage;

    .line 152
    .local v1, "message":Lcom/tzibbur/basic/model/TzbMessage;
    const-string v4, "00000000-0000-7000-8000-000000000001"

    iget-object v5, v1, Lcom/tzibbur/basic/model/TzbMessage;->senderId:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    return v3

    .line 153
    :cond_2
    const-string v3, "00000000-0000-7000-8000-000000000002"

    iget-object v4, v1, Lcom/tzibbur/basic/model/TzbMessage;->senderId:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    const/4 v2, 0x4

    return v2

    .line 154
    :cond_3
    iget-object v3, v1, Lcom/tzibbur/basic/model/TzbMessage;->senderId:Ljava/lang/String;

    if-eqz v3, :cond_4

    iget-object v3, v1, Lcom/tzibbur/basic/model/TzbMessage;->senderId:Ljava/lang/String;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->selfUserId:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    return v2

    .line 155
    :cond_4
    const/4 v2, 0x0

    return v2

    .line 157
    .end local v1
    :cond_5
    instance-of v1, v0, Lcom/tzibbur/basic/store/TzbOutboxItem;

    if-eqz v1, :cond_6

    return v2

    .line 158
    :cond_6
    return v3
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 8
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 163
    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->getItemViewType(I)I

    move-result v0

    .line 164
    .local v0, "type":I
    const/4 v1, 0x3

    const/4 v2, 0x0

    if-ne v0, v1, :cond_1

    .line 165
    if-eqz p2, :cond_0

    .line 166
    move-object v1, p2

    goto :goto_0

    .line 167
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v3, Lcom/tzibbur/basic/R$layout;->tzb_unread_divider:I

    invoke-virtual {v1, v3, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    .line 165
    :goto_0
    return-object v1

    .line 169
    :cond_1
    const/4 v1, 0x5

    if-ne v0, v1, :cond_3

    .line 170
    if-eqz p2, :cond_2

    .line 171
    move-object v1, p2

    goto :goto_1

    .line 172
    :cond_2
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v3, Lcom/tzibbur/basic/R$layout;->tzb_muted_divider:I

    invoke-virtual {v1, v3, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    .line 170
    :goto_1
    return-object v1

    .line 174
    :cond_3
    move-object v1, p2

    .line 175
    .local v1, "view":Landroid/view/View;
    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez v1, :cond_7

    .line 176
    if-nez v0, :cond_4

    sget v5, Lcom/tzibbur/basic/R$layout;->tzb_message_item_in:I

    goto :goto_2

    .line 177
    :cond_4
    if-ne v0, v3, :cond_5

    sget v5, Lcom/tzibbur/basic/R$layout;->tzb_message_item_out:I

    goto :goto_2

    .line 178
    :cond_5
    if-ne v0, v4, :cond_6

    sget v5, Lcom/tzibbur/basic/R$layout;->tzb_message_item_sponsored:I

    goto :goto_2

    .line 179
    :cond_6
    sget v5, Lcom/tzibbur/basic/R$layout;->tzb_message_item_system:I

    :goto_2
    nop

    .line 180
    .local v5, "layout":I
    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->inflater:Landroid/view/LayoutInflater;

    invoke-virtual {v6, v5, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    .line 183
    .end local v5
    :cond_7
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    invoke-interface {v5, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    .line 184
    .local v5, "item":Ljava/lang/Object;
    sget v6, Lcom/tzibbur/basic/R$id;->tzb_msg_body:I

    invoke-virtual {v1, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 185
    .local v6, "body":Landroid/widget/TextView;
    sget v7, Lcom/tzibbur/basic/R$id;->tzb_msg_time:I

    invoke-virtual {v1, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    .line 187
    .local v7, "time":Landroid/widget/TextView;
    if-eqz v0, :cond_d

    if-ne v0, v4, :cond_8

    goto/16 :goto_4

    .line 192
    :cond_8
    if-ne v0, v3, :cond_b

    .line 193
    instance-of v2, v5, Lcom/tzibbur/basic/store/TzbOutboxItem;

    if-eqz v2, :cond_a

    .line 194
    move-object v2, v5

    check-cast v2, Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 195
    .local v2, "outboxItem":Lcom/tzibbur/basic/store/TzbOutboxItem;
    iget-object v3, v2, Lcom/tzibbur/basic/store/TzbOutboxItem;->body:Ljava/lang/String;

    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 196
    sget v3, Lcom/tzibbur/basic/R$drawable;->tzb_bubble_pending:I

    # Bubble background belongs to the stock container.

    .line 197
    iget v3, v2, Lcom/tzibbur/basic/store/TzbOutboxItem;->state:I

    const/4 v4, 0x2

    if-ne v3, v4, :cond_9

    .line 198
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->context:Landroid/content/Context;

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_send_failed_retry:I

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 199
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->context:Landroid/content/Context;

    sget v4, Lcom/tzibbur/basic/R$color;->tzb_error:I

    invoke-virtual {v3, v4}, Landroid/content/Context;->getColor(I)I

    move-result v3

    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_3

    .line 201
    :cond_9
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->context:Landroid/content/Context;

    sget v4, Lcom/tzibbur/basic/R$string;->tzb_sending:I

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 202
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->context:Landroid/content/Context;

    sget v4, Lcom/tzibbur/basic/R$color;->tzb_text_hint:I

    invoke-virtual {v3, v4}, Landroid/content/Context;->getColor(I)I

    move-result v3

    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 204
    .end local v2
    :goto_3
    goto :goto_5

    .line 205
    :cond_a
    move-object v2, v5

    check-cast v2, Lcom/tzibbur/basic/model/TzbMessage;

    .line 206
    .local v2, "message":Lcom/tzibbur/basic/model/TzbMessage;
    iget-object v3, v2, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 207
    sget v3, Lcom/tzibbur/basic/R$drawable;->tzb_bubble_out:I

    # Bubble background belongs to the stock container.

    .line 208
    iget-object v3, v2, Lcom/tzibbur/basic/model/TzbMessage;->createdAt:Ljava/lang/String;

    invoke-virtual {p0, v3}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->formatIso(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 209
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->context:Landroid/content/Context;

    sget v4, Lcom/tzibbur/basic/R$color;->tzb_text_hint:I

    invoke-virtual {v3, v4}, Landroid/content/Context;->getColor(I)I

    move-result v3

    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 210
    .end local v2
    goto :goto_5

    .line 212
    :cond_b
    instance-of v3, v5, Lcom/tzibbur/basic/model/TzbMessage;

    if-eqz v3, :cond_c

    .line 213
    move-object v3, v5

    check-cast v3, Lcom/tzibbur/basic/model/TzbMessage;

    .line 214
    .local v3, "message":Lcom/tzibbur/basic/model/TzbMessage;
    iget-object v4, v3, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    invoke-virtual {v6, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 215
    iget-object v4, v3, Lcom/tzibbur/basic/model/TzbMessage;->createdAt:Ljava/lang/String;

    invoke-virtual {p0, v4}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->formatIso(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 216
    invoke-virtual {v7, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 217
    .end local v3
    goto :goto_5

    .line 219
    :cond_c
    move-object v2, v5

    check-cast v2, Lcom/tzibbur/basic/model/TzbCommandResult;

    iget-object v2, v2, Lcom/tzibbur/basic/model/TzbCommandResult;->text:Ljava/lang/String;

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 220
    const/16 v2, 0x8

    invoke-virtual {v7, v2}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_5

    .line 188
    :cond_d
    :goto_4
    move-object v2, v5

    check-cast v2, Lcom/tzibbur/basic/model/TzbMessage;

    .line 189
    .restart local v2
    iget-object v3, v2, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 190
    iget-object v3, v2, Lcom/tzibbur/basic/model/TzbMessage;->createdAt:Ljava/lang/String;

    invoke-virtual {p0, v3}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->formatIso(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 191
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->context:Landroid/content/Context;

    sget v4, Lcom/tzibbur/basic/R$color;->tzb_text_hint:I

    invoke-virtual {v3, v4}, Landroid/content/Context;->getColor(I)I

    move-result v3

    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 192
    .end local v2
    nop

    .line 223
    :goto_5
    # tzib conversation: row
    invoke-static {v1, v5}, Lcom/android/mms/tzib/TzibConversationStyle;->bind(Landroid/view/View;Ljava/lang/Object;)V
    return-object v1
.end method

.method public getViewTypeCount()I
    .locals 1

    .line 140
    const/4 v0, 0x6

    return v0
.end method

.method public isEnabled(I)Z
    .locals 2
    .param p1, "position"    # I

    .line 134
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    .line 135
    .local v0, "item":Ljava/lang/Object;
    sget-object v1, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->UNREAD_DIVIDER:Ljava/lang/Object;

    if-eq v0, v1, :cond_0

    sget-object v1, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->MUTED_DIVIDER:Ljava/lang/Object;

    if-eq v0, v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public setData(Ljava/util/List;Ljava/util/List;Ljava/util/List;J)V
    .locals 7
    .param p4, "unreadDividerSeq"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/store/TzbOutboxItem;",
            ">;",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbCommandResult;",
            ">;J)V"
        }
    .end annotation

    .line 77
    .local p1, "messages":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    .local p2, "outbox":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/store/TzbOutboxItem;>;"
    .local p3, "commandResults":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbCommandResult;>;"
    nop

    .line 78
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v6

    .line 77
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-wide v4, p4

    .end local p1
    .end local p2
    .end local p3
    .end local p4
    .local v1, "messages":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    .local v2, "outbox":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/store/TzbOutboxItem;>;"
    .local v3, "commandResults":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbCommandResult;>;"
    .local v4, "unreadDividerSeq":J
    invoke-virtual/range {v0 .. v6}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->setData(Ljava/util/List;Ljava/util/List;Ljava/util/List;JLjava/util/List;)V

    .line 79
    return-void
.end method

.method public setData(Ljava/util/List;Ljava/util/List;Ljava/util/List;JLjava/util/List;)V
    .locals 9
    .param p4, "unreadDividerSeq"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/store/TzbOutboxItem;",
            ">;",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbCommandResult;",
            ">;J",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .line 91
    .local p1, "messages":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    .local p2, "outbox":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/store/TzbOutboxItem;>;"
    .local p3, "commandResults":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbCommandResult;>;"
    .local p6, "muteGaps":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Long;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 92
    const-wide/16 v0, 0x0

    cmp-long v0, p4, v0

    if-gez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 93
    .local v0, "dividerInserted":Z
    :goto_0
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    .line 94
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/tzibbur/basic/model/TzbMessage;

    .line 95
    .local v2, "message":Lcom/tzibbur/basic/model/TzbMessage;
    if-nez v0, :cond_1

    iget-wide v3, v2, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    cmp-long v3, v3, p4

    if-ltz v3, :cond_1

    .line 96
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    sget-object v4, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->UNREAD_DIVIDER:Ljava/lang/Object;

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 97
    const/4 v0, 0x1

    .line 99
    :cond_1
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 100
    add-int/lit8 v3, v1, 0x1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_2

    add-int/lit8 v3, v1, 0x1

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/tzibbur/basic/model/TzbMessage;

    iget-wide v3, v3, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    goto :goto_2

    :cond_2
    const-wide/16 v3, -0x1

    .line 101
    .local v3, "next":J
    :goto_2
    iget-wide v5, v2, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    const-wide/16 v7, 0x1

    add-long/2addr v5, v7

    cmp-long v5, v3, v5

    if-lez v5, :cond_3

    iget-wide v5, v2, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-interface {p6, v5}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    .line 102
    iget-object v5, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    sget-object v6, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->MUTED_DIVIDER:Ljava/lang/Object;

    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 93
    .end local v2
    .end local v3
    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 105
    .end local v1
    :cond_4
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    invoke-interface {v1, p2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 106
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;

    invoke-interface {v1, p3}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 107
    # tzib message actions: filter
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->context:Landroid/content/Context;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->items:Ljava/util/List;
    invoke-static {v0, v1}, Lcom/android/mms/tzib/TzibDeletedMessages;->filter(Landroid/content/Context;Ljava/util/List;)V
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbMessageListAdapter;->notifyDataSetChanged()V

    .line 108
    return-void
.end method
