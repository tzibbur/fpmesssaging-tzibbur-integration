.class public final Lcom/tzibbur/basic/ui/TzbMemberListAdapter;
.super Landroid/widget/BaseAdapter;
.source "TzbMemberListAdapter.java"


# instance fields
.field private final context:Landroid/content/Context;

.field private final inflater:Landroid/view/LayoutInflater;

.field private final members:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;"
        }
    .end annotation
.end field

.field private final selfUserId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "selfUserId"    # Ljava/lang/String;

    .line 31
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 29
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->members:Ljava/util/List;

    .line 32
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->context:Landroid/content/Context;

    .line 33
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 34
    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->selfUserId:Ljava/lang/String;

    .line 35
    return-void
.end method


# virtual methods
.method public addMembers(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;)V"
        }
    .end annotation

    .line 44
    .local p1, "more":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMember;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->members:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 45
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->notifyDataSetChanged()V

    .line 46
    return-void
.end method

.method public areAllItemsEnabled()Z
    .locals 1

    .line 78
    const/4 v0, 0x1

    return v0
.end method

.method public getCount()I
    .locals 1

    .line 62
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->members:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 67
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->members:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 72
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 10
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 88
    const/4 v0, 0x0

    if-eqz p2, :cond_0

    .line 89
    move-object v1, p2

    goto :goto_0

    .line 90
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v2, Lcom/tzibbur/basic/R$layout;->tzb_member_list_item:I

    invoke-virtual {v1, v2, p3, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    :goto_0
    nop

    .line 91
    .local v1, "view":Landroid/view/View;
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->members:Ljava/util/List;

    invoke-interface {v2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/tzibbur/basic/model/TzbMember;

    .line 93
    .local v2, "member":Lcom/tzibbur/basic/model/TzbMember;
    sget v3, Lcom/tzibbur/basic/R$id;->tzb_member_name:I

    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    .line 94
    .local v3, "name":Landroid/widget/TextView;
    sget v4, Lcom/tzibbur/basic/R$id;->tzb_member_role:I

    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    .line 96
    .local v4, "role":Landroid/widget/TextView;
    iget-object v5, v2, Lcom/tzibbur/basic/model/TzbMember;->userId:Ljava/lang/String;

    if-eqz v5, :cond_1

    iget-object v5, v2, Lcom/tzibbur/basic/model/TzbMember;->userId:Ljava/lang/String;

    iget-object v6, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->selfUserId:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    const/4 v5, 0x1

    goto :goto_1

    :cond_1
    move v5, v0

    .line 98
    .local v5, "self":Z
    :goto_1
    if-eqz v5, :cond_3

    .line 99
    iget-object v6, v2, Lcom/tzibbur/basic/model/TzbMember;->displayName:Ljava/lang/String;

    if-eqz v6, :cond_2

    iget-object v6, v2, Lcom/tzibbur/basic/model/TzbMember;->displayName:Ljava/lang/String;

    goto :goto_2

    :cond_2
    const-string v6, ""

    .line 100
    .local v6, "own":Ljava/lang/String;
    :goto_2
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget-object v8, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->context:Landroid/content/Context;

    sget v9, Lcom/tzibbur/basic/R$string;->tzb_you_marker:I

    invoke-virtual {v8, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 101
    .local v6, "primary":Ljava/lang/String;
    goto :goto_3

    .line 102
    .end local v6
    :cond_3
    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->labelFor(Lcom/tzibbur/basic/model/TzbMember;)Ljava/lang/String;

    move-result-object v6

    .line 104
    .restart local v6
    :goto_3
    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 106
    const-string v7, "admin"

    iget-object v8, v2, Lcom/tzibbur/basic/model/TzbMember;->role:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4

    goto :goto_4

    :cond_4
    const/16 v0, 0x8

    :goto_4
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 107
    return-object v1
.end method

.method public isEnabled(I)Z
    .locals 1
    .param p1, "position"    # I

    .line 83
    const/4 v0, 0x1

    return v0
.end method

.method public labelFor(Lcom/tzibbur/basic/model/TzbMember;)Ljava/lang/String;
    .locals 4
    .param p1, "member"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 50
    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbMember;->displayName:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbMember;->displayName:Ljava/lang/String;

    goto :goto_0

    :cond_0
    const-string v0, ""

    .line 51
    .local v0, "name":Ljava/lang/String;
    :goto_0
    const-string v1, "organization"

    iget-object v2, p1, Lcom/tzibbur/basic/model/TzbMember;->kind:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 52
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->context:Landroid/content/Context;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_member_kind_organization:I

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 54
    :cond_1
    const-string v1, "service"

    iget-object v2, p1, Lcom/tzibbur/basic/model/TzbMember;->kind:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 55
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->context:Landroid/content/Context;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_member_kind_service:I

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 57
    :cond_2
    return-object v0
.end method

.method public setMembers(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;)V"
        }
    .end annotation

    .line 38
    .local p1, "newMembers":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMember;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->members:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 39
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->members:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 40
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->notifyDataSetChanged()V

    .line 41
    return-void
.end method
