.class Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;
.super Landroid/os/CountDownTimer;
.source "TzbEnrollCodeActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->startResendCountdown(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;JJ)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;
    .param p2, "arg0"    # J
    .param p4, "arg1"    # J
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .line 498
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-direct {p0, p2, p3, p4, p5}, Landroid/os/CountDownTimer;-><init>(JJ)V

    return-void
.end method


# virtual methods
.method public onFinish()V
    .locals 3

    .line 508
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$2002(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;Landroid/os/CountDownTimer;)Landroid/os/CountDownTimer;

    .line 509
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1000(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 510
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1900(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_enroll_resend_btn:I

    invoke-virtual {v1, v2}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 511
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1900(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Landroid/widget/Button;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 513
    :cond_0
    return-void
.end method

.method public onTick(J)V
    .locals 7
    .param p1, "millisUntilFinished"    # J

    .line 501
    const-wide/16 v0, 0x3e7

    add-long/2addr v0, p1

    const-wide/16 v2, 0x3e8

    div-long/2addr v0, v2

    long-to-int v0, v0

    .line 502
    .local v0, "left":I
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    invoke-static {v1}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->access$1900(Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;)Landroid/widget/Button;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_enroll_resend_btn_wait:I

    .line 503
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    aput-object v4, v5, v6

    invoke-virtual {v2, v3, v5}, Lcom/tzibbur/basic/ui/TzbEnrollCodeActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 502
    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 504
    return-void
.end method
