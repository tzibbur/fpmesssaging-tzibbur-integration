.class Lcom/tzibbur/basic/ui/TzbBaseActivity$5;
.super Ljava/lang/Object;
.source "TzbBaseActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbBaseActivity;->syncImeToFocus(Landroid/view/View;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$hasFocus:Z

.field final synthetic val$v:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/view/View;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 295
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$5;->val$v:Landroid/view/View;

    iput-boolean p2, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$5;->val$hasFocus:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 298
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$5;->val$v:Landroid/view/View;

    .line 299
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "input_method"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 300
    .local v0, "imm":Landroid/view/inputmethod/InputMethodManager;
    if-nez v0, :cond_0

    return-void

    .line 301
    :cond_0
    iget-boolean v1, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$5;->val$hasFocus:Z

    if-eqz v1, :cond_1

    .line 302
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$5;->val$v:Landroid/view/View;

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    goto :goto_0

    .line 306
    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$5;->val$v:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v1

    .line 307
    .local v1, "now":Landroid/view/View;
    instance-of v2, v1, Landroid/widget/EditText;

    if-nez v2, :cond_2

    .line 308
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbBaseActivity$5;->val$v:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3}, Landroid/view/inputmethod/InputMethodManager;->hideSoftInputFromWindow(Landroid/os/IBinder;I)Z

    .line 311
    .end local v1
    :cond_2
    :goto_0
    return-void
.end method
