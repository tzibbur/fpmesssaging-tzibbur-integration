.class Lcom/tzibbur/basic/ui/TzbConversationActivity$17$1;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->onResult([Ljava/lang/Object;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/tzibbur/basic/ui/TzbConversationActivity$17;

.field final synthetic val$position:I


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity$17;I)V
    .locals 0
    .param p1, "this$1"    # Lcom/tzibbur/basic/ui/TzbConversationActivity$17;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 806
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17$1;->this$1:Lcom/tzibbur/basic/ui/TzbConversationActivity$17;

    iput p2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17$1;->val$position:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 809
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17$1;->this$1:Lcom/tzibbur/basic/ui/TzbConversationActivity$17;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->requestFocus()Z

    .line 812
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17$1;->this$1:Lcom/tzibbur/basic/ui/TzbConversationActivity$17;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v0

    iget v1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17$1;->val$position:I

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$17$1;->this$1:Lcom/tzibbur/basic/ui/TzbConversationActivity$17;

    iget-object v2, v2, Lcom/tzibbur/basic/ui/TzbConversationActivity$17;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    .line 813
    invoke-static {v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$3700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)I

    move-result v2

    .line 812
    invoke-virtual {v0, v1, v2}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    .line 814
    return-void
.end method
