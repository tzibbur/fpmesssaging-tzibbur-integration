.class Lcom/tzibbur/basic/ui/TzbApplyActivity$12;
.super Ljava/lang/Object;
.source "TzbApplyActivity.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbApplyActivity;->linkKeys(Landroid/view/View;Landroid/view/View;Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$down:Landroid/view/View;

.field final synthetic val$up:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/view/View;Landroid/view/View;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 687
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$12;->val$down:Landroid/view/View;

    iput-object p2, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$12;->val$up:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "keyCode"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .line 690
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 691
    return v1

    .line 693
    :cond_0
    const/16 v0, 0x14

    const/4 v2, 0x1

    if-ne p2, v0, :cond_1

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$12;->val$down:Landroid/view/View;

    if-eqz v0, :cond_1

    .line 694
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$12;->val$down:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 695
    return v2

    .line 697
    :cond_1
    const/16 v0, 0x13

    if-ne p2, v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$12;->val$up:Landroid/view/View;

    if-eqz v0, :cond_2

    .line 698
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbApplyActivity$12;->val$up:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 699
    return v2

    .line 701
    :cond_2
    return v1
.end method
