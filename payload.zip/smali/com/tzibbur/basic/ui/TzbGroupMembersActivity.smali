.class public Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
.super Lcom/tzibbur/basic/ui/TzbBaseActivity;
.source "TzbGroupMembersActivity.java"


# static fields
.field private static final ADD_PHONES_PER_REQUEST:I = 0x64

.field private static final PAGE:I = 0x32

.field private static final REQ_CHOOSE_CONTACTS:I = 0x2


# instance fields
.field private adapter:Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

.field private addAllowedByServer:Z

.field private addBtn:Landroid/widget/Button;

.field private addDialog:Landroid/app/AlertDialog;

.field private addPhoneEdit:Landroid/widget/EditText;

.field private footerShown:Z

.field private group:Lcom/tzibbur/basic/model/TzbGroup;

.field private groupId:Ljava/lang/String;

.field private list:Landroid/widget/ListView;

.field private loadMoreFooter:Landroid/view/View;

.field private loading:Z

.field private nextCursor:Ljava/lang/String;

.field private selectedMember:Lcom/tzibbur/basic/model/TzbMember;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 39
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbBaseActivity;-><init>()V

    .line 56
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addAllowedByServer:Z

    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->showAddDialog()V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->nextCursor:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$1000(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->updateFooterVisibility()V

    return-void
.end method

.method static synthetic access$102(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 39
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->nextCursor:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic access$1100(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Landroid/app/AlertDialog;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addDialog:Landroid/app/AlertDialog;

    return-object v0
.end method

.method static synthetic access$1200(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->chooseFromContacts()V

    return-void
.end method

.method static synthetic access$1300(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Landroid/widget/EditText;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addPhoneEdit:Landroid/widget/EditText;

    return-object v0
.end method

.method static synthetic access$1400(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/util/List;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Ljava/util/List;

    .line 39
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->submitAdd(Ljava/util/List;)V

    return-void
.end method

.method static synthetic access$1500(Ljava/lang/StringBuilder;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Ljava/lang/StringBuilder;
    .param p1, "x1"    # Ljava/lang/String;

    .line 39
    invoke-static {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->appendLine(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1602(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Z

    .line 39
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addAllowedByServer:Z

    return p1
.end method

.method static synthetic access$1700(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 39
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->confirmRemove(Lcom/tzibbur/basic/model/TzbMember;)V

    return-void
.end method

.method static synthetic access$1800(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbMember;
    .param p2, "x2"    # Ljava/lang/String;

    .line 39
    invoke-direct {p0, p1, p2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->changeRole(Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1900(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 39
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->removeMember(Lcom/tzibbur/basic/model/TzbMember;)V

    return-void
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Z

    .line 39
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadMembers(Z)V

    return-void
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/model/TzbMember;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->selectedMember:Lcom/tzibbur/basic/model/TzbMember;

    return-object v0
.end method

.method static synthetic access$302(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)Lcom/tzibbur/basic/model/TzbMember;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 39
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->selectedMember:Lcom/tzibbur/basic/model/TzbMember;

    return-object p1
.end method

.method static synthetic access$400(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 39
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->showMemberActions(Lcom/tzibbur/basic/model/TzbMember;)V

    return-void
.end method

.method static synthetic access$500(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    return-object v0
.end method

.method static synthetic access$502(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbGroup;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbGroup;

    .line 39
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    return-object p1
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->applyGating()V

    return-void
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->showCountOfCap()V

    return-void
.end method

.method static synthetic access$802(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .param p1, "x1"    # Z

    .line 39
    iput-boolean p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loading:Z

    return p1
.end method

.method static synthetic access$900(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)Lcom/tzibbur/basic/ui/TzbMemberListAdapter;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    .line 39
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

    return-object v0
.end method

.method private static appendLine(Ljava/lang/StringBuilder;Ljava/lang/String;)V
    .locals 1
    .param p0, "sb"    # Ljava/lang/StringBuilder;
    .param p1, "line"    # Ljava/lang/String;

    .line 417
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-lez v0, :cond_0

    const/16 v0, 0xa

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 418
    :cond_0
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 419
    return-void
.end method

.method private applyGating()V
    .locals 3

    .line 186
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v0}, Lcom/tzibbur/basic/model/TzbGroup;->callerMayAddMembers()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addAllowedByServer:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    move v0, v1

    .line 187
    .local v0, "mayAdd":Z
    :goto_0
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addBtn:Landroid/widget/Button;

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    const/16 v1, 0x8

    :goto_1
    invoke-virtual {v2, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 188
    return-void
.end method

.method private canActOn(Lcom/tzibbur/basic/model/TzbMember;)Z
    .locals 2
    .param p1, "member"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 424
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v0}, Lcom/tzibbur/basic/model/TzbGroup;->callerIsAdmin()Z

    move-result v0

    if-eqz v0, :cond_0

    if-eqz p1, :cond_0

    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbMember;->userId:Ljava/lang/String;

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    .line 426
    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbSession;->userId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbMember;->kind:Ljava/lang/String;

    .line 432
    const-string v1, "service"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbMember;->userId:Ljava/lang/String;

    .line 433
    const-string v1, "00000000-0000-7000-8000-000000000001"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p1, Lcom/tzibbur/basic/model/TzbMember;->userId:Ljava/lang/String;

    .line 434
    const-string v1, "00000000-0000-7000-8000-000000000002"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 424
    :goto_0
    return v0
.end method

.method private changeRole(Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V
    .locals 3
    .param p1, "member"    # Lcom/tzibbur/basic/model/TzbMember;
    .param p2, "role"    # Ljava/lang/String;

    .line 498
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->groupId:Ljava/lang/String;

    .line 499
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;

    invoke-direct {v1, p0, v0, p1, p2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$19;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/lang/String;Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$20;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$20;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 516
    return-void
.end method

.method private chooseFromContacts()V
    .locals 2

    .line 330
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 331
    .local v0, "intent":Landroid/content/Intent;
    const/4 v1, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 332
    return-void
.end method

.method private confirmRemove(Lcom/tzibbur/basic/model/TzbMember;)V
    .locals 5
    .param p1, "member"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 462
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_menu_remove_member:I

    .line 463
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_remove_member_confirm:I

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

    .line 464
    invoke-virtual {v2, p1}, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->labelFor(Lcom/tzibbur/basic/model/TzbMember;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v2, v3, v4

    invoke-virtual {p0, v1, v3}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_remove:I

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$16;

    invoke-direct {v2, p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$16;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;)V

    .line 465
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 471
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 472
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 473
    return-void
.end method

.method private handleAction(ILcom/tzibbur/basic/model/TzbMember;)Z
    .locals 3
    .param p1, "itemId"    # I
    .param p2, "member"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 545
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_menu_add_member:I

    const/4 v1, 0x1

    if-ne p1, v0, :cond_0

    .line 546
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->showAddDialog()V

    .line 547
    return v1

    .line 549
    :cond_0
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_menu_refresh:I

    if-ne p1, v0, :cond_1

    .line 550
    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadMembers(Z)V

    .line 551
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadGroup()V

    .line 552
    return v1

    .line 554
    :cond_1
    const/4 v0, 0x0

    if-eqz p2, :cond_6

    invoke-direct {p0, p2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->canActOn(Lcom/tzibbur/basic/model/TzbMember;)Z

    move-result v2

    if-nez v2, :cond_2

    goto :goto_0

    .line 555
    :cond_2
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_menu_remove_member:I

    if-ne p1, v2, :cond_3

    .line 556
    invoke-direct {p0, p2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->confirmRemove(Lcom/tzibbur/basic/model/TzbMember;)V

    .line 557
    return v1

    .line 559
    :cond_3
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_menu_make_admin:I

    if-ne p1, v2, :cond_4

    .line 560
    const-string v0, "admin"

    invoke-direct {p0, p2, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->changeRole(Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V

    .line 561
    return v1

    .line 563
    :cond_4
    sget v2, Lcom/tzibbur/basic/R$id;->tzb_menu_remove_admin:I

    if-ne p1, v2, :cond_5

    .line 564
    const-string v0, "member"

    invoke-direct {p0, p2, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->changeRole(Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V

    .line 565
    return v1

    .line 567
    :cond_5
    return v0

    .line 554
    :cond_6
    :goto_0
    return v0
.end method

.method private loadGroup()V
    .locals 3

    .line 152
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->groupId:Ljava/lang/String;

    .line 153
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$5;

    invoke-direct {v1, p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$5;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/lang/String;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$6;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 183
    return-void
.end method

.method private loadMembers(Z)V
    .locals 4
    .param p1, "reset"    # Z

    .line 206
    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loading:Z

    if-eqz v0, :cond_0

    return-void

    .line 207
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loading:Z

    .line 208
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->groupId:Ljava/lang/String;

    .line 209
    .local v0, "gid":Ljava/lang/String;
    if-eqz p1, :cond_1

    const/4 v1, 0x0

    goto :goto_0

    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->nextCursor:Ljava/lang/String;

    .line 210
    .local v1, "cursor":Ljava/lang/String;
    :goto_0
    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;

    invoke-direct {v2, p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$7;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v3, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;

    invoke-direct {v3, p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$8;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)V

    invoke-static {v2, v3}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 240
    return-void
.end method

.method private removeMember(Lcom/tzibbur/basic/model/TzbMember;)V
    .locals 3
    .param p1, "member"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 476
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->groupId:Ljava/lang/String;

    .line 477
    .local v0, "gid":Ljava/lang/String;
    new-instance v1, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;

    invoke-direct {v1, p0, v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$17;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/lang/String;Lcom/tzibbur/basic/model/TzbMember;)V

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$18;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$18;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-static {v1, v2}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 495
    return-void
.end method

.method private showAddDialog()V
    .locals 7

    .line 257
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$layout;->tzb_add_member_dialog:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 258
    .local v0, "content":Landroid/view/View;
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_add_phone_edit:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    iput-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addPhoneEdit:Landroid/widget/EditText;

    .line 259
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addPhoneEdit:Landroid/widget/EditText;

    new-instance v3, Landroid/telephony/PhoneNumberFormattingTextWatcher;

    invoke-direct {v3}, Landroid/telephony/PhoneNumberFormattingTextWatcher;-><init>()V

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 263
    sget v1, Lcom/tzibbur/basic/R$id;->tzb_choose_contacts_btn:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    .line 266
    .local v1, "contactsBtn":Landroid/view/View;
    nop

    .line 267
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v3}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v3

    invoke-interface {v3}, Lcom/tzibbur/basic/store/TzbSession;->contactDiscovery()Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/16 v3, 0x8

    .line 266
    :goto_0
    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 268
    new-instance v3, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$9;

    invoke-direct {v3, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$9;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-virtual {v1, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 279
    move-object v3, v1

    .line 280
    .local v3, "contactsTarget":Landroid/view/View;
    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addPhoneEdit:Landroid/widget/EditText;

    new-instance v5, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$10;

    invoke-direct {v5, p0, v3}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$10;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Landroid/view/View;)V

    invoke-virtual {v4, v5}, Landroid/widget/EditText;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 294
    new-instance v4, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$11;

    invoke-direct {v4, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$11;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-virtual {v1, v4}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 305
    new-instance v4, Landroid/app/AlertDialog$Builder;

    invoke-direct {v4, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_add_member_title:I

    .line 306
    invoke-virtual {v4, v5}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    .line 307
    invoke-virtual {v4, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_add:I

    new-instance v6, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$12;

    invoke-direct {v6, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$12;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    .line 308
    invoke-virtual {v4, v5, v6}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 319
    invoke-virtual {v4, v5, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    .line 320
    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v2

    iput-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addDialog:Landroid/app/AlertDialog;

    .line 321
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addDialog:Landroid/app/AlertDialog;

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addPhoneEdit:Landroid/widget/EditText;

    invoke-static {v2, v4}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->attachDialogIme(Landroid/app/AlertDialog;Landroid/widget/EditText;)V

    .line 322
    return-void
.end method

.method private showCountOfCap()V
    .locals 6

    .line 196
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_title_extra:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 197
    .local v0, "titleExtra":Landroid/widget/TextView;
    if-eqz v0, :cond_1

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    if-nez v1, :cond_0

    goto :goto_0

    .line 198
    :cond_0
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_members_count_of_cap:I

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v2, v2, Lcom/tzibbur/basic/model/TzbGroup;->memberCount:I

    .line 199
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    iget v3, v3, Lcom/tzibbur/basic/model/TzbGroup;->memberCap:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x2

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v2, v4, v5

    const/4 v2, 0x1

    aput-object v3, v4, v2

    .line 198
    invoke-virtual {p0, v1, v4}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 200
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 201
    return-void

    .line 197
    :cond_1
    :goto_0
    return-void
.end method

.method private showMemberActions(Lcom/tzibbur/basic/model/TzbMember;)V
    .locals 5
    .param p1, "member"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 438
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->canActOn(Lcom/tzibbur/basic/model/TzbMember;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 439
    :cond_0
    const-string v0, "admin"

    iget-object v1, p1, Lcom/tzibbur/basic/model/TzbMember;->role:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    .line 440
    .local v0, "isAdmin":Z
    sget v1, Lcom/tzibbur/basic/R$string;->tzb_menu_remove_member:I

    .line 441
    invoke-virtual {p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 442
    if-eqz v0, :cond_1

    sget v2, Lcom/tzibbur/basic/R$string;->tzb_menu_remove_admin:I

    goto :goto_0

    :cond_1
    sget v2, Lcom/tzibbur/basic/R$string;->tzb_menu_make_admin:I

    :goto_0
    invoke-virtual {p0, v2}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    .line 444
    .local v1, "actions":[Ljava/lang/String;
    new-instance v2, Landroid/app/AlertDialog$Builder;

    invoke-direct {v2, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

    .line 445
    invoke-virtual {v3, p1}, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;->labelFor(Lcom/tzibbur/basic/model/TzbMember;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    new-instance v3, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;

    invoke-direct {v3, p0, p1, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$15;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Lcom/tzibbur/basic/model/TzbMember;Z)V

    .line 446
    invoke-virtual {v2, v1, v3}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_cancel:I

    .line 457
    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    .line 458
    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 459
    return-void
.end method

.method private submitAdd(Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 351
    .local p1, "phones":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 352
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->groupId:Ljava/lang/String;

    .line 356
    .local v0, "gid":Ljava/lang/String;
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    const/16 v2, 0x64

    invoke-interface {v1, v2}, Lcom/tzibbur/basic/store/TzbSession;->groupAddMaxPhones(I)I

    move-result v1

    .line 357
    .local v1, "chunk":I
    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;

    invoke-direct {v2, p0, p1, v1, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$13;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Ljava/util/List;ILjava/lang/String;)V

    new-instance v3, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;

    invoke-direct {v3, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$14;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-static {v2, v3}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    .line 414
    return-void
.end method

.method private updateFooterVisibility()V
    .locals 5

    .line 244
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->nextCursor:Ljava/lang/String;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 245
    .local v0, "show":Z
    :goto_0
    iget-boolean v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->footerShown:Z

    if-ne v0, v2, :cond_1

    return-void

    .line 246
    :cond_1
    if-eqz v0, :cond_2

    .line 247
    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->list:Landroid/widget/ListView;

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadMoreFooter:Landroid/view/View;

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4, v1}, Landroid/widget/ListView;->addFooterView(Landroid/view/View;Ljava/lang/Object;Z)V

    goto :goto_1

    .line 249
    :cond_2
    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->list:Landroid/widget/ListView;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadMoreFooter:Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->removeFooterView(Landroid/view/View;)Z

    .line 251
    :goto_1
    iput-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->footerShown:Z

    .line 252
    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 2
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 336
    invoke-super {p0, p1, p2, p3}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onActivityResult(IILandroid/content/Intent;)V

    .line 337
    const/4 v0, 0x2

    if-eq p1, v0, :cond_0

    return-void

    .line 338
    :cond_0
    const/4 v0, -0x1

    if-ne p2, v0, :cond_1

    if-eqz p3, :cond_1

    .line 339
    const-string v0, "tzb_phones"

    invoke-virtual {p3, v0}, Landroid/content/Intent;->getStringArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    .line 341
    .local v0, "phones":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    if-eqz v0, :cond_2

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->submitAdd(Ljava/util/List;)V

    goto :goto_0

    .line 342
    .end local v0
    :cond_1
    const/4 v0, 0x1

    if-ne p2, v0, :cond_2

    .line 343
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->showAddDialog()V

    goto :goto_1

    .line 342
    :cond_2
    :goto_0
    nop

    .line 345
    :goto_1
    return-void
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 64
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onCreate(Landroid/os/Bundle;)V

    .line 66
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 67
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->finish()V

    .line 68
    return-void

    .line 72
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->enforce(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 73
    return-void

    .line 75
    :cond_1
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "tzb_group_id"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->groupId:Ljava/lang/String;

    .line 76
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->groupId:Ljava/lang/String;

    if-nez v0, :cond_2

    .line 77
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->finish()V

    .line 78
    return-void

    .line 80
    :cond_2
    sget v0, Lcom/tzibbur/basic/R$layout;->tzb_member_list_activity:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->setContentView(I)V

    .line 83
    invoke-static {p0}, Lcom/tzibbur/basic/ui/TzbTctMenuBar;->hide(Landroid/app/Activity;)V

    .line 84
    sget v0, Lcom/tzibbur/basic/R$string;->tzb_members_title:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->setupTitleBar(Ljava/lang/CharSequence;Z)V

    .line 86
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_add_member_btn:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addBtn:Landroid/widget/Button;

    .line 87
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addBtn:Landroid/widget/Button;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$1;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$1;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 94
    sget v0, Lcom/tzibbur/basic/R$id;->tzb_member_list:I

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->list:Landroid/widget/ListView;

    .line 98
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->list:Landroid/widget/ListView;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setItemsCanFocus(Z)V

    .line 99
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    sget v3, Lcom/tzibbur/basic/R$layout;->tzb_member_list_footer:I

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->list:Landroid/widget/ListView;

    .line 100
    invoke-virtual {v0, v3, v4, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadMoreFooter:Landroid/view/View;

    .line 102
    new-instance v0, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->core:Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {v2}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v2

    invoke-interface {v2}, Lcom/tzibbur/basic/store/TzbSession;->userId()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, p0, v2}, Lcom/tzibbur/basic/ui/TzbMemberListAdapter;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

    .line 103
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->list:Landroid/widget/ListView;

    iget-object v2, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->adapter:Lcom/tzibbur/basic/ui/TzbMemberListAdapter;

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 104
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->list:Landroid/widget/ListView;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$2;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$2;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 118
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->list:Landroid/widget/ListView;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$3;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$3;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 133
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->list:Landroid/widget/ListView;

    new-instance v2, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$4;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$4;-><init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setOnItemLongClickListener(Landroid/widget/AdapterView$OnItemLongClickListener;)V

    .line 145
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadGroup()V

    .line 146
    invoke-direct {p0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadMembers(Z)V

    .line 147
    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 2
    .param p1, "menu"    # Landroid/view/Menu;

    .line 522
    invoke-virtual {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$menu;->tzb_members_menu:I

    invoke-virtual {v0, v1, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    .line 523
    const/4 v0, 0x1

    return v0
.end method

# overrides: Lcom/tzibbur/basic/ui/TzbBaseActivity;
.method public onGroupsChanged()V
    .locals 1

    .line 576
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadMembers(Z)V

    .line 577
    invoke-direct {p0}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->loadGroup()V

    .line 578
    return-void
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 2
    .param p1, "item"    # Landroid/view/MenuItem;

    .line 540
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    iget-object v1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->selectedMember:Lcom/tzibbur/basic/model/TzbMember;

    invoke-direct {p0, v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->handleAction(ILcom/tzibbur/basic/model/TzbMember;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    .line 541
    :cond_0
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result v0

    return v0
.end method

.method public onPrepareOptionsMenu(Landroid/view/Menu;)Z
    .locals 7
    .param p1, "menu"    # Landroid/view/Menu;

    .line 528
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->group:Lcom/tzibbur/basic/model/TzbGroup;

    invoke-virtual {v0}, Lcom/tzibbur/basic/model/TzbGroup;->callerMayAddMembers()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->addAllowedByServer:Z

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    .line 529
    .local v0, "mayAdd":Z
    :goto_0
    sget v3, Lcom/tzibbur/basic/R$id;->tzb_menu_add_member:I

    invoke-interface {p1, v3}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v3

    invoke-interface {v3, v0}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 530
    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->selectedMember:Lcom/tzibbur/basic/model/TzbMember;

    invoke-direct {p0, v3}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->canActOn(Lcom/tzibbur/basic/model/TzbMember;)Z

    move-result v3

    .line 531
    .local v3, "actionable":Z
    if-eqz v3, :cond_1

    iget-object v4, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->selectedMember:Lcom/tzibbur/basic/model/TzbMember;

    iget-object v4, v4, Lcom/tzibbur/basic/model/TzbMember;->role:Ljava/lang/String;

    const-string v5, "admin"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    move v4, v1

    goto :goto_1

    :cond_1
    move v4, v2

    .line 532
    .local v4, "targetIsAdmin":Z
    :goto_1
    sget v5, Lcom/tzibbur/basic/R$id;->tzb_menu_remove_member:I

    invoke-interface {p1, v5}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v5

    invoke-interface {v5, v3}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 533
    sget v5, Lcom/tzibbur/basic/R$id;->tzb_menu_make_admin:I

    invoke-interface {p1, v5}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v5

    if-eqz v3, :cond_2

    if-nez v4, :cond_2

    move v6, v1

    goto :goto_2

    :cond_2
    move v6, v2

    :goto_2
    invoke-interface {v5, v6}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 534
    sget v5, Lcom/tzibbur/basic/R$id;->tzb_menu_remove_admin:I

    invoke-interface {p1, v5}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v5

    if-eqz v3, :cond_3

    if-eqz v4, :cond_3

    goto :goto_3

    :cond_3
    move v1, v2

    :goto_3
    invoke-interface {v5, v1}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 535
    invoke-super {p0, p1}, Lcom/tzibbur/basic/ui/TzbBaseActivity;->onPrepareOptionsMenu(Landroid/view/Menu;)Z

    move-result v1

    return v1
.end method
