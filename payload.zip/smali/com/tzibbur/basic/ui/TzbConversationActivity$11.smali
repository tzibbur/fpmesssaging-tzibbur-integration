.class Lcom/tzibbur/basic/ui/TzbConversationActivity$11;
.super Ljava/lang/Object;
.source "TzbConversationActivity.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbConversationActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbConversationActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbConversationActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 358
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 4
    .param p1, "v"    # Landroid/view/View;
    .param p2, "keyCode"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .line 361
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    .line 362
    :cond_0
    const/16 v0, 0x14

    const/4 v2, 0x1

    if-ne p2, v0, :cond_4

    .line 363
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v0

    iget-object v3, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v3}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$300(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/ListView;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/ListView;->getCount()I

    move-result v3

    sub-int/2addr v3, v2

    if-lt v0, v3, :cond_3

    .line 364
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1800(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z

    move-result v0

    if-eqz v0, :cond_1

    return v2

    .line 365
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$100(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 366
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$200(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    goto :goto_0

    .line 370
    :cond_2
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1700(Lcom/tzibbur/basic/ui/TzbConversationActivity;)Z

    .line 372
    :goto_0
    return v2

    .line 374
    :cond_3
    return v1

    .line 376
    :cond_4
    const/16 v0, 0x13

    if-ne p2, v0, :cond_5

    .line 377
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbConversationActivity$11;->this$0:Lcom/tzibbur/basic/ui/TzbConversationActivity;

    invoke-static {v0, v2}, Lcom/tzibbur/basic/ui/TzbConversationActivity;->access$1800(Lcom/tzibbur/basic/ui/TzbConversationActivity;Z)Z

    move-result v0

    if-eqz v0, :cond_5

    return v2

    .line 381
    :cond_5
    return v1
.end method
