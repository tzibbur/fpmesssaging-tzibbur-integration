.class Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$5;
.super Ljava/lang/Object;
.source "TzbGroupInfoActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 108
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 111
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity$5;->this$0:Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;->access$400(Lcom/tzibbur/basic/ui/TzbGroupInfoActivity;)V

    .line 112
    return-void
.end method
