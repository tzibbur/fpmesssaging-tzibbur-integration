.class Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$20;
.super Ljava/lang/Object;
.source "TzbGroupMembersActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->changeRole(Lcom/tzibbur/basic/model/TzbMember;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Lcom/tzibbur/basic/model/TzbMember;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 504
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 1
    .param p1, "error"    # Ljava/lang/Exception;

    .line 513
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->toastProblem(Ljava/lang/Exception;)V

    .line 514
    return-void
.end method

.method public onResult(Lcom/tzibbur/basic/model/TzbMember;)V
    .locals 2
    .param p1, "result"    # Lcom/tzibbur/basic/model/TzbMember;

    .line 507
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;->access$200(Lcom/tzibbur/basic/ui/TzbGroupMembersActivity;Z)V

    .line 508
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 504
    check-cast p1, Lcom/tzibbur/basic/model/TzbMember;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbGroupMembersActivity$20;->onResult(Lcom/tzibbur/basic/model/TzbMember;)V

    return-void
.end method
