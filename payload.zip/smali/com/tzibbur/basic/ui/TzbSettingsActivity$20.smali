.class Lcom/tzibbur/basic/ui/TzbSettingsActivity$20;
.super Ljava/lang/Object;
.source "TzbSettingsActivity.java"

# interfaces
.implements Lcom/tzibbur/basic/util/TzbBg$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbSettingsActivity;->signOut()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tzibbur/basic/util/TzbBg$Callback<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/ui/TzbSettingsActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 447
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "error"    # Ljava/lang/Exception;

    .line 455
    instance-of v0, p1, Lcom/tzibbur/basic/net/TzbProblem;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Lcom/tzibbur/basic/net/TzbProblem;

    iget v0, v0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x191

    if-ne v0, v1, :cond_0

    .line 457
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    .line 458
    return-void

    .line 462
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$1200(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    .line 463
    return-void
.end method

.method public bridge synthetic onResult(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 447
    check-cast p1, Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/tzibbur/basic/ui/TzbSettingsActivity$20;->onResult(Ljava/lang/Void;)V

    return-void
.end method

.method public onResult(Ljava/lang/Void;)V
    .locals 1
    .param p1, "result"    # Ljava/lang/Void;

    .line 450
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbSettingsActivity$20;->this$0:Lcom/tzibbur/basic/ui/TzbSettingsActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbSettingsActivity;->access$1100(Lcom/tzibbur/basic/ui/TzbSettingsActivity;)V

    .line 451
    return-void
.end method
