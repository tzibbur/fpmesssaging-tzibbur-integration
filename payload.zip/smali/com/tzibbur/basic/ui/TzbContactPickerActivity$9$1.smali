.class Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$1;
.super Ljava/lang/Object;
.source "TzbContactPickerActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;)V
    .locals 0
    .param p1, "this$1"    # Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 291
    iput-object p1, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 294
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$500(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Landroid/widget/TextView;

    move-result-object v0

    sget v1, Lcom/tzibbur/basic/R$string;->tzb_contacts_empty_device:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 295
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$600(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)Landroid/widget/Button;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 296
    iget-object v0, p0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9$1;->this$1:Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;

    iget-object v0, v0, Lcom/tzibbur/basic/ui/TzbContactPickerActivity$9;->this$0:Lcom/tzibbur/basic/ui/TzbContactPickerActivity;

    invoke-static {v0}, Lcom/tzibbur/basic/ui/TzbContactPickerActivity;->access$700(Lcom/tzibbur/basic/ui/TzbContactPickerActivity;)V

    .line 297
    return-void
.end method
