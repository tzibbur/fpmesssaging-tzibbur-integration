.class public final Lcom/tzibbur/basic/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static tzb_bubble_in:I = 0x7f0701a2    # @drawable/tzb_bubble_in 'res/drawable/tzb_bubble_in.xml'

.field public static tzb_bubble_out:I = 0x7f0701a3    # @drawable/tzb_bubble_out 'res/drawable/tzb_bubble_out.xml'

.field public static tzb_bubble_pending:I = 0x7f0701a4    # @drawable/tzb_bubble_pending 'res/drawable/tzb_bubble_pending.xml'

.field public static tzb_bubble_sponsored:I = 0x7f0701a5    # @drawable/tzb_bubble_sponsored 'res/drawable/tzb_bubble_sponsored.xml'

.field public static tzb_bubble_system:I = 0x7f0701a6    # @drawable/tzb_bubble_system 'res/drawable/tzb_bubble_system.xml'

.field public static tzb_button_bg:I = 0x7f0701a7    # @drawable/tzb_button_bg 'res/drawable/tzb_button_bg.xml'

.field public static tzb_button_primary_bg:I = 0x7f0701a8    # @drawable/tzb_button_primary_bg 'res/drawable/tzb_button_primary_bg.xml'

.field public static tzb_compose_edit_bg:I = 0x7f0701a9    # @drawable/tzb_compose_edit_bg 'res/drawable/tzb_compose_edit_bg.xml'

.field public static tzb_enroll_edit_bg:I = 0x7f0701aa    # @drawable/tzb_enroll_edit_bg 'res/drawable/tzb_enroll_edit_bg.xml'

.field public static tzb_focusable_item_bg:I = 0x7f0701ab    # @drawable/tzb_focusable_item_bg 'res/drawable/tzb_focusable_item_bg.xml'

.field public static tzb_ic_launcher:I = 0x7f0701ac    # @drawable/tzb_ic_launcher 'res/drawable-anydpi-v24/tzb_ic_launcher.xml'

.field public static tzb_ic_overflow:I = 0x7f0701ad    # @drawable/tzb_ic_overflow 'res/drawable/tzb_ic_overflow.xml'

.field public static tzb_legal_scroll_bg:I = 0x7f0701ae    # @drawable/tzb_legal_scroll_bg 'res/drawable/tzb_legal_scroll_bg.xml'

.field public static tzb_notice_bg:I = 0x7f0701af    # @drawable/tzb_notice_bg 'res/drawable/tzb_notice_bg.xml'

.field public static tzb_title_focus_bg:I = 0x7f0701b0    # @drawable/tzb_title_focus_bg 'res/drawable/tzb_title_focus_bg.xml'

.field public static tzb_unread_badge_bg:I = 0x7f0701b1    # @drawable/tzb_unread_badge_bg 'res/drawable/tzb_unread_badge_bg.xml'


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
