.class public final Lcom/tzibbur/basic/net/TzbWebSocket;
.super Ljava/lang/Object;
.source "TzbWebSocket.java"


# static fields
.field private static final ACCEPT_GUID:Ljava/lang/String; = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

.field private static final APP_PING_INTERVAL_MS:J = 0xafc8L

.field private static final CONNECT_TIMEOUT_MS:I = 0x3a98

.field private static final MAX_FRAME_PAYLOAD:I = 0x400000

.field private static final MAX_HTTP_LINE:I = 0x4000

.field private static final OP_BINARY:I = 0x2

.field private static final OP_CLOSE:I = 0x8

.field private static final OP_CONT:I = 0x0

.field private static final OP_PING:I = 0x9

.field private static final OP_PONG:I = 0xa

.field private static final OP_TEXT:I = 0x1

.field private static final READ_TIMEOUT_MS:I = 0x15f90


# instance fields
.field private volatile clientClosed:Z

.field private volatile finished:Z

.field private volatile in:Ljava/io/InputStream;

.field private final listener:Lcom/tzibbur/basic/net/TzbSocketListener;

.field private volatile open:Z

.field private volatile out:Ljava/io/OutputStream;

.field private volatile outboundPausedUntilMs:J

.field private volatile pingIntervalMs:J

.field private volatile pingTimer:Ljava/util/Timer;

.field private final random:Ljava/security/SecureRandom;

.field private volatile socket:Ljava/net/Socket;

.field private final tokens:Lcom/tzibbur/basic/net/TzbTokenSupplier;

.field private final url:Ljava/lang/String;

.field private final writeLock:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/tzibbur/basic/net/TzbTokenSupplier;Lcom/tzibbur/basic/net/TzbSocketListener;)V
    .locals 2
    .param p1, "url"    # Ljava/lang/String;
    .param p2, "tokens"    # Lcom/tzibbur/basic/net/TzbTokenSupplier;
    .param p3, "listener"    # Lcom/tzibbur/basic/net/TzbSocketListener;

    .line 87
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 71
    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->random:Ljava/security/SecureRandom;

    .line 72
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->writeLock:Ljava/lang/Object;

    .line 82
    const-wide/32 v0, 0xafc8

    iput-wide v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->pingIntervalMs:J

    .line 88
    iput-object p1, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->url:Ljava/lang/String;

    .line 89
    iput-object p2, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->tokens:Lcom/tzibbur/basic/net/TzbTokenSupplier;

    .line 90
    iput-object p3, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->listener:Lcom/tzibbur/basic/net/TzbSocketListener;

    .line 91
    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/net/TzbWebSocket;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 47
    invoke-direct {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->runConnection()V

    return-void
.end method

.method private applyHeartbeat(I)V
    .locals 7
    .param p1, "heartbeatSeconds"    # I

    .line 521
    const/4 v0, 0x5

    if-lt p1, v0, :cond_3

    const/16 v0, 0x258

    if-le p1, v0, :cond_0

    goto :goto_1

    .line 524
    :cond_0
    int-to-long v0, p1

    const-wide/16 v2, 0x3e8

    mul-long/2addr v0, v2

    const-wide/16 v2, 0x2

    div-long/2addr v0, v2

    .line 525
    .local v0, "pingMs":J
    iget-wide v2, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->pingIntervalMs:J

    cmp-long v2, v0, v2

    if-nez v2, :cond_1

    .line 526
    return-void

    .line 528
    :cond_1
    iput-wide v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->pingIntervalMs:J

    .line 530
    :try_start_0
    iget-object v2, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->socket:Ljava/net/Socket;

    .line 531
    .local v2, "s":Ljava/net/Socket;
    if-eqz v2, :cond_2

    int-to-long v3, p1

    const-wide/16 v5, 0xbb8

    mul-long/2addr v3, v5

    long-to-int v3, v3

    invoke-virtual {v2, v3}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 534
    .end local v2
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    :cond_2

    goto :goto_0

    .line 532
    :catch_0
    move-exception v2

    .line 535
    :goto_0
    invoke-direct {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->stopPingTimer()V

    .line 536
    invoke-direct {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->startPingTimer()V

    .line 537
    return-void

    .line 522
    .end local v0
    :cond_3
    :goto_1
    return-void
.end method

.method private closeSocket()V
    .locals 2

    .line 557
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->open:Z

    .line 558
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->socket:Ljava/net/Socket;

    .line 559
    .local v0, "s":Ljava/net/Socket;
    if-eqz v0, :cond_0

    .line 561
    :try_start_0
    invoke-virtual {v0}, Ljava/net/Socket;->close()V

    .line 563
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 562
    :catch_0
    move-exception v1

    .line 565
    :cond_0
    :goto_0
    return-void
.end method

.method private deliverClosed(III)V
    .locals 1
    .param p1, "closeCode"    # I
    .param p2, "httpStatus"    # I
    .param p3, "retryAfterSeconds"    # I

    .line 569
    monitor-enter p0

    .line 570
    :try_start_0
    iget-boolean v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->finished:Z

    if-eqz v0, :cond_0

    monitor-exit p0

    return-void

    .line 571
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->finished:Z

    .line 572
    monitor-exit p0

    .line 573
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->open:Z

    .line 574
    iget-boolean v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->clientClosed:Z

    if-eqz v0, :cond_1

    return-void

    .line 575
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->listener:Lcom/tzibbur/basic/net/TzbSocketListener;

    invoke-interface {v0, p1, p2, p3}, Lcom/tzibbur/basic/net/TzbSocketListener;->onClosed(III)V

    .line 576
    return-void

    .line 572
    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method private static expectedAccept(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "key"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 504
    :try_start_0
    const-string v0, "SHA-1"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    .line 505
    .local v0, "sha1":Ljava/security/MessageDigest;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "UTF-8"

    invoke-virtual {v1, v2}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v1

    .line 506
    .local v1, "digest":[B
    const/4 v2, 0x2

    invoke-static {v1, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v2

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v2

    .line 507
    .end local v0
    .end local v1
    :catch_0
    move-exception v0

    .line 508
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/io/IOException;

    const-string v2, "cannot compute Sec-WebSocket-Accept"

    invoke-direct {v1, v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1
.end method

.method private handleText(Ljava/lang/String;)V
    .locals 13
    .param p1, "text"    # Ljava/lang/String;

    .line 351
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 354
    .local v0, "frame":Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    nop

    .line 355
    const-string v1, "type"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 356
    .local v1, "type":Ljava/lang/String;
    const-string v3, "hello"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_4

    .line 357
    const-string v3, "protocolVersion"

    const/4 v5, 0x1

    invoke-virtual {v0, v3, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    .line 358
    .local v3, "version":I
    if-le v3, v5, :cond_0

    .line 359
    iget-object v2, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->listener:Lcom/tzibbur/basic/net/TzbSocketListener;

    invoke-interface {v2, v3}, Lcom/tzibbur/basic/net/TzbSocketListener;->onProtocolTooNew(I)V

    .line 360
    invoke-virtual {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->close()V

    .line 361
    return-void

    .line 365
    :cond_0
    const-string v5, "limits"

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 366
    .local v5, "limits":Lorg/json/JSONObject;
    if-eqz v5, :cond_1

    const-string v6, "heartbeatSeconds"

    invoke-virtual {v5, v6, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v6

    goto :goto_0

    :cond_1
    move v6, v4

    :goto_0
    move v10, v6

    .line 367
    .local v10, "heartbeat":I
    if-eqz v5, :cond_2

    .line 368
    const-string v6, "maxConnectionsPerDevice"

    invoke-virtual {v5, v6, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v6

    move v11, v6

    goto :goto_1

    :cond_2
    move v11, v4

    .line 369
    .local v11, "maxConnections":I
    :goto_1
    if-eqz v5, :cond_3

    const-string v6, "maxFrameBytes"

    invoke-virtual {v5, v6, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v4

    :cond_3
    move v12, v4

    .line 370
    .local v12, "maxFrame":I
    invoke-direct {p0, v10}, Lcom/tzibbur/basic/net/TzbWebSocket;->applyHeartbeat(I)V

    .line 371
    iget-object v7, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->listener:Lcom/tzibbur/basic/net/TzbSocketListener;

    const-string v4, "userId"

    invoke-virtual {v0, v4, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v4, "deviceId"

    invoke-virtual {v0, v4, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-interface/range {v7 .. v12}, Lcom/tzibbur/basic/net/TzbSocketListener;->onHello(Ljava/lang/String;Ljava/lang/String;III)V

    .line 373
    .end local v3
    .end local v5
    .end local v10
    .end local v11
    .end local v12
    goto/16 :goto_4

    :cond_4
    const-string v3, "messages"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-string v6, "groupId"

    if-eqz v5, :cond_5

    .line 374
    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    .line 375
    .local v3, "items":Lorg/json/JSONArray;
    invoke-static {v3}, Lcom/tzibbur/basic/net/TzbJson;->messages(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v5

    .line 376
    .local v5, "batch":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    iget-object v7, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->listener:Lcom/tzibbur/basic/net/TzbSocketListener;

    invoke-virtual {v0, v6, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 377
    const-string v6, "hasMore"

    invoke-virtual {v0, v6, v4}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v4

    .line 376
    invoke-interface {v7, v2, v5, v4}, Lcom/tzibbur/basic/net/TzbSocketListener;->onMessages(Ljava/lang/String;Ljava/util/List;Z)V

    .line 378
    .end local v3
    .end local v5
    goto :goto_4

    :cond_5
    const-string v3, "group"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6

    .line 379
    iget-object v2, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->listener:Lcom/tzibbur/basic/net/TzbSocketListener;

    invoke-static {v0}, Lcom/tzibbur/basic/net/TzbJson;->groupEvent(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbGroupEvent;

    move-result-object v3

    invoke-interface {v2, v3}, Lcom/tzibbur/basic/net/TzbSocketListener;->onGroupEvent(Lcom/tzibbur/basic/model/TzbGroupEvent;)V

    goto :goto_4

    .line 380
    :cond_6
    const-string v3, "read"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_8

    .line 383
    const-string v3, "readSeq"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    const-wide/16 v7, -0x1

    if-eqz v4, :cond_7

    .line 384
    goto :goto_2

    :cond_7
    const-string v3, "seq"

    :goto_2
    invoke-virtual {v0, v3, v7, v8}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v3

    .line 385
    .local v3, "readSeq":J
    const-wide/16 v7, 0x0

    cmp-long v5, v3, v7

    if-ltz v5, :cond_9

    .line 386
    iget-object v5, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->listener:Lcom/tzibbur/basic/net/TzbSocketListener;

    invoke-virtual {v0, v6, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v5, v2, v3, v4}, Lcom/tzibbur/basic/net/TzbSocketListener;->onRead(Ljava/lang/String;J)V

    goto :goto_3

    .line 388
    .end local v3
    :cond_8
    const-string v3, "pong"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    :cond_9
    :goto_3
    goto :goto_4

    .line 390
    :cond_a
    const-string v3, "error"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_b

    .line 391
    iget-object v3, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->listener:Lcom/tzibbur/basic/net/TzbSocketListener;

    const-string v4, "code"

    invoke-virtual {v0, v4, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "detail"

    invoke-virtual {v0, v5, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v3, v4, v2}, Lcom/tzibbur/basic/net/TzbSocketListener;->onErrorFrame(Ljava/lang/String;Ljava/lang/String;)V

    .line 394
    :cond_b
    :goto_4
    return-void

    .line 352
    .end local v0
    .end local v1
    :catch_0
    move-exception v0

    .line 353
    .local v0, "e":Lorg/json/JSONException;
    return-void
.end method

.method private static parseStatusLine(Ljava/lang/String;)I
    .locals 4
    .param p0, "statusLine"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 480
    const-string v0, " "

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 481
    .local v0, "parts":[Ljava/lang/String;
    array-length v1, v0

    const/4 v2, 0x2

    if-lt v1, v2, :cond_0

    .line 483
    const/4 v1, 0x1

    :try_start_0
    aget-object v1, v0, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    .line 484
    :catch_0
    move-exception v1

    .line 485
    .local v1, "e":Ljava/lang/NumberFormatException;
    new-instance v2, Ljava/io/IOException;

    const-string v3, "malformed handshake status code"

    invoke-direct {v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 481
    .end local v1
    :cond_0
    new-instance v1, Ljava/io/IOException;

    const-string v2, "malformed handshake status line"

    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method private readByte()I
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 445
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->in:Ljava/io/InputStream;

    .line 446
    .local v0, "i":Ljava/io/InputStream;
    if-eqz v0, :cond_1

    .line 447
    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v1

    .line 448
    .local v1, "b":I
    if-ltz v1, :cond_0

    .line 449
    return v1

    .line 448
    :cond_0
    new-instance v2, Ljava/io/IOException;

    const-string v3, "connection closed by peer"

    invoke-direct {v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 446
    .end local v1
    :cond_1
    new-instance v1, Ljava/io/IOException;

    const-string v2, "socket not open"

    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method private readFully(I)[B
    .locals 6
    .param p1, "n"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 453
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->in:Ljava/io/InputStream;

    .line 454
    .local v0, "i":Ljava/io/InputStream;
    if-eqz v0, :cond_2

    .line 455
    new-array v1, p1, [B

    .line 456
    .local v1, "buf":[B
    const/4 v2, 0x0

    .line 457
    .local v2, "off":I
    :goto_0
    if-ge v2, p1, :cond_1

    .line 458
    sub-int v3, p1, v2

    invoke-virtual {v0, v1, v2, v3}, Ljava/io/InputStream;->read([BII)I

    move-result v3

    .line 459
    .local v3, "read":I
    if-ltz v3, :cond_0

    .line 460
    add-int/2addr v2, v3

    .line 461
    .end local v3
    goto :goto_0

    .line 459
    .restart local v3
    :cond_0
    new-instance v4, Ljava/io/IOException;

    const-string v5, "connection closed mid-frame"

    invoke-direct {v4, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 462
    .end local v3
    :cond_1
    return-object v1

    .line 454
    .end local v1
    .end local v2
    :cond_2
    new-instance v1, Ljava/io/IOException;

    const-string v2, "socket not open"

    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method private static readHeaders(Ljava/io/InputStream;)Ljava/util/Map;
    .locals 5
    .param p0, "in"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/InputStream;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 490
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 492
    .local v0, "headers":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    :goto_0
    invoke-static {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->readHttpLine(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v1

    .line 493
    .local v1, "line":Ljava/lang/String;
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    return-object v0

    .line 494
    :cond_0
    const/16 v2, 0x3a

    invoke-virtual {v1, v2}, Ljava/lang/String;->indexOf(I)I

    move-result v2

    .line 495
    .local v2, "colon":I
    if-gtz v2, :cond_1

    goto :goto_0

    .line 496
    :cond_1
    const/4 v3, 0x0

    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v3, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    .line 497
    .local v3, "name":Ljava/lang/String;
    add-int/lit8 v4, v2, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    .line 498
    .local v4, "value":Ljava/lang/String;
    invoke-interface {v0, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 499
    .end local v1
    .end local v2
    .end local v3
    .end local v4
    goto :goto_0
.end method

.method private static readHttpLine(Ljava/io/InputStream;)Ljava/lang/String;
    .locals 4
    .param p0, "in"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 467
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/16 v1, 0x50

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 469
    .local v0, "line":Ljava/io/ByteArrayOutputStream;
    :goto_0
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v1

    .line 470
    .local v1, "b":I
    if-ltz v1, :cond_3

    .line 471
    const/16 v2, 0xa

    if-ne v1, v2, :cond_0

    .line 475
    .end local v1
    new-instance v1, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    const-string v3, "UTF-8"

    invoke-direct {v1, v2, v3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    return-object v1

    .line 472
    .restart local v1
    :cond_0
    const/16 v2, 0xd

    if-eq v1, v2, :cond_1

    invoke-virtual {v0, v1}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 473
    :cond_1
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v2

    const/16 v3, 0x4000

    if-gt v2, v3, :cond_2

    .line 474
    .end local v1
    goto :goto_0

    .line 473
    .restart local v1
    :cond_2
    new-instance v2, Ljava/io/IOException;

    const-string v3, "handshake header too long"

    invoke-direct {v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 470
    :cond_3
    new-instance v2, Ljava/io/IOException;

    const-string v3, "connection closed during handshake"

    invoke-direct {v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method private readLoop()V
    .locals 18
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 269
    move-object/from16 v1, p0

    const/4 v0, 0x0

    .line 270
    .local v0, "fragments":Ljava/io/ByteArrayOutputStream;
    const/4 v2, 0x0

    move v3, v2

    move-object v2, v0

    .line 272
    .end local v0
    .local v2, "fragments":Ljava/io/ByteArrayOutputStream;
    .local v3, "fragmentOpcode":I
    :goto_0
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->readByte()I

    move-result v4

    .line 273
    .local v4, "b0":I
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->readByte()I

    move-result v5

    .line 274
    .local v5, "b1":I
    and-int/lit16 v0, v4, 0x80

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_1

    :cond_0
    move v0, v6

    :goto_1
    move v8, v0

    .line 275
    .local v8, "fin":Z
    and-int/lit8 v9, v4, 0xf

    .line 276
    .local v9, "opcode":I
    and-int/lit16 v0, v5, 0x80

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    goto :goto_2

    :cond_1
    move v0, v6

    :goto_2
    move v10, v0

    .line 277
    .local v10, "masked":Z
    and-int/lit8 v0, v5, 0x7f

    int-to-long v11, v0

    .line 278
    .local v11, "length":J
    const-wide/16 v13, 0x7e

    cmp-long v0, v11, v13

    const/16 v13, 0x8

    if-nez v0, :cond_2

    .line 279
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->readByte()I

    move-result v0

    int-to-long v14, v0

    shl-long/2addr v14, v13

    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->readByte()I

    move-result v0

    move/from16 v17, v8

    const/16 v16, 0x1

    .end local v8
    .local v17, "fin":Z
    int-to-long v7, v0

    or-long v11, v14, v7

    goto :goto_4

    .line 280
    .end local v17
    .restart local v8
    :cond_2
    move/from16 v17, v8

    const/16 v16, 0x1

    .end local v8
    .restart local v17
    const-wide/16 v7, 0x7f

    cmp-long v0, v11, v7

    if-nez v0, :cond_3

    .line 281
    const-wide/16 v7, 0x0

    .line 282
    .end local v11
    .local v7, "length":J
    const/4 v0, 0x0

    move-wide v11, v7

    .end local v7
    .local v0, "i":I
    .restart local v11
    :goto_3
    if-ge v0, v13, :cond_3

    .line 283
    shl-long v7, v11, v13

    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->readByte()I

    move-result v14

    int-to-long v14, v14

    or-long v11, v7, v14

    .line 282
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    .line 286
    .end local v0
    :cond_3
    :goto_4
    const-wide/16 v7, 0x0

    cmp-long v0, v11, v7

    if-ltz v0, :cond_10

    const-wide/32 v7, 0x400000

    cmp-long v0, v11, v7

    if-gtz v0, :cond_10

    .line 290
    if-eqz v10, :cond_4

    const/4 v0, 0x4

    invoke-direct {v1, v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->readFully(I)[B

    move-result-object v0

    goto :goto_5

    :cond_4
    const/4 v0, 0x0

    :goto_5
    move-object v7, v0

    .line 291
    .local v7, "maskKey":[B
    long-to-int v0, v11

    invoke-direct {v1, v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->readFully(I)[B

    move-result-object v8

    .line 292
    .local v8, "payload":[B
    if-eqz v7, :cond_5

    .line 293
    const/4 v0, 0x0

    .restart local v0
    :goto_6
    array-length v14, v8

    if-ge v0, v14, :cond_5

    .line 294
    aget-byte v14, v8, v0

    and-int/lit8 v15, v0, 0x3

    aget-byte v15, v7, v15

    xor-int/2addr v14, v15

    int-to-byte v14, v14

    aput-byte v14, v8, v0

    .line 293
    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    .line 298
    .end local v0
    :cond_5
    const/16 v0, 0x9

    const/16 v14, 0xa

    if-ne v9, v0, :cond_6

    .line 300
    invoke-direct {v1, v14, v8}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendFrame(I[B)V

    .line 301
    goto/16 :goto_0

    .line 303
    :cond_6
    if-ne v9, v14, :cond_7

    .line 304
    goto/16 :goto_0

    .line 306
    :cond_7
    const/4 v0, 0x2

    if-ne v9, v13, :cond_a

    .line 307
    const/4 v14, -0x1

    .line 308
    .local v14, "code":I
    array-length v15, v8

    if-lt v15, v0, :cond_8

    .line 309
    aget-byte v15, v8, v6

    and-int/lit16 v15, v15, 0xff

    shl-int/2addr v15, v13

    aget-byte v13, v8, v16

    and-int/lit16 v13, v13, 0xff

    or-int v14, v15, v13

    .line 312
    :cond_8
    :try_start_0
    array-length v13, v8

    if-lt v13, v0, :cond_9

    .line 313
    aget-byte v13, v8, v6

    aget-byte v15, v8, v16

    new-array v0, v0, [B

    aput-byte v13, v0, v6

    aput-byte v15, v0, v16

    goto :goto_7

    :cond_9
    new-array v0, v6, [B

    .line 312
    :goto_7
    const/16 v6, 0x8

    invoke-direct {v1, v6, v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendFrame(I[B)V

    .line 316
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_8

    .line 314
    :catch_0
    move-exception v0

    .line 317
    :goto_8
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->closeSocket()V

    .line 318
    const/4 v0, -0x1

    invoke-direct {v1, v14, v0, v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->deliverClosed(III)V

    .line 319
    return-void

    .line 321
    .end local v14
    :cond_a
    move/from16 v13, v16

    if-eq v9, v13, :cond_b

    if-eq v9, v0, :cond_b

    if-nez v9, :cond_e

    .line 322
    :cond_b
    if-eqz v9, :cond_c

    .line 323
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 324
    .end local v2
    .local v0, "fragments":Ljava/io/ByteArrayOutputStream;
    move v2, v9

    move v3, v2

    move-object v2, v0

    .line 326
    .end local v0
    .restart local v2
    :cond_c
    if-nez v2, :cond_d

    .line 327
    goto/16 :goto_0

    .line 329
    :cond_d
    array-length v0, v8

    invoke-virtual {v2, v8, v6, v0}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 330
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v0

    const/high16 v6, 0x400000

    if-gt v0, v6, :cond_f

    .line 333
    if-eqz v17, :cond_e

    .line 334
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    .line 335
    .local v0, "whole":[B
    const/4 v2, 0x0

    .line 336
    const/4 v13, 0x1

    if-ne v3, v13, :cond_e

    .line 337
    new-instance v6, Ljava/lang/String;

    const-string v13, "UTF-8"

    invoke-direct {v6, v0, v13}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-direct {v1, v6}, Lcom/tzibbur/basic/net/TzbWebSocket;->handleText(Ljava/lang/String;)V

    .line 343
    .end local v0
    .end local v4
    .end local v5
    .end local v7
    .end local v8
    .end local v9
    .end local v10
    .end local v11
    .end local v17
    :cond_e
    goto/16 :goto_0

    .line 331
    .restart local v4
    .restart local v5
    .restart local v7
    .restart local v8
    .restart local v9
    .restart local v10
    .restart local v11
    .restart local v17
    :cond_f
    new-instance v0, Ljava/io/IOException;

    const-string v6, "fragmented message too large"

    invoke-direct {v0, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 287
    .end local v7
    .end local v8
    :cond_10
    new-instance v0, Ljava/io/IOException;

    const-string v6, "frame payload too large"

    invoke-direct {v0, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private runConnection()V
    .locals 19

    .line 183
    move-object/from16 v1, p0

    const/4 v2, -0x1

    :try_start_0
    iget-object v0, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->url:Ljava/lang/String;

    invoke-static {v0}, Ljava/net/URI;->create(Ljava/lang/String;)Ljava/net/URI;

    move-result-object v0

    move-object v4, v0

    .line 184
    .local v4, "uri":Ljava/net/URI;
    const-string v0, "ws"

    invoke-virtual {v4}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x1

    if-nez v0, :cond_0

    move v0, v5

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    move v6, v0

    .line 185
    .local v6, "tls":Z
    invoke-virtual {v4}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v0

    move-object v7, v0

    .line 186
    .local v7, "host":Ljava/lang/String;
    if-eqz v6, :cond_1

    const/16 v0, 0x1bb

    goto :goto_1

    :cond_1
    const/16 v0, 0x50

    :goto_1
    move v8, v0

    .line 187
    .local v8, "defaultPort":I
    invoke-virtual {v4}, Ljava/net/URI;->getPort()I

    move-result v0

    if-eq v0, v2, :cond_2

    invoke-virtual {v4}, Ljava/net/URI;->getPort()I

    move-result v0

    goto :goto_2

    :cond_2
    move v0, v8

    :goto_2
    move v9, v0

    .line 188
    .local v9, "port":I
    invoke-virtual {v4}, Ljava/net/URI;->getRawPath()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {v4}, Ljava/net/URI;->getRawPath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_3

    goto :goto_3

    .line 189
    :cond_3
    invoke-virtual {v4}, Ljava/net/URI;->getRawPath()Ljava/lang/String;

    move-result-object v0

    goto :goto_4

    :cond_4
    :goto_3
    const-string v0, "/"

    .line 190
    .local v0, "path":Ljava/lang/String;
    :goto_4
    invoke-virtual {v4}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_5

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "?"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v4}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    move-object v0, v10

    goto :goto_5

    :cond_5
    move-object v10, v0

    .line 192
    .end local v0
    .local v10, "path":Ljava/lang/String;
    :goto_5
    new-instance v0, Ljava/net/Socket;

    invoke-direct {v0}, Ljava/net/Socket;-><init>()V

    move-object v11, v0

    .line 193
    .local v11, "raw":Ljava/net/Socket;
    new-instance v0, Ljava/net/InetSocketAddress;

    invoke-direct {v0, v7, v9}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    const/16 v12, 0x3a98

    invoke-virtual {v11, v0, v12}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    .line 194
    move-object v0, v11

    .line 195
    .local v0, "s":Ljava/net/Socket;
    if-eqz v6, :cond_7

    .line 196
    invoke-static {}, Ljavax/net/ssl/SSLSocketFactory;->getDefault()Ljavax/net/SocketFactory;

    move-result-object v12

    check-cast v12, Ljavax/net/ssl/SSLSocketFactory;

    .line 197
    .local v12, "factory":Ljavax/net/ssl/SSLSocketFactory;
    invoke-virtual {v12, v11, v7, v9, v5}, Ljavax/net/ssl/SSLSocketFactory;->createSocket(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;

    move-result-object v13

    check-cast v13, Ljavax/net/ssl/SSLSocket;

    .line 198
    .local v13, "ssl":Ljavax/net/ssl/SSLSocket;
    invoke-virtual {v13}, Ljavax/net/ssl/SSLSocket;->startHandshake()V

    .line 201
    invoke-static {}, Ljavax/net/ssl/HttpsURLConnection;->getDefaultHostnameVerifier()Ljavax/net/ssl/HostnameVerifier;

    move-result-object v14

    .line 202
    .local v14, "verifier":Ljavax/net/ssl/HostnameVerifier;
    invoke-virtual {v13}, Ljavax/net/ssl/SSLSocket;->getSession()Ljavax/net/ssl/SSLSession;

    move-result-object v15

    invoke-interface {v14, v7, v15}, Ljavax/net/ssl/HostnameVerifier;->verify(Ljava/lang/String;Ljavax/net/ssl/SSLSession;)Z

    move-result v15

    if-eqz v15, :cond_6

    .line 205
    move-object v0, v13

    move-object v12, v0

    goto :goto_6

    .line 203
    :cond_6
    new-instance v5, Ljava/io/IOException;

    const-string v15, "TLS hostname verification failed"

    invoke-direct {v5, v15}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 195
    .end local v12
    .end local v13
    .end local v14
    :cond_7
    move-object v12, v0

    .line 207
    .end local v0
    .local v12, "s":Ljava/net/Socket;
    :goto_6
    const v0, 0x15f90

    invoke-virtual {v12, v0}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 208
    iput-object v12, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->socket:Ljava/net/Socket;

    .line 209
    invoke-virtual {v12}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    iput-object v0, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->in:Ljava/io/InputStream;

    .line 210
    invoke-virtual {v12}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    iput-object v0, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->out:Ljava/io/OutputStream;

    .line 212
    const/16 v0, 0x10

    new-array v0, v0, [B

    move-object v13, v0

    .line 213
    .local v13, "keyBytes":[B
    iget-object v0, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->random:Ljava/security/SecureRandom;

    invoke-virtual {v0, v13}, Ljava/security/SecureRandom;->nextBytes([B)V

    .line 214
    const/4 v0, 0x2

    invoke-static {v13, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    move-object v14, v0

    .line 216
    .local v14, "key":Ljava/lang/String;
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v15, 0x100

    invoke-direct {v0, v15}, Ljava/lang/StringBuilder;-><init>(I)V

    move-object v15, v0

    .line 217
    .local v15, "req":Ljava/lang/StringBuilder;
    const-string v0, "GET "

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v5, " HTTP/1.1\r\n"

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 218
    const-string v0, "Host: "

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 219
    if-eq v9, v8, :cond_8

    const/16 v0, 0x3a

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 220
    :cond_8
    const-string v0, "\r\n"

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 221
    const-string v0, "Upgrade: websocket\r\n"

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 222
    const-string v0, "Connection: Upgrade\r\n"

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 223
    const-string v0, "Sec-WebSocket-Key: "

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v5, "\r\n"

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 224
    const-string v0, "Sec-WebSocket-Version: 13\r\n"

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 225
    iget-object v0, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->tokens:Lcom/tzibbur/basic/net/TzbTokenSupplier;

    invoke-interface {v0}, Lcom/tzibbur/basic/net/TzbTokenSupplier;->token()Ljava/lang/String;

    move-result-object v0

    move-object v5, v0

    .line 226
    .local v5, "token":Ljava/lang/String;
    if-eqz v5, :cond_9

    .line 227
    const-string v0, "Authorization: Bearer "

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "\r\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 229
    :cond_9
    const-string v0, "\r\n"

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 230
    iget-object v3, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->writeLock:Ljava/lang/Object;

    monitor-enter v3

    .line 231
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_3
    :try_start_1

    iget-object v0, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->out:Ljava/io/OutputStream;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    move-object/from16 v17, v4

    .end local v4
    .local v17, "uri":Ljava/net/URI;
    :try_start_2
    const-string v4, "UTF-8"

    invoke-virtual {v2, v4}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/io/OutputStream;->write([B)V

    .line 232
    iget-object v0, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->out:Ljava/io/OutputStream;

    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V

    .line 233
    monitor-exit v3

    .line 235
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0
    :try_start_3

    iget-object v0, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->in:Ljava/io/InputStream;

    invoke-static {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->readHttpLine(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->parseStatusLine(Ljava/lang/String;)I

    move-result v0

    move v2, v0

    .line 236
    .local v2, "httpStatus":I
    iget-object v0, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->in:Ljava/io/InputStream;

    invoke-static {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->readHeaders(Ljava/io/InputStream;)Ljava/util/Map;

    move-result-object v0

    move-object v3, v0

    .line 237
    .local v3, "headers":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    const/16 v0, 0x65

    if-eq v2, v0, :cond_b

    .line 239
    const/4 v4, -0x1

    .line 240
    .local v4, "retryAfter":I
    const-string v0, "retry-after"

    invoke-interface {v3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    move-object/from16 v16, v0

    .line 241
    .local v16, "ra":Ljava/lang/String;
    if-eqz v16, :cond_a

    .line 243
    :try_start_4
    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_4 .. :try_end_4} :catch_0
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    move v4, v0

    .line 245
    goto :goto_7

    .line 244
    :catch_0
    move-exception v0

    .line 247
    :cond_a
    :goto_7
    :try_start_5
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->closeSocket()V

    .line 248
    move-object/from16 v18, v5

    const/4 v5, -0x1

    .end local v5
    .local v18, "token":Ljava/lang/String;
    invoke-direct {v1, v5, v2, v4}, Lcom/tzibbur/basic/net/TzbWebSocket;->deliverClosed(III)V

    .line 263
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    const/4 v5, 0x0

    iput-boolean v5, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->open:Z

    .line 264
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->stopPingTimer()V

    .line 249
    return-void

    .line 251
    .end local v4
    .end local v16
    .end local v18
    .restart local v5
    :cond_b
    move-object/from16 v18, v5

    .end local v5
    .restart local v18
    :try_start_6
    const-string v0, "sec-websocket-accept"

    invoke-interface {v3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 252
    .local v0, "accept":Ljava/lang/String;
    if-eqz v0, :cond_c

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-static {v14}, Lcom/tzibbur/basic/net/TzbWebSocket;->expectedAccept(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_c

    .line 256
    const/4 v4, 0x1

    iput-boolean v4, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->open:Z

    .line 257
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->startPingTimer()V

    .line 258
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->readLoop()V

    .end local v0
    .end local v2
    .end local v3
    .end local v6
    .end local v7
    .end local v8
    .end local v9
    .end local v10
    .end local v11
    .end local v12
    .end local v13
    .end local v14
    .end local v15
    .end local v17
    .end local v18
    goto :goto_9

    .line 253
    .restart local v0
    .restart local v2
    .restart local v3
    .restart local v6
    .restart local v7
    .restart local v8
    .restart local v9
    .restart local v10
    .restart local v11
    .restart local v12
    .restart local v13
    .restart local v14
    .restart local v15
    .restart local v17
    .restart local v18
    :cond_c
    new-instance v4, Ljava/io/IOException;

    const-string v5, "bad Sec-WebSocket-Accept"

    invoke-direct {v4, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 233
    .end local v0
    .end local v2
    .end local v3
    .end local v18
    .restart local v5
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_3
    :catchall_0

    move-exception v0

    move-object/from16 v18, v5

    .end local v5
    .restart local v18
    goto :goto_8

    .end local v17
    .end local v18
    .local v4, "uri":Ljava/net/URI;
    .restart local v5
    :catchall_1
    move-exception v0

    move-object/from16 v17, v4

    move-object/from16 v18, v5

    .end local v4
    .end local v5
    .restart local v17
    .restart local v18
    :goto_8
    :try_start_7
    monitor-exit v3

    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2
    :try_start_8

    throw v0

    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_1
    .catchall {:try_start_8 .. :try_end_8} :catchall_3
    :catchall_2

    move-exception v0

    goto :goto_8

    .line 263
    .end local v6
    .end local v7
    .end local v8
    .end local v9
    .end local v10
    .end local v11
    .end local v12
    .end local v13
    .end local v14
    .end local v15
    .end local v17
    .end local v18
    :catchall_3
    move-exception v0

    goto :goto_a

    .line 259
    :catch_1
    move-exception v0

    .line 260
    .local v0, "e":Ljava/lang/Exception;
    :try_start_9
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->closeSocket()V

    .line 261
    const/4 v5, -0x1

    invoke-direct {v1, v5, v5, v5}, Lcom/tzibbur/basic/net/TzbWebSocket;->deliverClosed(III)V

    .line 263
    .end local v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3
    :goto_9

    const/4 v5, 0x0

    iput-boolean v5, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->open:Z

    .line 264
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->stopPingTimer()V

    .line 265
    nop

    .line 266
    return-void

    .line 263
    :goto_a
    const/4 v5, 0x0

    iput-boolean v5, v1, Lcom/tzibbur/basic/net/TzbWebSocket;->open:Z

    .line 264
    invoke-direct {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->stopPingTimer()V

    .line 265
    throw v0
.end method

.method private sendFrame(I[B)V
    .locals 10
    .param p1, "opcode"    # I
    .param p2, "payload"    # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 413
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->out:Ljava/io/OutputStream;

    .line 414
    .local v0, "o":Ljava/io/OutputStream;
    if-eqz v0, :cond_5

    iget-boolean v1, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->clientClosed:Z

    if-eqz v1, :cond_0

    const/16 v1, 0x8

    if-ne p1, v1, :cond_5

    .line 417
    :cond_0
    const/4 v1, 0x4

    new-array v2, v1, [B

    .line 418
    .local v2, "mask":[B
    iget-object v3, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->random:Ljava/security/SecureRandom;

    invoke-virtual {v3, v2}, Ljava/security/SecureRandom;->nextBytes([B)V

    .line 419
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    array-length v4, p2

    add-int/lit8 v4, v4, 0xe

    invoke-direct {v3, v4}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 420
    .local v3, "buf":Ljava/io/ByteArrayOutputStream;
    or-int/lit16 v4, p1, 0x80

    invoke-virtual {v3, v4}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 421
    array-length v4, p2

    .line 422
    .local v4, "len":I
    const/16 v5, 0x7d

    if-gt v4, v5, :cond_1

    .line 423
    or-int/lit16 v5, v4, 0x80

    invoke-virtual {v3, v5}, Ljava/io/ByteArrayOutputStream;->write(I)V

    goto :goto_1

    .line 424
    :cond_1
    const v5, 0xffff

    const/16 v6, 0xff

    if-gt v4, v5, :cond_2

    .line 425
    const/16 v5, 0xfe

    invoke-virtual {v3, v5}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 426
    shr-int/lit8 v5, v4, 0x8

    and-int/2addr v5, v6

    invoke-virtual {v3, v5}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 427
    and-int/lit16 v5, v4, 0xff

    invoke-virtual {v3, v5}, Ljava/io/ByteArrayOutputStream;->write(I)V

    goto :goto_1

    .line 429
    :cond_2
    invoke-virtual {v3, v6}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 430
    const/4 v5, 0x7

    .local v5, "i":I
    :goto_0
    if-ltz v5, :cond_3

    .line 431
    int-to-long v6, v4

    mul-int/lit8 v8, v5, 0x8

    shr-long/2addr v6, v8

    const-wide/16 v8, 0xff

    and-long/2addr v6, v8

    long-to-int v6, v6

    invoke-virtual {v3, v6}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 430
    add-int/lit8 v5, v5, -0x1

    goto :goto_0

    .line 434
    .end local v5
    :cond_3
    :goto_1
    const/4 v5, 0x0

    invoke-virtual {v3, v2, v5, v1}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 435
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_2
    if-ge v1, v4, :cond_4

    .line 436
    aget-byte v5, p2, v1

    and-int/lit8 v6, v1, 0x3

    aget-byte v6, v2, v6

    xor-int/2addr v5, v6

    invoke-virtual {v3, v5}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 435
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 438
    .end local v1
    :cond_4
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->writeLock:Ljava/lang/Object;

    monitor-enter v1

    .line 439
    :try_start_0
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/io/OutputStream;->write([B)V

    .line 440
    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V

    .line 441
    monitor-exit v1

    .line 442
    return-void

    .line 441
    :catchall_0
    move-exception v5

    monitor-exit v1

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v5

    .line 415
    .end local v2
    .end local v3
    .end local v4
    :cond_5
    new-instance v1, Ljava/io/IOException;

    const-string v2, "socket not open"

    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method private sendTextQuietly(Ljava/lang/String;)Z
    .locals 2
    .param p1, "json"    # Ljava/lang/String;

    .line 401
    :try_start_0
    const-string v0, "UTF-8"

    invoke-virtual {p1, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v0

    const/4 v1, 0x1

    invoke-direct {p0, v1, v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendFrame(I[B)V

    .line 402
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    .line 403
    :catch_0
    move-exception v0

    .line 406
    .local v0, "e":Ljava/io/IOException;
    invoke-direct {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->closeSocket()V

    .line 407
    const/4 v1, 0x0

    return v1
.end method

.method private startPingTimer()V
    .locals 9

    .line 540
    new-instance v0, Ljava/util/Timer;

    const-string v1, "TzbWebSocketPing"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Ljava/util/Timer;-><init>(Ljava/lang/String;Z)V

    move-object v3, v0

    .line 541
    .local v3, "timer":Ljava/util/Timer;
    new-instance v4, Lcom/tzibbur/basic/net/TzbWebSocket$2;

    invoke-direct {v4, p0}, Lcom/tzibbur/basic/net/TzbWebSocket$2;-><init>(Lcom/tzibbur/basic/net/TzbWebSocket;)V

    iget-wide v5, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->pingIntervalMs:J

    iget-wide v7, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->pingIntervalMs:J

    invoke-virtual/range {v3 .. v8}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;JJ)V

    .line 547
    iput-object v3, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->pingTimer:Ljava/util/Timer;

    .line 548
    return-void
.end method

.method private stopPingTimer()V
    .locals 2

    .line 551
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->pingTimer:Ljava/util/Timer;

    .line 552
    .local v0, "timer":Ljava/util/Timer;
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->pingTimer:Ljava/util/Timer;

    .line 553
    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/util/Timer;->cancel()V

    .line 554
    :cond_0
    return-void
.end method


# virtual methods
.method public close()V
    .locals 2

    .line 169
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->clientClosed:Z

    .line 170
    invoke-direct {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->stopPingTimer()V

    .line 172
    const/4 v0, 0x2

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    invoke-direct {p0, v1, v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendFrame(I[B)V

    .line 175
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 173
    :catch_0
    move-exception v0

    .line 176
    :goto_0
    invoke-direct {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->closeSocket()V

    .line 177
    return-void

    nop

    :array_0
    .array-data 1
        0x3t
        -0x18t
    .end array-data
.end method

.method public connect()V
    .locals 3

    .line 95
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/tzibbur/basic/net/TzbWebSocket$1;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/net/TzbWebSocket$1;-><init>(Lcom/tzibbur/basic/net/TzbWebSocket;)V

    const-string v2, "TzbWebSocket"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 101
    .local v0, "reader":Ljava/lang/Thread;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setDaemon(Z)V

    .line 102
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 103
    return-void
.end method

.method public isOpen()Z
    .locals 1

    .line 106
    iget-boolean v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->open:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->clientClosed:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public outboundPaused()Z
    .locals 4

    .line 152
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->outboundPausedUntilMs:J

    cmp-long v0, v0, v2

    if-gez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public pauseOutbound(J)V
    .locals 2
    .param p1, "durationMs"    # J

    .line 147
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    add-long/2addr v0, p1

    iput-wide v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket;->outboundPausedUntilMs:J

    .line 148
    return-void
.end method

.method public sendAck(Ljava/lang/String;J)V
    .locals 3
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "seq"    # J

    .line 111
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 113
    .local v0, "frame":Lorg/json/JSONObject;
    :try_start_0
    const-string v1, "type"

    const-string v2, "ack"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 114
    const-string v1, "groupId"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 115
    const-string v1, "seq"

    invoke-virtual {v0, v1, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 118
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    nop

    .line 119
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendTextQuietly(Ljava/lang/String;)Z

    .line 120
    return-void

    .line 116
    :catch_0
    move-exception v1

    .line 117
    .local v1, "e":Lorg/json/JSONException;
    return-void
.end method

.method public sendPing()V
    .locals 3

    .line 157
    invoke-virtual {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->outboundPaused()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 158
    :cond_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 160
    .local v0, "frame":Lorg/json/JSONObject;
    :try_start_0
    const-string v1, "type"

    const-string v2, "ping"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 163
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    nop

    .line 164
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendTextQuietly(Ljava/lang/String;)Z

    .line 165
    return-void

    .line 161
    :catch_0
    move-exception v1

    .line 162
    .local v1, "e":Lorg/json/JSONException;
    return-void
.end method

.method public sendRead(Ljava/lang/String;J)Z
    .locals 4
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "seq"    # J

    .line 128
    invoke-virtual {p0}, Lcom/tzibbur/basic/net/TzbWebSocket;->isOpen()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 129
    :cond_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 131
    .local v0, "frame":Lorg/json/JSONObject;
    :try_start_0
    const-string v2, "type"

    const-string v3, "read"

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 132
    const-string v2, "groupId"

    invoke-virtual {v0, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 133
    const-string v2, "seq"

    invoke-virtual {v0, v2, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 136
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    nop

    .line 137
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendTextQuietly(Ljava/lang/String;)Z

    move-result v1

    return v1

    .line 134
    :catch_0
    move-exception v2

    .line 135
    .local v2, "e":Lorg/json/JSONException;
    return v1
.end method
