.class public interface abstract Lcom/tzibbur/basic/net/TzbApi;
.super Ljava/lang/Object;
.source "TzbApi.java"


# virtual methods
# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract ack(Ljava/lang/String;J)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract addMembers(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMemberAddResult;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Lcom/tzibbur/basic/model/TzbMemberAddResult;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract applicationStatus(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbApplicationStatus;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract authStart(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbAuthStart;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract authVerify(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbEnrollment;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract capabilities(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbCapabilities;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract contactsCheck(Ljava/util/List;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract createGroup(Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract deleteGroup(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract getGroup(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract groupCategories()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract leaveGroup(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract legalDocument(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbLegalDocument;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lcom/tzibbur/basic/net/TzbProblem;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract listGroups(Ljava/lang/String;Ljava/lang/Integer;)Lcom/tzibbur/basic/model/TzbPage;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ")",
            "Lcom/tzibbur/basic/model/TzbPage<",
            "Lcom/tzibbur/basic/model/TzbGroup;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract listMembers(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)Lcom/tzibbur/basic/model/TzbPage;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ")",
            "Lcom/tzibbur/basic/model/TzbPage<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract listMessages(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Integer;)Lcom/tzibbur/basic/model/TzbMessagePage;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract logout()V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract markRead(Ljava/lang/String;J)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract me()Lcom/tzibbur/basic/model/TzbUser;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract myDevices()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbDevice;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract pending(Ljava/lang/Integer;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Integer;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbPendingGroup;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract removeMember(Ljava/lang/String;Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract revokeDevice(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract sendMessage(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbSendResult;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract setRole(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMember;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract submitApplication(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbApplication;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract updateDisplayName(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbUser;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

# implemented-by: Lcom/tzibbur/basic/net/TzbApiClient;
.method public abstract updateGroup(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method
