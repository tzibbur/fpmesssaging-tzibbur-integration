.class Lcom/tzibbur/basic/net/TzbWebSocket$1;
.super Ljava/lang/Object;
.source "TzbWebSocket.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/net/TzbWebSocket;->connect()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/net/TzbWebSocket;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/net/TzbWebSocket;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/net/TzbWebSocket;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 95
    iput-object p1, p0, Lcom/tzibbur/basic/net/TzbWebSocket$1;->this$0:Lcom/tzibbur/basic/net/TzbWebSocket;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 98
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket$1;->this$0:Lcom/tzibbur/basic/net/TzbWebSocket;

    invoke-static {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->access$000(Lcom/tzibbur/basic/net/TzbWebSocket;)V

    .line 99
    return-void
.end method
