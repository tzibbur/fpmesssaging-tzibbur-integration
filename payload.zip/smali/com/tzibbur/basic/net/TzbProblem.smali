.class public Lcom/tzibbur/basic/net/TzbProblem;
.super Ljava/io/IOException;
.source "TzbProblem.java"


# instance fields
.field public final code:Ljava/lang/String;

.field public final detail:Ljava/lang/String;

.field public final errors:Lorg/json/JSONObject;

.field public final requestId:Ljava/lang/String;

.field public final retryAfterSeconds:I

.field public final status:I


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;I)V
    .locals 2
    .param p1, "code"    # Ljava/lang/String;
    .param p2, "status"    # I
    .param p3, "detail"    # Ljava/lang/String;
    .param p4, "requestId"    # Ljava/lang/String;
    .param p5, "errors"    # Lorg/json/JSONObject;
    .param p6, "retryAfterSeconds"    # I

    .line 23
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "): "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 24
    iput-object p1, p0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    .line 25
    iput p2, p0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    .line 26
    iput-object p3, p0, Lcom/tzibbur/basic/net/TzbProblem;->detail:Ljava/lang/String;

    .line 27
    iput-object p4, p0, Lcom/tzibbur/basic/net/TzbProblem;->requestId:Ljava/lang/String;

    .line 28
    if-eqz p5, :cond_0

    move-object v0, p5

    goto :goto_0

    :cond_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :goto_0
    iput-object v0, p0, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    .line 29
    iput p6, p0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    .line 30
    return-void
.end method


# virtual methods
.method public isDeviceBlocked()Z
    .locals 2

    .line 44
    iget v0, p0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x193

    if-ne v0, v1, :cond_0

    const-string v0, "device_blocked"

    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isForbidden()Z
    .locals 2

    .line 49
    iget v0, p0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x193

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isRateLimited()Z
    .locals 2

    .line 53
    iget v0, p0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x1ad

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isRetryable()Z
    .locals 2

    .line 58
    iget v0, p0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x1ad

    if-eq v0, v1, :cond_1

    iget v0, p0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x1f4

    if-lt v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public isUnauthorized()Z
    .locals 2

    .line 34
    iget v0, p0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    const/16 v1, 0x191

    if-ne v0, v1, :cond_0

    const-string v0, "unauthorized"

    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method
