.class public final Lcom/tzibbur/basic/net/TzbApiClient;
.super Ljava/lang/Object;
.source "TzbApiClient.java"

# interfaces
.implements Lcom/tzibbur/basic/net/TzbApi;


# instance fields
.field private final http:Lcom/tzibbur/basic/net/TzbHttp;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/tzibbur/basic/net/TzbTokenSupplier;)V
    .locals 1
    .param p1, "baseUrl"    # Ljava/lang/String;
    .param p2, "tokens"    # Lcom/tzibbur/basic/net/TzbTokenSupplier;

    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 38
    new-instance v0, Lcom/tzibbur/basic/net/TzbHttp;

    invoke-direct {v0, p1, p2}, Lcom/tzibbur/basic/net/TzbHttp;-><init>(Ljava/lang/String;Lcom/tzibbur/basic/net/TzbTokenSupplier;)V

    iput-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    .line 39
    return-void
.end method

.method private static obj()Lorg/json/JSONObject;
    .locals 1

    .line 310
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    return-object v0
.end method

.method private static put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V
    .locals 3
    .param p0, "o"    # Lorg/json/JSONObject;
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "value"    # Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 315
    if-nez p2, :cond_0

    return-void

    .line 317
    :cond_0
    :try_start_0
    invoke-virtual {p0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 320
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    nop

    .line 321
    return-void

    .line 318
    :catch_0
    move-exception v0

    .line 319
    .local v0, "e":Lorg/json/JSONException;
    new-instance v1, Ljava/io/IOException;

    const-string v2, "failed to build request body"

    invoke-direct {v1, v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1
.end method

.method private static varargs query([Ljava/lang/Object;)Ljava/lang/String;
    .locals 6
    .param p0, "pairs"    # [Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 330
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 331
    .local v0, "sb":Ljava/lang/StringBuilder;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    add-int/lit8 v2, v1, 0x1

    array-length v3, p0

    if-ge v2, v3, :cond_2

    .line 332
    add-int/lit8 v2, v1, 0x1

    aget-object v2, p0, v2

    .line 333
    .local v2, "value":Ljava/lang/Object;
    if-nez v2, :cond_0

    goto :goto_2

    .line 334
    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    if-nez v3, :cond_1

    const/16 v3, 0x3f

    goto :goto_1

    :cond_1
    const/16 v3, 0x26

    :goto_1
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 335
    aget-object v3, p0, v1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const/16 v4, 0x3d

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 336
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "UTF-8"

    invoke-static {v4, v5}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 331
    .end local v2
    :goto_2
    add-int/lit8 v1, v1, 0x2

    goto :goto_0

    .line 338
    .end local v1
    :cond_2
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private static seg(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "s"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 325
    const-string v0, "UTF-8"

    invoke-static {p0, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "+"

    const-string v2, "%20"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static trimToNull(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "s"    # Ljava/lang/String;

    .line 117
    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    .line 118
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 119
    .local v1, "t":Ljava/lang/String;
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-nez v2, :cond_1

    goto :goto_0

    :cond_1
    move-object v0, v1

    :goto_0
    return-object v0
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public ack(Ljava/lang/String;J)V
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "seq"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 293
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 294
    .local v0, "body":Lorg/json/JSONObject;
    const-string v1, "seq"

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 295
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/groups/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/ack"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    const-string v4, "POST"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    .line 296
    return-void
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public addMembers(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMemberAddResult;
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p3, "region"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Lcom/tzibbur/basic/model/TzbMemberAddResult;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 212
    .local p2, "phones":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 213
    .local v0, "body":Lorg/json/JSONObject;
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1, p2}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    const-string v2, "phones"

    invoke-static {v0, v2, v1}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 214
    const-string v1, "region"

    invoke-static {v0, v1, p3}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 215
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/groups/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/members"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    const-string v4, "POST"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 216
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->memberAddResult(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMemberAddResult;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public applicationStatus(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbApplicationStatus;
    .locals 5
    .param p1, "phone"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 111
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "/applications/status"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    const-string v3, "phone"

    aput-object v3, v1, v2

    const/4 v3, 0x1

    aput-object p1, v1, v3

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbApiClient;->query([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 112
    .local v0, "path":Ljava/lang/String;
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v3, "GET"

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v0, v4, v2}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 113
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->applicationStatus(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbApplicationStatus;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public authStart(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbAuthStart;
    .locals 5
    .param p1, "phone"    # Ljava/lang/String;
    .param p2, "region"    # Ljava/lang/String;
    .param p3, "displayName"    # Ljava/lang/String;
    .param p4, "deviceModel"    # Ljava/lang/String;
    .param p5, "serialNumber"    # Ljava/lang/String;
    .param p6, "imei"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 57
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 58
    .local v0, "body":Lorg/json/JSONObject;
    const-string v1, "phone"

    invoke-static {v0, v1, p1}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 59
    const-string v1, "region"

    invoke-static {v0, v1, p2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 60
    const-string v1, "displayName"

    invoke-static {v0, v1, p3}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 61
    const-string v1, "platform"

    const-string v2, "kosher"

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 62
    const-string v1, "deviceModel"

    invoke-static {v0, v1, p4}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 65
    if-nez p5, :cond_0

    if-eqz p6, :cond_1

    .line 66
    :cond_0
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v1

    .line 67
    .local v1, "hardware":Lorg/json/JSONObject;
    const-string v2, "serialNumber"

    invoke-static {v1, v2, p5}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 68
    const-string v2, "imei"

    invoke-static {v1, v2, p6}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 70
    :try_start_0
    const-string v2, "hardware"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 73
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 71
    :catch_0
    move-exception v2

    .line 75
    .end local v1
    :cond_1
    :goto_0
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v2, "/auth/start"

    const/4 v3, 0x0

    const-string v4, "POST"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 76
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->authStart(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbAuthStart;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public authVerify(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbEnrollment;
    .locals 5
    .param p1, "challengeId"    # Ljava/lang/String;
    .param p2, "code"    # Ljava/lang/String;
    .param p3, "displayName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 82
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 83
    .local v0, "body":Lorg/json/JSONObject;
    const-string v1, "challengeId"

    invoke-static {v0, v1, p1}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 84
    const-string v1, "code"

    invoke-static {v0, v1, p2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 85
    const-string v1, "displayName"

    invoke-static {v0, v1, p3}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 86
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v2, "/auth/verify"

    const/4 v3, 0x0

    const-string v4, "POST"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 87
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->enrollment(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbEnrollment;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public capabilities(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbCapabilities;
    .locals 6
    .param p1, "platformOrNull"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 45
    const/4 v0, 0x1

    const/4 v1, 0x0

    if-nez p1, :cond_0

    move v2, v0

    goto :goto_0

    :cond_0
    move v2, v1

    .line 46
    .local v2, "auth":Z
    :goto_0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "/capabilities"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const/4 v4, 0x2

    new-array v4, v4, [Ljava/lang/Object;

    const-string v5, "platform"

    aput-object v5, v4, v1

    aput-object p1, v4, v0

    invoke-static {v4}, Lcom/tzibbur/basic/net/TzbApiClient;->query([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 47
    .local v0, "path":Ljava/lang/String;
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v3, "GET"

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v0, v4, v2}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 48
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v3, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v3}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    invoke-static {v3}, Lcom/tzibbur/basic/net/TzbJson;->capabilities(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbCapabilities;

    move-result-object v3

    return-object v3
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public contactsCheck(Ljava/util/List;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 164
    .local p1, "phones":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 165
    .local v0, "body":Lorg/json/JSONObject;
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1, p1}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    const-string v2, "phones"

    invoke-static {v0, v2, v1}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 166
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v2, "/contacts/check"

    const/4 v3, 0x1

    const-string v4, "POST"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 167
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "registered"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->stringList(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public createGroup(Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 5
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "category"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 180
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 181
    .local v0, "body":Lorg/json/JSONObject;
    const-string v1, "name"

    invoke-static {v0, v1, p1}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 182
    const-string v1, "category"

    invoke-static {v0, v1, p2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 183
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v2, "/groups"

    const/4 v3, 0x1

    const-string v4, "POST"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 184
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->group(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public deleteGroup(Ljava/lang/String;)V
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 256
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/groups/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v4, "DELETE"

    invoke-virtual {v0, v4, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    .line 257
    return-void
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public getGroup(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 196
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/groups/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v4, "GET"

    invoke-virtual {v0, v4, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v0

    .line 197
    .local v0, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->group(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v1

    return-object v1
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public groupCategories()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 174
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v3, "GET"

    const-string v4, "/groups/categories"

    invoke-virtual {v0, v3, v4, v1, v2}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v0

    .line 175
    .local v0, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "categories"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->stringList(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v1

    return-object v1
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public leaveGroup(Ljava/lang/String;)V
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 226
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/groups/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/leave"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v4, "POST"

    invoke-virtual {v0, v4, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    .line 227
    return-void
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public legalDocument(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbLegalDocument;
    .locals 5
    .param p1, "key"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 126
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/legal/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v4, "GET"

    invoke-virtual {v0, v4, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v0

    .line 127
    .local v0, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->legalDocument(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbLegalDocument;

    move-result-object v1

    return-object v1
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public listGroups(Ljava/lang/String;Ljava/lang/Integer;)Lcom/tzibbur/basic/model/TzbPage;
    .locals 5
    .param p1, "cursor"    # Ljava/lang/String;
    .param p2, "limit"    # Ljava/lang/Integer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ")",
            "Lcom/tzibbur/basic/model/TzbPage<",
            "Lcom/tzibbur/basic/model/TzbGroup;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 189
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "/groups"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/4 v1, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const-string v2, "cursor"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    aput-object p1, v1, v2

    const-string v3, "limit"

    const/4 v4, 0x2

    aput-object v3, v1, v4

    const/4 v3, 0x3

    aput-object p2, v1, v3

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbApiClient;->query([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 190
    .local v0, "path":Ljava/lang/String;
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v3, "GET"

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v0, v4, v2}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 191
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->groupPage(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbPage;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public listMembers(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)Lcom/tzibbur/basic/model/TzbPage;
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "cursor"    # Ljava/lang/String;
    .param p3, "limit"    # Ljava/lang/Integer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ")",
            "Lcom/tzibbur/basic/model/TzbPage<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 203
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "/groups/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/members"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/4 v1, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const-string v2, "cursor"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    aput-object p2, v1, v2

    const-string v3, "limit"

    const/4 v4, 0x2

    aput-object v3, v1, v4

    const/4 v3, 0x3

    aput-object p3, v1, v3

    .line 204
    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbApiClient;->query([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 205
    .local v0, "path":Ljava/lang/String;
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v3, "GET"

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v0, v4, v2}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 206
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->memberPage(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbPage;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public listMessages(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Integer;)Lcom/tzibbur/basic/model/TzbMessagePage;
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "afterSeq"    # Ljava/lang/Long;
    .param p3, "beforeSeq"    # Ljava/lang/Long;
    .param p4, "limit"    # Ljava/lang/Integer;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 277
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "/groups/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/messages"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/4 v1, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const-string v2, "afterSeq"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    aput-object p2, v1, v2

    const-string v3, "beforeSeq"

    const/4 v4, 0x2

    aput-object v3, v1, v4

    const/4 v3, 0x3

    aput-object p3, v1, v3

    const-string v3, "limit"

    const/4 v4, 0x4

    aput-object v3, v1, v4

    const/4 v3, 0x5

    aput-object p4, v1, v3

    .line 278
    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbApiClient;->query([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 279
    .local v0, "path":Ljava/lang/String;
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v3, "GET"

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v0, v4, v2}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 280
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->messagePage(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMessagePage;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public logout()V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 154
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v3, "POST"

    const-string v4, "/sessions/logout"

    invoke-virtual {v0, v3, v4, v1, v2}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    .line 155
    return-void
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public markRead(Ljava/lang/String;J)V
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "seq"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 302
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 303
    .local v0, "body":Lorg/json/JSONObject;
    const-string v1, "seq"

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 304
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/groups/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/read"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    const-string v4, "POST"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    .line 305
    return-void
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public me()Lcom/tzibbur/basic/model/TzbUser;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 134
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v3, "GET"

    const-string v4, "/me"

    invoke-virtual {v0, v3, v4, v1, v2}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v0

    .line 135
    .local v0, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->user(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbUser;

    move-result-object v1

    return-object v1
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public myDevices()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbDevice;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 148
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v3, "GET"

    const-string v4, "/me/devices"

    invoke-virtual {v0, v3, v4, v1, v2}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v0

    .line 149
    .local v0, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "items"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->devices(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v1

    return-object v1
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public pending(Ljava/lang/Integer;)Ljava/util/List;
    .locals 5
    .param p1, "limit"    # Ljava/lang/Integer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Integer;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbPendingGroup;",
            ">;"
        }
    .end annotation
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 287
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/pending"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const-string v3, "limit"

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbApiClient;->query([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const-string v4, "GET"

    invoke-virtual {v0, v4, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v0

    .line 288
    .local v0, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v1, v0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->pendingGroups(Lorg/json/JSONObject;)Ljava/util/List;

    move-result-object v1

    return-object v1
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public removeMember(Ljava/lang/String;Ljava/lang/String;)V
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "userId"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 221
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/groups/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/members/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {p2}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v4, "DELETE"

    invoke-virtual {v0, v4, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    .line 222
    return-void
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public revokeDevice(Ljava/lang/String;)V
    .locals 5
    .param p1, "deviceId"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 159
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/me/devices/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v4, "DELETE"

    invoke-virtual {v0, v4, v1, v2, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    .line 160
    return-void
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public sendMessage(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbSendResult;
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "clientMessageId"    # Ljava/lang/String;
    .param p3, "body"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 264
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 265
    .local v0, "json":Lorg/json/JSONObject;
    const-string v1, "clientMessageId"

    invoke-static {v0, v1, p2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 266
    const-string v1, "body"

    invoke-static {v0, v1, p3}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 267
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/groups/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 268
    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/messages"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 267
    const-string v3, "POST"

    const/4 v4, 0x1

    invoke-virtual {v1, v3, v2, v0, v4}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 271
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->sendResult(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbSendResult;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public setRole(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbMember;
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "userId"    # Ljava/lang/String;
    .param p3, "role"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 231
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 232
    .local v0, "body":Lorg/json/JSONObject;
    const-string v1, "role"

    invoke-static {v0, v1, p3}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 233
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/groups/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 234
    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/members/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {p2}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 233
    const-string v3, "PATCH"

    const/4 v4, 0x1

    invoke-virtual {v1, v3, v2, v0, v4}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 235
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->member(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMember;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public submitApplication(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbApplication;
    .locals 5
    .param p1, "phone"    # Ljava/lang/String;
    .param p2, "displayName"    # Ljava/lang/String;
    .param p3, "reason"    # Ljava/lang/String;
    .param p4, "organization"    # Ljava/lang/String;
    .param p5, "notes"    # Ljava/lang/String;
    .param p6, "deviceModel"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 96
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 97
    .local v0, "body":Lorg/json/JSONObject;
    const-string v1, "phone"

    invoke-static {v0, v1, p1}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 99
    const-string v1, "displayName"

    invoke-static {p2}, Lcom/tzibbur/basic/net/TzbApiClient;->trimToNull(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 100
    const-string v1, "reason"

    invoke-static {p3}, Lcom/tzibbur/basic/net/TzbApiClient;->trimToNull(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 101
    const-string v1, "organization"

    invoke-static {p4}, Lcom/tzibbur/basic/net/TzbApiClient;->trimToNull(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 102
    const-string v1, "notes"

    invoke-static {p5}, Lcom/tzibbur/basic/net/TzbApiClient;->trimToNull(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 103
    const-string v1, "deviceModel"

    invoke-static {p6}, Lcom/tzibbur/basic/net/TzbApiClient;->trimToNull(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 104
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v2, "/applications"

    const/4 v3, 0x0

    const-string v4, "POST"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 105
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->application(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbApplication;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public updateDisplayName(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbUser;
    .locals 5
    .param p1, "displayName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 140
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 141
    .local v0, "body":Lorg/json/JSONObject;
    const-string v1, "displayName"

    invoke-static {v0, v1, p1}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 142
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    const-string v2, "/me"

    const/4 v3, 0x1

    const-string v4, "PATCH"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 143
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->user(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbUser;

    move-result-object v2

    return-object v2
.end method

# overrides: Lcom/tzibbur/basic/net/TzbApi;
.method public updateGroup(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "whoCanPost"    # Ljava/lang/String;
    .param p4, "whoCanAddMembers"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 242
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v0

    .line 243
    .local v0, "body":Lorg/json/JSONObject;
    const-string v1, "name"

    invoke-static {v0, v1, p2}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 244
    if-nez p3, :cond_0

    if-eqz p4, :cond_1

    .line 245
    :cond_0
    invoke-static {}, Lcom/tzibbur/basic/net/TzbApiClient;->obj()Lorg/json/JSONObject;

    move-result-object v1

    .line 246
    .local v1, "settings":Lorg/json/JSONObject;
    const-string v2, "whoCanPost"

    invoke-static {v1, v2, p3}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 247
    const-string v2, "whoCanAddMembers"

    invoke-static {v1, v2, p4}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 248
    const-string v2, "settings"

    invoke-static {v0, v2, v1}, Lcom/tzibbur/basic/net/TzbApiClient;->put(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)V

    .line 250
    .end local v1
    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/net/TzbApiClient;->http:Lcom/tzibbur/basic/net/TzbHttp;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/groups/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {p1}, Lcom/tzibbur/basic/net/TzbApiClient;->seg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    const-string v4, "PATCH"

    invoke-virtual {v1, v4, v2, v0, v3}, Lcom/tzibbur/basic/net/TzbHttp;->exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;

    move-result-object v1

    .line 251
    .local v1, "r":Lcom/tzibbur/basic/net/TzbHttp$Response;
    iget-object v2, v1, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->parseObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->group(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v2

    return-object v2
.end method
