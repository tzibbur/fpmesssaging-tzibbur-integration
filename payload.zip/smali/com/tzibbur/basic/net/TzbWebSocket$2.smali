.class Lcom/tzibbur/basic/net/TzbWebSocket$2;
.super Ljava/util/TimerTask;
.source "TzbWebSocket.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/net/TzbWebSocket;->startPingTimer()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/net/TzbWebSocket;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/net/TzbWebSocket;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/net/TzbWebSocket;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 541
    iput-object p1, p0, Lcom/tzibbur/basic/net/TzbWebSocket$2;->this$0:Lcom/tzibbur/basic/net/TzbWebSocket;

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 544
    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket$2;->this$0:Lcom/tzibbur/basic/net/TzbWebSocket;

    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->isOpen()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tzibbur/basic/net/TzbWebSocket$2;->this$0:Lcom/tzibbur/basic/net/TzbWebSocket;

    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendPing()V

    .line 545
    :cond_0
    return-void
.end method
