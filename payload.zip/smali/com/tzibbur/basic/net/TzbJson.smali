.class public final Lcom/tzibbur/basic/net/TzbJson;
.super Ljava/lang/Object;
.source "TzbJson.java"


# static fields
.field private static final FALLBACK_MEMBER_CAP:I = 0x64

.field private static final FALLBACK_MESSAGE_MAX_LENGTH:I = 0x3e8


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static application(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbApplication;
    .locals 5
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 107
    const-string v0, "application"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 108
    .local v0, "a":Lorg/json/JSONObject;
    if-nez v0, :cond_0

    move-object v0, p0

    .line 109
    :cond_0
    new-instance v1, Lcom/tzibbur/basic/model/TzbApplication;

    .line 110
    const-string v2, "id"

    invoke-static {v0, v2}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 111
    const-string v3, "status"

    const-string v4, "pending"

    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 112
    const-string v4, "submittedAt"

    invoke-static {v0, v4}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v2, v3, v4}, Lcom/tzibbur/basic/model/TzbApplication;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    return-object v1
.end method

.method public static applicationStatus(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbApplicationStatus;
    .locals 6
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 121
    new-instance v0, Lcom/tzibbur/basic/model/TzbApplicationStatus;

    .line 122
    const-string v1, "status"

    const-string v2, "none"

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 123
    const-string v2, "canApply"

    const/4 v3, 0x0

    invoke-virtual {p0, v2, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v2

    .line 124
    const-string v4, "decidedAt"

    invoke-static {p0, v4}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 125
    const-string v5, "submissionCount"

    invoke-virtual {p0, v5, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    invoke-direct {v0, v1, v2, v4, v3}, Lcom/tzibbur/basic/model/TzbApplicationStatus;-><init>(Ljava/lang/String;ZLjava/lang/String;I)V

    .line 121
    return-object v0
.end method

.method public static authStart(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbAuthStart;
    .locals 5
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 90
    new-instance v0, Lcom/tzibbur/basic/model/TzbAuthStart;

    .line 91
    const-string v1, "challengeId"

    const-string v2, ""

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 92
    const-string v3, "expiresAt"

    invoke-virtual {p0, v3, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 93
    const-string v3, "resendAfterSeconds"

    const/16 v4, 0x3c

    invoke-virtual {p0, v3, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    invoke-direct {v0, v1, v2, v3}, Lcom/tzibbur/basic/model/TzbAuthStart;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 90
    return-object v0
.end method

.method public static capabilities(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbCapabilities;
    .locals 20

    # tzib unified: metadata capabilities
    invoke-static/range {p0 .. p0}, Lcom/android/mms/tzib/TzibMetadata;->capabilities(Lorg/json/JSONObject;)V

    .param p0, "o"    # Lorg/json/JSONObject;

    .line 148
    move-object/from16 v0, p0

    const-string v1, "limits"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->objOrEmpty(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v1

    .line 149
    .local v1, "limits":Lorg/json/JSONObject;
    const-string v2, "auth"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->objOrEmpty(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v2

    .line 150
    .local v2, "auth":Lorg/json/JSONObject;
    const-string v3, "features"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    invoke-static {v3}, Lcom/tzibbur/basic/net/TzbJson;->objOrEmpty(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v3

    .line 151
    .local v3, "features":Lorg/json/JSONObject;
    const-string v4, "device"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 152
    .local v4, "device":Lorg/json/JSONObject;
    const/4 v5, 0x1

    .line 153
    .local v5, "smsOnly":Z
    const-string v6, "requiredFactors"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    .line 154
    .local v6, "factors":Lorg/json/JSONArray;
    if-eqz v6, :cond_1

    .line 155
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_0
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v8

    if-ge v7, v8, :cond_1

    .line 156
    const-string v8, "sms"

    invoke-virtual {v6, v7}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_0

    .line 157
    const/4 v5, 0x0

    .line 158
    move v15, v5

    goto :goto_1

    .line 155
    :cond_0
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    .line 162
    .end local v7
    :cond_1
    move v15, v5

    .end local v5
    .local v15, "smsOnly":Z
    :goto_1
    new-instance v8, Lcom/tzibbur/basic/model/TzbCapabilities;

    .line 163
    const-string v5, "displayNameMaxLength"

    const/4 v7, 0x0

    invoke-virtual {v1, v5, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v9

    .line 164
    const-string v5, "groupNameMaxLength"

    invoke-virtual {v1, v5, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v10

    .line 165
    const-string v5, "contactsCheckMaxPhones"

    invoke-virtual {v1, v5, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v11

    .line 166
    const-string v5, "groupAddMaxPhones"

    invoke-virtual {v1, v5, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v12

    .line 167
    const-string v5, "unreadCountMax"

    invoke-virtual {v1, v5, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v13

    .line 168
    const-string v5, "deviceModelMaxLength"

    invoke-virtual {v1, v5, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v14

    .line 170
    const-string v5, "contactDiscovery"

    const/4 v7, 0x1

    invoke-virtual {v3, v5, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v5

    .line 171
    if-eqz v4, :cond_2

    const-string v7, "reason"

    invoke-static {v4, v7}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_2

    :cond_2
    const/4 v7, 0x0

    :goto_2
    if-eqz v4, :cond_3

    .line 172
    const-string v0, "enabled"

    move-object/from16 v19, v1

    const/4 v1, 0x0

    .end local v1
    .local v19, "limits":Lorg/json/JSONObject;
    invoke-virtual {v4, v0, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_4

    const/16 v18, 0x1

    goto :goto_3

    .line 171
    .end local v19
    .restart local v1
    :cond_3
    move-object/from16 v19, v1

    const/4 v1, 0x0

    .line 172
    .end local v1
    .restart local v19
    :cond_4
    move/from16 v18, v1

    :goto_3
    move/from16 v16, v5

    move-object/from16 v17, v7

    invoke-direct/range {v8 .. v18}, Lcom/tzibbur/basic/model/TzbCapabilities;-><init>(IIIIIIZZLjava/lang/String;Z)V

    .line 162
    return-object v8
.end method

.method public static commandResult(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbCommandResult;
    .locals 8
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 339
    new-instance v0, Lcom/tzibbur/basic/model/TzbCommandResult;

    .line 340
    const-string v1, "name"

    const-string v2, ""

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 341
    const-string v3, "ok"

    const/4 v4, 0x0

    invoke-virtual {p0, v3, v4}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v3

    .line 342
    const-string v4, "code"

    invoke-virtual {p0, v4, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 343
    const-string v5, "params"

    invoke-virtual {p0, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 344
    const-string v6, "text"

    invoke-virtual {p0, v6, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object v7, v5

    move-object v5, v2

    move v2, v3

    move-object v3, v4

    move-object v4, v7

    invoke-direct/range {v0 .. v5}, Lcom/tzibbur/basic/model/TzbCommandResult;-><init>(Ljava/lang/String;ZLjava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    .line 339
    return-object v0
.end method

.method public static device(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbDevice;
    .locals 10
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 187
    new-instance v0, Lcom/tzibbur/basic/model/TzbDevice;

    .line 188
    const-string v1, "id"

    const-string v2, ""

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 189
    const-string v3, "userId"

    invoke-virtual {p0, v3, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 190
    const-string v4, "platform"

    invoke-virtual {p0, v4, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 191
    const-string v4, "deviceModel"

    invoke-static {p0, v4}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 192
    const-string v5, "registeredAt"

    invoke-static {p0, v5}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 193
    const-string v6, "lastSeenAt"

    invoke-static {p0, v6}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 196
    const-string v7, "serialNumber"

    invoke-static {p0, v7}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 197
    const-string v8, "imei"

    invoke-static {p0, v8}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v9, v3

    move-object v3, v2

    move-object v2, v9

    invoke-direct/range {v0 .. v8}, Lcom/tzibbur/basic/model/TzbDevice;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 187
    return-object v0
.end method

.method public static devices(Lorg/json/JSONArray;)Ljava/util/List;
    .locals 4
    .param p0, "a"    # Lorg/json/JSONArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbDevice;",
            ">;"
        }
    .end annotation

    .line 201
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 202
    .local v0, "out":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbDevice;>;"
    if-nez p0, :cond_0

    return-object v0

    .line 203
    :cond_0
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_2

    .line 204
    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 205
    .local v2, "o":Lorg/json/JSONObject;
    if-eqz v2, :cond_1

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->device(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbDevice;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 203
    .end local v2
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 207
    .end local v1
    :cond_2
    return-object v0
.end method

.method public static enrollment(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbEnrollment;
    .locals 4
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 97
    new-instance v0, Lcom/tzibbur/basic/model/TzbEnrollment;

    .line 98
    const-string v1, "token"

    invoke-static {p0, v1}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 99
    const-string v2, "user"

    invoke-virtual {p0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->objOrEmpty(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->user(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbUser;

    move-result-object v2

    .line 100
    const-string v3, "device"

    invoke-virtual {p0, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    invoke-static {v3}, Lcom/tzibbur/basic/net/TzbJson;->objOrEmpty(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v3

    invoke-static {v3}, Lcom/tzibbur/basic/net/TzbJson;->device(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbDevice;

    move-result-object v3

    invoke-direct {v0, v1, v2, v3}, Lcom/tzibbur/basic/model/TzbEnrollment;-><init>(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbUser;Lcom/tzibbur/basic/model/TzbDevice;)V

    .line 97
    return-object v0
.end method

.method private static expiresAt(Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 2
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 317
    const-string v0, "expiresAt"

    invoke-static {p0, v0}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 318
    .local v0, "v":Ljava/lang/String;
    if-eqz v0, :cond_0

    move-object v1, v0

    goto :goto_0

    :cond_0
    const-string v1, "expires_at"

    invoke-static {p0, v1}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_0
    return-object v1
.end method

.method public static group(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbGroup;
    .locals 24

    # tzib unified: metadata group
    invoke-static/range {p0 .. p0}, Lcom/android/mms/tzib/TzibMetadata;->group(Lorg/json/JSONObject;)V

    .param p0, "o"    # Lorg/json/JSONObject;

    .line 214
    move-object/from16 v0, p0

    const-string v1, "settings"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    .line 215
    .local v1, "settings":Lorg/json/JSONObject;
    const-string v2, "everyone"

    .line 216
    .local v2, "whoCanPost":Ljava/lang/String;
    const-string v3, "everyone"

    .line 217
    .local v3, "whoCanAddMembers":Ljava/lang/String;
    if-eqz v1, :cond_0

    .line 218
    const-string v4, "whoCanPost"

    const-string v5, "everyone"

    invoke-virtual {v1, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 219
    const-string v4, "whoCanAddMembers"

    invoke-virtual {v1, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object v9, v2

    move-object v10, v3

    goto :goto_0

    .line 217
    :cond_0
    move-object v9, v2

    move-object v10, v3

    .line 222
    .end local v2
    .end local v3
    .local v9, "whoCanPost":Ljava/lang/String;
    .local v10, "whoCanAddMembers":Ljava/lang/String;
    :goto_0
    const-string v2, "limits"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 223
    .local v2, "limits":Lorg/json/JSONObject;
    const/16 v3, 0x3e8

    .line 224
    .local v3, "messageMaxLength":I
    const/16 v4, 0x64

    .line 226
    .local v4, "memberCap":I
    const/4 v5, -0x1

    .line 227
    .local v5, "minMembersToPost":I
    if-eqz v2, :cond_1

    .line 228
    const-string v6, "messageMaxLength"

    const/16 v7, 0x3e8

    invoke-virtual {v2, v6, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    .line 229
    const-string v6, "memberCap"

    const/16 v7, 0x64

    invoke-virtual {v2, v6, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v4

    .line 230
    const-string v6, "minMembersToPost"

    const/4 v7, -0x1

    invoke-virtual {v2, v6, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v5

    move/from16 v19, v3

    move/from16 v20, v4

    move/from16 v21, v5

    goto :goto_1

    .line 227
    :cond_1
    move/from16 v19, v3

    move/from16 v20, v4

    move/from16 v21, v5

    .line 232
    .end local v3
    .end local v4
    .end local v5
    .local v19, "messageMaxLength":I
    .local v20, "memberCap":I
    .local v21, "minMembersToPost":I
    :goto_1
    new-instance v4, Lcom/tzibbur/basic/model/TzbGroup;

    .line 233
    const-string v3, "id"

    const-string v5, ""

    invoke-virtual {v0, v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 234
    const-string v6, "name"

    invoke-virtual {v0, v6, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 235
    const-string v7, "category"

    invoke-virtual {v0, v7, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 236
    const-string v5, "kind"

    const-string v8, "standard"

    invoke-virtual {v0, v5, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 239
    const-string v5, "createdBy"

    invoke-static {v0, v5}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 240
    const-string v5, "createdAt"

    invoke-static {v0, v5}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 241
    const-string v5, "role"

    const-string v13, "member"

    invoke-virtual {v0, v5, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 242
    const-string v5, "memberCount"

    const/4 v14, 0x0

    invoke-virtual {v0, v5, v14}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v5

    .line 243
    const-string v15, "muted"

    invoke-virtual {v0, v15, v14}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v15

    .line 246
    const-string v14, "readSeq"

    move-object/from16 v22, v1

    move-object/from16 v23, v2

    .end local v1
    .end local v2
    .local v22, "settings":Lorg/json/JSONObject;
    .local v23, "limits":Lorg/json/JSONObject;
    const-wide/16 v1, 0x0

    invoke-virtual {v0, v14, v1, v2}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v1

    .line 247
    const-string v14, "unreadCount"

    move-wide/from16 v17, v1

    const/4 v1, 0x0

    invoke-virtual {v0, v14, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    move v14, v5

    move-wide/from16 v16, v17

    move/from16 v18, v1

    move-object v5, v3

    invoke-direct/range {v4 .. v21}, Lcom/tzibbur/basic/model/TzbGroup;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZJIIII)V

    .line 232
    return-object v4
.end method

.method public static groupEvent(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbGroupEvent;
    .locals 15
    .param p0, "f"    # Lorg/json/JSONObject;

    .line 390
    const/4 v0, 0x0

    .line 391
    .local v0, "whoCanPost":Ljava/lang/String;
    const/4 v1, 0x0

    .line 392
    .local v1, "whoCanAddMembers":Ljava/lang/String;
    const-string v2, "settings"

    invoke-virtual {p0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 393
    .local v2, "settings":Lorg/json/JSONObject;
    if-eqz v2, :cond_0

    .line 394
    const-string v3, "whoCanPost"

    invoke-static {v2, v3}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 395
    const-string v3, "whoCanAddMembers"

    invoke-static {v2, v3}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object v13, v0

    move-object v14, v1

    goto :goto_0

    .line 393
    :cond_0
    move-object v13, v0

    move-object v14, v1

    .line 397
    .end local v0
    .end local v1
    .local v13, "whoCanPost":Ljava/lang/String;
    .local v14, "whoCanAddMembers":Ljava/lang/String;
    :goto_0
    new-instance v3, Lcom/tzibbur/basic/model/TzbGroupEvent;

    .line 398
    const-string v0, "event"

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 399
    const-string v0, "groupId"

    invoke-virtual {p0, v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 400
    const-string v0, "userId"

    invoke-static {p0, v0}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 401
    const-string v0, "role"

    invoke-static {p0, v0}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 402
    const-string v0, "actorId"

    invoke-static {p0, v0}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 403
    const-string v0, "reason"

    invoke-static {p0, v0}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 404
    const-string v0, "joinedSeq"

    const-wide/16 v10, -0x1

    invoke-virtual {p0, v0, v10, v11}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v10

    .line 405
    const-string v0, "name"

    invoke-static {p0, v0}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-direct/range {v3 .. v14}, Lcom/tzibbur/basic/model/TzbGroupEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 397
    return-object v3
.end method

.method public static groupPage(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbPage;
    .locals 3
    .param p0, "o"    # Lorg/json/JSONObject;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONObject;",
            ")",
            "Lcom/tzibbur/basic/model/TzbPage<",
            "Lcom/tzibbur/basic/model/TzbGroup;",
            ">;"
        }
    .end annotation

    .line 264
    new-instance v0, Lcom/tzibbur/basic/model/TzbPage;

    const-string v1, "items"

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->groups(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v1

    const-string v2, "nextCursor"

    invoke-static {p0, v2}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lcom/tzibbur/basic/model/TzbPage;-><init>(Ljava/util/List;Ljava/lang/String;)V

    return-object v0
.end method

.method public static groups(Lorg/json/JSONArray;)Ljava/util/List;
    .locals 4
    .param p0, "a"    # Lorg/json/JSONArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbGroup;",
            ">;"
        }
    .end annotation

    .line 254
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 255
    .local v0, "out":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbGroup;>;"
    if-nez p0, :cond_0

    return-object v0

    .line 256
    :cond_0
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_2

    .line 257
    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 258
    .local v2, "o":Lorg/json/JSONObject;
    if-eqz v2, :cond_1

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->group(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 256
    .end local v2
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 260
    .end local v1
    :cond_2
    return-object v0
.end method

.method public static legalDocument(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbLegalDocument;
    .locals 6
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 132
    const-string v0, "document"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 133
    .local v0, "d":Lorg/json/JSONObject;
    if-nez v0, :cond_0

    move-object v0, p0

    .line 134
    :cond_0
    new-instance v1, Lcom/tzibbur/basic/model/TzbLegalDocument;

    .line 135
    const-string v2, "key"

    const-string v3, ""

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 136
    const-string v4, "text"

    invoke-virtual {v0, v4, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 137
    const-string v5, "checksum"

    invoke-virtual {v0, v5, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v4, v3}, Lcom/tzibbur/basic/model/TzbLegalDocument;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 134
    return-object v1
.end method

.method public static member(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMember;
    .locals 7
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 268
    new-instance v0, Lcom/tzibbur/basic/model/TzbMember;

    .line 269
    const-string v1, "userId"

    const-string v2, ""

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 270
    const-string v3, "displayName"

    invoke-virtual {p0, v3, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 271
    const-string v3, "phoneE164"

    invoke-static {p0, v3}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 272
    const-string v4, "kind"

    const-string v5, "person"

    invoke-virtual {p0, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 273
    const-string v5, "role"

    const-string v6, "member"

    invoke-virtual {p0, v5, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 274
    const-string v6, "joinedAt"

    invoke-static {p0, v6}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-direct/range {v0 .. v6}, Lcom/tzibbur/basic/model/TzbMember;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 268
    return-object v0
.end method

.method public static memberAddResult(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMemberAddResult;
    .locals 4
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 292
    new-instance v0, Lcom/tzibbur/basic/model/TzbMemberAddResult;

    .line 293
    const-string v1, "added"

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->members(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v1

    .line 294
    const-string v2, "alreadyMembers"

    invoke-virtual {p0, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->stringList(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v2

    .line 295
    const-string v3, "notFound"

    invoke-virtual {p0, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    invoke-static {v3}, Lcom/tzibbur/basic/net/TzbJson;->stringList(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v3

    invoke-direct {v0, v1, v2, v3}, Lcom/tzibbur/basic/model/TzbMemberAddResult;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    .line 292
    return-object v0
.end method

.method public static memberPage(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbPage;
    .locals 3
    .param p0, "o"    # Lorg/json/JSONObject;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONObject;",
            ")",
            "Lcom/tzibbur/basic/model/TzbPage<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;"
        }
    .end annotation

    .line 288
    new-instance v0, Lcom/tzibbur/basic/model/TzbPage;

    const-string v1, "items"

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->members(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v1

    const-string v2, "nextCursor"

    invoke-static {p0, v2}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lcom/tzibbur/basic/model/TzbPage;-><init>(Ljava/util/List;Ljava/lang/String;)V

    return-object v0
.end method

.method public static members(Lorg/json/JSONArray;)Ljava/util/List;
    .locals 4
    .param p0, "a"    # Lorg/json/JSONArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMember;",
            ">;"
        }
    .end annotation

    .line 278
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 279
    .local v0, "out":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMember;>;"
    if-nez p0, :cond_0

    return-object v0

    .line 280
    :cond_0
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_2

    .line 281
    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 282
    .local v2, "o":Lorg/json/JSONObject;
    if-eqz v2, :cond_1

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->member(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMember;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 280
    .end local v2
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 284
    .end local v1
    :cond_2
    return-object v0
.end method

.method public static message(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMessage;
    .locals 11
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 301
    new-instance v0, Lcom/tzibbur/basic/model/TzbMessage;

    .line 302
    const-string v1, "id"

    const-string v2, ""

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 303
    const-string v3, "groupId"

    invoke-virtual {p0, v3, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 304
    const-string v4, "seq"

    const-wide/16 v5, 0x0

    invoke-virtual {p0, v4, v5, v6}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    .line 305
    const-string v6, "senderId"

    invoke-virtual {p0, v6, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 306
    const-string v7, "body"

    invoke-virtual {p0, v7, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 307
    const-string v7, "clientMessageId"

    invoke-static {p0, v7}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 308
    const-string v8, "createdAt"

    invoke-static {p0, v8}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 309
    invoke-static {p0}, Lcom/tzibbur/basic/net/TzbJson;->expiresAt(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v9

    move-object v10, v6

    move-object v6, v2

    move-object v2, v3

    move-wide v3, v4

    move-object v5, v10

    invoke-direct/range {v0 .. v9}, Lcom/tzibbur/basic/model/TzbMessage;-><init>(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 301
    return-object v0
.end method

.method public static messagePage(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMessagePage;
    .locals 4
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 332
    new-instance v0, Lcom/tzibbur/basic/model/TzbMessagePage;

    .line 333
    const-string v1, "items"

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    invoke-static {v1}, Lcom/tzibbur/basic/net/TzbJson;->messages(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v1

    .line 334
    const-string v2, "nextAfterSeq"

    invoke-static {p0, v2}, Lcom/tzibbur/basic/net/TzbJson;->optLongObj(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v2

    .line 335
    const-string v3, "nextBeforeSeq"

    invoke-static {p0, v3}, Lcom/tzibbur/basic/net/TzbJson;->optLongObj(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    invoke-direct {v0, v1, v2, v3}, Lcom/tzibbur/basic/model/TzbMessagePage;-><init>(Ljava/util/List;Ljava/lang/Long;Ljava/lang/Long;)V

    .line 332
    return-object v0
.end method

.method public static messages(Lorg/json/JSONArray;)Ljava/util/List;
    .locals 4
    .param p0, "a"    # Lorg/json/JSONArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;"
        }
    .end annotation

    .line 322
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 323
    .local v0, "out":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    if-nez p0, :cond_0

    return-object v0

    .line 324
    :cond_0
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_2

    .line 325
    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 326
    .local v2, "o":Lorg/json/JSONObject;
    if-eqz v2, :cond_1

    invoke-static {v2}, Lcom/tzibbur/basic/net/TzbJson;->message(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMessage;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 324
    .end local v2
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 328
    .end local v1
    :cond_2
    return-object v0
.end method

.method private static objOrEmpty(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .locals 1
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 74
    if-eqz p0, :cond_0

    move-object v0, p0

    goto :goto_0

    :cond_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :goto_0
    return-object v0
.end method

.method static optLongObj(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;
    .locals 2
    .param p0, "o"    # Lorg/json/JSONObject;
    .param p1, "key"    # Ljava/lang/String;

    .line 70
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method static optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p0, "o"    # Lorg/json/JSONObject;
    .param p1, "key"    # Ljava/lang/String;

    .line 65
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_0
    return-object v1
.end method

.method public static parseObject(Ljava/lang/String;)Lorg/json/JSONObject;
    .locals 3
    .param p0, "text"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 53
    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 57
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 58
    :catch_0
    move-exception v0

    .line 59
    .local v0, "e":Lorg/json/JSONException;
    new-instance v1, Ljava/io/IOException;

    const-string v2, "malformed JSON response"

    invoke-direct {v1, v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    .line 54
    .end local v0
    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "empty response body where JSON was expected"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static pendingGroup(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbPendingGroup;
    .locals 7
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 367
    new-instance v0, Lcom/tzibbur/basic/model/TzbPendingGroup;

    .line 368
    const-string v1, "groupId"

    const-string v2, ""

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 369
    const-string v2, "deliveredSeq"

    const-wide/16 v3, 0x0

    invoke-virtual {p0, v2, v3, v4}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v2

    .line 370
    const-string v4, "messages"

    invoke-virtual {p0, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    invoke-static {v4}, Lcom/tzibbur/basic/net/TzbJson;->messages(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v4

    .line 371
    const-string v5, "hasMore"

    const/4 v6, 0x0

    invoke-virtual {p0, v5, v6}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v5

    invoke-direct/range {v0 .. v5}, Lcom/tzibbur/basic/model/TzbPendingGroup;-><init>(Ljava/lang/String;JLjava/util/List;Z)V

    .line 367
    return-object v0
.end method

.method public static pendingGroups(Lorg/json/JSONObject;)Ljava/util/List;
    .locals 5
    .param p0, "o"    # Lorg/json/JSONObject;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONObject;",
            ")",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbPendingGroup;",
            ">;"
        }
    .end annotation

    .line 375
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 376
    .local v0, "out":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbPendingGroup;>;"
    const-string v1, "groups"

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    .line 377
    .local v1, "a":Lorg/json/JSONArray;
    if-nez v1, :cond_0

    return-object v0

    .line 378
    :cond_0
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_2

    .line 379
    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    .line 380
    .local v3, "g":Lorg/json/JSONObject;
    if-eqz v3, :cond_1

    invoke-static {v3}, Lcom/tzibbur/basic/net/TzbJson;->pendingGroup(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbPendingGroup;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 378
    .end local v3
    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 382
    .end local v2
    :cond_2
    return-object v0
.end method

.method public static problem(ILjava/lang/String;I)Lcom/tzibbur/basic/net/TzbProblem;
    .locals 10
    .param p0, "httpStatus"    # I
    .param p1, "body"    # Ljava/lang/String;
    .param p2, "retryAfterSeconds"    # I

    .line 418
    const/4 v1, 0x0

    .line 419
    .local v1, "code":Ljava/lang/String;
    const/4 v2, 0x0

    .line 420
    .local v2, "detail":Ljava/lang/String;
    const/4 v3, 0x0

    .line 421
    .local v3, "requestId":Ljava/lang/String;
    const/4 v4, 0x0

    .line 422
    .local v4, "errors":Lorg/json/JSONObject;
    if-eqz p1, :cond_3

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    .line 424
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 427
    .local v0, "o":Lorg/json/JSONObject;
    const-string v5, "title"

    invoke-static {v0, v5}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object v1, v5

    .line 428
    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_2

    .line 429
    :cond_0
    const-string v5, "type"

    invoke-static {v0, v5}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 430
    .local v5, "type":Ljava/lang/String;
    if-eqz v5, :cond_2

    .line 431
    const/16 v6, 0x3a

    invoke-virtual {v5, v6}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v6

    .line 432
    .local v6, "i":I
    if-ltz v6, :cond_1

    add-int/lit8 v7, v6, 0x1

    invoke-virtual {v5, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v7

    goto :goto_0

    :cond_1
    move-object v7, v5

    :goto_0
    move-object v1, v7

    .line 435
    .end local v5
    .end local v6
    :cond_2
    const-string v5, "detail"

    invoke-static {v0, v5}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object v2, v5

    .line 436
    const-string v5, "requestId"

    invoke-static {v0, v5}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object v3, v5

    .line 437
    const-string v5, "errors"

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v4, v5

    .line 440
    .end local v0
    move-object v7, v3

    move-object v8, v4

    goto :goto_1

    .line 438
    :catch_0
    move-exception v0

    move-object v7, v3

    move-object v8, v4

    goto :goto_1

    .line 442
    :cond_3
    move-object v7, v3

    move-object v8, v4

    .end local v3
    .end local v4
    .local v7, "requestId":Ljava/lang/String;
    .local v8, "errors":Lorg/json/JSONObject;
    :goto_1
    if-eqz v1, :cond_4

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_5

    :cond_4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "http_"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_5
    move-object v4, v1

    .line 443
    .end local v1
    .local v4, "code":Ljava/lang/String;
    if-nez v2, :cond_6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "HTTP "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_6
    move-object v6, v2

    .line 444
    .end local v2
    .local v6, "detail":Ljava/lang/String;
    new-instance v3, Lcom/tzibbur/basic/net/TzbProblem;

    move v5, p0

    move v9, p2

    .end local p0
    .end local p2
    .local v5, "httpStatus":I
    .local v9, "retryAfterSeconds":I
    invoke-direct/range {v3 .. v9}, Lcom/tzibbur/basic/net/TzbProblem;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;I)V

    return-object v3
.end method

.method public static sendResult(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbSendResult;
    .locals 7
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 353
    const-string v0, "command"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 354
    .local v0, "command":Lorg/json/JSONObject;
    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    .line 355
    new-instance v3, Lcom/tzibbur/basic/model/TzbSendResult;

    invoke-static {v0}, Lcom/tzibbur/basic/net/TzbJson;->commandResult(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbCommandResult;

    move-result-object v4

    invoke-direct {v3, v2, v1, v4}, Lcom/tzibbur/basic/model/TzbSendResult;-><init>(Lcom/tzibbur/basic/model/TzbMessage;ZLcom/tzibbur/basic/model/TzbCommandResult;)V

    return-object v3

    .line 357
    :cond_0
    const-string v3, "message"

    invoke-virtual {p0, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 358
    .local v3, "message":Lorg/json/JSONObject;
    new-instance v4, Lcom/tzibbur/basic/model/TzbSendResult;

    .line 359
    if-eqz v3, :cond_1

    invoke-static {v3}, Lcom/tzibbur/basic/net/TzbJson;->message(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbMessage;

    move-result-object v5

    goto :goto_0

    :cond_1
    move-object v5, v2

    .line 360
    :goto_0
    const-string v6, "duplicate"

    invoke-virtual {p0, v6, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v1

    invoke-direct {v4, v5, v1, v2}, Lcom/tzibbur/basic/model/TzbSendResult;-><init>(Lcom/tzibbur/basic/model/TzbMessage;ZLcom/tzibbur/basic/model/TzbCommandResult;)V

    .line 358
    return-object v4
.end method

.method public static stringList(Lorg/json/JSONArray;)Ljava/util/List;
    .locals 3
    .param p0, "a"    # Lorg/json/JSONArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 78
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 79
    .local v0, "out":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    if-nez p0, :cond_0

    return-object v0

    .line 80
    :cond_0
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_2

    .line 81
    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 82
    .local v2, "s":Ljava/lang/String;
    if-eqz v2, :cond_1

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 80
    .end local v2
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 84
    .end local v1
    :cond_2
    return-object v0
.end method

.method public static user(Lorg/json/JSONObject;)Lcom/tzibbur/basic/model/TzbUser;
    .locals 7
    .param p0, "o"    # Lorg/json/JSONObject;

    .line 178
    new-instance v0, Lcom/tzibbur/basic/model/TzbUser;

    .line 179
    const-string v1, "id"

    const-string v2, ""

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 180
    const-string v3, "phoneE164"

    invoke-static {p0, v3}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 181
    const-string v4, "kind"

    const-string v5, "person"

    invoke-virtual {p0, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 182
    const-string v5, "displayName"

    invoke-virtual {p0, v5, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 183
    const-string v5, "createdAt"

    invoke-static {p0, v5}, Lcom/tzibbur/basic/net/TzbJson;->optStr(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object v6, v4

    move-object v4, v2

    move-object v2, v3

    move-object v3, v6

    invoke-direct/range {v0 .. v5}, Lcom/tzibbur/basic/model/TzbUser;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 178
    return-object v0
.end method
