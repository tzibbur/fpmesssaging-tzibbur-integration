.class public final Lcom/tzibbur/basic/net/TzbHttp;
.super Ljava/lang/Object;
.source "TzbHttp.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tzibbur/basic/net/TzbHttp$Response;
    }
.end annotation


# static fields
.field private static final CONNECT_TIMEOUT_MS:I = 0x3a98

.field private static final READ_TIMEOUT_MS:I = 0x7530

.field private static final TAG:Ljava/lang/String; = "TzbHttp"


# instance fields
.field private final baseUrl:Ljava/lang/String;

.field private final tokens:Lcom/tzibbur/basic/net/TzbTokenSupplier;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/tzibbur/basic/net/TzbTokenSupplier;)V
    .locals 2
    .param p1, "baseUrl"    # Ljava/lang/String;
    .param p2, "tokens"    # Lcom/tzibbur/basic/net/TzbTokenSupplier;

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    const-string v0, "/"

    invoke-virtual {p1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 44
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    move-object v0, p1

    :goto_0
    iput-object v0, p0, Lcom/tzibbur/basic/net/TzbHttp;->baseUrl:Ljava/lang/String;

    .line 45
    iput-object p2, p0, Lcom/tzibbur/basic/net/TzbHttp;->tokens:Lcom/tzibbur/basic/net/TzbTokenSupplier;

    .line 46
    return-void
.end method

.method private static findDelegate(Ljava/net/HttpURLConnection;)Ljava/lang/Object;
    .locals 4
    .param p0, "conn"    # Ljava/net/HttpURLConnection;

    .line 141
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    .local v0, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    :goto_0
    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 143
    :try_start_0
    const-string v2, "delegate"

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    .line 144
    .local v2, "d":Ljava/lang/reflect/Field;
    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    .line 145
    invoke-virtual {v2, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    :try_end_0
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    .line 148
    .end local v2
    :catch_0
    move-exception v2

    .line 149
    .local v2, "e":Ljava/lang/Exception;
    return-object v1

    .line 146
    .end local v2
    :catch_1
    move-exception v1

    .line 150
    nop

    .line 141
    invoke-virtual {v0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v0

    goto :goto_0

    .line 152
    .end local v0
    :cond_0
    return-object v1
.end method

.method private static path(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p0, "pathAndQuery"    # Ljava/lang/String;

    .line 115
    const/16 v0, 0x3f

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    .line 116
    .local v0, "q":I
    if-gez v0, :cond_0

    move-object v1, p0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    :goto_0
    return-object v1
.end method

.method private static readAll(Ljava/io/InputStream;)Ljava/lang/String;
    .locals 6
    .param p0, "in"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 156
    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    .line 158
    :cond_0
    :try_start_0
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 159
    .local v1, "buf":Ljava/io/ByteArrayOutputStream;
    const/16 v2, 0x1000

    new-array v2, v2, [B

    .line 161
    .local v2, "chunk":[B
    :goto_0
    invoke-virtual {p0, v2}, Ljava/io/InputStream;->read([B)I

    move-result v3

    move v4, v3

    .local v4, "n":I
    const/4 v5, -0x1

    if-eq v3, v5, :cond_1

    .line 162
    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_0

    .line 164
    :cond_1
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v3

    if-nez v3, :cond_2

    :goto_1
    goto :goto_2

    :cond_2
    new-instance v0, Ljava/lang/String;

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    const-string v5, "UTF-8"

    invoke-direct {v0, v3, v5}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    .line 167
    :goto_2
    :try_start_1
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 169
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_3

    .line 168
    :catch_0
    move-exception v3

    .line 164
    :goto_3
    return-object v0

    .line 166
    .end local v1
    .end local v2
    .end local v4
    :catchall_0
    move-exception v0

    .line 167
    :try_start_2
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 169
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_4

    .line 168
    :catch_1
    move-exception v1

    .line 170
    :goto_4
    throw v0
.end method

.method private static readAllQuiet(Ljava/io/InputStream;)Ljava/lang/String;
    .locals 2
    .param p0, "in"    # Ljava/io/InputStream;

    .line 175
    :try_start_0
    invoke-static {p0}, Lcom/tzibbur/basic/net/TzbHttp;->readAll(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v0

    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 176
    :catch_0
    move-exception v0

    .line 177
    .local v0, "e":Ljava/io/IOException;
    const/4 v1, 0x0

    return-object v1
.end method

.method private static setMethod(Ljava/net/HttpURLConnection;Ljava/lang/String;)V
    .locals 4
    .param p0, "conn"    # Ljava/net/HttpURLConnection;
    .param p1, "method"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 121
    :try_start_0
    invoke-virtual {p0, p1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 122
    :try_end_0
    .catch Ljava/net/ProtocolException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 123
    :catch_0
    move-exception v0

    .line 127
    :try_start_1
    invoke-static {p0}, Lcom/tzibbur/basic/net/TzbHttp;->findDelegate(Ljava/net/HttpURLConnection;)Ljava/lang/Object;

    move-result-object v0

    .line 128
    .local v0, "delegate":Ljava/lang/Object;
    const-class v1, Ljava/net/HttpURLConnection;

    const-string v2, "method"

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    .line 129
    .local v1, "f":Ljava/lang/reflect/Field;
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    .line 130
    instance-of v2, v0, Ljava/net/HttpURLConnection;

    if-eqz v2, :cond_0

    .line 131
    invoke-virtual {v1, v0, p1}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 133
    :cond_0
    invoke-virtual {v1, p0, p1}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 136
    .end local v0
    .end local v1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    nop

    .line 137
    return-void

    .line 134
    :catch_1
    move-exception v0

    .line 135
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "HTTP method "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " unsupported on this platform"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1
.end method


# virtual methods
.method public exec(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Lcom/tzibbur/basic/net/TzbHttp$Response;
    .locals 10
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "pathAndQuery"    # Ljava/lang/String;
    .param p3, "body"    # Lorg/json/JSONObject;
    .param p4, "auth"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 57
    const-string v0, " "

    new-instance v1, Ljava/net/URL;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/tzibbur/basic/net/TzbHttp;->baseUrl:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 58
    .local v1, "url":Ljava/net/URL;
    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v2

    check-cast v2, Ljava/net/HttpURLConnection;

    .line 60
    .local v2, "conn":Ljava/net/HttpURLConnection;
    const/16 v3, 0x3a98

    :try_start_0
    invoke-virtual {v2, v3}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 61
    const/16 v3, 0x7530

    invoke-virtual {v2, v3}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 62
    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/net/HttpURLConnection;->setUseCaches(Z)V

    .line 63
    invoke-static {v2, p1}, Lcom/tzibbur/basic/net/TzbHttp;->setMethod(Ljava/net/HttpURLConnection;Ljava/lang/String;)V

    .line 64
    const-string v3, "Accept"

    const-string v4, "application/json, application/problem+json"

    invoke-virtual {v2, v3, v4}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 65
    if-eqz p4, :cond_0

    .line 66
    iget-object v3, p0, Lcom/tzibbur/basic/net/TzbHttp;->tokens:Lcom/tzibbur/basic/net/TzbTokenSupplier;

    invoke-interface {v3}, Lcom/tzibbur/basic/net/TzbTokenSupplier;->token()Ljava/lang/String;

    move-result-object v3

    .line 67
    .local v3, "token":Ljava/lang/String;
    if-eqz v3, :cond_0

    .line 68
    const-string v4, "Authorization"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Bearer "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 76
    .end local v3
    :cond_0
    if-nez p3, :cond_1

    const-string v3, "GET"

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    .line 77
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    move-object p3, v3

    .line 79
    :cond_1
    if-eqz p3, :cond_2

    .line 80
    invoke-virtual {p3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "UTF-8"

    invoke-virtual {v3, v4}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v3

    .line 81
    .local v3, "data":[B
    const/4 v4, 0x1

    invoke-virtual {v2, v4}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 82
    const-string v4, "Content-Type"

    const-string v5, "application/json; charset=utf-8"

    invoke-virtual {v2, v4, v5}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 83
    array-length v4, v3

    invoke-virtual {v2, v4}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 84
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v4

    .line 85
    .local v4, "out":Ljava/io/OutputStream;
    invoke-virtual {v4, v3}, Ljava/io/OutputStream;->write([B)V

    .line 86
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V

    .line 89
    .end local v3
    .end local v4
    :cond_2
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v3

    .line 90
    .local v3, "status":I
    const/16 v4, 0xc8

    if-lt v3, v4, :cond_4

    const/16 v4, 0x12c

    if-ge v3, v4, :cond_4

    .line 91
    const/16 v0, 0xcc

    if-ne v3, v0, :cond_3

    const/4 v0, 0x0

    goto :goto_0

    :cond_3
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    invoke-static {v0}, Lcom/tzibbur/basic/net/TzbHttp;->readAll(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v0

    .line 92
    .local v0, "text":Ljava/lang/String;
    :goto_0
    new-instance v4, Lcom/tzibbur/basic/net/TzbHttp$Response;

    invoke-direct {v4, v3, v0}, Lcom/tzibbur/basic/net/TzbHttp$Response;-><init>(ILjava/lang/String;)V

    .line 103
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 92
    return-object v4

    .line 94
    .end local v0
    :cond_4
    :try_start_1
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object v4

    invoke-static {v4}, Lcom/tzibbur/basic/net/TzbHttp;->readAllQuiet(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v4

    .line 95
    .local v4, "errorBody":Ljava/lang/String;
    const-string v5, "Retry-After"

    const/4 v6, -0x1

    invoke-virtual {v2, v5, v6}, Ljava/net/HttpURLConnection;->getHeaderFieldInt(Ljava/lang/String;I)I

    move-result v5

    .line 96
    .local v5, "retryAfter":I
    invoke-static {v3, v4, v5}, Lcom/tzibbur/basic/net/TzbJson;->problem(ILjava/lang/String;I)Lcom/tzibbur/basic/net/TzbProblem;

    move-result-object v6

    .line 99
    .local v6, "problem":Lcom/tzibbur/basic/net/TzbProblem;
    const-string v7, "TzbHttp"

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-static {p2}, Lcom/tzibbur/basic/net/TzbHttp;->path(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " -> "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v8, v6, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v8, " requestId="

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v8, v6, Lcom/tzibbur/basic/net/TzbProblem;->requestId:Ljava/lang/String;

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 101
    nop

    .end local v1
    .end local v2
    .end local p1
    .end local p2
    .end local p3
    .end local p4
    throw v6

    .line 103
    .end local v3
    .end local v4
    .end local v5
    .end local v6
    .restart local v1
    .restart local v2
    .restart local p1
    .restart local p2
    .restart local p3
    .restart local p4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0
    :catchall_0

    move-exception v0

    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 104
    throw v0
.end method
