.class public final Lcom/tzibbur/basic/net/TzbHttp$Response;
.super Ljava/lang/Object;
.source "TzbHttp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/net/TzbHttp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Response"
.end annotation


# instance fields
.field public final body:Ljava/lang/String;

.field public final status:I


# direct methods
.method constructor <init>(ILjava/lang/String;)V
    .locals 0
    .param p1, "status"    # I
    .param p2, "body"    # Ljava/lang/String;

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    iput p1, p0, Lcom/tzibbur/basic/net/TzbHttp$Response;->status:I

    .line 34
    iput-object p2, p0, Lcom/tzibbur/basic/net/TzbHttp$Response;->body:Ljava/lang/String;

    .line 35
    return-void
.end method
