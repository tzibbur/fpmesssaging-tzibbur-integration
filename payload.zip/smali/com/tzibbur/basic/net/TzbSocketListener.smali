.class public interface abstract Lcom/tzibbur/basic/net/TzbSocketListener;
.super Ljava/lang/Object;
.source "TzbSocketListener.java"


# virtual methods
.method public abstract onClosed(III)V
.end method

.method public abstract onErrorFrame(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract onGroupEvent(Lcom/tzibbur/basic/model/TzbGroupEvent;)V
.end method

.method public abstract onHello(Ljava/lang/String;Ljava/lang/String;III)V
.end method

.method public abstract onMessages(Ljava/lang/String;Ljava/util/List;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;Z)V"
        }
    .end annotation
.end method

.method public abstract onProtocolTooNew(I)V
.end method

.method public abstract onRead(Ljava/lang/String;J)V
.end method
