.class public interface abstract Lcom/tzibbur/basic/net/TzbTokenSupplier;
.super Ljava/lang/Object;
.source "TzbTokenSupplier.java"


# virtual methods
.method public abstract token()Ljava/lang/String;
.end method
