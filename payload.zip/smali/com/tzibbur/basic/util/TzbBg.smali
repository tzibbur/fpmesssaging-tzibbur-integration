.class public final Lcom/tzibbur/basic/util/TzbBg;
.super Ljava/lang/Object;
.source "TzbBg.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tzibbur/basic/util/TzbBg$Callback;
    }
.end annotation


# static fields
.field private static final EXECUTOR:Ljava/util/concurrent/ExecutorService;

.field private static final MAIN:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 19
    const/4 v0, 0x2

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lcom/tzibbur/basic/util/TzbBg;->EXECUTOR:Ljava/util/concurrent/ExecutorService;

    .line 20
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lcom/tzibbur/basic/util/TzbBg;->MAIN:Landroid/os/Handler;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000()Landroid/os/Handler;
    .locals 1

    .line 11
    sget-object v0, Lcom/tzibbur/basic/util/TzbBg;->MAIN:Landroid/os/Handler;

    return-object v0
.end method

.method public static onMain(Ljava/lang/Runnable;)V
    .locals 1
    .param p0, "task"    # Ljava/lang/Runnable;

    .line 29
    sget-object v0, Lcom/tzibbur/basic/util/TzbBg;->MAIN:Landroid/os/Handler;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 30
    return-void
.end method

.method public static run(Ljava/lang/Runnable;)V
    .locals 1
    .param p0, "task"    # Ljava/lang/Runnable;

    .line 25
    sget-object v0, Lcom/tzibbur/basic/util/TzbBg;->EXECUTOR:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, p0}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 26
    return-void
.end method

.method public static run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/Callable<",
            "TT;>;",
            "Lcom/tzibbur/basic/util/TzbBg$Callback<",
            "TT;>;)V"
        }
    .end annotation

    .line 34
    .local p0, "task":Ljava/util/concurrent/Callable;, "Ljava/util/concurrent/Callable<TT;>;"
    .local p1, "callback":Lcom/tzibbur/basic/util/TzbBg$Callback;, "Lcom/tzibbur/basic/util/TzbBg$Callback<TT;>;"
    sget-object v0, Lcom/tzibbur/basic/util/TzbBg;->EXECUTOR:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lcom/tzibbur/basic/util/TzbBg$1;

    invoke-direct {v1, p0, p1}, Lcom/tzibbur/basic/util/TzbBg$1;-><init>(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 55
    return-void
.end method
