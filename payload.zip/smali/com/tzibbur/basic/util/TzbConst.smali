.class public final Lcom/tzibbur/basic/util/TzbConst;
.super Ljava/lang/Object;
.source "TzbConst.java"


# static fields
.field public static final API_BASE:Ljava/lang/String; = "https://api.tzibbur.me/v1"

.field public static final GROUP_KIND_STANDARD:Ljava/lang/String; = "standard"

.field public static final GROUP_KIND_SYSTEM:Ljava/lang/String; = "system"

.field public static final MEMBER_KIND_ORGANIZATION:Ljava/lang/String; = "organization"

.field public static final MEMBER_KIND_PERSON:Ljava/lang/String; = "person"

.field public static final MEMBER_KIND_SERVICE:Ljava/lang/String; = "service"

.field public static final PLATFORM:Ljava/lang/String; = "kosher"

.field public static final ROLE_ADMIN:Ljava/lang/String; = "admin"

.field public static final ROLE_MEMBER:Ljava/lang/String; = "member"

.field public static final SETTING_ADMINS:Ljava/lang/String; = "admins"

.field public static final SETTING_EVERYONE:Ljava/lang/String; = "everyone"

.field public static final SPONSORED_USER_ID:Ljava/lang/String; = "00000000-0000-7000-8000-000000000002"

.field public static final SYSTEM_USER_ID:Ljava/lang/String; = "00000000-0000-7000-8000-000000000001"

.field public static final WS_PROTOCOL_VERSION:I = 0x1

.field public static final WS_URL:Ljava/lang/String; = "wss://api.tzibbur.me/v1/ws"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
