.class Lcom/tzibbur/basic/util/TzbBg$1$1;
.super Ljava/lang/Object;
.source "TzbBg.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/util/TzbBg$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/util/TzbBg$1;

.field final synthetic val$result:Ljava/lang/Object;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/util/TzbBg$1;Ljava/lang/Object;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/util/TzbBg$1;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 39
    iput-object p1, p0, Lcom/tzibbur/basic/util/TzbBg$1$1;->this$0:Lcom/tzibbur/basic/util/TzbBg$1;

    iput-object p2, p0, Lcom/tzibbur/basic/util/TzbBg$1$1;->val$result:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 42
    iget-object v0, p0, Lcom/tzibbur/basic/util/TzbBg$1$1;->this$0:Lcom/tzibbur/basic/util/TzbBg$1;

    iget-object v0, v0, Lcom/tzibbur/basic/util/TzbBg$1;->val$callback:Lcom/tzibbur/basic/util/TzbBg$Callback;

    iget-object v1, p0, Lcom/tzibbur/basic/util/TzbBg$1$1;->val$result:Ljava/lang/Object;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/util/TzbBg$Callback;->onResult(Ljava/lang/Object;)V

    .line 43
    return-void
.end method
