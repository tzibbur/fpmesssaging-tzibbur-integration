.class public final Lcom/tzibbur/basic/util/TzbKillSwitch;
.super Ljava/lang/Object;
.source "TzbKillSwitch.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static blocked(Landroid/content/Context;)Z
    .registers 1

    .line 11
    invoke-static {p0}, Lcom/android/mms/tzib/TzibGate;->sync(Landroid/content/Context;)Z

    .line 12
    const/4 p0, 0x0

    return p0
.end method
