.class Lcom/tzibbur/basic/util/TzbBg$1;
.super Ljava/lang/Object;
.source "TzbBg.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$callback:Lcom/tzibbur/basic/util/TzbBg$Callback;

.field final synthetic val$task:Ljava/util/concurrent/Callable;


# direct methods
.method constructor <init>(Ljava/util/concurrent/Callable;Lcom/tzibbur/basic/util/TzbBg$Callback;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 34
    iput-object p1, p0, Lcom/tzibbur/basic/util/TzbBg$1;->val$task:Ljava/util/concurrent/Callable;

    iput-object p2, p0, Lcom/tzibbur/basic/util/TzbBg$1;->val$callback:Lcom/tzibbur/basic/util/TzbBg$Callback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 38
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/util/TzbBg$1;->val$task:Ljava/util/concurrent/Callable;

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    .line 39
    .local v0, "result":Ljava/lang/Object;, "TT;"
    invoke-static {}, Lcom/tzibbur/basic/util/TzbBg;->access$000()Landroid/os/Handler;

    move-result-object v1

    new-instance v2, Lcom/tzibbur/basic/util/TzbBg$1$1;

    invoke-direct {v2, p0, v0}, Lcom/tzibbur/basic/util/TzbBg$1$1;-><init>(Lcom/tzibbur/basic/util/TzbBg$1;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 52
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    nop

    .end local v0
    goto :goto_0

    .line 45
    :catch_0
    move-exception v0

    .line 46
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, Lcom/tzibbur/basic/util/TzbBg;->access$000()Landroid/os/Handler;

    move-result-object v1

    new-instance v2, Lcom/tzibbur/basic/util/TzbBg$1$2;

    invoke-direct {v2, p0, v0}, Lcom/tzibbur/basic/util/TzbBg$1$2;-><init>(Lcom/tzibbur/basic/util/TzbBg$1;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 53
    .end local v0
    :goto_0
    return-void
.end method
