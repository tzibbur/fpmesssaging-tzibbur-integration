.class public final Lcom/tzibbur/basic/R$menu;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "menu"
.end annotation


# static fields
.field public static tzb_conversation_menu:I = 0x7f0b0007    # @menu/tzb_conversation_menu 'res/menu/tzb_conversation_menu.xml'

.field public static tzb_group_list_menu:I = 0x7f0b0008    # @menu/tzb_group_list_menu 'res/menu/tzb_group_list_menu.xml'

.field public static tzb_members_menu:I = 0x7f0b0009    # @menu/tzb_members_menu 'res/menu/tzb_members_menu.xml'


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
