.class public final Lcom/tzibbur/basic/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tzibbur/basic/R$color;,
        Lcom/tzibbur/basic/R$dimen;,
        Lcom/tzibbur/basic/R$drawable;,
        Lcom/tzibbur/basic/R$id;,
        Lcom/tzibbur/basic/R$layout;,
        Lcom/tzibbur/basic/R$menu;,
        Lcom/tzibbur/basic/R$mipmap;,
        Lcom/tzibbur/basic/R$plurals;,
        Lcom/tzibbur/basic/R$string;,
        Lcom/tzibbur/basic/R$style;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
