.class public final Lcom/tzibbur/basic/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static tzb_accent:I = 0x7f0500be    # @color/tzb_accent '#0d9488'

.field public static tzb_bubble_in:I = 0x7f0500bf    # @color/tzb_bubble_in '#ffffff'

.field public static tzb_bubble_out:I = 0x7f0500c0    # @color/tzb_bubble_out '#ccfbf1'

.field public static tzb_bubble_pending:I = 0x7f0500c1    # @color/tzb_bubble_pending '#e8e8e8'

.field public static tzb_bubble_sponsored:I = 0x7f0500c2    # @color/tzb_bubble_sponsored '#e6d3a3'

.field public static tzb_bubble_system:I = 0x7f0500c3    # @color/tzb_bubble_system '#fff3d6'

.field public static tzb_button_primary_text:I = 0x7f0500c4    # @color/tzb_button_primary_text 'res/color/tzb_button_primary_text.xml'

.field public static tzb_compose_divider:I = 0x7f0500c5    # @color/tzb_compose_divider '#d5d5d5'

.field public static tzb_compose_edit_focus_bg:I = 0x7f0500c6    # @color/tzb_compose_edit_focus_bg '#efefef'

.field public static tzb_compose_edit_stroke:I = 0x7f0500c7    # @color/tzb_compose_edit_stroke '#999999'

.field public static tzb_compose_panel_bg:I = 0x7f0500c8    # @color/tzb_compose_panel_bg '#e1e1e1'

.field public static tzb_divider:I = 0x7f0500c9    # @color/tzb_divider '#d9d9d9'

.field public static tzb_error:I = 0x7f0500ca    # @color/tzb_error '#c62828'

.field public static tzb_focus_bg:I = 0x7f0500cb    # @color/tzb_focus_bg '#99f6e4'

.field public static tzb_pressed_bg:I = 0x7f0500cc    # @color/tzb_pressed_bg '#5eead4'

.field public static tzb_primary:I = 0x7f0500cd    # @color/tzb_primary '#0f766e'

.field public static tzb_primary_dark:I = 0x7f0500ce    # @color/tzb_primary_dark '#115e59'

.field public static tzb_screen_bg:I = 0x7f0500cf    # @color/tzb_screen_bg '#f1f2f5'

.field public static tzb_text_hint:I = 0x7f0500d0    # @color/tzb_text_hint '#a3a3a3'

.field public static tzb_text_on_primary:I = 0x7f0500d1    # @color/tzb_text_on_primary '#ffffff'

.field public static tzb_text_primary:I = 0x7f0500d2    # @color/tzb_text_primary '#1a1a1a'

.field public static tzb_text_secondary:I = 0x7f0500d3    # @color/tzb_text_secondary '#666666'

.field public static tzb_unread_badge:I = 0x7f0500d4    # @color/tzb_unread_badge '#0d9488'


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
