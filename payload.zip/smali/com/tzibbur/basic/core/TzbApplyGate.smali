.class public final Lcom/tzibbur/basic/core/TzbApplyGate;
.super Ljava/lang/Object;
.source "TzbApplyGate.java"


# static fields
.field private static final APPLY_ACTIVITY:Ljava/lang/String; = "com.tzibbur.basic.ui.TzbApplyActivity"

.field public static final EXTRA_PHONE:Ljava/lang/String; = "tzb_apply_phone"

.field private static final MIN_CALL_SPACING_SECONDS:I = 0x8

.field private static final RECHECK_INTERVAL_MS:J = 0x1499700L


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 62
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static apply(Landroid/content/Context;Ljava/lang/String;Lcom/tzibbur/basic/model/TzbApplicationStatus;)V
    .locals 2
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "phoneE164"    # Ljava/lang/String;
    .param p2, "status"    # Lcom/tzibbur/basic/model/TzbApplicationStatus;

    .line 188
    if-nez p2, :cond_0

    .line 189
    return-void

    .line 191
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->applyStore()Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v0

    .line 192
    .local v0, "store":Lcom/tzibbur/basic/store/TzbApplyStore;
    invoke-virtual {p2}, Lcom/tzibbur/basic/model/TzbApplicationStatus;->isApproved()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 193
    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/store/TzbApplyStore;->setApproved(Ljava/lang/String;)V

    .line 194
    return-void

    .line 196
    :cond_1
    invoke-virtual {p2}, Lcom/tzibbur/basic/model/TzbApplicationStatus;->revokesApproval()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/store/TzbApplyStore;->approvedFor(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 197
    iget-object v1, p2, Lcom/tzibbur/basic/model/TzbApplicationStatus;->status:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/store/TzbApplyStore;->clearApproval(Ljava/lang/String;)V

    .line 198
    return-void

    .line 202
    :cond_2
    iget-object v1, p2, Lcom/tzibbur/basic/model/TzbApplicationStatus;->status:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/tzibbur/basic/store/TzbApplyStore;->setLastStatus(Ljava/lang/String;)V

    .line 203
    return-void
.end method

.method public static check(Landroid/content/Context;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbApplicationStatus;
    .locals 5
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "phoneE164"    # Ljava/lang/String;

    .line 154
    const/4 v0, 0x0

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_0

    goto :goto_1

    .line 157
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v1

    .line 158
    .local v1, "core":Lcom/tzibbur/basic/core/TzbCore;
    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->applyStore()Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v2

    .line 159
    .local v2, "store":Lcom/tzibbur/basic/store/TzbApplyStore;
    invoke-virtual {v2}, Lcom/tzibbur/basic/store/TzbApplyStore;->statusCallAllowed()Z

    move-result v3

    if-nez v3, :cond_1

    .line 160
    return-object v0

    .line 164
    :cond_1
    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Lcom/tzibbur/basic/store/TzbApplyStore;->holdStatusCalls(I)V

    .line 166
    :try_start_0
    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v3

    invoke-interface {v3, p1}, Lcom/tzibbur/basic/net/TzbApi;->applicationStatus(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbApplicationStatus;

    move-result-object v3

    .line 167
    .local v3, "status":Lcom/tzibbur/basic/model/TzbApplicationStatus;
    invoke-static {p0, p1, v3}, Lcom/tzibbur/basic/core/TzbApplyGate;->apply(Landroid/content/Context;Ljava/lang/String;Lcom/tzibbur/basic/model/TzbApplicationStatus;)V

    .line 168
    :try_end_0
    .catch Lcom/tzibbur/basic/net/TzbProblem; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v3

    .line 177
    .end local v3
    :catch_0
    move-exception v3

    .line 178
    .local v3, "offline":Ljava/io/IOException;
    return-object v0

    .line 169
    .end local v3
    :catch_1
    move-exception v3

    .line 170
    .local v3, "problem":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-virtual {v3}, Lcom/tzibbur/basic/net/TzbProblem;->isRateLimited()Z

    move-result v4

    if-eqz v4, :cond_3

    .line 171
    iget v4, v3, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    if-lez v4, :cond_2

    .line 172
    iget v4, v3, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    goto :goto_0

    :cond_2
    const/16 v4, 0x3c

    .line 171
    :goto_0
    invoke-virtual {v2, v4}, Lcom/tzibbur/basic/store/TzbApplyStore;->holdStatusCalls(I)V

    .line 176
    :cond_3
    return-object v0

    .line 155
    .end local v1
    .end local v2
    .end local v3
    :cond_4
    :goto_1
    return-object v0
.end method

.method public static enabled(Landroid/content/Context;)Z
    .locals 1
    .param p0, "context"    # Landroid/content/Context;

    .line 68
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbApplyFlag;->required(Landroid/content/Context;)Z

    move-result v0

    return v0
.end method

.method public static enforce(Landroid/app/Activity;)Z
    .locals 1
    .param p0, "activity"    # Landroid/app/Activity;

    .line 110
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->holding(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 111
    const/4 v0, 0x0

    return v0

    .line 113
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/tzibbur/basic/core/TzbApplyGate;->show(Landroid/content/Context;Ljava/lang/String;)V

    .line 114
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 115
    const/4 v0, 0x1

    return v0
.end method

.method public static holding(Landroid/content/Context;)Z
    .locals 3
    .param p0, "context"    # Landroid/content/Context;

    .line 91
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbApplyFlag;->required(Landroid/content/Context;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 92
    return v1

    .line 94
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    .line 95
    .local v0, "session":Lcom/tzibbur/basic/store/TzbSession;
    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v2

    if-nez v2, :cond_1

    .line 97
    return v1

    .line 99
    :cond_1
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->applyStore()Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v1

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/tzibbur/basic/store/TzbApplyStore;->approvedFor(Ljava/lang/String;)Z

    move-result v1

    xor-int/lit8 v1, v1, 0x1

    return v1
.end method

.method public static onEnrolled(Landroid/content/Context;)V
    .locals 3
    .param p0, "context"    # Landroid/content/Context;

    .line 136
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    .line 137
    .local v0, "core":Lcom/tzibbur/basic/core/TzbCore;
    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->applyStore()Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v1

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v2

    invoke-interface {v2}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/tzibbur/basic/store/TzbApplyStore;->rekeyApproval(Ljava/lang/String;)V

    .line 138
    return-void
.end method

.method public static recheckBlocking(Landroid/content/Context;)V
    .locals 4
    .param p0, "context"    # Landroid/content/Context;

    .line 249
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 250
    .local v0, "app":Landroid/content/Context;
    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbApplyGate;->recheckDue(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 251
    return-void

    .line 253
    :cond_0
    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v1

    invoke-interface {v1}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v1

    .line 254
    .local v1, "phone":Ljava/lang/String;
    invoke-static {v0, v1}, Lcom/tzibbur/basic/core/TzbApplyGate;->check(Landroid/content/Context;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbApplicationStatus;

    move-result-object v2

    .line 255
    .local v2, "status":Lcom/tzibbur/basic/model/TzbApplicationStatus;
    if-eqz v2, :cond_1

    invoke-virtual {v2}, Lcom/tzibbur/basic/model/TzbApplicationStatus;->revokesApproval()Z

    move-result v3

    if-eqz v3, :cond_1

    .line 261
    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v3

    invoke-virtual {v3}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v3

    invoke-interface {v3}, Lcom/tzibbur/basic/sync/TzbSync;->stop()V

    .line 262
    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncService;->stop(Landroid/content/Context;)V

    .line 264
    :cond_1
    return-void
.end method

.method public static recheckDue(Landroid/content/Context;)Z
    .locals 9
    .param p0, "context"    # Landroid/content/Context;

    .line 226
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 227
    .local v0, "app":Landroid/content/Context;
    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_5

    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbApplyFlag;->required(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_1

    .line 230
    :cond_0
    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v1

    .line 231
    .local v1, "core":Lcom/tzibbur/basic/core/TzbCore;
    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v3

    invoke-interface {v3}, Lcom/tzibbur/basic/store/TzbSession;->phoneE164()Ljava/lang/String;

    move-result-object v3

    .line 232
    .local v3, "phone":Ljava/lang/String;
    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v4

    invoke-interface {v4}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v4

    if-eqz v4, :cond_4

    if-nez v3, :cond_1

    goto :goto_0

    .line 235
    :cond_1
    invoke-virtual {v1}, Lcom/tzibbur/basic/core/TzbCore;->applyStore()Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v4

    .line 236
    .local v4, "store":Lcom/tzibbur/basic/store/TzbApplyStore;
    invoke-virtual {v4, v3}, Lcom/tzibbur/basic/store/TzbApplyStore;->approvedFor(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_2

    .line 239
    return v2

    .line 241
    :cond_2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    invoke-virtual {v4}, Lcom/tzibbur/basic/store/TzbApplyStore;->lastCheckMs()J

    move-result-wide v7

    sub-long/2addr v5, v7

    const-wide/32 v7, 0x1499700

    cmp-long v5, v5, v7

    if-ltz v5, :cond_3

    const/4 v2, 0x1

    :cond_3
    return v2

    .line 233
    .end local v4
    :cond_4
    :goto_0
    return v2

    .line 228
    .end local v1
    .end local v3
    :cond_5
    :goto_1
    return v2
.end method

.method public static recheckIfStale(Landroid/content/Context;)V
    .locals 4
    .param p0, "context"    # Landroid/content/Context;

    .line 212
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 213
    .local v0, "app":Landroid/content/Context;
    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbApplyGate;->recheckDue(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 214
    return-void

    .line 216
    :cond_0
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lcom/tzibbur/basic/core/TzbApplyGate$1;

    invoke-direct {v2, v0}, Lcom/tzibbur/basic/core/TzbApplyGate$1;-><init>(Landroid/content/Context;)V

    const-string v3, "tzb-apply-recheck"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 221
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 222
    return-void
.end method

.method public static requiredFor(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 1
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "phoneE164"    # Ljava/lang/String;

    .line 77
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbApplyFlag;->required(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 78
    const/4 v0, 0x0

    return v0

    .line 80
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->applyStore()Lcom/tzibbur/basic/store/TzbApplyStore;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/tzibbur/basic/store/TzbApplyStore;->approvedFor(Ljava/lang/String;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public static show(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "phoneE164"    # Ljava/lang/String;

    .line 120
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 121
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "com.tzibbur.basic.ui.TzbApplyActivity"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 122
    const v1, 0x10008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 123
    if-eqz p1, :cond_0

    .line 124
    const-string v1, "tzb_apply_phone"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 126
    :cond_0
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 127
    return-void
.end method
