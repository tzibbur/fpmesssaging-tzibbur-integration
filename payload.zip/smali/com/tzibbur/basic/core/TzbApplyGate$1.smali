.class Lcom/tzibbur/basic/core/TzbApplyGate$1;
.super Ljava/lang/Object;
.source "TzbApplyGate.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/core/TzbApplyGate;->recheckIfStale(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$app:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 216
    iput-object p1, p0, Lcom/tzibbur/basic/core/TzbApplyGate$1;->val$app:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 219
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbApplyGate$1;->val$app:Landroid/content/Context;

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbApplyGate;->recheckBlocking(Landroid/content/Context;)V

    .line 220
    return-void
.end method
