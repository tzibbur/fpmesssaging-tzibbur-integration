.class public final Lcom/tzibbur/basic/core/TzbCore;
.super Ljava/lang/Object;
.source "TzbCore.java"


# static fields
.field private static volatile instance:Lcom/tzibbur/basic/core/TzbCore;


# instance fields
.field private volatile api:Lcom/tzibbur/basic/net/TzbApi;

.field private final appContext:Landroid/content/Context;

.field private volatile applyStore:Lcom/tzibbur/basic/store/TzbApplyStore;

.field private volatile session:Lcom/tzibbur/basic/store/TzbSession;

.field private volatile store:Lcom/tzibbur/basic/store/TzbStore;

.field private volatile sync:Lcom/tzibbur/basic/sync/TzbSync;


# direct methods
.method private constructor <init>(Landroid/content/Context;)V
    .locals 0
    .param p1, "appContext"    # Landroid/content/Context;

    .line 49
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 50
    iput-object p1, p0, Lcom/tzibbur/basic/core/TzbCore;->appContext:Landroid/content/Context;

    .line 51
    return-void
.end method

.method public static get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;
    .locals 3
    .param p0, "context"    # Landroid/content/Context;

    .line 32
    sget-object v0, Lcom/tzibbur/basic/core/TzbCore;->instance:Lcom/tzibbur/basic/core/TzbCore;

    if-nez v0, :cond_1

    .line 33
    const-class v0, Lcom/tzibbur/basic/core/TzbCore;

    monitor-enter v0

    .line 34
    :try_start_0
    sget-object v1, Lcom/tzibbur/basic/core/TzbCore;->instance:Lcom/tzibbur/basic/core/TzbCore;

    if-nez v1, :cond_0

    .line 35
    new-instance v1, Lcom/tzibbur/basic/core/TzbCore;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/tzibbur/basic/core/TzbCore;-><init>(Landroid/content/Context;)V

    sput-object v1, Lcom/tzibbur/basic/core/TzbCore;->instance:Lcom/tzibbur/basic/core/TzbCore;

    .line 37
    :cond_0
    monitor-exit v0

    goto :goto_0

    :catchall_0
    move-exception v1

    monitor-exit v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1

    .line 39
    :cond_1
    :goto_0
    sget-object v0, Lcom/tzibbur/basic/core/TzbCore;->instance:Lcom/tzibbur/basic/core/TzbCore;

    return-object v0
.end method


# virtual methods
.method public api()Lcom/tzibbur/basic/net/TzbApi;
    .locals 3

    .line 92
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->api:Lcom/tzibbur/basic/net/TzbApi;

    if-nez v0, :cond_1

    .line 93
    monitor-enter p0

    .line 94
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->api:Lcom/tzibbur/basic/net/TzbApi;

    if-nez v0, :cond_0

    .line 95
    new-instance v0, Lcom/tzibbur/basic/net/TzbApiClient;

    const-string v1, "https://api.tzibbur.me/v1"

    new-instance v2, Lcom/tzibbur/basic/core/TzbCore$1;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/core/TzbCore$1;-><init>(Lcom/tzibbur/basic/core/TzbCore;)V

    invoke-direct {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbApiClient;-><init>(Ljava/lang/String;Lcom/tzibbur/basic/net/TzbTokenSupplier;)V

    iput-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->api:Lcom/tzibbur/basic/net/TzbApi;

    .line 102
    :cond_0
    monitor-exit p0

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit p0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    .line 104
    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->api:Lcom/tzibbur/basic/net/TzbApi;

    return-object v0
.end method

.method public applyStore()Lcom/tzibbur/basic/store/TzbApplyStore;
    .locals 2

    .line 70
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->applyStore:Lcom/tzibbur/basic/store/TzbApplyStore;

    if-nez v0, :cond_1

    .line 71
    monitor-enter p0

    .line 72
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->applyStore:Lcom/tzibbur/basic/store/TzbApplyStore;

    if-nez v0, :cond_0

    .line 73
    new-instance v0, Lcom/tzibbur/basic/store/TzbApplyStore;

    iget-object v1, p0, Lcom/tzibbur/basic/core/TzbCore;->appContext:Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/tzibbur/basic/store/TzbApplyStore;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->applyStore:Lcom/tzibbur/basic/store/TzbApplyStore;

    .line 75
    :cond_0
    monitor-exit p0

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit p0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    .line 77
    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->applyStore:Lcom/tzibbur/basic/store/TzbApplyStore;

    return-object v0
.end method

.method public session()Lcom/tzibbur/basic/store/TzbSession;
    .locals 2

    .line 54
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->session:Lcom/tzibbur/basic/store/TzbSession;

    if-nez v0, :cond_1

    .line 55
    monitor-enter p0

    .line 56
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->session:Lcom/tzibbur/basic/store/TzbSession;

    if-nez v0, :cond_0

    .line 57
    new-instance v0, Lcom/tzibbur/basic/store/TzbSessionPrefs;

    iget-object v1, p0, Lcom/tzibbur/basic/core/TzbCore;->appContext:Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/tzibbur/basic/store/TzbSessionPrefs;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->session:Lcom/tzibbur/basic/store/TzbSession;

    .line 59
    :cond_0
    monitor-exit p0

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit p0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    .line 61
    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->session:Lcom/tzibbur/basic/store/TzbSession;

    return-object v0
.end method

.method public signOutLocally()V
    .locals 1

    .line 120
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->stop()V

    .line 121
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->clear()V

    .line 122
    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbStore;->clearAll()V

    .line 123
    return-void
.end method

.method public store()Lcom/tzibbur/basic/store/TzbStore;
    .locals 2

    .line 81
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->store:Lcom/tzibbur/basic/store/TzbStore;

    if-nez v0, :cond_1

    .line 82
    monitor-enter p0

    .line 83
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->store:Lcom/tzibbur/basic/store/TzbStore;

    if-nez v0, :cond_0

    .line 84
    new-instance v0, Lcom/tzibbur/basic/store/TzbDatabase;

    iget-object v1, p0, Lcom/tzibbur/basic/core/TzbCore;->appContext:Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/tzibbur/basic/store/TzbDatabase;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->store:Lcom/tzibbur/basic/store/TzbStore;

    .line 86
    :cond_0
    monitor-exit p0

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit p0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    .line 88
    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->store:Lcom/tzibbur/basic/store/TzbStore;

    return-object v0
.end method

.method public sync()Lcom/tzibbur/basic/sync/TzbSync;
    .locals 5

    .line 108
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->sync:Lcom/tzibbur/basic/sync/TzbSync;

    if-nez v0, :cond_1

    .line 109
    monitor-enter p0

    .line 110
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->sync:Lcom/tzibbur/basic/sync/TzbSync;

    if-nez v0, :cond_0

    .line 111
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v1, p0, Lcom/tzibbur/basic/core/TzbCore;->appContext:Landroid/content/Context;

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->api()Lcom/tzibbur/basic/net/TzbApi;

    move-result-object v2

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->store()Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v3

    invoke-virtual {p0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v4

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;-><init>(Landroid/content/Context;Lcom/tzibbur/basic/net/TzbApi;Lcom/tzibbur/basic/store/TzbStore;Lcom/tzibbur/basic/store/TzbSession;)V

    iput-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->sync:Lcom/tzibbur/basic/sync/TzbSync;

    .line 113
    :cond_0
    monitor-exit p0

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit p0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    .line 115
    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/core/TzbCore;->sync:Lcom/tzibbur/basic/sync/TzbSync;

    return-object v0
.end method
