.class public Lcom/tzibbur/basic/core/TzbApp;
.super Landroid/app/Application;
.source "TzbApp.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method


# virtual methods
.method public onCreate()V
    .locals 1

    .line 14
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 17
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 18
    return-void

    .line 22
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/sync/TzbApplyAlarm;->schedule(Landroid/content/Context;)V

    .line 23
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 25
    invoke-static {p0}, Lcom/tzibbur/basic/sync/TzbSyncService;->ensureRunning(Landroid/content/Context;)V

    .line 27
    :cond_1
    return-void
.end method
