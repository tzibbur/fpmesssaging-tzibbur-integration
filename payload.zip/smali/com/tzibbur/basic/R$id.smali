.class public final Lcom/tzibbur/basic/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tzibbur/basic/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static tzb_about_privacy_label:I = 0x7f080205    # @id/tzb_about_privacy_label

.field public static tzb_about_privacy_row:I = 0x7f080206    # @id/tzb_about_privacy_row

.field public static tzb_about_terms_label:I = 0x7f080207    # @id/tzb_about_terms_label

.field public static tzb_about_terms_row:I = 0x7f080208    # @id/tzb_about_terms_row

.field public static tzb_about_version_value:I = 0x7f080209    # @id/tzb_about_version_value

.field public static tzb_add_member_btn:I = 0x7f08020a    # @id/tzb_add_member_btn

.field public static tzb_add_phone_edit:I = 0x7f08020b    # @id/tzb_add_phone_edit

.field public static tzb_apply_body:I = 0x7f08020c    # @id/tzb_apply_body

.field public static tzb_apply_form:I = 0x7f08020d    # @id/tzb_apply_form

.field public static tzb_apply_head:I = 0x7f08020e    # @id/tzb_apply_head

.field public static tzb_apply_name_input:I = 0x7f08020f    # @id/tzb_apply_name_input

.field public static tzb_apply_notes_input:I = 0x7f080210    # @id/tzb_apply_notes_input

.field public static tzb_apply_org_input:I = 0x7f080211    # @id/tzb_apply_org_input

.field public static tzb_apply_phone_hint_text:I = 0x7f080212    # @id/tzb_apply_phone_hint_text

.field public static tzb_apply_phone_input:I = 0x7f080213    # @id/tzb_apply_phone_input

.field public static tzb_apply_privacy_link:I = 0x7f080214    # @id/tzb_apply_privacy_link

.field public static tzb_apply_reason_input:I = 0x7f080215    # @id/tzb_apply_reason_input

.field public static tzb_apply_refresh_btn:I = 0x7f080216    # @id/tzb_apply_refresh_btn

.field public static tzb_apply_scroll:I = 0x7f080217    # @id/tzb_apply_scroll

.field public static tzb_apply_status:I = 0x7f080218    # @id/tzb_apply_status

.field public static tzb_apply_submit_btn:I = 0x7f080219    # @id/tzb_apply_submit_btn

.field public static tzb_apply_terms_link:I = 0x7f08021a    # @id/tzb_apply_terms_link

.field public static tzb_category_list:I = 0x7f08021b    # @id/tzb_category_list

.field public static tzb_category_retry_btn:I = 0x7f08021c    # @id/tzb_category_retry_btn

.field public static tzb_category_status:I = 0x7f08021d    # @id/tzb_category_status

.field public static tzb_char_counter:I = 0x7f08021e    # @id/tzb_char_counter

.field public static tzb_choose_contacts_btn:I = 0x7f08021f    # @id/tzb_choose_contacts_btn

.field public static tzb_compose_edit:I = 0x7f080220    # @id/tzb_compose_edit

.field public static tzb_compose_label:I = 0x7f080221    # @id/tzb_compose_label

.field public static tzb_compose_notice:I = 0x7f080222    # @id/tzb_compose_notice

.field public static tzb_compose_panel:I = 0x7f080223    # @id/tzb_compose_panel

.field public static tzb_contact_check:I = 0x7f080224    # @id/tzb_contact_check

.field public static tzb_contact_name:I = 0x7f080225    # @id/tzb_contact_name

.field public static tzb_contact_phone:I = 0x7f080226    # @id/tzb_contact_phone

.field public static tzb_contacts_add_btn:I = 0x7f080227    # @id/tzb_contacts_add_btn

.field public static tzb_contacts_browse_btn:I = 0x7f080228    # @id/tzb_contacts_browse_btn

.field public static tzb_contacts_cancel_btn:I = 0x7f080229    # @id/tzb_contacts_cancel_btn

.field public static tzb_contacts_list:I = 0x7f08022a    # @id/tzb_contacts_list

.field public static tzb_contacts_manual_btn:I = 0x7f08022b    # @id/tzb_contacts_manual_btn

.field public static tzb_contacts_resume_btn:I = 0x7f08022c    # @id/tzb_contacts_resume_btn

.field public static tzb_contacts_search:I = 0x7f08022d    # @id/tzb_contacts_search

.field public static tzb_contacts_settings_btn:I = 0x7f08022e    # @id/tzb_contacts_settings_btn

.field public static tzb_contacts_status:I = 0x7f08022f    # @id/tzb_contacts_status

.field public static tzb_create_btn:I = 0x7f080230    # @id/tzb_create_btn

.field public static tzb_create_first_group_btn:I = 0x7f080231    # @id/tzb_create_first_group_btn

.field public static tzb_delete_btn:I = 0x7f080232    # @id/tzb_delete_btn

.field public static tzb_dialog_edit_text:I = 0x7f080233    # @id/tzb_dialog_edit_text

.field public static tzb_enroll_code_input:I = 0x7f080234    # @id/tzb_enroll_code_input

.field public static tzb_enroll_code_sent:I = 0x7f080235    # @id/tzb_enroll_code_sent

.field public static tzb_enroll_code_status:I = 0x7f080236    # @id/tzb_enroll_code_status

.field public static tzb_enroll_name_continue_btn:I = 0x7f080237    # @id/tzb_enroll_name_continue_btn

.field public static tzb_enroll_name_counter:I = 0x7f080238    # @id/tzb_enroll_name_counter

.field public static tzb_enroll_name_edit:I = 0x7f080239    # @id/tzb_enroll_name_edit

.field public static tzb_enroll_name_status:I = 0x7f08023a    # @id/tzb_enroll_name_status

.field public static tzb_enroll_phone_input:I = 0x7f08023b    # @id/tzb_enroll_phone_input

.field public static tzb_enroll_phone_rationale:I = 0x7f08023c    # @id/tzb_enroll_phone_rationale

.field public static tzb_enroll_phone_status:I = 0x7f08023d    # @id/tzb_enroll_phone_status

.field public static tzb_enroll_privacy_link:I = 0x7f08023e    # @id/tzb_enroll_privacy_link

.field public static tzb_enroll_resend_btn:I = 0x7f08023f    # @id/tzb_enroll_resend_btn

.field public static tzb_enroll_send_btn:I = 0x7f080240    # @id/tzb_enroll_send_btn

.field public static tzb_enroll_sms_hint:I = 0x7f080241    # @id/tzb_enroll_sms_hint

.field public static tzb_enroll_terms_link:I = 0x7f080242    # @id/tzb_enroll_terms_link

.field public static tzb_enroll_verify_btn:I = 0x7f080243    # @id/tzb_enroll_verify_btn

.field public static tzb_group_list:I = 0x7f080244    # @id/tzb_group_list

.field public static tzb_group_list_empty:I = 0x7f080245    # @id/tzb_group_list_empty

.field public static tzb_group_muted:I = 0x7f080246    # @id/tzb_group_muted

.field public static tzb_group_name:I = 0x7f080247    # @id/tzb_group_name

.field public static tzb_group_name_edit:I = 0x7f080248    # @id/tzb_group_name_edit

.field public static tzb_group_snippet:I = 0x7f080249    # @id/tzb_group_snippet

.field public static tzb_group_unread:I = 0x7f08024a    # @id/tzb_group_unread

.field public static tzb_info_add_value:I = 0x7f08024b    # @id/tzb_info_add_value

.field public static tzb_info_category_value:I = 0x7f08024c    # @id/tzb_info_category_value

.field public static tzb_info_members_value:I = 0x7f08024d    # @id/tzb_info_members_value

.field public static tzb_info_muted_value:I = 0x7f08024e    # @id/tzb_info_muted_value

.field public static tzb_info_name_value:I = 0x7f08024f    # @id/tzb_info_name_value

.field public static tzb_info_post_value:I = 0x7f080250    # @id/tzb_info_post_value

.field public static tzb_info_role_value:I = 0x7f080251    # @id/tzb_info_role_value

.field public static tzb_leave_btn:I = 0x7f080252    # @id/tzb_leave_btn

.field public static tzb_legal_error_box:I = 0x7f080253    # @id/tzb_legal_error_box

.field public static tzb_legal_retry_btn:I = 0x7f080254    # @id/tzb_legal_retry_btn

.field public static tzb_legal_scroll:I = 0x7f080255    # @id/tzb_legal_scroll

.field public static tzb_legal_text:I = 0x7f080256    # @id/tzb_legal_text

.field public static tzb_load_earlier_row:I = 0x7f080257    # @id/tzb_load_earlier_row

.field public static tzb_load_more_row:I = 0x7f080258    # @id/tzb_load_more_row

.field public static tzb_member_list:I = 0x7f080259    # @id/tzb_member_list

.field public static tzb_member_name:I = 0x7f08025a    # @id/tzb_member_name

.field public static tzb_member_role:I = 0x7f08025b    # @id/tzb_member_role

.field public static tzb_menu_add_member:I = 0x7f08025c    # @id/tzb_menu_add_member

.field public static tzb_menu_btn:I = 0x7f08025d    # @id/tzb_menu_btn

.field public static tzb_menu_btn_bottom:I = 0x7f08025e    # @id/tzb_menu_btn_bottom

.field public static tzb_menu_group_info:I = 0x7f08025f    # @id/tzb_menu_group_info

.field public static tzb_menu_make_admin:I = 0x7f080260    # @id/tzb_menu_make_admin

.field public static tzb_menu_members:I = 0x7f080261    # @id/tzb_menu_members

.field public static tzb_menu_mute:I = 0x7f080262    # @id/tzb_menu_mute

.field public static tzb_menu_new_group:I = 0x7f080263    # @id/tzb_menu_new_group

.field public static tzb_menu_refresh:I = 0x7f080264    # @id/tzb_menu_refresh

.field public static tzb_menu_remove_admin:I = 0x7f080265    # @id/tzb_menu_remove_admin

.field public static tzb_menu_remove_member:I = 0x7f080266    # @id/tzb_menu_remove_member

.field public static tzb_menu_settings:I = 0x7f080267    # @id/tzb_menu_settings

.field public static tzb_message_list:I = 0x7f080268    # @id/tzb_message_list

.field public static tzb_msg_body:I = 0x7f080269    # @id/tzb_msg_body

.field public static tzb_msg_time:I = 0x7f08026a    # @id/tzb_msg_time

.field public static tzb_rename_btn:I = 0x7f08026b    # @id/tzb_rename_btn

.field public static tzb_send_btn:I = 0x7f08026c    # @id/tzb_send_btn

.field public static tzb_settings_about_row:I = 0x7f08026d    # @id/tzb_settings_about_row

.field public static tzb_settings_connection_value:I = 0x7f08026e    # @id/tzb_settings_connection_value

.field public static tzb_settings_devices_row:I = 0x7f08026f    # @id/tzb_settings_devices_row

.field public static tzb_settings_name_row:I = 0x7f080270    # @id/tzb_settings_name_row

.field public static tzb_settings_name_value:I = 0x7f080271    # @id/tzb_settings_name_value

.field public static tzb_settings_notification_desc:I = 0x7f080272    # @id/tzb_settings_notification_desc

.field public static tzb_settings_notification_row:I = 0x7f080273    # @id/tzb_settings_notification_row

.field public static tzb_settings_phone_value:I = 0x7f080274    # @id/tzb_settings_phone_value

.field public static tzb_settings_signout_row:I = 0x7f080275    # @id/tzb_settings_signout_row

.field public static tzb_settings_version_value:I = 0x7f080276    # @id/tzb_settings_version_value

.field public static tzb_title_extra:I = 0x7f080277    # @id/tzb_title_extra

.field public static tzb_title_text:I = 0x7f080278    # @id/tzb_title_text

.field public static tzb_toggle_add_btn:I = 0x7f080279    # @id/tzb_toggle_add_btn

.field public static tzb_toggle_post_btn:I = 0x7f08027a    # @id/tzb_toggle_post_btn


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
