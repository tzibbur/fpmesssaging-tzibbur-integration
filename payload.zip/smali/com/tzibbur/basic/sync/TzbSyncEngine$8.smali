.class Lcom/tzibbur/basic/sync/TzbSyncEngine$8;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->nudge()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 221
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 224
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 225
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$500(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 226
    return-void

    .line 228
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$802(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)I

    .line 229
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$902(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)I

    .line 230
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const-wide/16 v1, 0x0

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1002(Lcom/tzibbur/basic/sync/TzbSyncEngine;J)J

    .line 231
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1100(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 232
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1200(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Lcom/tzibbur/basic/net/TzbWebSocket;

    move-result-object v0

    .line 233
    .local v0, "s":Lcom/tzibbur/basic/net/TzbWebSocket;
    if-eqz v0, :cond_1

    .line 234
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendPing()V

    .line 236
    .end local v0
    :cond_1
    goto :goto_0

    .line 237
    :cond_2
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1400(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;)V

    .line 238
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$100(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 239
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1500(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 240
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1600(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1400(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;)V

    .line 241
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1600(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1700(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;)Z

    .line 243
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1800(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 244
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 245
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$000(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 246
    return-void
.end method
