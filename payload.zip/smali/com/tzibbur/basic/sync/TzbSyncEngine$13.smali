.class Lcom/tzibbur/basic/sync/TzbSyncEngine$13;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->onMessages(Ljava/lang/String;Ljava/util/List;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$groupId:Ljava/lang/String;

.field final synthetic val$messages:Ljava/util/List;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;Ljava/util/List;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 372
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$13;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput-object p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$13;->val$groupId:Ljava/lang/String;

    iput-object p3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$13;->val$messages:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 375
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$13;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$13;->val$groupId:Ljava/lang/String;

    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$13;->val$messages:Ljava/util/List;

    invoke-static {v0, v1, v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2500(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;Ljava/util/List;)V

    .line 376
    return-void
.end method
