.class Lcom/tzibbur/basic/sync/TzbApplyAlarm$1;
.super Ljava/lang/Object;
.source "TzbApplyAlarm.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbApplyAlarm;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbApplyAlarm;

.field final synthetic val$app:Landroid/content/Context;

.field final synthetic val$result:Landroid/content/BroadcastReceiver$PendingResult;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbApplyAlarm;Landroid/content/Context;Landroid/content/BroadcastReceiver$PendingResult;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbApplyAlarm;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 58
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbApplyAlarm$1;->this$0:Lcom/tzibbur/basic/sync/TzbApplyAlarm;

    iput-object p2, p0, Lcom/tzibbur/basic/sync/TzbApplyAlarm$1;->val$app:Landroid/content/Context;

    iput-object p3, p0, Lcom/tzibbur/basic/sync/TzbApplyAlarm$1;->val$result:Landroid/content/BroadcastReceiver$PendingResult;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 62
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbApplyAlarm$1;->val$app:Landroid/content/Context;

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbApplyGate;->recheckBlocking(Landroid/content/Context;)V

    .line 64
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbApplyAlarm$1;->val$result:Landroid/content/BroadcastReceiver$PendingResult;

    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 65
    nop

    .line 66
    return-void

    .line 64
    :catchall_0
    move-exception v0

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbApplyAlarm$1;->val$result:Landroid/content/BroadcastReceiver$PendingResult;

    invoke-virtual {v1}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 65
    throw v0
.end method
