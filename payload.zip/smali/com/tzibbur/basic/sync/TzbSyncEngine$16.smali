.class Lcom/tzibbur/basic/sync/TzbSyncEngine$16;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->onErrorFrame(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$code:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 431
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput-object p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->val$code:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 434
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 435
    return-void

    .line 437
    :cond_0
    const-string v0, "too_many_connections"

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->val$code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 442
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/16 v1, 0x1e

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2902(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)I

    goto :goto_0

    .line 443
    :cond_1
    const-string v0, "push_failed"

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->val$code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 448
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3000(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 449
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;

    move-result-object v1

    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v3}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$808(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I

    move-result v3

    const/4 v4, 0x0

    invoke-static {v2, v3, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3100(Lcom/tzibbur/basic/sync/TzbSyncEngine;II)J

    move-result-wide v2

    invoke-static {v0, v1, v2, v3}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3200(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;J)Z

    .line 450
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1500(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 451
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I

    move-result v0

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_5

    .line 452
    :cond_2
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v1, 0x3

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2200(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)V

    goto :goto_0

    .line 454
    :cond_3
    const-string v0, "rate_limited"

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->val$code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 460
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1200(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Lcom/tzibbur/basic/net/TzbWebSocket;

    move-result-object v0

    .line 461
    .local v0, "s":Lcom/tzibbur/basic/net/TzbWebSocket;
    const-wide/16 v1, 0x2710

    if-eqz v0, :cond_4

    .line 462
    invoke-virtual {v0, v1, v2}, Lcom/tzibbur/basic/net/TzbWebSocket;->pauseOutbound(J)V

    .line 464
    :cond_4
    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3400(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1400(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;)V

    .line 465
    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3400(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;

    move-result-object v4

    invoke-static {v3, v4, v1, v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3200(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;J)Z

    .line 473
    .end local v0
    :cond_5
    :goto_0
    return-void
.end method
