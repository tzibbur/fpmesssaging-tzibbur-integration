.class Lcom/tzibbur/basic/sync/TzbSyncEngine$25;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifySendFailed(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$groupId:Ljava/lang/String;

.field final synthetic val$problemCode:Ljava/lang/String;

.field final synthetic val$safeErrors:Lorg/json/JSONObject;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1252
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput-object p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;->val$groupId:Ljava/lang/String;

    iput-object p3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;->val$problemCode:Ljava/lang/String;

    iput-object p4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;->val$safeErrors:Lorg/json/JSONObject;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 1255
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$4000(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/tzibbur/basic/sync/TzbSyncListener;

    .line 1256
    .local v1, "l":Lcom/tzibbur/basic/sync/TzbSyncListener;
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;->val$groupId:Ljava/lang/String;

    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;->val$problemCode:Ljava/lang/String;

    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;->val$safeErrors:Lorg/json/JSONObject;

    invoke-interface {v1, v2, v3, v4}, Lcom/tzibbur/basic/sync/TzbSyncListener;->onSendFailed(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 1257
    .end local v1
    goto :goto_0

    .line 1258
    :cond_0
    return-void
.end method
