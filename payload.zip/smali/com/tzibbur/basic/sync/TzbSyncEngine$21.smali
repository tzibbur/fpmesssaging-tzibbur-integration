.class Lcom/tzibbur/basic/sync/TzbSyncEngine$21;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->setState(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$value:I


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1205
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$21;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$21;->val$value:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 1208
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$21;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$4000(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/tzibbur/basic/sync/TzbSyncListener;

    .line 1209
    .local v1, "l":Lcom/tzibbur/basic/sync/TzbSyncListener;
    iget v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$21;->val$value:I

    invoke-interface {v1, v2}, Lcom/tzibbur/basic/sync/TzbSyncListener;->onConnectionChanged(I)V

    .line 1210
    .end local v1
    goto :goto_0

    .line 1211
    :cond_0
    return-void
.end method
