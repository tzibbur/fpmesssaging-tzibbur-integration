.class Lcom/tzibbur/basic/sync/TzbSyncEngine$14;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->onGroupEvent(Lcom/tzibbur/basic/model/TzbGroupEvent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$event:Lcom/tzibbur/basic/model/TzbGroupEvent;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Lcom/tzibbur/basic/model/TzbGroupEvent;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 382
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$14;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput-object p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$14;->val$event:Lcom/tzibbur/basic/model/TzbGroupEvent;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 385
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$14;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 386
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$14;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$14;->val$event:Lcom/tzibbur/basic/model/TzbGroupEvent;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2600(Lcom/tzibbur/basic/sync/TzbSyncEngine;Lcom/tzibbur/basic/model/TzbGroupEvent;)V

    .line 388
    :cond_0
    return-void
.end method
