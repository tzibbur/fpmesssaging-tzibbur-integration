.class public final Lcom/tzibbur/basic/sync/TzbSyncEngine;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Lcom/tzibbur/basic/sync/TzbSync;
.implements Lcom/tzibbur/basic/net/TzbSocketListener;


# static fields
.field private static final ABUSE_CLOSE_FLOOR_SECONDS:I = 0x1e

.field private static final BACKOFF_CAP_MS:J = 0xea60L

.field private static final CHANNEL_MESSAGES:Ljava/lang/String; = "tzb_messages"

.field private static final CONVERSATION_ACTIVITY:Ljava/lang/String; = "com.tzibbur.basic.ui.TzbConversationActivity"

.field private static final EXTRA_GROUP_ID:Ljava/lang/String; = "tzb_group_id"

.field private static final POLL_INTERVAL_MS:J = 0xea60L

.field private static final RATE_LIMIT_PAUSE_MS:J = 0x2710L

.field private static final READ_COALESCE_MS:J = 0x12cL

.field private static final TAG:Ljava/lang/String; = "TzbSyncEngine"

.field private static final WS_CLOSE_SESSION_REVOKED:I = 0xfa1


# instance fields
.field private final ackSkipped:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private volatile activeGroupId:Ljava/lang/String;

.field private final api:Lcom/tzibbur/basic/net/TzbApi;

.field private connectPending:Z

.field private final context:Landroid/content/Context;

.field private final drainRunnable:Ljava/lang/Runnable;

.field private volatile engine:Landroid/os/Handler;

.field private initialRefreshDone:Z

.field private final listeners:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lcom/tzibbur/basic/sync/TzbSyncListener;",
            ">;"
        }
    .end annotation
.end field

.field private final main:Landroid/os/Handler;

.field private volatile networkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

.field private final pendingReads:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private final pollRunnable:Ljava/lang/Runnable;

.field private pollingActive:Z

.field private final random:Ljava/util/Random;

.field private final readFlushRunnable:Ljava/lang/Runnable;

.field private reconnectFloorSeconds:I

.field private final reconnectRunnable:Ljava/lang/Runnable;

.field private final resumeOutboundRunnable:Ljava/lang/Runnable;

.field private sendAttempts:I

.field private sendBlockedUntilMs:J

.field private final session:Lcom/tzibbur/basic/store/TzbSession;

.field private socket:Lcom/tzibbur/basic/net/TzbWebSocket;

.field private socketLive:Z

.field private volatile started:Z

.field private volatile state:I

.field private final store:Lcom/tzibbur/basic/store/TzbStore;

.field private final threadLock:Ljava/lang/Object;

.field private wsAttempts:I

.field private wsDisabled:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/tzibbur/basic/net/TzbApi;Lcom/tzibbur/basic/store/TzbStore;Lcom/tzibbur/basic/store/TzbSession;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "api"    # Lcom/tzibbur/basic/net/TzbApi;
    .param p3, "store"    # Lcom/tzibbur/basic/store/TzbStore;
    .param p4, "session"    # Lcom/tzibbur/basic/store/TzbSession;

    .line 181
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 98
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->main:Landroid/os/Handler;

    .line 99
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 100
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->random:Ljava/util/Random;

    .line 101
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->threadLock:Ljava/lang/Object;

    .line 107
    const/4 v0, 0x0

    iput v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->state:I

    .line 136
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->ackSkipped:Ljava/util/Map;

    .line 144
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    .line 146
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$1;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$1;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->readFlushRunnable:Ljava/lang/Runnable;

    .line 153
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$2;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$2;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->reconnectRunnable:Ljava/lang/Runnable;

    .line 160
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$3;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$3;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollRunnable:Ljava/lang/Runnable;

    .line 167
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$4;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$4;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainRunnable:Ljava/lang/Runnable;

    .line 174
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$5;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$5;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->resumeOutboundRunnable:Ljava/lang/Runnable;

    .line 182
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    .line 183
    iput-object p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->api:Lcom/tzibbur/basic/net/TzbApi;

    .line 184
    iput-object p3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    .line 185
    iput-object p4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->session:Lcom/tzibbur/basic/store/TzbSession;

    .line 186
    return-void
.end method

.method static synthetic access$000(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->flushPendingReads()V

    return-void
.end method

.method static synthetic access$100(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->connectSocket()V

    return-void
.end method

.method static synthetic access$1002(Lcom/tzibbur/basic/sync/TzbSyncEngine;J)J
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # J

    .line 63
    iput-wide p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendBlockedUntilMs:J

    return-wide p1
.end method

.method static synthetic access$1100(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    return v0
.end method

.method static synthetic access$1102(Lcom/tzibbur/basic/sync/TzbSyncEngine;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Z

    .line 63
    iput-boolean p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    return p1
.end method

.method static synthetic access$1200(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Lcom/tzibbur/basic/net/TzbWebSocket;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    return-object v0
.end method

.method static synthetic access$1202(Lcom/tzibbur/basic/sync/TzbSyncEngine;Lcom/tzibbur/basic/net/TzbWebSocket;)Lcom/tzibbur/basic/net/TzbWebSocket;
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 63
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    return-object p1
.end method

.method static synthetic access$1300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->reconnectRunnable:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic access$1400(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Ljava/lang/Runnable;

    .line 63
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->removeCb(Ljava/lang/Runnable;)V

    return-void
.end method

.method static synthetic access$1500(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->startPollingInternal()V

    return-void
.end method

.method static synthetic access$1600(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollRunnable:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic access$1700(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Ljava/lang/Runnable;

    .line 63
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    move-result v0

    return v0
.end method

.method static synthetic access$1800(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->refreshGroupsInternal()V

    return-void
.end method

.method static synthetic access$1900(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Lcom/tzibbur/basic/store/TzbStore;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    return-object v0
.end method

.method static synthetic access$200(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollNow()V

    return-void
.end method

.method static synthetic access$2000(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Ljava/lang/String;

    .line 63
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyMessagesChanged(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$2102(Lcom/tzibbur/basic/sync/TzbSyncEngine;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Z

    .line 63
    iput-boolean p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->connectPending:Z

    return p1
.end method

.method static synthetic access$2200(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # I

    .line 63
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->setState(I)V

    return-void
.end method

.method static synthetic access$2300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->stopPollingInternal()V

    return-void
.end method

.method static synthetic access$2400(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->refreshCapabilitiesInternal()V

    return-void
.end method

.method static synthetic access$2500(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;Ljava/util/List;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Ljava/lang/String;
    .param p2, "x2"    # Ljava/util/List;

    .line 63
    invoke-direct {p0, p1, p2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleSocketBatch(Ljava/lang/String;Ljava/util/List;)V

    return-void
.end method

.method static synthetic access$2600(Lcom/tzibbur/basic/sync/TzbSyncEngine;Lcom/tzibbur/basic/model/TzbGroupEvent;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Lcom/tzibbur/basic/model/TzbGroupEvent;

    .line 63
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleGroupEvent(Lcom/tzibbur/basic/model/TzbGroupEvent;)V

    return-void
.end method

.method static synthetic access$2700(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Ljava/lang/String;

    .line 63
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->cancelNotification(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$2800(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyGroupsChanged()V

    return-void
.end method

.method static synthetic access$2900(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->reconnectFloorSeconds:I

    return v0
.end method

.method static synthetic access$2902(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)I
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # I

    .line 63
    iput p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->reconnectFloorSeconds:I

    return p1
.end method

.method static synthetic access$300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainOutbox()V

    return-void
.end method

.method static synthetic access$3000(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->closeSocketQuietly()V

    return-void
.end method

.method static synthetic access$3100(Lcom/tzibbur/basic/sync/TzbSyncEngine;II)J
    .locals 2
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # I
    .param p2, "x2"    # I

    .line 63
    invoke-direct {p0, p1, p2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->backoffDelay(II)J

    move-result-wide v0

    return-wide v0
.end method

.method static synthetic access$3200(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;J)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Ljava/lang/Runnable;
    .param p2, "x2"    # J

    .line 63
    invoke-direct {p0, p1, p2, p3}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v0

    return v0
.end method

.method static synthetic access$3300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->state:I

    return v0
.end method

.method static synthetic access$3400(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->resumeOutboundRunnable:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic access$3500(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->wsDisabled:Z

    return v0
.end method

.method static synthetic access$3502(Lcom/tzibbur/basic/sync/TzbSyncEngine;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # Z

    .line 63
    iput-boolean p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->wsDisabled:Z

    return p1
.end method

.method static synthetic access$3600(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->clearOutboundPause()V

    return-void
.end method

.method static synthetic access$3700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleDeviceBlocked()V

    return-void
.end method

.method static synthetic access$3800(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleUnauthorized()V

    return-void
.end method

.method static synthetic access$3900(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Lcom/tzibbur/basic/store/TzbSession;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->session:Lcom/tzibbur/basic/store/TzbSession;

    return-object v0
.end method

.method static synthetic access$400(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->resumeOutbound()V

    return-void
.end method

.method static synthetic access$4000(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/util/concurrent/CopyOnWriteArrayList;
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    return-object v0
.end method

.method static synthetic access$500(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->startInternal()V

    return-void
.end method

.method static synthetic access$600(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->teardownOnEngine()V

    return-void
.end method

.method static synthetic access$700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z
    .locals 1
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    return v0
.end method

.method static synthetic access$802(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)I
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # I

    .line 63
    iput p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->wsAttempts:I

    return p1
.end method

.method static synthetic access$808(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I
    .locals 2
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;

    .line 63
    iget v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->wsAttempts:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->wsAttempts:I

    return v0
.end method

.method static synthetic access$902(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)I
    .locals 0
    .param p0, "x0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .param p1, "x1"    # I

    .line 63
    iput p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    return p1
.end method

.method private backoffDelay(II)J
    .locals 9
    .param p1, "attempt"    # I
    .param p2, "floorSeconds"    # I

    .line 1191
    const/4 v0, 0x6

    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    const-wide/16 v1, 0x3e8

    shl-long v3, v1, v0

    const-wide/32 v5, 0xea60

    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v3

    .line 1192
    .local v3, "cap":J
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->random:Ljava/util/Random;

    invoke-virtual {v0}, Ljava/util/Random;->nextDouble()D

    move-result-wide v5

    long-to-double v7, v3

    mul-double/2addr v5, v7

    double-to-long v5, v5

    .line 1193
    .local v5, "jitter":J
    if-lez p2, :cond_0

    int-to-long v7, p2

    mul-long/2addr v7, v1

    goto :goto_0

    :cond_0
    const-wide/16 v7, 0x0

    .line 1194
    .local v7, "floor":J
    :goto_0
    invoke-static {v7, v8, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private blockedBy(Lcom/tzibbur/basic/net/TzbProblem;)Z
    .locals 1
    .param p1, "p"    # Lcom/tzibbur/basic/net/TzbProblem;

    .line 420
    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lcom/tzibbur/basic/net/TzbProblem;->isDeviceBlocked()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 423
    :cond_0
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleDeviceBlocked()V

    .line 424
    const/4 v0, 0x1

    return v0

    .line 421
    :cond_1
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method private cancelNotification(Ljava/lang/String;)V
    .locals 2
    .param p1, "groupId"    # Ljava/lang/String;

    .line 1353
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notificationManager()Landroid/app/NotificationManager;

    move-result-object v0

    .line 1354
    .local v0, "nm":Landroid/app/NotificationManager;
    if-eqz v0, :cond_0

    .line 1355
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->cancel(I)V

    .line 1357
    :cond_0
    return-void
.end method

.method private clearOutboundPause()V
    .locals 1

    .line 719
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->resumeOutboundRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->removeCb(Ljava/lang/Runnable;)V

    .line 720
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->ackSkipped:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 721
    return-void
.end method

.method private closeSocketQuietly()V
    .locals 2

    .line 674
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 675
    .local v0, "s":Lcom/tzibbur/basic/net/TzbWebSocket;
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 676
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    .line 677
    iput-boolean v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->connectPending:Z

    .line 678
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->clearOutboundPause()V

    .line 679
    if-eqz v0, :cond_0

    .line 680
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->close()V

    .line 682
    :cond_0
    return-void
.end method

.method private connectSocket()V
    .locals 4

    .line 653
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->wsDisabled:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->connectPending:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 656
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 657
    .local v0, "s":Lcom/tzibbur/basic/net/TzbWebSocket;
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->isOpen()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 658
    return-void

    .line 660
    :cond_1
    iget v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->state:I

    const/4 v2, 0x1

    if-nez v1, :cond_2

    .line 661
    invoke-direct {p0, v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->setState(I)V

    .line 663
    :cond_2
    iput-boolean v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->connectPending:Z

    .line 664
    new-instance v1, Lcom/tzibbur/basic/net/TzbWebSocket;

    new-instance v2, Lcom/tzibbur/basic/sync/TzbSyncEngine$20;

    invoke-direct {v2, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$20;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    const-string v3, "wss://api.tzibbur.me/v1/ws"

    invoke-direct {v1, v3, v2, p0}, Lcom/tzibbur/basic/net/TzbWebSocket;-><init>(Ljava/lang/String;Lcom/tzibbur/basic/net/TzbTokenSupplier;Lcom/tzibbur/basic/net/TzbSocketListener;)V

    iput-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 670
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    invoke-virtual {v1}, Lcom/tzibbur/basic/net/TzbWebSocket;->connect()V

    .line 671
    return-void

    .line 654
    .end local v0
    :cond_3
    :goto_0
    return-void
.end method

.method private static containsGroup(Ljava/util/List;Ljava/lang/String;)Z
    .locals 3
    .param p1, "id"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbGroup;",
            ">;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    .line 840
    .local p0, "groups":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbGroup;>;"
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/tzibbur/basic/model/TzbGroup;

    .line 841
    .local v1, "g":Lcom/tzibbur/basic/model/TzbGroup;
    iget-object v2, v1, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v0, 0x1

    return v0

    .line 842
    .end local v1
    :cond_0
    goto :goto_0

    .line 843
    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method private doPollOnce()J
    .locals 11

    .line 783
    const/4 v0, 0x1

    .line 784
    .local v0, "more":Z
    :goto_0
    const-wide/32 v1, 0xea60

    if-eqz v0, :cond_5

    :try_start_0
    iget-boolean v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-eqz v3, :cond_5

    iget-boolean v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    if-nez v3, :cond_5

    .line 785
    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->api:Lcom/tzibbur/basic/net/TzbApi;

    const/16 v4, 0x64

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4}, Lcom/tzibbur/basic/net/TzbApi;->pending(Ljava/lang/Integer;)Ljava/util/List;

    move-result-object v3

    .line 786
    .local v3, "batches":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbPendingGroup;>;"
    const/4 v0, 0x0

    .line 787
    if-nez v3, :cond_0

    .line 788
    goto :goto_2

    .line 790
    :cond_0
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1
    :goto_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/tzibbur/basic/model/TzbPendingGroup;

    .line 791
    .local v5, "batch":Lcom/tzibbur/basic/model/TzbPendingGroup;
    iget-object v6, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->messages:Ljava/util/List;

    if-eqz v6, :cond_1

    iget-object v6, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->messages:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_2

    .line 792
    goto :goto_1

    .line 794
    :cond_2
    iget-object v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v7, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->messages:Ljava/util/List;

    invoke-interface {v6, v7}, Lcom/tzibbur/basic/store/TzbStore;->insertMessages(Ljava/util/List;)I

    move-result v6

    .line 795
    .local v6, "inserted":I
    iget-object v7, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->groupId:Ljava/lang/String;

    iget-object v8, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->messages:Ljava/util/List;

    invoke-direct {p0, v7, v8}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->matchEchoes(Ljava/lang/String;Ljava/util/List;)V

    .line 797
    iget-object v7, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->api:Lcom/tzibbur/basic/net/TzbApi;

    iget-object v8, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->groupId:Ljava/lang/String;

    iget-object v9, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->messages:Ljava/util/List;

    iget-object v10, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->messages:Ljava/util/List;

    .line 798
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v10

    add-int/lit8 v10, v10, -0x1

    invoke-interface {v9, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/tzibbur/basic/model/TzbMessage;

    iget-wide v9, v9, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    .line 797
    invoke-interface {v7, v8, v9, v10}, Lcom/tzibbur/basic/net/TzbApi;->ack(Ljava/lang/String;J)V

    .line 799
    iget-object v7, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->groupId:Ljava/lang/String;

    invoke-direct {p0, v7}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyMessagesChanged(Ljava/lang/String;)V

    .line 800
    iget-object v7, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->groupId:Ljava/lang/String;

    iget-object v8, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->messages:Ljava/util/List;

    invoke-direct {p0, v7, v8, v6}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->maybeShowNotification(Ljava/lang/String;Ljava/util/List;I)V

    .line 801
    iget-boolean v7, v5, Lcom/tzibbur/basic/model/TzbPendingGroup;->hasMore:Z

    if-eqz v7, :cond_3

    .line 802
    const/4 v0, 0x1

    .line 804
    .end local v5
    .end local v6
    :cond_3
    goto :goto_1

    .line 805
    .end local v3
    :cond_4
    goto :goto_0

    .line 806
    :cond_5
    :goto_2
    iget-boolean v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-eqz v3, :cond_6

    iget-boolean v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    if-nez v3, :cond_6

    .line 807
    const/4 v3, 0x3

    invoke-direct {p0, v3}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->setState(I)V

    .line 809
    :cond_6
    iget-boolean v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->initialRefreshDone:Z

    if-nez v3, :cond_7

    .line 810
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->refreshGroupsInternal()V

    .line 812
    :cond_7
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainOutbox()V

    .line 813
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->flushPendingReads()V

    .line 814
    :try_end_0
    .catch Lcom/tzibbur/basic/net/TzbProblem; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-wide v1

    .line 828
    .end local v0
    :catch_0
    move-exception v0

    .line 830
    .local v0, "e":Ljava/io/IOException;
    iget-boolean v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-eqz v3, :cond_8

    iget-boolean v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    if-nez v3, :cond_8

    .line 831
    const/4 v3, 0x0

    invoke-direct {p0, v3}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->setState(I)V

    .line 833
    :cond_8
    return-wide v1

    .line 815
    .end local v0
    :catch_1
    move-exception v0

    .line 816
    .local v0, "p":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->blockedBy(Lcom/tzibbur/basic/net/TzbProblem;)Z

    move-result v3

    if-eqz v3, :cond_9

    .line 817
    return-wide v1

    .line 819
    :cond_9
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isUnauthorized()Z

    move-result v3

    if-eqz v3, :cond_a

    .line 820
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleUnauthorized()V

    .line 821
    return-wide v1

    .line 823
    :cond_a
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "poll problem: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v4, v0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "TzbSyncEngine"

    invoke-static {v4, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 824
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isRateLimited()Z

    move-result v3

    if-eqz v3, :cond_b

    iget v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    if-lez v3, :cond_b

    .line 825
    iget v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    int-to-long v3, v3

    const-wide/16 v5, 0x3e8

    mul-long/2addr v3, v5

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    return-wide v1

    .line 827
    :cond_b
    return-wide v1
.end method

.method private drainOutbox()V
    .locals 11

    .line 942
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-nez v0, :cond_0

    .line 943
    return-void

    .line 945
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 946
    .local v0, "now":J
    iget-wide v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendBlockedUntilMs:J

    cmp-long v2, v0, v2

    if-gez v2, :cond_1

    .line 947
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->removeCb(Ljava/lang/Runnable;)V

    .line 948
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainRunnable:Ljava/lang/Runnable;

    iget-wide v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendBlockedUntilMs:J

    sub-long/2addr v3, v0

    invoke-direct {p0, v2, v3, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 949
    return-void

    .line 951
    :cond_1
    :goto_0
    iget-boolean v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-eqz v2, :cond_8

    .line 952
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v2}, Lcom/tzibbur/basic/store/TzbStore;->pendingOutbox()Ljava/util/List;

    move-result-object v2

    .line 953
    .local v2, "queue":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/store/TzbOutboxItem;>;"
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_2

    .line 954
    iput v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    .line 955
    return-void

    .line 957
    :cond_2
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 958
    .local v3, "item":Lcom/tzibbur/basic/store/TzbOutboxItem;
    iget-object v5, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v6, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-interface {v5, v6, v7, v8}, Lcom/tzibbur/basic/store/TzbStore;->outboxSetState(Ljava/lang/String;ILjava/lang/String;)V

    .line 961
    :try_start_0
    iget-object v5, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->api:Lcom/tzibbur/basic/net/TzbApi;

    iget-object v6, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    iget-object v7, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    iget-object v9, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->body:Ljava/lang/String;

    .line 962
    invoke-interface {v5, v6, v7, v9}, Lcom/tzibbur/basic/net/TzbApi;->sendMessage(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbSendResult;

    move-result-object v5

    .line 963
    .local v5, "result":Lcom/tzibbur/basic/model/TzbSendResult;
    iput v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    .line 964
    invoke-virtual {v5}, Lcom/tzibbur/basic/model/TzbSendResult;->isCommand()Z

    move-result v6

    if-eqz v6, :cond_3

    .line 965
    iget-object v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v7, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    invoke-interface {v6, v7}, Lcom/tzibbur/basic/store/TzbStore;->outboxDone(Ljava/lang/String;)V

    .line 966
    iget-object v6, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    invoke-direct {p0, v6}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyMessagesChanged(Ljava/lang/String;)V

    .line 967
    iget-object v6, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    iget-object v7, v5, Lcom/tzibbur/basic/model/TzbSendResult;->command:Lcom/tzibbur/basic/model/TzbCommandResult;

    invoke-direct {p0, v6, v7}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleCommandSideEffects(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbCommandResult;)V

    .line 968
    iget-object v6, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    iget-object v7, v5, Lcom/tzibbur/basic/model/TzbSendResult;->command:Lcom/tzibbur/basic/model/TzbCommandResult;

    invoke-direct {p0, v6, v7}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyCommandResult(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbCommandResult;)V

    goto/16 :goto_1

    .line 969
    :cond_3
    iget-object v6, v5, Lcom/tzibbur/basic/model/TzbSendResult;->message:Lcom/tzibbur/basic/model/TzbMessage;

    if-nez v6, :cond_4

    .line 972
    iget-object v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v7, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    invoke-interface {v6, v7, v4, v8}, Lcom/tzibbur/basic/store/TzbStore;->outboxSetState(Ljava/lang/String;ILjava/lang/String;)V

    .line 974
    iget-object v6, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    invoke-direct {p0, v6}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyMessagesChanged(Ljava/lang/String;)V

    .line 975
    iget-object v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainRunnable:Ljava/lang/Runnable;

    iget v7, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    add-int/lit8 v9, v7, 0x1

    iput v9, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    invoke-direct {p0, v7, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->backoffDelay(II)J

    move-result-wide v9

    invoke-direct {p0, v6, v9, v10}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 976
    return-void

    .line 980
    :cond_4
    iget-object v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v7, v5, Lcom/tzibbur/basic/model/TzbSendResult;->message:Lcom/tzibbur/basic/model/TzbMessage;

    invoke-static {v7}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v7

    invoke-interface {v6, v7}, Lcom/tzibbur/basic/store/TzbStore;->insertMessages(Ljava/util/List;)I

    .line 981
    iget-object v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v7, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    invoke-interface {v6, v7}, Lcom/tzibbur/basic/store/TzbStore;->outboxDone(Ljava/lang/String;)V

    .line 982
    iget-object v6, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    invoke-direct {p0, v6}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyMessagesChanged(Ljava/lang/String;)V

    :try_end_0
    .catch Lcom/tzibbur/basic/net/TzbProblem; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_1

    .line 1007
    .end local v5
    :catch_0
    move-exception v5

    .line 1008
    .local v5, "e":Ljava/io/IOException;
    iget-object v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v7, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    invoke-interface {v6, v7, v4, v8}, Lcom/tzibbur/basic/store/TzbStore;->outboxSetState(Ljava/lang/String;ILjava/lang/String;)V

    .line 1010
    iget-object v4, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    invoke-direct {p0, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyMessagesChanged(Ljava/lang/String;)V

    .line 1011
    iget v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    add-int/lit8 v6, v4, 0x1

    iput v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    const/4 v6, -0x1

    invoke-direct {p0, v4, v6}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->backoffDelay(II)J

    move-result-wide v6

    .line 1012
    .local v6, "delay":J
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    add-long/2addr v8, v6

    iput-wide v8, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendBlockedUntilMs:J

    .line 1013
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->removeCb(Ljava/lang/Runnable;)V

    .line 1014
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v4, v6, v7}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1015
    return-void

    .line 984
    .end local v5
    .end local v6
    :catch_1
    move-exception v5

    .line 985
    .local v5, "p":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-direct {p0, v5}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->blockedBy(Lcom/tzibbur/basic/net/TzbProblem;)Z

    move-result v6

    if-eqz v6, :cond_5

    .line 986
    return-void

    .line 988
    :cond_5
    invoke-virtual {v5}, Lcom/tzibbur/basic/net/TzbProblem;->isUnauthorized()Z

    move-result v6

    if-eqz v6, :cond_6

    .line 989
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleUnauthorized()V

    .line 990
    return-void

    .line 992
    :cond_6
    invoke-virtual {v5}, Lcom/tzibbur/basic/net/TzbProblem;->isRetryable()Z

    move-result v6

    if-eqz v6, :cond_7

    .line 993
    iget-object v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v7, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    iget-object v8, v5, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-interface {v6, v7, v4, v8}, Lcom/tzibbur/basic/store/TzbStore;->outboxSetState(Ljava/lang/String;ILjava/lang/String;)V

    .line 995
    iget-object v4, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    invoke-direct {p0, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyMessagesChanged(Ljava/lang/String;)V

    .line 996
    iget v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    add-int/lit8 v6, v4, 0x1

    iput v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    iget v6, v5, Lcom/tzibbur/basic/net/TzbProblem;->retryAfterSeconds:I

    invoke-direct {p0, v4, v6}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->backoffDelay(II)J

    move-result-wide v6

    .line 997
    .restart local v6
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    add-long/2addr v8, v6

    iput-wide v8, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendBlockedUntilMs:J

    .line 998
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->removeCb(Ljava/lang/Runnable;)V

    .line 999
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v4, v6, v7}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1000
    return-void

    .line 1003
    .end local v6
    :cond_7
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v6, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    const/4 v7, 0x2

    iget-object v8, v5, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-interface {v4, v6, v7, v8}, Lcom/tzibbur/basic/store/TzbStore;->outboxSetState(Ljava/lang/String;ILjava/lang/String;)V

    .line 1005
    iget-object v4, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    invoke-direct {p0, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyMessagesChanged(Ljava/lang/String;)V

    .line 1006
    iget-object v4, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->groupId:Ljava/lang/String;

    iget-object v6, v5, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    iget-object v7, v5, Lcom/tzibbur/basic/net/TzbProblem;->errors:Lorg/json/JSONObject;

    invoke-direct {p0, v4, v6, v7}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifySendFailed(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 1016
    .end local v5
    :goto_1
    nop

    .line 1017
    .end local v2
    .end local v3
    goto/16 :goto_0

    .line 1018
    :cond_8
    return-void
.end method

.method private engineHandler()Landroid/os/Handler;
    .locals 4

    .line 540
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->threadLock:Ljava/lang/Object;

    monitor-enter v0

    .line 541
    :try_start_0
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    if-nez v1, :cond_0

    .line 542
    new-instance v1, Landroid/os/HandlerThread;

    const-string v2, "tzb-sync"

    invoke-direct {v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 543
    .local v1, "thread":Landroid/os/HandlerThread;
    invoke-virtual {v1}, Landroid/os/HandlerThread;->start()V

    .line 544
    new-instance v2, Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 546
    .end local v1
    :cond_0
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    monitor-exit v0

    return-object v1

    .line 547
    :catchall_0
    move-exception v1

    monitor-exit v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method private flushPendingReads()V
    .locals 7

    .line 1074
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-nez v0, :cond_0

    .line 1075
    return-void

    .line 1077
    :cond_0
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->outboundPaused()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 1080
    return-void

    .line 1083
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    monitor-enter v0

    .line 1084
    :try_start_0
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 1085
    monitor-exit v0

    return-void

    .line 1087
    :cond_2
    new-instance v1, Ljava/util/HashMap;

    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 1088
    .local v1, "batch":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Long;>;"
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->clear()V

    .line 1089
    monitor-exit v0

    .line 1090
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 1091
    .local v2, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Long;>;"
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 1092
    .local v3, "groupId":Ljava/lang/String;
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Long;

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    .line 1095
    .local v4, "seq":J
    iget-object v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v6, v3, v4, v5}, Lcom/tzibbur/basic/store/TzbStore;->setReadSeq(Ljava/lang/String;J)V

    .line 1096
    invoke-direct {p0, v3, v4, v5}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->reportReadOnce(Ljava/lang/String;J)Z

    move-result v6

    if-nez v6, :cond_3

    .line 1097
    invoke-direct {p0, v3, v4, v5}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->rememberPendingRead(Ljava/lang/String;J)V

    .line 1099
    :cond_3
    iget-boolean v6, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-nez v6, :cond_4

    .line 1100
    return-void

    .line 1102
    .end local v2
    .end local v3
    .end local v4
    :cond_4
    goto :goto_0

    .line 1103
    :cond_5
    return-void

    .line 1089
    .end local v1
    :catchall_0
    move-exception v1

    :try_start_1
    monitor-exit v0

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method

.method private flushSkippedAcks()V
    .locals 6

    .line 703
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->ackSkipped:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 704
    return-void

    .line 706
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 707
    .local v0, "s":Lcom/tzibbur/basic/net/TzbWebSocket;
    iget-boolean v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    if-eqz v1, :cond_3

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->isOpen()Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_1

    .line 711
    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->ackSkipped:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 712
    .local v2, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Long;>;"
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Long;

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    invoke-virtual {v0, v3, v4, v5}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendAck(Ljava/lang/String;J)V

    .line 713
    .end local v2
    goto :goto_0

    .line 714
    :cond_2
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->ackSkipped:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    .line 715
    return-void

    .line 708
    :cond_3
    :goto_1
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->ackSkipped:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    .line 709
    return-void
.end method

.method private handleCommandSideEffects(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbCommandResult;)V
    .locals 3
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "command"    # Lcom/tzibbur/basic/model/TzbCommandResult;

    .line 1022
    const-string v0, "left_group"

    iget-object v1, p2, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1023
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v0, p1}, Lcom/tzibbur/basic/store/TzbStore;->removeGroup(Ljava/lang/String;)V

    .line 1024
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->cancelNotification(Ljava/lang/String;)V

    .line 1025
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyGroupsChanged()V

    goto :goto_1

    .line 1026
    :cond_0
    const-string v0, "muted"

    iget-object v1, p2, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    const-string v0, "already_muted"

    iget-object v1, p2, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    .line 1032
    :cond_1
    const-string v0, "unmuted"

    iget-object v1, p2, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p2, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    .line 1033
    const-string v1, "member_added"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p2, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    .line 1037
    const-string v1, "not_muted"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p2, Lcom/tzibbur/basic/model/TzbCommandResult;->code:Ljava/lang/String;

    .line 1038
    const-string v1, "already_member"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 1039
    :cond_2
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->refreshGroupsInternal()V

    goto :goto_1

    .line 1030
    :cond_3
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v1, p1}, Lcom/tzibbur/basic/store/TzbStore;->maxSeq(Ljava/lang/String;)J

    move-result-wide v1

    invoke-interface {v0, p1, v1, v2}, Lcom/tzibbur/basic/store/TzbStore;->recordMuteGap(Ljava/lang/String;J)V

    .line 1031
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->refreshGroupsInternal()V

    .line 1041
    :cond_4
    :goto_1
    return-void
.end method

.method private handleDeviceBlocked()V
    .locals 3

    .line 1146
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->session:Lcom/tzibbur/basic/store/TzbSession;

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->setDeviceBlocked()V

    .line 1148
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->threadLock:Ljava/lang/Object;

    monitor-enter v0

    .line 1149
    :try_start_0
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 1150
    .local v1, "h":Landroid/os/Handler;
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 1151
    monitor-exit v0

    .line 1152
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->wsDisabled:Z

    .line 1153
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->teardownOnEngine()V

    .line 1154
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->stopPollingInternal()V

    .line 1155
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notificationManager()Landroid/app/NotificationManager;

    move-result-object v0

    .line 1156
    .local v0, "nm":Landroid/app/NotificationManager;
    if-eqz v0, :cond_0

    .line 1157
    invoke-virtual {v0}, Landroid/app/NotificationManager;->cancelAll()V

    .line 1159
    :cond_0
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyDeviceBlocked()V

    .line 1160
    if-eqz v1, :cond_1

    .line 1161
    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Looper;->quitSafely()V

    .line 1163
    :cond_1
    return-void

    .line 1151
    .end local v0
    .end local v1
    :catchall_0
    move-exception v1

    :try_start_1
    monitor-exit v0

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method

.method private handleGroupEvent(Lcom/tzibbur/basic/model/TzbGroupEvent;)V
    .locals 26
    .param p1, "e"    # Lcom/tzibbur/basic/model/TzbGroupEvent;

    .line 885
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->session:Lcom/tzibbur/basic/store/TzbSession;

    invoke-interface {v2}, Lcom/tzibbur/basic/store/TzbSession;->userId()Ljava/lang/String;

    move-result-object v2

    .line 886
    .local v2, "me":Ljava/lang/String;
    if-eqz v2, :cond_0

    iget-object v3, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->userId:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    .line 887
    .local v3, "aboutMe":Z
    :goto_0
    const-string v4, "member-added"

    iget-object v5, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->event:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 893
    invoke-direct {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->refreshGroupsInternal()V

    move-object/from16 v24, v2

    move/from16 v25, v3

    goto/16 :goto_5

    .line 894
    :cond_1
    const-string v4, "member-removed"

    iget-object v5, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->event:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    .line 895
    if-eqz v3, :cond_2

    .line 898
    iget-object v4, v0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v5, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->groupId:Ljava/lang/String;

    invoke-interface {v4, v5}, Lcom/tzibbur/basic/store/TzbStore;->removeGroup(Ljava/lang/String;)V

    .line 899
    iget-object v4, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->groupId:Ljava/lang/String;

    invoke-direct {v0, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->cancelNotification(Ljava/lang/String;)V

    .line 900
    invoke-direct {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyGroupsChanged()V

    move-object/from16 v24, v2

    move/from16 v25, v3

    goto/16 :goto_5

    .line 902
    :cond_2
    invoke-direct {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->refreshGroupsInternal()V

    move-object/from16 v24, v2

    move/from16 v25, v3

    goto/16 :goto_5

    .line 904
    :cond_3
    const-string v4, "group-deleted"

    iget-object v5, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->event:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    .line 905
    iget-object v4, v0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v5, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->groupId:Ljava/lang/String;

    invoke-interface {v4, v5}, Lcom/tzibbur/basic/store/TzbStore;->removeGroup(Ljava/lang/String;)V

    .line 906
    iget-object v4, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->groupId:Ljava/lang/String;

    invoke-direct {v0, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->cancelNotification(Ljava/lang/String;)V

    .line 907
    invoke-direct {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyGroupsChanged()V

    move-object/from16 v24, v2

    move/from16 v25, v3

    goto/16 :goto_5

    .line 908
    :cond_4
    const-string v4, "group-updated"

    iget-object v5, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->event:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9

    .line 909
    iget-object v4, v0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v5, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->groupId:Ljava/lang/String;

    invoke-interface {v4, v5}, Lcom/tzibbur/basic/store/TzbStore;->group(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v4

    .line 910
    .local v4, "g":Lcom/tzibbur/basic/model/TzbGroup;
    if-nez v4, :cond_5

    .line 911
    invoke-direct {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->refreshGroupsInternal()V

    move-object/from16 v24, v2

    move/from16 v25, v3

    goto :goto_4

    .line 917
    :cond_5
    iget-object v5, v0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    new-instance v6, Lcom/tzibbur/basic/model/TzbGroup;

    iget-object v7, v4, Lcom/tzibbur/basic/model/TzbGroup;->id:Ljava/lang/String;

    .line 918
    iget-object v8, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->name:Ljava/lang/String;

    if-eqz v8, :cond_6

    iget-object v8, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->name:Ljava/lang/String;

    goto :goto_1

    :cond_6
    iget-object v8, v4, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    :goto_1
    iget-object v9, v4, Lcom/tzibbur/basic/model/TzbGroup;->category:Ljava/lang/String;

    iget-object v10, v4, Lcom/tzibbur/basic/model/TzbGroup;->kind:Ljava/lang/String;

    .line 920
    iget-object v11, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->whoCanPost:Ljava/lang/String;

    if-eqz v11, :cond_7

    iget-object v11, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->whoCanPost:Ljava/lang/String;

    goto :goto_2

    :cond_7
    iget-object v11, v4, Lcom/tzibbur/basic/model/TzbGroup;->whoCanPost:Ljava/lang/String;

    .line 921
    :goto_2
    iget-object v12, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->whoCanAddMembers:Ljava/lang/String;

    if-eqz v12, :cond_8

    iget-object v12, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->whoCanAddMembers:Ljava/lang/String;

    goto :goto_3

    :cond_8
    iget-object v12, v4, Lcom/tzibbur/basic/model/TzbGroup;->whoCanAddMembers:Ljava/lang/String;

    :goto_3
    iget-object v13, v4, Lcom/tzibbur/basic/model/TzbGroup;->createdBy:Ljava/lang/String;

    iget-object v14, v4, Lcom/tzibbur/basic/model/TzbGroup;->createdAt:Ljava/lang/String;

    iget-object v15, v4, Lcom/tzibbur/basic/model/TzbGroup;->role:Ljava/lang/String;

    iget v0, v4, Lcom/tzibbur/basic/model/TzbGroup;->memberCount:I

    move/from16 v16, v0

    iget-boolean v0, v4, Lcom/tzibbur/basic/model/TzbGroup;->muted:Z

    move-object/from16 v24, v2

    move/from16 v25, v3

    .end local v2
    .end local v3
    .local v24, "me":Ljava/lang/String;
    .local v25, "aboutMe":Z
    iget-wide v2, v4, Lcom/tzibbur/basic/model/TzbGroup;->readSeq:J

    move/from16 v17, v0

    iget v0, v4, Lcom/tzibbur/basic/model/TzbGroup;->unreadCount:I

    move/from16 v20, v0

    iget v0, v4, Lcom/tzibbur/basic/model/TzbGroup;->messageMaxLength:I

    move/from16 v21, v0

    iget v0, v4, Lcom/tzibbur/basic/model/TzbGroup;->memberCap:I

    move/from16 v22, v0

    iget v0, v4, Lcom/tzibbur/basic/model/TzbGroup;->minMembersToPost:I

    move/from16 v23, v0

    move-wide/from16 v18, v2

    invoke-direct/range {v6 .. v23}, Lcom/tzibbur/basic/model/TzbGroup;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZJIIII)V

    .line 917
    invoke-interface {v5, v6}, Lcom/tzibbur/basic/store/TzbStore;->upsertGroup(Lcom/tzibbur/basic/model/TzbGroup;)V

    .line 925
    invoke-direct/range {p0 .. p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyGroupsChanged()V

    .line 927
    .end local v4
    :goto_4
    goto :goto_5

    .end local v24
    .end local v25
    .restart local v2
    .restart local v3
    :cond_9
    move-object/from16 v24, v2

    move/from16 v25, v3

    .end local v2
    .end local v3
    .restart local v24
    .restart local v25
    const-string v0, "role-changed"

    iget-object v2, v1, Lcom/tzibbur/basic/model/TzbGroupEvent;->event:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 928
    if-eqz v25, :cond_a

    .line 929
    invoke-direct/range {p0 .. p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->refreshGroupsInternal()V

    goto :goto_5

    .line 931
    :cond_a
    invoke-direct/range {p0 .. p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyGroupsChanged()V

    goto :goto_5

    .line 935
    :cond_b
    invoke-direct/range {p0 .. p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyGroupsChanged()V

    .line 937
    :goto_5
    return-void
.end method

.method private handleSocketBatch(Ljava/lang/String;Ljava/util/List;)V
    .locals 7
    .param p1, "groupId"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;)V"
        }
    .end annotation

    .line 726
    .local p2, "messages":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-eqz v0, :cond_5

    if-eqz p2, :cond_5

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    .line 730
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v0, p2}, Lcom/tzibbur/basic/store/TzbStore;->insertMessages(Ljava/util/List;)I

    move-result v0

    .line 731
    .local v0, "inserted":I
    invoke-direct {p0, p1, p2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->matchEchoes(Ljava/lang/String;Ljava/util/List;)V

    .line 732
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-interface {p2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/tzibbur/basic/model/TzbMessage;

    iget-wide v1, v1, Lcom/tzibbur/basic/model/TzbMessage;->seq:J

    .line 733
    .local v1, "lastSeq":J
    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 734
    .local v3, "s":Lcom/tzibbur/basic/net/TzbWebSocket;
    if-eqz v3, :cond_4

    invoke-virtual {v3}, Lcom/tzibbur/basic/net/TzbWebSocket;->isOpen()Z

    move-result v4

    if-eqz v4, :cond_4

    .line 735
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->outboundPaused()Z

    move-result v4

    if-eqz v4, :cond_3

    .line 739
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->ackSkipped:Ljava/util/Map;

    invoke-interface {v4, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Long;

    .line 740
    .local v4, "held":Ljava/lang/Long;
    if-eqz v4, :cond_1

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    cmp-long v5, v1, v5

    if-lez v5, :cond_2

    .line 741
    :cond_1
    iget-object v5, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->ackSkipped:Ljava/util/Map;

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface {v5, p1, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 743
    .end local v4
    :cond_2
    goto :goto_0

    .line 744
    :cond_3
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->ackSkipped:Ljava/util/Map;

    invoke-interface {v4, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 745
    invoke-virtual {v3, p1, v1, v2}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendAck(Ljava/lang/String;J)V

    .line 750
    :cond_4
    :goto_0
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyMessagesChanged(Ljava/lang/String;)V

    .line 751
    invoke-direct {p0, p1, p2, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->maybeShowNotification(Ljava/lang/String;Ljava/util/List;I)V

    .line 752
    return-void

    .line 727
    .end local v0
    .end local v1
    .end local v3
    :cond_5
    :goto_1
    return-void
.end method

.method private handleUnauthorized()V
    .locals 3

    .line 1167
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->threadLock:Ljava/lang/Object;

    monitor-enter v0

    .line 1168
    :try_start_0
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 1169
    .local v1, "h":Landroid/os/Handler;
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 1170
    monitor-exit v0

    .line 1171
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->teardownOnEngine()V

    .line 1172
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->session:Lcom/tzibbur/basic/store/TzbSession;

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->clear()V

    .line 1173
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbStore;->clearAll()V

    .line 1174
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    monitor-enter v2

    .line 1175
    :try_start_1
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 1176
    monitor-exit v2

    .line 1177
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notificationManager()Landroid/app/NotificationManager;

    move-result-object v0

    .line 1178
    .local v0, "nm":Landroid/app/NotificationManager;
    if-eqz v0, :cond_0

    .line 1179
    invoke-virtual {v0}, Landroid/app/NotificationManager;->cancelAll()V

    .line 1181
    :cond_0
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifySessionExpired()V

    .line 1182
    if-eqz v1, :cond_1

    .line 1183
    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Looper;->quitSafely()V

    .line 1185
    :cond_1
    return-void

    .line 1176
    .end local v0
    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit v2

    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0

    .line 1170
    .end local v1
    :catchall_1
    move-exception v1

    :try_start_3
    monitor-exit v0

    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw v1
.end method

.method private matchEchoes(Ljava/lang/String;Ljava/util/List;)V
    .locals 6
    .param p1, "groupId"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;)V"
        }
    .end annotation

    .line 1045
    .local p2, "messages":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v0, p1}, Lcom/tzibbur/basic/store/TzbStore;->outbox(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    .line 1046
    .local v0, "pending":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/store/TzbOutboxItem;>;"
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 1047
    return-void

    .line 1049
    :cond_0
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 1050
    .local v1, "pendingIds":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 1051
    .local v3, "item":Lcom/tzibbur/basic/store/TzbOutboxItem;
    iget-object v4, v3, Lcom/tzibbur/basic/store/TzbOutboxItem;->clientMessageId:Ljava/lang/String;

    invoke-interface {v1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 1052
    .end local v3
    goto :goto_0

    .line 1053
    :cond_1
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/tzibbur/basic/model/TzbMessage;

    .line 1054
    .local v3, "m":Lcom/tzibbur/basic/model/TzbMessage;
    iget-object v4, v3, Lcom/tzibbur/basic/model/TzbMessage;->clientMessageId:Ljava/lang/String;

    if-eqz v4, :cond_2

    iget-object v4, v3, Lcom/tzibbur/basic/model/TzbMessage;->clientMessageId:Ljava/lang/String;

    invoke-interface {v1, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 1055
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    iget-object v5, v3, Lcom/tzibbur/basic/model/TzbMessage;->clientMessageId:Ljava/lang/String;

    invoke-interface {v4, v5}, Lcom/tzibbur/basic/store/TzbStore;->outboxDone(Ljava/lang/String;)V

    .line 1057
    .end local v3
    :cond_2
    goto :goto_1

    .line 1058
    :cond_3
    return-void
.end method

.method private maybeShowNotification(Ljava/lang/String;Ljava/util/List;I)V
    .locals 5
    .param p1, "groupId"    # Ljava/lang/String;
    .param p3, "insertedCount"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;I)V"
        }
    .end annotation

    .line 1288
    .local p2, "messages":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    if-lez p3, :cond_5

    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->activeGroupId:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    .line 1292
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->session:Lcom/tzibbur/basic/store/TzbSession;

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->userId()Ljava/lang/String;

    move-result-object v0

    .line 1293
    .local v0, "me":Ljava/lang/String;
    const/4 v1, 0x0

    .line 1294
    .local v1, "latestFromOther":Lcom/tzibbur/basic/model/TzbMessage;
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/tzibbur/basic/model/TzbMessage;

    .line 1295
    .local v3, "m":Lcom/tzibbur/basic/model/TzbMessage;
    if-eqz v0, :cond_1

    iget-object v4, v3, Lcom/tzibbur/basic/model/TzbMessage;->senderId:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2

    .line 1296
    :cond_1
    move-object v1, v3

    .line 1298
    .end local v3
    :cond_2
    goto :goto_0

    .line 1299
    :cond_3
    if-nez v1, :cond_4

    .line 1300
    return-void

    .line 1302
    :cond_4
    invoke-direct {p0, p1, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->showNotification(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbMessage;)V

    .line 1303
    return-void

    .line 1289
    .end local v0
    .end local v1
    :cond_5
    :goto_1
    return-void
.end method

.method private notificationManager()Landroid/app/NotificationManager;
    .locals 2

    .line 1360
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    const-string v1, "notification"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    return-object v0
.end method

.method private notifyCommandResult(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbCommandResult;)V
    .locals 2
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "result"    # Lcom/tzibbur/basic/model/TzbCommandResult;

    .line 1238
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->main:Landroid/os/Handler;

    new-instance v1, Lcom/tzibbur/basic/sync/TzbSyncEngine$24;

    invoke-direct {v1, p0, p1, p2}, Lcom/tzibbur/basic/sync/TzbSyncEngine$24;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;Lcom/tzibbur/basic/model/TzbCommandResult;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1246
    return-void
.end method

.method private notifyDeviceBlocked()V
    .locals 2

    .line 1263
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->main:Landroid/os/Handler;

    new-instance v1, Lcom/tzibbur/basic/sync/TzbSyncEngine$26;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$26;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1271
    return-void
.end method

.method private notifyGroupsChanged()V
    .locals 2

    .line 1227
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->main:Landroid/os/Handler;

    new-instance v1, Lcom/tzibbur/basic/sync/TzbSyncEngine$23;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$23;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1235
    return-void
.end method

.method private notifyMessagesChanged(Ljava/lang/String;)V
    .locals 2
    .param p1, "groupId"    # Ljava/lang/String;

    .line 1216
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->main:Landroid/os/Handler;

    new-instance v1, Lcom/tzibbur/basic/sync/TzbSyncEngine$22;

    invoke-direct {v1, p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine$22;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1224
    return-void
.end method

.method private notifySendFailed(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
    .locals 3
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "problemCode"    # Ljava/lang/String;
    .param p3, "errors"    # Lorg/json/JSONObject;

    .line 1251
    if-eqz p3, :cond_0

    move-object v0, p3

    goto :goto_0

    :cond_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 1252
    .local v0, "safeErrors":Lorg/json/JSONObject;
    :goto_0
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->main:Landroid/os/Handler;

    new-instance v2, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;

    invoke-direct {v2, p0, p1, p2, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$25;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1260
    return-void
.end method

.method private notifySessionExpired()V
    .locals 2

    .line 1274
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->main:Landroid/os/Handler;

    new-instance v1, Lcom/tzibbur/basic/sync/TzbSyncEngine$27;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$27;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1282
    return-void
.end method

.method private outboundPaused()Z
    .locals 2

    .line 688
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 689
    .local v0, "s":Lcom/tzibbur/basic/net/TzbWebSocket;
    iget-boolean v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    if-eqz v1, :cond_0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbWebSocket;->outboundPaused()Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method private pollNow()V
    .locals 3

    .line 771
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollingActive:Z

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 774
    :cond_0
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->doPollOnce()J

    move-result-wide v0

    .line 775
    .local v0, "nextDelay":J
    iget-boolean v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-eqz v2, :cond_1

    iget-boolean v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollingActive:Z

    if-eqz v2, :cond_1

    iget-boolean v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    if-nez v2, :cond_1

    .line 776
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v2, v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 778
    :cond_1
    return-void

    .line 772
    .end local v0
    :cond_2
    :goto_0
    return-void
.end method

.method private post(Ljava/lang/Runnable;)Z
    .locals 2
    .param p1, "r"    # Ljava/lang/Runnable;

    .line 551
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 552
    .local v0, "h":Landroid/os/Handler;
    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method private postDelayed(Ljava/lang/Runnable;J)Z
    .locals 2
    .param p1, "r"    # Ljava/lang/Runnable;
    .param p2, "delayMs"    # J

    .line 556
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 557
    .local v0, "h":Landroid/os/Handler;
    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2, p3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method private refreshCapabilitiesInternal()V
    .locals 3

    .line 361
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->session:Lcom/tzibbur/basic/store/TzbSession;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->api:Lcom/tzibbur/basic/net/TzbApi;

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Lcom/tzibbur/basic/net/TzbApi;->capabilities(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbCapabilities;

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbSession;->saveCapabilities(Lcom/tzibbur/basic/model/TzbCapabilities;)V

    :try_end_0
    .catch Lcom/tzibbur/basic/net/TzbProblem; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 364
    :catch_0
    move-exception v0

    goto :goto_1

    .line 362
    :catch_1
    move-exception v0

    .line 363
    .local v0, "p":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->blockedBy(Lcom/tzibbur/basic/net/TzbProblem;)Z

    .line 366
    .end local v0
    :goto_0
    nop

    .line 367
    :goto_1
    return-void
.end method

.method private refreshGroupsInternal()V
    .locals 7

    .line 848
    const-string v0, "TzbSyncEngine"

    :try_start_0
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 849
    .local v1, "all":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbGroup;>;"
    const/4 v2, 0x0

    .line 851
    .local v2, "cursor":Ljava/lang/String;
    :cond_0
    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->api:Lcom/tzibbur/basic/net/TzbApi;

    const/16 v4, 0x64

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v2, v4}, Lcom/tzibbur/basic/net/TzbApi;->listGroups(Ljava/lang/String;Ljava/lang/Integer;)Lcom/tzibbur/basic/model/TzbPage;

    move-result-object v3

    .line 852
    .local v3, "page":Lcom/tzibbur/basic/model/TzbPage;, "Lcom/tzibbur/basic/model/TzbPage<Lcom/tzibbur/basic/model/TzbGroup;>;"
    iget-object v4, v3, Lcom/tzibbur/basic/model/TzbPage;->items:Ljava/util/List;

    invoke-interface {v1, v4}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 853
    iget-object v4, v3, Lcom/tzibbur/basic/model/TzbPage;->nextCursor:Ljava/lang/String;

    move-object v2, v4

    .line 854
    .end local v3
    if-nez v2, :cond_0

    .line 859
    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v3}, Lcom/tzibbur/basic/store/TzbStore;->groupIds()Ljava/util/List;

    move-result-object v3

    .line 860
    .local v3, "before":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v4, v1}, Lcom/tzibbur/basic/store/TzbStore;->replaceGroups(Ljava/util/List;)V

    .line 861
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 862
    .local v5, "id":Ljava/lang/String;
    invoke-static {v1, v5}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->containsGroup(Ljava/util/List;Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_1

    .line 863
    invoke-direct {p0, v5}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->cancelNotification(Ljava/lang/String;)V

    .line 865
    .end local v5
    :cond_1
    goto :goto_0

    .line 866
    :cond_2
    const/4 v4, 0x1

    iput-boolean v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->initialRefreshDone:Z

    .line 867
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notifyGroupsChanged()V

    .end local v1
    .end local v2
    .end local v3
    :try_end_0
    .catch Lcom/tzibbur/basic/net/TzbProblem; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    .line 877
    :catch_0
    move-exception v1

    .line 878
    .local v1, "e":Ljava/io/IOException;
    const-string v2, "groups refresh failed: network"

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_2

    .line 868
    .end local v1
    :catch_1
    move-exception v1

    .line 869
    .local v1, "p":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-direct {p0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->blockedBy(Lcom/tzibbur/basic/net/TzbProblem;)Z

    move-result v2

    if-eqz v2, :cond_3

    .line 870
    return-void

    .line 872
    :cond_3
    invoke-virtual {v1}, Lcom/tzibbur/basic/net/TzbProblem;->isUnauthorized()Z

    move-result v2

    if-eqz v2, :cond_4

    .line 873
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleUnauthorized()V

    .line 874
    return-void

    .line 876
    :cond_4
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "groups refresh problem: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v1, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v1, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 879
    .end local v1
    :goto_1
    nop

    .line 880
    :goto_2
    return-void
.end method

.method private registerNetworkCallback()V
    .locals 2

    .line 573
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->networkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    if-eqz v0, :cond_0

    .line 574
    return-void

    .line 577
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    const-string v1, "connectivity"

    .line 578
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    .line 579
    .local v0, "cm":Landroid/net/ConnectivityManager;
    if-nez v0, :cond_1

    return-void

    .line 580
    :cond_1
    new-instance v1, Lcom/tzibbur/basic/sync/TzbSyncEngine$19;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$19;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 587
    .local v1, "cb":Landroid/net/ConnectivityManager$NetworkCallback;
    invoke-virtual {v0, v1}, Landroid/net/ConnectivityManager;->registerDefaultNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V

    .line 588
    iput-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->networkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    .line 591
    .end local v0
    .end local v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 589
    :catchall_0
    move-exception v0

    .line 592
    :goto_0
    return-void
.end method

.method private rememberPendingRead(Ljava/lang/String;J)V
    .locals 4
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "seq"    # J

    .line 1064
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    monitor-enter v0

    .line 1065
    :try_start_0
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    .line 1066
    .local v1, "current":Ljava/lang/Long;
    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    cmp-long v2, p2, v2

    if-lez v2, :cond_1

    .line 1067
    :cond_0
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pendingReads:Ljava/util/Map;

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-interface {v2, p1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1069
    .end local v1
    :cond_1
    monitor-exit v0

    .line 1070
    return-void

    .line 1069
    :catchall_0
    move-exception v1

    monitor-exit v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method private removeCb(Ljava/lang/Runnable;)V
    .locals 1
    .param p1, "r"    # Ljava/lang/Runnable;

    .line 561
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 562
    .local v0, "h":Landroid/os/Handler;
    if-eqz v0, :cond_0

    .line 563
    invoke-virtual {v0, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 565
    :cond_0
    return-void
.end method

.method private reportReadOnce(Ljava/lang/String;J)Z
    .locals 4
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "seq"    # J

    .line 1112
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socketLive:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    .line 1113
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->socket:Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 1114
    .local v0, "s":Lcom/tzibbur/basic/net/TzbWebSocket;
    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2, p3}, Lcom/tzibbur/basic/net/TzbWebSocket;->sendRead(Ljava/lang/String;J)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 1117
    return v1

    .line 1121
    .end local v0
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->api:Lcom/tzibbur/basic/net/TzbApi;

    invoke-interface {v0, p1, p2, p3}, Lcom/tzibbur/basic/net/TzbApi;->markRead(Ljava/lang/String;J)V

    .line 1122
    :try_end_0
    .catch Lcom/tzibbur/basic/net/TzbProblem; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    .line 1133
    :catch_0
    move-exception v0

    .line 1134
    .local v0, "e":Ljava/io/IOException;
    const/4 v1, 0x0

    return v1

    .line 1123
    .end local v0
    :catch_1
    move-exception v0

    .line 1124
    .local v0, "p":Lcom/tzibbur/basic/net/TzbProblem;
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->blockedBy(Lcom/tzibbur/basic/net/TzbProblem;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 1125
    return v1

    .line 1127
    :cond_1
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isUnauthorized()Z

    move-result v2

    if-eqz v2, :cond_2

    .line 1128
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->handleUnauthorized()V

    .line 1129
    return v1

    .line 1131
    :cond_2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "read report problem: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->code:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v0, Lcom/tzibbur/basic/net/TzbProblem;->status:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "TzbSyncEngine"

    invoke-static {v3, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 1132
    invoke-virtual {v0}, Lcom/tzibbur/basic/net/TzbProblem;->isRetryable()Z

    move-result v2

    xor-int/2addr v1, v2

    return v1
.end method

.method private resumeOutbound()V
    .locals 1

    .line 694
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->outboundPaused()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 697
    :cond_0
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->flushSkippedAcks()V

    .line 698
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->flushPendingReads()V

    .line 699
    return-void

    .line 695
    :cond_1
    :goto_0
    return-void
.end method

.method private setState(I)V
    .locals 3
    .param p1, "newState"    # I

    .line 1200
    iget v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->state:I

    if-ne v0, p1, :cond_0

    .line 1201
    return-void

    .line 1203
    :cond_0
    iput p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->state:I

    .line 1204
    move v0, p1

    .line 1205
    .local v0, "value":I
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->main:Landroid/os/Handler;

    new-instance v2, Lcom/tzibbur/basic/sync/TzbSyncEngine$21;

    invoke-direct {v2, p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$21;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1213
    return-void
.end method

.method private showNotification(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbMessage;)V
    .locals 12
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "latest"    # Lcom/tzibbur/basic/model/TzbMessage;

    .line 1306
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->notificationManager()Landroid/app/NotificationManager;

    move-result-object v0

    .line 1307
    .local v0, "nm":Landroid/app/NotificationManager;
    if-nez v0, :cond_0

    .line 1308
    return-void

    .line 1310
    :cond_0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const-string v2, "tzb_messages"

    const/16 v3, 0x1a

    if-lt v1, v3, :cond_1

    .line 1311
    new-instance v1, Landroid/app/NotificationChannel;

    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_sync_channel_messages:I

    .line 1312
    invoke-virtual {v4, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x3

    invoke-direct {v1, v2, v4, v5}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 1311
    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 1315
    :cond_1
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v1, p1}, Lcom/tzibbur/basic/store/TzbStore;->group(Ljava/lang/String;)Lcom/tzibbur/basic/model/TzbGroup;

    move-result-object v1

    .line 1316
    .local v1, "group":Lcom/tzibbur/basic/model/TzbGroup;
    if-eqz v1, :cond_2

    iget-object v4, v1, Lcom/tzibbur/basic/model/TzbGroup;->name:Ljava/lang/String;

    goto :goto_0

    .line 1317
    :cond_2
    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_sync_fallback_title:I

    invoke-virtual {v4, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v4

    :goto_0
    nop

    .line 1322
    .local v4, "title":Ljava/lang/String;
    iget-object v5, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->store:Lcom/tzibbur/basic/store/TzbStore;

    invoke-interface {v5, p1}, Lcom/tzibbur/basic/store/TzbStore;->unreadCount(Ljava/lang/String;)I

    move-result v5

    .line 1324
    .local v5, "unread":I
    new-instance v6, Landroid/content/Intent;

    invoke-direct {v6}, Landroid/content/Intent;-><init>()V

    .line 1325
    .local v6, "intent":Landroid/content/Intent;
    iget-object v7, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    const-string v8, "com.tzibbur.basic.ui.TzbConversationActivity"

    invoke-virtual {v6, v7, v8}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 1326
    const-string v7, "tzb_group_id"

    invoke-virtual {v6, v7, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 1327
    const/high16 v7, 0x14000000

    invoke-virtual {v6, v7}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 1328
    iget-object v7, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    .line 1329
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v8

    .line 1328
    const/high16 v9, 0xc000000

    invoke-static {v7, v8, v6, v9}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v7

    .line 1333
    .local v7, "contentIntent":Landroid/app/PendingIntent;
    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v9, 0x0

    if-lt v8, v3, :cond_3

    .line 1334
    new-instance v3, Landroid/app/Notification$Builder;

    iget-object v8, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    invoke-direct {v3, v8, v2}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .local v3, "builder":Landroid/app/Notification$Builder;
    goto :goto_1

    .line 1336
    .end local v3
    :cond_3
    new-instance v2, Landroid/app/Notification$Builder;

    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    invoke-direct {v2, v3}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .line 1337
    .restart local v3
    invoke-virtual {v3, v9}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    .line 1339
    :goto_1
    sget v2, Lcom/tzibbur/basic/R$drawable;->tzb_ic_launcher:I

    invoke-virtual {v3, v2}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 1340
    invoke-virtual {v2, v4}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    iget-object v8, p2, Lcom/tzibbur/basic/model/TzbMessage;->body:Ljava/lang/String;

    .line 1341
    invoke-static {v8}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->snippet(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 1342
    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 1343
    const/4 v8, 0x1

    invoke-virtual {v2, v8}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 1344
    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setNumber(I)Landroid/app/Notification$Builder;

    .line 1345
    if-le v5, v8, :cond_4

    .line 1346
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    sget v10, Lcom/tzibbur/basic/R$string;->tzb_sync_unread_fmt:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    new-array v8, v8, [Ljava/lang/Object;

    aput-object v11, v8, v9

    invoke-virtual {v2, v10, v8}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/app/Notification$Builder;->setSubText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 1349
    :cond_4
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v2

    invoke-virtual {v3}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v8

    # tzib inbox options: group pause
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;
    invoke-static {v1, p1, v8}, Lcom/android/mms/tzib/TzibNotifications;->postGroup(Landroid/content/Context;Ljava/lang/String;Landroid/app/Notification;)V

    .line 1350
    return-void
.end method

.method private static snippet(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "body"    # Ljava/lang/String;

    .line 1364
    if-nez p0, :cond_0

    .line 1365
    const-string v0, ""

    return-object v0

    .line 1367
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x50

    if-gt v0, v1, :cond_1

    move-object v0, p0

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    const/16 v2, 0x4d

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\u2026"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method private startInternal()V
    .locals 4

    .line 608
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->session:Lcom/tzibbur/basic/store/TzbSession;

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 616
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 617
    return-void

    .line 625
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbApplyGate;->holding(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 626
    return-void

    .line 628
    :cond_2
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    .line 629
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->wsDisabled:Z

    .line 630
    iput v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->wsAttempts:I

    .line 631
    iput v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendAttempts:I

    .line 632
    const-wide/16 v2, 0x0

    iput-wide v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->sendBlockedUntilMs:J

    .line 633
    iput-boolean v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->initialRefreshDone:Z

    .line 634
    iput v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->reconnectFloorSeconds:I

    .line 635
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->setState(I)V

    .line 636
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->registerNetworkCallback()V

    .line 637
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->connectSocket()V

    .line 640
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->startPollingInternal()V

    .line 641
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->drainOutbox()V

    .line 642
    return-void

    .line 609
    :cond_3
    :goto_0
    return-void
.end method

.method private startPollingInternal()V
    .locals 1

    .line 757
    iget-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollingActive:Z

    if-eqz v0, :cond_0

    .line 758
    return-void

    .line 760
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollingActive:Z

    .line 761
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->removeCb(Ljava/lang/Runnable;)V

    .line 762
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 763
    return-void
.end method

.method private stopPollingInternal()V
    .locals 1

    .line 766
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollingActive:Z

    .line 767
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->removeCb(Ljava/lang/Runnable;)V

    .line 768
    return-void
.end method

.method private teardownOnEngine()V
    .locals 1

    .line 645
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->started:Z

    .line 646
    iput-boolean v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->pollingActive:Z

    .line 647
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->unregisterNetworkCallback()V

    .line 648
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->closeSocketQuietly()V

    .line 649
    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->setState(I)V

    .line 650
    return-void
.end method

.method private unregisterNetworkCallback()V
    .locals 3

    .line 595
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->networkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    .line 596
    .local v0, "cb":Landroid/net/ConnectivityManager$NetworkCallback;
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->networkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    .line 597
    if-nez v0, :cond_0

    return-void

    .line 599
    :cond_0
    :try_start_0
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->context:Landroid/content/Context;

    const-string v2, "connectivity"

    .line 600
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/ConnectivityManager;

    .line 601
    .local v1, "cm":Landroid/net/ConnectivityManager;
    if-eqz v1, :cond_1

    invoke-virtual {v1, v0}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V

    .line 604
    .end local v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    :cond_1

    goto :goto_0

    .line 602
    :catchall_0
    move-exception v1

    .line 605
    :goto_0
    return-void
.end method


# virtual methods
# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public addListener(Lcom/tzibbur/basic/sync/TzbSyncListener;)V
    .locals 1
    .param p1, "listener"    # Lcom/tzibbur/basic/sync/TzbSyncListener;

    .line 315
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->addIfAbsent(Ljava/lang/Object;)Z

    .line 316
    return-void
.end method

# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public connectionState()I
    .locals 1

    .line 310
    iget v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->state:I

    return v0
.end method

# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public enqueueSend(Ljava/lang/String;Ljava/lang/String;)V
    .locals 8
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "body"    # Ljava/lang/String;

    .line 253
    new-instance v0, Lcom/tzibbur/basic/store/TzbOutboxItem;

    .line 254
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v1

    .line 255
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v2, p1

    move-object v3, p2

    .end local p1
    .end local p2
    .local v2, "groupId":Ljava/lang/String;
    .local v3, "body":Ljava/lang/String;
    invoke-direct/range {v0 .. v7}, Lcom/tzibbur/basic/store/TzbOutboxItem;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JILjava/lang/String;)V

    .line 256
    .local v0, "item":Lcom/tzibbur/basic/store/TzbOutboxItem;
    nop

    .line 257
    .local p1, "gid":Ljava/lang/String;
    new-instance p2, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;

    invoke-direct {p2, p0, v0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Lcom/tzibbur/basic/store/TzbOutboxItem;Ljava/lang/String;)V

    invoke-direct {p0, p2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    move-result p2

    .line 265
    .local p2, "posted":Z
    if-nez p2, :cond_0

    .line 267
    new-instance v1, Lcom/tzibbur/basic/sync/TzbSyncEngine$10;

    invoke-direct {v1, p0, v0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine$10;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Lcom/tzibbur/basic/store/TzbOutboxItem;Ljava/lang/String;)V

    invoke-static {v1}, Lcom/tzibbur/basic/util/TzbBg;->run(Ljava/lang/Runnable;)V

    .line 275
    :cond_0
    return-void
.end method

# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public markRead(Ljava/lang/String;J)V
    .locals 3
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "seq"    # J

    .line 289
    if-eqz p1, :cond_1

    const-wide/16 v0, 0x0

    cmp-long v0, p2, v0

    if-gtz v0, :cond_0

    goto :goto_0

    .line 295
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->rememberPendingRead(Ljava/lang/String;J)V

    .line 296
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->readFlushRunnable:Ljava/lang/Runnable;

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->removeCb(Ljava/lang/Runnable;)V

    .line 297
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->readFlushRunnable:Ljava/lang/Runnable;

    const-wide/16 v1, 0x12c

    invoke-direct {p0, v0, v1, v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 298
    return-void

    .line 290
    :cond_1
    :goto_0
    return-void
.end method

# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public nudge()V
    .locals 1

    .line 221
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$8;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 248
    return-void
.end method

.method public onClosed(III)V
    .locals 1
    .param p1, "closeCode"    # I
    .param p2, "httpStatus"    # I
    .param p3, "retryAfterSeconds"    # I

    .line 496
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;

    invoke-direct {v0, p0, p2, p1, p3}, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;III)V

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 535
    return-void
.end method

.method public onErrorFrame(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .param p1, "code"    # Ljava/lang/String;
    .param p2, "detail"    # Ljava/lang/String;

    .line 430
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "ws error frame: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "TzbSyncEngine"

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 431
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;

    invoke-direct {v0, p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine$16;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 475
    return-void
.end method

.method public onGroupEvent(Lcom/tzibbur/basic/model/TzbGroupEvent;)V
    .locals 1
    .param p1, "event"    # Lcom/tzibbur/basic/model/TzbGroupEvent;

    .line 382
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$14;

    invoke-direct {v0, p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine$14;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Lcom/tzibbur/basic/model/TzbGroupEvent;)V

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 390
    return-void
.end method

.method public onHello(Ljava/lang/String;Ljava/lang/String;III)V
    .locals 1
    .param p1, "userId"    # Ljava/lang/String;
    .param p2, "deviceId"    # Ljava/lang/String;
    .param p3, "heartbeatSeconds"    # I
    .param p4, "maxConnectionsPerDevice"    # I
    .param p5, "maxFrameBytes"    # I

    .line 328
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 352
    return-void
.end method

.method public onMessages(Ljava/lang/String;Ljava/util/List;Z)V
    .locals 1
    .param p1, "groupId"    # Ljava/lang/String;
    .param p3, "hasMore"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tzibbur/basic/model/TzbMessage;",
            ">;Z)V"
        }
    .end annotation

    .line 372
    .local p2, "messages":Ljava/util/List;, "Ljava/util/List<Lcom/tzibbur/basic/model/TzbMessage;>;"
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$13;

    invoke-direct {v0, p0, p1, p2}, Lcom/tzibbur/basic/sync/TzbSyncEngine$13;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;Ljava/util/List;)V

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 378
    return-void
.end method

.method public onProtocolTooNew(I)V
    .locals 1
    .param p1, "serverVersion"    # I

    .line 479
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;

    invoke-direct {v0, p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)V

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 491
    return-void
.end method

.method public onRead(Ljava/lang/String;J)V
    .locals 1
    .param p1, "groupId"    # Ljava/lang/String;
    .param p2, "readSeq"    # J

    .line 394
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;J)V

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 416
    return-void
.end method

# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public refreshGroups()V
    .locals 1

    .line 279
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$11;

    invoke-direct {v0, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$11;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    invoke-direct {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->post(Ljava/lang/Runnable;)Z

    .line 285
    return-void
.end method

# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public removeListener(Lcom/tzibbur/basic/sync/TzbSyncListener;)V
    .locals 1
    .param p1, "listener"    # Lcom/tzibbur/basic/sync/TzbSyncListener;

    .line 320
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    .line 321
    return-void
.end method

# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public setActiveGroup(Ljava/lang/String;)V
    .locals 0
    .param p1, "groupIdOrNull"    # Ljava/lang/String;

    .line 302
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->activeGroupId:Ljava/lang/String;

    .line 303
    if-eqz p1, :cond_0

    .line 304
    invoke-direct {p0, p1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->cancelNotification(Ljava/lang/String;)V

    .line 306
    :cond_0
    return-void
.end method

# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public start()V
    .locals 2

    .line 192
    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engineHandler()Landroid/os/Handler;

    move-result-object v0

    new-instance v1, Lcom/tzibbur/basic/sync/TzbSyncEngine$6;

    invoke-direct {v1, p0}, Lcom/tzibbur/basic/sync/TzbSyncEngine$6;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 198
    return-void
.end method

# overrides: Lcom/tzibbur/basic/sync/TzbSync;
.method public stop()V
    .locals 3

    .line 203
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->threadLock:Ljava/lang/Object;

    monitor-enter v0

    .line 204
    :try_start_0
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 205
    .local v1, "h":Landroid/os/Handler;
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine;->engine:Landroid/os/Handler;

    .line 206
    monitor-exit v0

    .line 207
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v1, :cond_0

    .line 208
    return-void

    .line 210
    :cond_0
    new-instance v0, Lcom/tzibbur/basic/sync/TzbSyncEngine$7;

    invoke-direct {v0, p0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine$7;-><init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Landroid/os/Handler;)V

    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 217
    return-void

    .line 206
    .end local v1
    :catchall_0
    move-exception v1

    :try_start_1
    monitor-exit v0

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method
