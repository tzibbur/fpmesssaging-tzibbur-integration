.class Lcom/tzibbur/basic/sync/TzbSyncEngine$18;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->onClosed(III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$closeCode:I

.field final synthetic val$httpStatus:I

.field final synthetic val$retryAfterSeconds:I


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;III)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 496
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->val$httpStatus:I

    iput p3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->val$closeCode:I

    iput p4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->val$retryAfterSeconds:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 499
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2102(Lcom/tzibbur/basic/sync/TzbSyncEngine;Z)Z

    .line 500
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1102(Lcom/tzibbur/basic/sync/TzbSyncEngine;Z)Z

    .line 501
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v2, 0x0

    invoke-static {v0, v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1202(Lcom/tzibbur/basic/sync/TzbSyncEngine;Lcom/tzibbur/basic/net/TzbWebSocket;)Lcom/tzibbur/basic/net/TzbWebSocket;

    .line 502
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3600(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 503
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 504
    return-void

    .line 506
    :cond_0
    iget v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->val$httpStatus:I

    const/16 v2, 0x193

    if-ne v0, v2, :cond_1

    .line 510
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 511
    return-void

    .line 513
    :cond_1
    iget v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->val$httpStatus:I

    const/16 v2, 0x191

    if-eq v0, v2, :cond_8

    iget v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->val$closeCode:I

    const/16 v2, 0xfa1

    if-ne v0, v2, :cond_2

    goto :goto_0

    .line 519
    :cond_2
    iget v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->val$retryAfterSeconds:I

    .line 520
    .local v0, "floorSeconds":I
    iget v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->val$closeCode:I

    const/16 v3, 0xfad

    if-eq v2, v3, :cond_3

    iget v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->val$closeCode:I

    const/16 v3, 0xfbd

    if-ne v2, v3, :cond_4

    .line 521
    :cond_3
    const/16 v2, 0x1e

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 524
    :cond_4
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2900(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 525
    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v2, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2902(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)I

    .line 526
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3500(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z

    move-result v1

    if-nez v1, :cond_5

    .line 527
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Ljava/lang/Runnable;

    move-result-object v2

    iget-object v3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v4, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$808(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I

    move-result v4

    invoke-static {v3, v4, v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3100(Lcom/tzibbur/basic/sync/TzbSyncEngine;II)J

    move-result-wide v3

    invoke-static {v1, v2, v3, v4}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3200(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/Runnable;J)Z

    .line 529
    :cond_5
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1500(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 530
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I

    move-result v1

    const/4 v2, 0x2

    if-eq v1, v2, :cond_6

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_7

    .line 531
    :cond_6
    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v2, 0x3

    invoke-static {v1, v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2200(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)V

    .line 533
    :cond_7
    return-void

    .line 516
    .end local v0
    :cond_8
    :goto_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$18;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3800(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 517
    return-void
.end method
