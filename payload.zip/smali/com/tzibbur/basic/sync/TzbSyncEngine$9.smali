.class Lcom/tzibbur/basic/sync/TzbSyncEngine$9;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->enqueueSend(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$gid:Ljava/lang/String;

.field final synthetic val$item:Lcom/tzibbur/basic/store/TzbOutboxItem;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Lcom/tzibbur/basic/store/TzbOutboxItem;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 257
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput-object p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;->val$item:Lcom/tzibbur/basic/store/TzbOutboxItem;

    iput-object p3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;->val$gid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 260
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1900(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;->val$item:Lcom/tzibbur/basic/store/TzbOutboxItem;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbStore;->enqueueOutbox(Lcom/tzibbur/basic/store/TzbOutboxItem;)V

    .line 261
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;->val$gid:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2000(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;)V

    .line 262
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$9;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 263
    return-void
.end method
