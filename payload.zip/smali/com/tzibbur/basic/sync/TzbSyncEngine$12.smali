.class Lcom/tzibbur/basic/sync/TzbSyncEngine$12;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->onHello(Ljava/lang/String;Ljava/lang/String;III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 328
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 331
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 332
    return-void

    .line 334
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2102(Lcom/tzibbur/basic/sync/TzbSyncEngine;Z)Z

    .line 335
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v2, 0x1

    invoke-static {v0, v2}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1102(Lcom/tzibbur/basic/sync/TzbSyncEngine;Z)Z

    .line 336
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$802(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)I

    .line 337
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v1, 0x2

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2200(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)V

    .line 338
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 346
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2400(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 347
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1800(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 348
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$300(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 349
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$12;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$000(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 350
    return-void
.end method
