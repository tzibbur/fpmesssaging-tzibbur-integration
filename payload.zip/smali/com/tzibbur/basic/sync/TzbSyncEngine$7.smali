.class Lcom/tzibbur/basic/sync/TzbSyncEngine$7;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->stop()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$h:Landroid/os/Handler;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Landroid/os/Handler;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 210
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$7;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput-object p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$7;->val$h:Landroid/os/Handler;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 213
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$7;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$600(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 214
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$7;->val$h:Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->quitSafely()V

    .line 215
    return-void
.end method
