.class public Lcom/tzibbur/basic/sync/TzbApplyAlarm;
.super Landroid/content/BroadcastReceiver;
.source "TzbApplyAlarm.java"


# static fields
.field private static final ACTION_CHECK:Ljava/lang/String; = "com.tzibbur.basic.APPLY_STATUS_CHECK"

.field private static final INTERVAL_MS:J = 0x1499700L

.field private static final REQUEST_CODE:I = 0x545a0003


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 28
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method public static cancel(Landroid/content/Context;)V
    .locals 3
    .param p0, "context"    # Landroid/content/Context;

    .line 89
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 90
    .local v0, "app":Landroid/content/Context;
    const-string v1, "alarm"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/AlarmManager;

    .line 91
    .local v1, "am":Landroid/app/AlarmManager;
    if-eqz v1, :cond_0

    .line 92
    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbApplyAlarm;->pending(Landroid/content/Context;)Landroid/app/PendingIntent;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V

    .line 94
    :cond_0
    return-void
.end method

.method private static pending(Landroid/content/Context;)Landroid/app/PendingIntent;
    .locals 3
    .param p0, "app"    # Landroid/content/Context;

    .line 97
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/tzibbur/basic/sync/TzbApplyAlarm;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 98
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "com.tzibbur.basic.APPLY_STATUS_CHECK"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 99
    const v1, 0x545a0003

    const/high16 v2, 0xc000000

    invoke-static {p0, v1, v0, v2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    return-object v1
.end method

.method public static schedule(Landroid/content/Context;)V
    .locals 9
    .param p0, "context"    # Landroid/content/Context;

    .line 72
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 73
    .local v0, "app":Landroid/content/Context;
    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_2

    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbApplyFlag;->required(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 77
    :cond_0
    const-string v1, "alarm"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Landroid/app/AlarmManager;

    .line 78
    .local v2, "am":Landroid/app/AlarmManager;
    if-nez v2, :cond_1

    .line 79
    return-void

    .line 84
    :cond_1
    nop

    .line 85
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    const-wide/32 v5, 0x1499700

    add-long/2addr v3, v5

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbApplyAlarm;->pending(Landroid/content/Context;)Landroid/app/PendingIntent;

    move-result-object v8

    .line 84
    move-wide v4, v3

    const/4 v3, 0x3

    const-wide/32 v6, 0x1499700

    invoke-virtual/range {v2 .. v8}, Landroid/app/AlarmManager;->setInexactRepeating(IJJLandroid/app/PendingIntent;)V

    .line 86
    return-void

    .line 74
    .end local v2
    :cond_2
    :goto_0
    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbApplyAlarm;->cancel(Landroid/content/Context;)V

    .line 75
    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .line 38
    if-eqz p2, :cond_4

    const-string v0, "com.tzibbur.basic.APPLY_STATUS_CHECK"

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 42
    :cond_0
    invoke-static {p1}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 43
    invoke-static {p1}, Lcom/tzibbur/basic/sync/TzbApplyAlarm;->cancel(Landroid/content/Context;)V

    .line 44
    return-void

    .line 46
    :cond_1
    invoke-static {p1}, Lcom/tzibbur/basic/util/TzbApplyFlag;->required(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 48
    invoke-static {p1}, Lcom/tzibbur/basic/sync/TzbApplyAlarm;->cancel(Landroid/content/Context;)V

    .line 49
    return-void

    .line 51
    :cond_2
    invoke-static {p1}, Lcom/tzibbur/basic/core/TzbApplyGate;->recheckDue(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_3

    .line 52
    return-void

    .line 56
    :cond_3
    invoke-virtual {p0}, Lcom/tzibbur/basic/sync/TzbApplyAlarm;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    move-result-object v0

    .line 57
    .local v0, "result":Landroid/content/BroadcastReceiver$PendingResult;
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    .line 58
    .local v1, "app":Landroid/content/Context;
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lcom/tzibbur/basic/sync/TzbApplyAlarm$1;

    invoke-direct {v3, p0, v1, v0}, Lcom/tzibbur/basic/sync/TzbApplyAlarm$1;-><init>(Lcom/tzibbur/basic/sync/TzbApplyAlarm;Landroid/content/Context;Landroid/content/BroadcastReceiver$PendingResult;)V

    const-string v4, "tzb-apply-alarm"

    invoke-direct {v2, v3, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 67
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 68
    return-void

    .line 39
    .end local v0
    .end local v1
    :cond_4
    :goto_0
    return-void
.end method
