.class public Lcom/tzibbur/basic/sync/TzbSyncService;
.super Landroid/app/Service;
.source "TzbSyncService.java"


# static fields
.field public static final CHANNEL_SERVICE:Ljava/lang/String; = "tzb_service_quiet"

.field private static final CHANNEL_SERVICE_OLD:Ljava/lang/String; = "tzb_service"

.field private static final LAUNCH_ACTIVITY:Ljava/lang/String; = "com.tzibbur.basic.ui.TzbLaunchActivity"

.field private static final SERVICE_NOTIFICATION_ID:I = 0x545a0001

.field private static final SERVICE_REQUEST_CODE:I = 0x545a0002


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 23
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method private buildServiceNotification()Landroid/app/Notification;
    .locals 6

    .line 80
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    const/4 v2, 0x1

    if-lt v0, v1, :cond_0

    .line 81
    nop

    .line 82
    const-string v0, "notification"

    invoke-virtual {p0, v0}, Lcom/tzibbur/basic/sync/TzbSyncService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 85
    .local v0, "nm":Landroid/app/NotificationManager;
    new-instance v1, Landroid/app/NotificationChannel;

    sget v3, Lcom/tzibbur/basic/R$string;->tzb_sync_channel_service:I

    .line 86
    invoke-virtual {p0, v3}, Lcom/tzibbur/basic/sync/TzbSyncService;->getString(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, "tzb_service_quiet"

    invoke-direct {v1, v4, v3, v2}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 88
    .local v1, "channel":Landroid/app/NotificationChannel;
    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    .line 89
    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 92
    const-string v3, "tzb_service"

    invoke-virtual {v0, v3}, Landroid/app/NotificationManager;->deleteNotificationChannel(Ljava/lang/String;)V

    .line 93
    new-instance v3, Landroid/app/Notification$Builder;

    invoke-direct {v3, p0, v4}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 94
    .end local v0
    .end local v1
    .local v3, "builder":Landroid/app/Notification$Builder;
    goto :goto_0

    .line 95
    .end local v3
    :cond_0
    new-instance v0, Landroid/app/Notification$Builder;

    invoke-direct {v0, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    move-object v3, v0

    .line 96
    .restart local v3
    const/4 v0, -0x2

    invoke-virtual {v3, v0}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    .line 100
    :goto_0
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 101
    .local v0, "launch":Landroid/content/Intent;
    const-string v1, "com.tzibbur.basic.ui.TzbLaunchActivity"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 102
    const/high16 v1, 0x14000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 103
    const v1, 0x545a0002

    const/high16 v4, 0xc000000

    invoke-static {p0, v1, v0, v4}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    .line 106
    .local v1, "contentIntent":Landroid/app/PendingIntent;
    sget v4, Lcom/tzibbur/basic/R$drawable;->tzb_ic_launcher:I

    invoke-virtual {v3, v4}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v4

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_sync_fallback_title:I

    .line 107
    invoke-virtual {p0, v5}, Lcom/tzibbur/basic/sync/TzbSyncService;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v4

    sget v5, Lcom/tzibbur/basic/R$string;->tzb_sync_service_text:I

    .line 108
    invoke-virtual {p0, v5}, Lcom/tzibbur/basic/sync/TzbSyncService;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v4

    .line 109
    invoke-virtual {v4, v1}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v4

    .line 110
    const-string v5, "service"

    invoke-virtual {v4, v5}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    move-result-object v4

    .line 111
    const/4 v5, -0x1

    invoke-virtual {v4, v5}, Landroid/app/Notification$Builder;->setVisibility(I)Landroid/app/Notification$Builder;

    move-result-object v4

    .line 112
    invoke-virtual {v4, v2}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 113
    invoke-virtual {v2}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v2

    .line 106
    return-object v2
.end method

.method public static ensureRunning(Landroid/content/Context;)V
    .locals 4
    .param p0, "c"    # Landroid/content/Context;

    .line 118
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 119
    .local v0, "app":Landroid/content/Context;
    invoke-static {v0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_2

    invoke-static {v0}, Lcom/tzibbur/basic/core/TzbApplyGate;->holding(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    .line 122
    :cond_0
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/tzibbur/basic/sync/TzbSyncService;

    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 123
    .local v1, "intent":Landroid/content/Intent;
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_1

    .line 124
    invoke-virtual {v0, v1}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    .line 126
    :cond_1
    invoke-virtual {v0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 128
    :goto_0
    return-void

    .line 120
    .end local v1
    :cond_2
    :goto_1
    return-void
.end method

.method public static stop(Landroid/content/Context;)V
    .locals 3
    .param p0, "c"    # Landroid/content/Context;

    .line 131
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 132
    .local v0, "app":Landroid/content/Context;
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/tzibbur/basic/sync/TzbSyncService;

    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v0, v1}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 133
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;

    .line 75
    const/4 v0, 0x0

    return-object v0
.end method

.method public onCreate()V
    .locals 2

    .line 44
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 48
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 49
    invoke-virtual {p0}, Lcom/tzibbur/basic/sync/TzbSyncService;->stopSelf()V

    .line 50
    return-void

    .line 55
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->holding(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 56
    invoke-virtual {p0}, Lcom/tzibbur/basic/sync/TzbSyncService;->stopSelf()V

    .line 57
    return-void

    .line 60
    :cond_1
    const v0, 0x545a0001

    invoke-direct {p0}, Lcom/tzibbur/basic/sync/TzbSyncService;->buildServiceNotification()Landroid/app/Notification;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncService;->startForeground(ILandroid/app/Notification;)V

    .line 61
    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->sync()Lcom/tzibbur/basic/sync/TzbSync;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/sync/TzbSync;->start()V

    .line 62
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .line 66
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {p0}, Lcom/tzibbur/basic/core/TzbApplyGate;->holding(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 70
    :cond_0
    const/4 v0, 0x1

    return v0

    .line 67
    :cond_1
    :goto_0
    invoke-virtual {p0}, Lcom/tzibbur/basic/sync/TzbSyncService;->stopSelf()V

    .line 68
    const/4 v0, 0x2

    return v0
.end method
