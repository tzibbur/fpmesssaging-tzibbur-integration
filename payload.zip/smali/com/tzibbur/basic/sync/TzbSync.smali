.class public interface abstract Lcom/tzibbur/basic/sync/TzbSync;
.super Ljava/lang/Object;
.source "TzbSync.java"


# static fields
.field public static final STATE_CONNECTING:I = 0x1

.field public static final STATE_LIVE:I = 0x2

.field public static final STATE_OFFLINE:I = 0x0

.field public static final STATE_POLLING:I = 0x3


# virtual methods
# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract addListener(Lcom/tzibbur/basic/sync/TzbSyncListener;)V
.end method

# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract connectionState()I
.end method

# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract enqueueSend(Ljava/lang/String;Ljava/lang/String;)V
.end method

# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract markRead(Ljava/lang/String;J)V
.end method

# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract nudge()V
.end method

# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract refreshGroups()V
.end method

# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract removeListener(Lcom/tzibbur/basic/sync/TzbSyncListener;)V
.end method

# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract setActiveGroup(Ljava/lang/String;)V
.end method

# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract start()V
.end method

# implemented-by: Lcom/tzibbur/basic/sync/TzbSyncEngine;
.method public abstract stop()V
.end method
