.class Lcom/tzibbur/basic/sync/TzbSyncEngine$15;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->onRead(Ljava/lang/String;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$groupId:Ljava/lang/String;

.field final synthetic val$readSeq:J


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;J)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 394
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput-object p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->val$groupId:Ljava/lang/String;

    iput-wide p3, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->val$readSeq:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 397
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->val$groupId:Ljava/lang/String;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->val$groupId:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 408
    :cond_0
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1900(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->val$groupId:Ljava/lang/String;

    iget-wide v2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->val$readSeq:J

    invoke-interface {v0, v1, v2, v3}, Lcom/tzibbur/basic/store/TzbStore;->setReadSeq(Ljava/lang/String;J)V

    .line 409
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1900(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Lcom/tzibbur/basic/store/TzbStore;

    move-result-object v0

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->val$groupId:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/tzibbur/basic/store/TzbStore;->unreadCount(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_1

    .line 411
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iget-object v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->val$groupId:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2700(Lcom/tzibbur/basic/sync/TzbSyncEngine;Ljava/lang/String;)V

    .line 413
    :cond_1
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$15;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2800(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 414
    return-void

    .line 398
    :cond_2
    :goto_0
    return-void
.end method
