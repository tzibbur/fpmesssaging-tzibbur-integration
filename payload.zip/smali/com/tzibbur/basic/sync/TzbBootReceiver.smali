.class public Lcom/tzibbur/basic/sync/TzbBootReceiver;
.super Landroid/content/BroadcastReceiver;
.source "TzbBootReceiver.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .line 15
    const-string v0, "android.intent.action.BOOT_COMPLETED"

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 16
    return-void

    .line 18
    :cond_0
    invoke-static {p1}, Lcom/tzibbur/basic/util/TzbKillSwitch;->blocked(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 19
    return-void

    .line 22
    :cond_1
    invoke-static {p1}, Lcom/tzibbur/basic/sync/TzbApplyAlarm;->schedule(Landroid/content/Context;)V

    .line 23
    invoke-static {p1}, Lcom/tzibbur/basic/core/TzbCore;->get(Landroid/content/Context;)Lcom/tzibbur/basic/core/TzbCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tzibbur/basic/core/TzbCore;->session()Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->enrolled()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 25
    invoke-static {p1}, Lcom/tzibbur/basic/sync/TzbSyncService;->ensureRunning(Landroid/content/Context;)V

    .line 27
    :cond_2
    return-void
.end method
