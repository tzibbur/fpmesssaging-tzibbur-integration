.class Lcom/tzibbur/basic/sync/TzbSyncEngine$17;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->onProtocolTooNew(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

.field final synthetic val$serverVersion:I


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 479
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    iput p2, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;->val$serverVersion:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 482
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "ws protocol too new: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;->val$serverVersion:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "; falling back to REST"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "TzbSyncEngine"

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 483
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3502(Lcom/tzibbur/basic/sync/TzbSyncEngine;Z)Z

    .line 484
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3000(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 485
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$700(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 486
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$1500(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V

    .line 487
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$17;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    const/4 v1, 0x3

    invoke-static {v0, v1}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$2200(Lcom/tzibbur/basic/sync/TzbSyncEngine;I)V

    .line 489
    :cond_0
    return-void
.end method
