.class Lcom/tzibbur/basic/sync/TzbSyncEngine$20;
.super Ljava/lang/Object;
.source "TzbSyncEngine.java"

# interfaces
.implements Lcom/tzibbur/basic/net/TzbTokenSupplier;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->connectSocket()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 664
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$20;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public token()Ljava/lang/String;
    .locals 1

    .line 667
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$20;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-static {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->access$3900(Lcom/tzibbur/basic/sync/TzbSyncEngine;)Lcom/tzibbur/basic/store/TzbSession;

    move-result-object v0

    invoke-interface {v0}, Lcom/tzibbur/basic/store/TzbSession;->token()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
