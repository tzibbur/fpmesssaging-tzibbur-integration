.class public interface abstract Lcom/tzibbur/basic/sync/TzbSyncListener;
.super Ljava/lang/Object;
.source "TzbSyncListener.java"


# virtual methods
.method public abstract onCommandResult(Ljava/lang/String;Lcom/tzibbur/basic/model/TzbCommandResult;)V
.end method

.method public abstract onConnectionChanged(I)V
.end method

.method public abstract onDeviceBlocked()V
.end method

.method public abstract onGroupMessagesChanged(Ljava/lang/String;)V
.end method

.method public abstract onGroupsChanged()V
.end method

.method public abstract onSendFailed(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
.end method

.method public abstract onSessionExpired()V
.end method
