.class Lcom/tzibbur/basic/sync/TzbSyncEngine$19;
.super Landroid/net/ConnectivityManager$NetworkCallback;
.source "TzbSyncEngine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tzibbur/basic/sync/TzbSyncEngine;->registerNetworkCallback()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;


# direct methods
.method constructor <init>(Lcom/tzibbur/basic/sync/TzbSyncEngine;)V
    .locals 0
    .param p1, "this$0"    # Lcom/tzibbur/basic/sync/TzbSyncEngine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 581
    iput-object p1, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$19;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-direct {p0}, Landroid/net/ConnectivityManager$NetworkCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onAvailable(Landroid/net/Network;)V
    .locals 1
    .param p1, "network"    # Landroid/net/Network;

    .line 584
    iget-object v0, p0, Lcom/tzibbur/basic/sync/TzbSyncEngine$19;->this$0:Lcom/tzibbur/basic/sync/TzbSyncEngine;

    invoke-virtual {v0}, Lcom/tzibbur/basic/sync/TzbSyncEngine;->nudge()V

    .line 585
    return-void
.end method
