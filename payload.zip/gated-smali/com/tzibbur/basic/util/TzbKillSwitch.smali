.class public final Lcom/tzibbur/basic/util/TzbKillSwitch;
.super Ljava/lang/Object;
.source "TzbKillSwitch.java"


# static fields
.field private static final KEY:Ljava/lang/String; = "not_tag"

.field private static final PREFS_NAME:Ljava/lang/String; = "tzb_config"

.field private static final PREF_KEY:Ljava/lang/String; = "disable_tzibbur"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static blocked(Landroid/content/Context;)Z
    .locals 2

    # tzib unified: property sync
    invoke-static/range {p0 .. p0}, Lcom/android/mms/tzib/TzibGate;->sync(Landroid/content/Context;)Z

    .param p0, "context"    # Landroid/content/Context;

    .line 44
    const/4 v0, 0x0

    if-nez p0, :cond_0

    .line 45
    return v0

    .line 47
    :cond_0
    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->globalBlocked(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_1

    invoke-static {p0}, Lcom/tzibbur/basic/util/TzbKillSwitch;->prefBlocked(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_2

    :cond_1
    const/4 v0, 0x1

    :cond_2
    return v0
.end method

.method private static globalBlocked(Landroid/content/Context;)Z
    .locals 3
    .param p0, "context"    # Landroid/content/Context;

    .line 52
    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "not_tag"

    invoke-static {v1, v2, v0}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    if-ne v1, v2, :cond_0

    move v0, v2

    :cond_0
    return v0

    .line 53
    :catchall_0
    move-exception v1

    .line 55
    .local v1, "ignored":Ljava/lang/Throwable;
    return v0
.end method

.method private static prefBlocked(Landroid/content/Context;)Z
    .locals 4
    .param p0, "context"    # Landroid/content/Context;

    .line 70
    const/4 v0, 0x0

    :try_start_0
    const-string v1, "tzb_config"

    const/4 v2, 0x4

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    .line 72
    .local v1, "prefs":Landroid/content/SharedPreferences;
    invoke-interface {v1}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object v2

    .line 73
    .local v2, "all":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;*>;"
    if-nez v2, :cond_0

    .line 74
    return v0

    .line 76
    :cond_0
    const-string v3, "disable_tzibbur"

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, Lcom/tzibbur/basic/util/TzbKillSwitch;->truthy(Ljava/lang/Object;)Z

    move-result v0

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return v0

    .line 77
    .end local v1
    .end local v2
    :catchall_0
    move-exception v1

    .line 79
    .local v1, "ignored":Ljava/lang/Throwable;
    return v0
.end method

.method private static truthy(Ljava/lang/Object;)Z
    .locals 4
    .param p0, "value"    # Ljava/lang/Object;

    .line 90
    instance-of v0, p0, Ljava/lang/Boolean;

    if-eqz v0, :cond_0

    .line 91
    move-object v0, p0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 93
    :cond_0
    instance-of v0, p0, Ljava/lang/Number;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    .line 94
    move-object v0, p0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    if-ne v0, v2, :cond_1

    move v1, v2

    :cond_1
    return v1

    .line 96
    :cond_2
    instance-of v0, p0, Ljava/lang/String;

    if-eqz v0, :cond_5

    .line 97
    move-object v0, p0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 98
    .local v0, "s":Ljava/lang/String;
    const-string v3, "1"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_3

    const-string v3, "true"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_4

    :cond_3
    move v1, v2

    :cond_4
    return v1

    .line 100
    .end local v0
    :cond_5
    return v1
.end method
