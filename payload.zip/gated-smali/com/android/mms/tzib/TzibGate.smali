.class public final Lcom/android/mms/tzib/TzibGate;
.super Ljava/lang/Object;
.source "TzibGate.java"


# static fields
.field private static final DIALER_ALLOWED:Ljava/lang/String; = "dialer_allowed"

.field private static final DISABLED:Ljava/lang/String; = "disable_tzibbur"

.field private static final OVERRIDE_PREFS:Ljava/lang/String; = "tzib_gate"

.field private static final PREFS:Ljava/lang/String; = "tzb_config"

.field private static final PROPERTY:Ljava/lang/String; = "tzibbur.allow"


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static dialerAllowed(Landroid/content/Context;)Z
    .registers 4

    .line 66
    const/4 v0, 0x0

    :try_start_1
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string v2, "tzib_gate"

    .line 67
    invoke-virtual {p0, v2, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 68
    invoke-interface {p0}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object p0

    const-string v2, "dialer_allowed"

    invoke-interface {p0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    .line 66
    invoke-virtual {v1, p0}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result p0
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1b} :catch_1c

    return p0

    .line 69
    :catch_1c
    move-exception p0

    .line 70
    return v0
.end method

.method static declared-synchronized enableFromDialer(Landroid/content/Context;)Z
    .registers 7

    const-class v0, Lcom/android/mms/tzib/TzibGate;

    monitor-enter v0

    .line 45
    :try_start_3
    invoke-static {p0}, Lcom/android/mms/tzib/TzibGate;->notTag(Landroid/content/Context;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_f

    .line 46
    invoke-static {p0}, Lcom/android/mms/tzib/TzibGate;->sync(Landroid/content/Context;)Z
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_4c

    .line 47
    monitor-exit v0

    return v2

    .line 50
    :cond_f
    :try_start_f
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v3, "tzib_gate"

    .line 51
    invoke-virtual {v1, v3, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    .line 52
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object v4

    const-string v5, "dialer_allowed"

    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v3

    .line 53
    const/4 v4, 0x1

    if-nez v3, :cond_3e

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v5, "dialer_allowed"

    invoke-interface {v1, v5, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v1
    :try_end_3a
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_3a} :catch_49
    .catchall {:try_start_f .. :try_end_3a} :catchall_4c

    if-nez v1, :cond_3e

    .line 54
    monitor-exit v0

    return v2

    .line 58
    :cond_3e
    :try_start_3e
    invoke-static {p0}, Lcom/android/mms/tzib/TzibGate;->sync(Landroid/content/Context;)Z

    move-result p0
    :try_end_42
    .catch Ljava/lang/Exception; {:try_start_3e .. :try_end_42} :catch_49
    .catchall {:try_start_3e .. :try_end_42} :catchall_4c

    if-eqz p0, :cond_47

    if-nez v3, :cond_47

    move v2, v4

    :cond_47
    monitor-exit v0

    return v2

    .line 59
    :catch_49
    move-exception p0

    .line 60
    monitor-exit v0

    return v2

    .line 44
    :catchall_4c
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method private static getProperty(Ljava/lang/String;)Ljava/lang/String;
    .registers 9

    .line 86
    const-string v0, ""

    :try_start_2
    const-string v1, "android.os.SystemProperties"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    .line 87
    const-string v2, "get"

    const/4 v3, 0x2

    new-array v4, v3, [Ljava/lang/Class;

    const-class v5, Ljava/lang/String;

    const/4 v6, 0x0

    aput-object v5, v4, v6

    const-class v5, Ljava/lang/String;

    const/4 v7, 0x1

    aput-object v5, v4, v7

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 88
    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v6

    aput-object v0, v2, v7

    const/4 p0, 0x0

    invoke-virtual {v1, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    .line 89
    instance-of v1, p0, Ljava/lang/String;

    if-eqz v1, :cond_2d

    check-cast p0, Ljava/lang/String;
    :try_end_2c
    .catchall {:try_start_2 .. :try_end_2c} :catchall_2e

    move-object v0, p0

    :cond_2d
    return-object v0

    .line 90
    :catchall_2e
    move-exception p0

    .line 91
    return-object v0
.end method

.method private static notTag(Landroid/content/Context;)Z
    .registers 4

    .line 75
    const/4 v0, 0x1

    if-nez p0, :cond_4

    return v0

    .line 77
    :cond_4
    :try_start_4
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string v1, "not_tag"

    const/4 v2, 0x0

    invoke-static {p0, v1, v2}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result p0
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_f} :catch_14

    if-ne p0, v0, :cond_12

    goto :goto_13

    :cond_12
    move v0, v2

    :goto_13
    return v0

    .line 78
    :catch_14
    move-exception p0

    .line 80
    return v0
.end method

.method public static sync(Landroid/content/Context;)Z
    .registers 6

    .line 23
    const-string v0, "disable_tzibbur"

    invoke-static {p0}, Lcom/android/mms/tzib/TzibMetadata;->init(Landroid/content/Context;)V

    .line 24
    invoke-static {p0}, Lcom/android/mms/tzib/TzibDeletedMessages;->init(Landroid/content/Context;)V

    .line 25
    invoke-static {p0}, Lcom/android/mms/tzib/TzibGate;->notTag(Landroid/content/Context;)Z

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v1, :cond_26

    .line 26
    const-string v1, "tzibbur.allow"

    invoke-static {v1}, Lcom/android/mms/tzib/TzibGate;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v4, "1"

    invoke-virtual {v4, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_24

    invoke-static {p0}, Lcom/android/mms/tzib/TzibGate;->dialerAllowed(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_26

    :cond_24
    move v1, v2

    goto :goto_27

    :cond_26
    move v1, v3

    .line 27
    :goto_27
    if-eqz p0, :cond_58

    .line 29
    :try_start_29
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string v4, "tzb_config"

    .line 30
    invoke-virtual {p0, v4, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 31
    invoke-interface {p0}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object v4

    invoke-interface {v4, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 32
    if-nez v1, :cond_3e

    goto :goto_3f

    :cond_3e
    move v2, v3

    .line 33
    :goto_3f
    instance-of v3, v4, Ljava/lang/Boolean;

    if-eqz v3, :cond_4b

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eq v3, v2, :cond_56

    .line 34
    :cond_4b
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v0, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_56
    .catchall {:try_start_29 .. :try_end_56} :catchall_57

    .line 38
    :cond_56
    goto :goto_58

    .line 36
    :catchall_57
    move-exception p0

    .line 40
    :cond_58
    :goto_58
    return v1
.end method
